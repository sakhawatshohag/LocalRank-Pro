"""Database access.  All tenant queries run inside ``tenant_tx`` so PostgreSQL
Row Level Security scopes them to one organization."""
from __future__ import annotations

from contextlib import contextmanager
from functools import lru_cache
from typing import Iterator

from sqlalchemy import create_engine, text
from sqlalchemy.engine import Connection, Engine

from app.config import get_settings


@lru_cache
def get_engine() -> Engine:
    return create_engine(get_settings().database_url, pool_pre_ping=True, pool_size=10, max_overflow=10)


@contextmanager
def system_tx() -> Iterator[Connection]:
    """Transaction WITHOUT tenant context: identity tables only (users, organizations, members)."""
    with get_engine().begin() as conn:
        yield conn


@contextmanager
def tenant_tx(org_id: str) -> Iterator[Connection]:
    with get_engine().begin() as conn:
        # is_local=true: the setting dies with the transaction, so pooled
        # connections can never leak one tenant's context to another request.
        conn.execute(text("SELECT set_config('app.current_org', :org, true)"), {"org": str(org_id)})
        yield conn
