"""Executes one GeoGrid scan against a ranking provider (no database access).

The persistence layer stores what this returns:
* one row per grid point (outcome status, provider metadata, cost)
* one ranking row per (grid point, subject)
"""
from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal
from typing import Callable, Optional, Sequence

from app.engine.analytics import PointResult, ScanMetrics, compute_scan_metrics
from app.engine.geogrid import GridPoint
from app.providers.base import PointOutcome, RankingProvider, SearchConfig, Subject, resolve_subject


@dataclass(frozen=True)
class ScanResult:
    outcomes: dict[int, PointOutcome]                 # point_index -> raw outcome
    rankings: dict[str, list[PointResult]]            # subject.key -> per-point results
    metrics: dict[str, ScanMetrics]                   # subject.key -> derived metrics
    actual_cost: Decimal
    failed_points: int
    is_demo: bool


def execute_scan(
    provider: RankingProvider,
    points: Sequence[GridPoint],
    config: SearchConfig,
    subjects: Sequence[Subject],
    *,
    scan_id: Optional[str] = None,
    on_progress: Optional[Callable[[int, int], None]] = None,
) -> ScanResult:
    if not subjects:
        raise ValueError("a scan needs at least one subject (the tracked business)")
    if len({s.key for s in subjects}) != len(subjects):
        raise ValueError("duplicate subject keys")
    outcomes: dict[int, PointOutcome] = {}
    rankings: dict[str, list[PointResult]] = {s.key: [] for s in subjects}
    cost = Decimal(0)
    for n, point in enumerate(points, start=1):
        tag = f"{scan_id}:{point.index}" if scan_id else None
        try:
            outcome = provider.fetch_point(point.lat, point.lng, config, tag)
        except Exception as exc:  # a provider bug must not abort the scan or invent data
            outcome = PointOutcome(False, depth_requested=config.depth, error_code="provider_exception",
                                   error_message=str(exc)[:300])
        outcomes[point.index] = outcome
        if outcome.cost:
            cost += outcome.cost
        # every subject is resolved from the SAME response for this coordinate
        for s in subjects:
            rankings[s.key].append(resolve_subject(outcome, s, point.index))
        if on_progress:
            on_progress(n, len(points))
    return ScanResult(
        outcomes=outcomes,
        rankings=rankings,
        metrics={k: compute_scan_metrics(v, config.depth) for k, v in rankings.items()},
        actual_cost=cost,
        failed_points=sum(1 for o in outcomes.values() if not o.ok),
        is_demo=provider.is_demo,
    )
