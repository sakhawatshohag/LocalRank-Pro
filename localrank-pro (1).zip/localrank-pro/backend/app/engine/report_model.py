"""Report content model and the deterministic text derived from it (pure, no I/O).

Everything a report says is computed from stored scan data.  The executive summary and the
"observations" are rule-based statements of fact; recommendations are written by the user and
printed as given.  Nothing is generated or estimated.
"""
from __future__ import annotations

import calendar
from dataclasses import dataclass, field
from datetime import date, datetime, timedelta
from typing import Optional

from app.engine.alerts import detect_change

TYPE_TITLES = {
    "weekly": "Weekly Ranking Report", "monthly": "Monthly Ranking Report",
    "geogrid_comparison": "GeoGrid Comparison Report", "competitor_comparison": "Competitor Comparison Report",
    "performance": "Local SEO Performance Report", "custom": "Ranking Report",
}


@dataclass(frozen=True)
class Branding:
    agency_name: Optional[str] = None
    website: Optional[str] = None
    email: Optional[str] = None
    phone: Optional[str] = None
    primary_color: str = "#0b1f3a"
    footer_text: Optional[str] = None
    logo_png: Optional[bytes] = None
    white_label: bool = False


@dataclass(frozen=True)
class PointView:
    index: int
    row: int
    col: int
    lat: float
    lng: float
    status: str                      # ranked | not_found | error
    position: Optional[int] = None


@dataclass(frozen=True)
class ScanRef:
    id: str
    completed_at: datetime
    status: str
    valid_points: int
    total_points: int


@dataclass
class BusinessRow:
    name: str
    is_mine: bool
    previous: Optional[dict]         # historical_metrics of the previous scan (None = no comparable scan)
    current: Optional[dict]
    current_points: list[PointView] = field(default_factory=list)


@dataclass
class KeywordSection:
    campaign_name: str
    location_name: str
    keyword: str
    grid_size: int
    spacing_m: float
    depth: int
    current: ScanRef
    previous: Optional[ScanRef]
    current_points: list[PointView]
    previous_points: list[PointView]
    change_counts: Optional[dict] = None
    comparable_points: Optional[int] = None
    average_delta: Optional[float] = None
    businesses: list[BusinessRow] = field(default_factory=list)
    history: list[dict] = field(default_factory=list)   # {date, average_position, top3_coverage, top10_coverage, valid_points, total_points}
    is_demo: bool = False


@dataclass
class ReportModel:
    title: str
    report_type: str
    client_name: str
    period_start: date
    period_end: date
    generated_at: datetime
    branding: Branding
    sections: list[KeywordSection]
    client_logo_png: Optional[bytes] = None
    recommendations: Optional[str] = None
    without_data: list[str] = field(default_factory=list)   # "campaign · keyword" with no finished scan in the period
    data_source: str = ""
    include_competitors: bool = True
    include_history: bool = True

    @property
    def is_demo(self) -> bool:
        return any(s.is_demo for s in self.sections)


# ------------------------------------------------------------------ periods
def report_period(report_type: str, run_day: date) -> tuple[date, date]:
    """Period covered by a scheduled report generated on ``run_day``:
    weekly = the 7 days ending yesterday; monthly = the previous calendar month."""
    if report_type == "weekly":
        end = run_day - timedelta(days=1)
        return end - timedelta(days=6), end
    if report_type == "monthly":
        last = run_day.replace(day=1) - timedelta(days=1)
        return last.replace(day=1), last
    raise ValueError("only weekly and monthly reports are scheduled")


def month_end(d: date) -> date:
    return d.replace(day=calendar.monthrange(d.year, d.month)[1])


# ------------------------------------------------------------------ derived text
def fmt(v: Optional[float], suffix: str = "") -> str:
    if v is None:
        return "—"
    v = float(v)
    return f"{v:.0f}{suffix}" if v == int(v) else f"{v:.1f}{suffix}"


def quadrant_weakness(points: list[PointView], size: int) -> Optional[str]:
    """Area of the grid with the lowest Top 10 share, if it is clearly weaker than the rest.

    The grid is split into four quadrants around the centre row/column (centre lines excluded).
    Returned only for grids of 5x5 or larger and when the weakest quadrant's share is at least
    25 percentage points below the grid as a whole.
    """
    if size < 5:
        return None
    mid = size // 2
    names = {(True, True): "north-west", (True, False): "north-east", (False, True): "south-west", (False, False): "south-east"}
    buckets: dict[str, list[PointView]] = {n: [] for n in names.values()}
    valid = [p for p in points if p.status != "error"]
    for p in valid:
        if p.row == mid or p.col == mid:
            continue
        buckets[names[(p.row < mid, p.col < mid)]].append(p)
    top10 = lambda ps: sum(1 for p in ps if p.status == "ranked" and p.position <= 10)  # noqa: E731
    if not valid:
        return None
    overall = top10(valid) / len(valid)
    scored = [(top10(ps) / len(ps), name, top10(ps), len(ps)) for name, ps in buckets.items() if len(ps) >= 2]
    if not scored:
        return None
    share, name, hits, n = min(scored)
    if overall - share < 0.25:
        return None
    return f"Weakest area: the {name} of the grid (Top 10 at {hits} of {n} points, versus {round(100 * overall)}% across the grid)."


def section_observations(s: KeywordSection) -> list[str]:
    out: list[str] = []
    mine = next((b for b in s.businesses if b.is_mine), None)
    cur = mine.current if mine else None
    if cur and cur.get("valid_points"):
        out.append(f"Top 3 at {cur['top3_count']} of {cur['valid_points']} valid points ({fmt(cur.get('top3_coverage'), '%')}); "
                   f"Top 10 at {cur['top10_count']} ({fmt(cur.get('top10_coverage'), '%')}).")
        if cur.get("not_found_points"):
            out.append(f"Not within the first {s.depth} results at {cur['not_found_points']} points.")
    elif cur is not None:
        out.append("The latest scan returned no usable data for this business.")
    if s.change_counts and s.comparable_points:
        c = s.change_counts
        out.append(f"Compared with the previous scan ({s.comparable_points} comparable points): improved at {c.get('improved', 0)}, "
                   f"declined at {c.get('declined', 0)}, unchanged at {c.get('unchanged', 0)}, newly found at {c.get('newly_found', 0)}, "
                   f"lost at {c.get('lost_visibility', 0)}.")
    weak = quadrant_weakness(s.current_points, s.grid_size)
    if weak:
        out.append(weak)
    rivals = [b for b in s.businesses if not b.is_mine and b.current and b.current.get("valid_points")]
    if rivals and cur and cur.get("valid_points"):
        best = max(rivals, key=lambda b: (b.current["top3_count"], -(b.current.get("average_position") or 1e9)))
        if best.current["top3_count"] > cur["top3_count"]:
            out.append(f"{best.name} is in the Top 3 at {best.current['top3_count']} points, versus {cur['top3_count']} for you.")
        else:
            out.append(f"You are in the Top 3 at more points than any tracked competitor (best: {best.name} at {best.current['top3_count']}).")
    if s.current.valid_points < s.current.total_points:
        out.append(f"{s.current.total_points - s.current.valid_points} of {s.current.total_points} points returned no data in the latest scan and are excluded.")
    return out


def executive_summary(model: ReportModel) -> list[str]:
    tracked = len(model.sections)
    if tracked == 0:
        return ["No finished scans fall within this reporting period, so there are no rankings to report."]
    improved = declined = steady = no_baseline = 0
    for s in model.sections:
        mine = next((b for b in s.businesses if b.is_mine), None)
        if not mine or mine.previous is None:
            no_baseline += 1
            continue
        change = detect_change(mine.previous, mine.current)
        if change is None:
            steady += 1
        elif change.direction == "improved":
            improved += 1
        else:
            declined += 1
    lines = [f"{tracked} keyword{'s' if tracked != 1 else ''} with ranking data in this period."]
    compared = tracked - no_baseline
    if compared:
        lines.append(f"Of {compared} compared with an earlier scan: {improved} improved significantly, {declined} declined significantly, "
                     f"{steady} without a significant change.")
    if no_baseline:
        lines.append(f"{no_baseline} keyword{'s have' if no_baseline != 1 else ' has'} no earlier comparable scan yet, so no change is shown.")
    covs = [b.current["top3_coverage"] for s in model.sections for b in s.businesses
            if b.is_mine and b.current and b.current.get("top3_coverage") is not None]
    if covs:
        lines.append(f"Average Top 3 coverage across keywords in the latest scans: {fmt(sum(float(c) for c in covs) / len(covs), '%')}.")
    if model.without_data:
        lines.append(f"{len(model.without_data)} tracked keyword{'s' if len(model.without_data) != 1 else ''} had no finished scan in this period.")
    lines.append("A significant change means the average position moved by 3 or more, or Top 10 coverage moved by 15 or more percentage points.")
    return lines
