"""Recurring scan schedule maths (pure, no I/O).

Rules (documented business logic)
---------------------------------
* A schedule runs at ``local_time`` in the business location's IANA time zone.
* Interval frequencies (daily, every 2 days, weekly, biweekly, custom N days) count whole local
  days from an ``anchor`` date, so "every 2 days" stays on the same rhythm and "weekly" stays on
  the anchor's weekday.
* Monthly runs on the anchor's day of the month, clamped to the month's last day
  (anchor 31 Jan -> 28/29 Feb -> 31 Mar).
* Daylight-saving edges: a local time that does not exist (spring forward) runs at the same
  wall-clock time with the pre-transition offset, i.e. one hour later in local terms (02:30 ->
  03:30); an ambiguous time (fall back) runs at its first occurrence.
* The occurrence key is the local calendar date of the run.  Together with the unique
  idempotency key on scans it guarantees one scan per keyword per occurrence.
* Missed occurrences (e.g. while workers were down) are not back-filled: after a run the next
  occurrence is the first one strictly after "now".
"""
from __future__ import annotations

import calendar
from datetime import date, datetime, time, timedelta, timezone
from typing import Optional
from zoneinfo import ZoneInfo

INTERVAL_DAYS = {"daily": 1, "every_2_days": 2, "weekly": 7, "biweekly": 14}
FREQUENCIES = (*INTERVAL_DAYS, "monthly", "custom")
MAX_CUSTOM_DAYS = 90
AVG_DAYS_PER_MONTH = 30.44


class ScheduleError(ValueError):
    pass


def interval_for(frequency: str, interval_days: Optional[int]) -> Optional[int]:
    """Days between runs; None for monthly."""
    if frequency not in FREQUENCIES:
        raise ScheduleError(f"unknown frequency '{frequency}'")
    if frequency == "custom":
        if not isinstance(interval_days, int) or not 1 <= interval_days <= MAX_CUSTOM_DAYS:
            raise ScheduleError(f"custom schedules need interval_days between 1 and {MAX_CUSTOM_DAYS}")
        return interval_days
    if interval_days is not None:
        raise ScheduleError("interval_days is only used with the custom frequency")
    return None if frequency == "monthly" else INTERVAL_DAYS[frequency]


def localize(day: date, at: time, tz: ZoneInfo) -> datetime:
    """Local wall-clock time -> aware UTC datetime, with the DST rules above."""
    return datetime.combine(day, at).replace(tzinfo=tz, fold=0).astimezone(timezone.utc)


def _add_months(day: date, months: int, anchor_day: int) -> date:
    m = day.month - 1 + months
    y, m = day.year + m // 12, m % 12 + 1
    return date(y, m, min(anchor_day, calendar.monthrange(y, m)[1]))


def next_run(frequency: str, local_time: time, tz_name: str, anchor: date, after: datetime,
             interval_days: Optional[int] = None) -> datetime:
    """First occurrence strictly after ``after`` (aware).  Returns an aware UTC datetime."""
    if after.tzinfo is None:
        raise ScheduleError("'after' must be timezone-aware")
    try:
        tz = ZoneInfo(tz_name)
    except Exception as exc:  # ZoneInfoNotFoundError, ValueError
        raise ScheduleError(f"unknown time zone '{tz_name}'") from exc
    step = interval_for(frequency, interval_days)
    local_after = after.astimezone(tz).date()
    if step is not None:
        k = max(0, (local_after - anchor).days // step)
        day = anchor + timedelta(days=k * step)
        while True:
            run = localize(day, local_time, tz)
            if run > after:
                return run
            day += timedelta(days=step)
    # monthly
    months = max(0, (local_after.year - anchor.year) * 12 + local_after.month - anchor.month - 1)
    while True:
        day = _add_months(anchor, months, anchor.day)
        run = localize(day, local_time, tz)
        if run > after:
            return run
        months += 1


def occurrence_key(run_at: datetime, tz_name: str) -> str:
    return run_at.astimezone(ZoneInfo(tz_name)).date().isoformat()


def runs_per_month(frequency: str, interval_days: Optional[int] = None) -> float:
    step = interval_for(frequency, interval_days)
    return 1.0 if step is None else round(AVG_DAYS_PER_MONTH / step, 2)
