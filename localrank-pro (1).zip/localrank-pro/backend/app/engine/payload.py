"""Serialises a finished scan into the JSON payload accepted by the SQL function
``store_scan_result`` (migration 0003).  Pure function, no I/O."""
from __future__ import annotations

from dataclasses import asdict
from typing import Any, Sequence

from app.engine.geogrid import GridPoint
from app.engine.scan_runner import ScanResult

MAX_STORED_LISTINGS = 20  # listings kept per grid point for competitor discovery


def split_subject_key(key: str) -> tuple[str, str]:
    kind, _, ident = key.partition(":")
    if kind not in ("location", "competitor") or not ident:
        raise ValueError(f"invalid subject key: {key!r}")
    return kind, ident


def scan_result_to_payload(points: Sequence[GridPoint], result: ScanResult, grid_signature: str) -> dict[str, Any]:
    by_index = {p.index: p for p in points}
    if set(by_index) != set(result.outcomes):
        raise ValueError("scan result does not cover exactly the grid points of the scan")
    pts = []
    for idx in sorted(by_index):
        p, o = by_index[idx], result.outcomes[idx]
        pts.append({
            "index": p.index, "row": p.row, "col": p.col, "lat": p.lat, "lng": p.lng,
            "ok": o.ok,
            "task_id": o.provider_task_id,
            "check_url": o.check_url,
            "cost": str(o.cost) if o.cost is not None else None,
            "error_code": None if o.ok else (o.error_code or "unknown"),
            "error_message": None if o.ok else o.error_message,
            "meta": o.meta or None,
            "listings": [
                {"position": l.position, "title": l.title, "place_id": l.place_id, "cid": l.cid,
                 "rating": l.rating, "reviews": l.reviews, "category": l.category}
                for l in o.listings[:MAX_STORED_LISTINGS]
            ] if o.ok else None,
        })
    rankings, metrics = [], []
    for key, rows in result.rankings.items():
        kind, ident = split_subject_key(key)
        for r in rows:
            rankings.append({"subject_type": kind, "subject_id": ident, "point_index": r.point_index,
                             "status": r.status.value, "position": r.position})
        m = asdict(result.metrics[key])
        m.pop("depth")
        metrics.append({"subject_type": kind, "subject_id": ident, **m})
    return {"is_demo": result.is_demo, "grid_signature": grid_signature, "points": pts,
            "rankings": rankings, "metrics": metrics}
