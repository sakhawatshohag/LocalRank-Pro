"""GeoGrid coordinate generation.

Methodology (documented business logic)
---------------------------------------
* The grid is a square of ``size x size`` points centred on ``(center_lat, center_lng)``.
* ``spacing_m`` is the distance in metres between neighbouring points, both
  north-south and east-west.  "Radius" is the distance from the centre to the
  middle of an edge:  ``radius = spacing * (size - 1) / 2``.
* Row 0 is the northern-most row, column 0 the western-most column.
  ``index = row * size + col`` is the stable Point ID used to compare scans.
* Offsets use a spherical-earth model (mean radius 6,371,008.8 m).  For the
  distances used in local rank tracking (< 100 km) the error is far below the
  resolution at which a search engine localises a query.
* Coordinates are rounded to 7 decimal places (~1 cm), which is also the
  maximum precision DataForSEO accepts in ``location_coordinate``.
"""
from __future__ import annotations

import hashlib
import math
from dataclasses import dataclass

EARTH_RADIUS_M = 6_371_008.8
COORD_DECIMALS = 7
STANDARD_SIZES = (3, 5, 7, 9, 11, 13, 15)
MAX_CUSTOM_SIZE = 21
MIN_SPACING_M = 50.0
MAX_ABS_LAT = 85.0


class GridError(ValueError):
    """Raised for an invalid grid configuration."""


@dataclass(frozen=True)
class GridPoint:
    index: int
    row: int
    col: int
    lat: float
    lng: float


def spacing_from_radius(radius_m: float, size: int) -> float:
    if size < 2:
        raise GridError("size must be at least 2")
    return 2.0 * radius_m / (size - 1)


def radius_from_spacing(spacing_m: float, size: int) -> float:
    return spacing_m * (size - 1) / 2.0


def _normalize_lng(lng: float) -> float:
    return (lng + 180.0) % 360.0 - 180.0


def generate_grid(
    center_lat: float,
    center_lng: float,
    size: int,
    spacing_m: float,
    *,
    max_size: int = MAX_CUSTOM_SIZE,
) -> list[GridPoint]:
    """Return ``size * size`` unique points ordered row-major from the NW corner."""
    if not isinstance(size, int) or size < 1 or size > max_size:
        raise GridError(f"size must be an integer between 1 and {max_size}")
    if size % 2 == 0:
        raise GridError("size must be odd so the grid has a centre point")
    if not (-MAX_ABS_LAT <= center_lat <= MAX_ABS_LAT):
        raise GridError(f"center latitude must be within +/-{MAX_ABS_LAT}")
    if not (-180.0 <= center_lng <= 180.0):
        raise GridError("center longitude must be within +/-180")
    if size > 1 and spacing_m < MIN_SPACING_M:
        raise GridError(f"spacing must be at least {MIN_SPACING_M} m")

    half = (size - 1) / 2.0
    points: list[GridPoint] = []
    seen: set[tuple[float, float]] = set()
    for row in range(size):
        dy = (half - row) * spacing_m  # positive = north
        lat = center_lat + math.degrees(dy / EARTH_RADIUS_M)
        if abs(lat) > MAX_ABS_LAT:
            raise GridError("grid extends beyond the supported latitude range")
        metres_per_radian_lng = EARTH_RADIUS_M * math.cos(math.radians(lat))
        for col in range(size):
            dx = (col - half) * spacing_m  # positive = east
            lng = _normalize_lng(center_lng + math.degrees(dx / metres_per_radian_lng))
            key = (round(lat, COORD_DECIMALS), round(lng, COORD_DECIMALS))
            if key in seen:  # cannot happen with MIN_SPACING_M, but never emit duplicates
                raise GridError("grid produced duplicate coordinates")
            seen.add(key)
            points.append(GridPoint(row * size + col, row, col, key[0], key[1]))
    return points


def grid_signature(center_lat: float, center_lng: float, size: int, spacing_m: float) -> str:
    """Stable identifier of a grid geometry.

    Two scans are point-by-point comparable only when their signatures match.
    """
    raw = f"{center_lat:.{COORD_DECIMALS}f}|{center_lng:.{COORD_DECIMALS}f}|{size}|{float(spacing_m):.2f}"
    return hashlib.sha256(raw.encode()).hexdigest()[:32]


def haversine_m(lat1: float, lng1: float, lat2: float, lng2: float) -> float:
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dp, dl = p2 - p1, math.radians(lng2 - lng1)
    a = math.sin(dp / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return 2 * EARTH_RADIUS_M * math.asin(math.sqrt(a))
