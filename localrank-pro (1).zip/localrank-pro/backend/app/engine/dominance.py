"""Competitor comparison at matching coordinates.

Methodology (shown to users)
----------------------------
Every business in a scan is read from the SAME search response at each grid point, so positions
at one point are directly comparable.  For each point the tracked business is compared with the
best-placed competitor there:

* no_data     - the point failed (API error); nothing is inferred.
* all_weak    - neither the business nor any competitor is within the first ``weak_after``
                positions (default 20), including the case where none was found.
* similar     - both are placed and their positions differ by at most ``tolerance`` (default 2).
* mine        - the tracked business is ahead by more than ``tolerance``, or it is found and no
                competitor is.
* competitor  - a competitor is ahead by more than ``tolerance``, or one is found and the tracked
                business is not.

A not-found business has no numeric position; it is treated only as "behind any found business".
"""
from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Mapping, Optional, Sequence

from app.engine.analytics import PointResult, ResultStatus


class Dominance(str, Enum):
    MINE = "mine"
    COMPETITOR = "competitor"
    SIMILAR = "similar"
    ALL_WEAK = "all_weak"
    NO_DATA = "no_data"


@dataclass(frozen=True)
class PointDominance:
    point_index: int
    dominance: Dominance
    my_position: Optional[int]
    leader_key: Optional[str]        # best-placed competitor at this point, if any was found
    leader_position: Optional[int]


@dataclass(frozen=True)
class DominanceSummary:
    points: list[PointDominance]
    counts: dict[str, int]
    valid_points: int


def compare_businesses(
    mine: Sequence[PointResult],
    competitors: Mapping[str, Sequence[PointResult]],
    *,
    tolerance: int = 2,
    weak_after: int = 20,
) -> DominanceSummary:
    if not competitors:
        raise ValueError("at least one competitor is required for a comparison")
    if tolerance < 0 or weak_after < 1:
        raise ValueError("tolerance must be >= 0 and weak_after >= 1")
    by_comp = {k: {r.point_index: r for r in rows} for k, rows in competitors.items()}
    out: list[PointDominance] = []
    for me in sorted(mine, key=lambda r: r.point_index):
        idx = me.point_index
        others = {k: rows.get(idx) for k, rows in by_comp.items()}
        # same response for everyone: if my result is an error, or any competitor row is missing or
        # an error, the point has no trustworthy comparison
        if me.status is ResultStatus.ERROR or any(o is None or o.status is ResultStatus.ERROR for o in others.values()):
            out.append(PointDominance(idx, Dominance.NO_DATA, None, None, None))
            continue
        ranked = [(o.position, k) for k, o in others.items() if o.status is ResultStatus.RANKED]
        best_pos, best_key = min(ranked) if ranked else (None, None)
        my_pos = me.position
        my_weak = my_pos is None or my_pos > weak_after
        comp_weak = best_pos is None or best_pos > weak_after
        if my_weak and comp_weak:
            kind = Dominance.ALL_WEAK
        elif my_pos is None:
            kind = Dominance.COMPETITOR
        elif best_pos is None:
            kind = Dominance.MINE
        elif abs(best_pos - my_pos) <= tolerance:
            kind = Dominance.SIMILAR
        else:
            kind = Dominance.MINE if my_pos < best_pos else Dominance.COMPETITOR
        out.append(PointDominance(idx, kind, my_pos, best_key, best_pos))
    counts = {d.value: 0 for d in Dominance}
    for p in out:
        counts[p.dominance.value] += 1
    return DominanceSummary(out, counts, len(out) - counts[Dominance.NO_DATA.value])
