"""Significant ranking-change detection between two comparable scans (pure).

Defaults (documented, adjustable per call):
* average position moves by 3 or more positions, or
* Top 10 coverage moves by 15 or more percentage points.
A decline signal takes precedence over an improvement signal in the same scan, so a business
that ranks higher on fewer points is reported as a decline.  Metrics that are missing (no valid
points) never produce an alert.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Mapping, Optional

Metrics = Mapping[str, Optional[float]]


@dataclass(frozen=True)
class Thresholds:
    average_position: float = 3.0
    top10_points: float = 15.0


@dataclass(frozen=True)
class Change:
    direction: str                      # "improved" | "declined"
    reasons: list[str] = field(default_factory=list)
    data: dict = field(default_factory=dict)


def _num(m: Optional[Metrics], k: str) -> Optional[float]:
    v = m.get(k) if m else None
    return float(v) if v is not None else None


def detect_change(previous: Optional[Metrics], current: Optional[Metrics], t: Thresholds = Thresholds()) -> Optional[Change]:
    if not previous or not current:
        return None
    better, worse, data = [], [], {}
    pa, ca = _num(previous, "average_position"), _num(current, "average_position")
    if pa is not None and ca is not None:
        d = round(pa - ca, 2)                  # positive = moved up
        data["average_position"] = {"previous": pa, "current": ca, "delta": d}
        if d >= t.average_position:
            better.append(f"average position {pa:g} → {ca:g}")
        elif d <= -t.average_position:
            worse.append(f"average position {pa:g} → {ca:g}")
    pt, ct = _num(previous, "top10_coverage"), _num(current, "top10_coverage")
    if pt is not None and ct is not None:
        d = round(ct - pt, 2)
        data["top10_coverage"] = {"previous": pt, "current": ct, "delta": d}
        if d >= t.top10_points:
            better.append(f"Top 10 coverage {pt:g}% → {ct:g}%")
        elif d <= -t.top10_points:
            worse.append(f"Top 10 coverage {pt:g}% → {ct:g}%")
    if worse:
        return Change("declined", worse, data)
    if better:
        return Change("improved", better, data)
    return None
