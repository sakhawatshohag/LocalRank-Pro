"""Ranking analytics for a single scan and for scan-to-scan comparison.

Calculation methodology (shown to users in tooltips)
----------------------------------------------------
Every grid point for a business has exactly one of three statuses:

* RANKED     - the business was found; ``position`` is its 1-based rank.
* NOT_FOUND  - the provider answered successfully, but the business was not in
               the first ``depth`` results.  It is NOT position 0 and has no
               numeric position.
* ERROR      - the provider did not return usable data (timeout, API error).
               The point is excluded from every metric.

Definitions
* valid points       = RANKED + NOT_FOUND            (ERROR excluded)
* average position   = mean of positions over RANKED points only
* capped average     = mean over valid points where NOT_FOUND counts as
                       ``depth + 1`` (comparable across scans with the same depth)
* median/best/worst  = over RANKED points only
* Top N coverage     = RANKED points with position <= N  /  valid points
* not-found %        = NOT_FOUND / valid points

Comparison (previous scan -> current scan) is done per Point ID and only for
points that are valid in BOTH scans ("comparable points"):
* improved / declined / unchanged : RANKED in both; delta = previous - current
  (positive delta = moved up, e.g. 15 -> 8 = +7).
* newly_found      : NOT_FOUND -> RANKED
* lost_visibility  : RANKED -> NOT_FOUND
* not_found_both   : NOT_FOUND -> NOT_FOUND
* not_comparable   : ERROR or missing in either scan
"""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from statistics import median
from typing import Iterable, Mapping, Optional


class ResultStatus(str, Enum):
    RANKED = "ranked"
    NOT_FOUND = "not_found"
    ERROR = "error"


@dataclass(frozen=True)
class PointResult:
    point_index: int
    status: ResultStatus
    position: Optional[int] = None

    def __post_init__(self) -> None:
        if self.status is ResultStatus.RANKED:
            if self.position is None or self.position < 1:
                raise ValueError("a RANKED result needs a position >= 1")
        elif self.position is not None:
            raise ValueError(f"a {self.status.value} result must not carry a position")


@dataclass(frozen=True)
class ScanMetrics:
    total_points: int
    valid_points: int
    ranked_points: int
    not_found_points: int
    error_points: int
    depth: int
    average_position: Optional[float]
    capped_average_position: Optional[float]
    median_position: Optional[float]
    best_position: Optional[int]
    worst_position: Optional[int]
    top3_count: int
    top10_count: int
    top20_count: int
    top3_coverage: Optional[float]
    top10_coverage: Optional[float]
    top20_coverage: Optional[float]
    not_found_pct: Optional[float]


def _pct(n: int, d: int) -> Optional[float]:
    return round(100.0 * n / d, 2) if d else None


def compute_scan_metrics(results: Iterable[PointResult], depth: int) -> ScanMetrics:
    results = list(results)
    if depth < 1:
        raise ValueError("depth must be >= 1")
    ranked = [r.position for r in results if r.status is ResultStatus.RANKED]
    not_found = sum(1 for r in results if r.status is ResultStatus.NOT_FOUND)
    errors = sum(1 for r in results if r.status is ResultStatus.ERROR)
    valid = len(ranked) + not_found
    top = lambda n: sum(1 for p in ranked if p <= n)  # noqa: E731
    return ScanMetrics(
        total_points=len(results),
        valid_points=valid,
        ranked_points=len(ranked),
        not_found_points=not_found,
        error_points=errors,
        depth=depth,
        average_position=round(sum(ranked) / len(ranked), 2) if ranked else None,
        capped_average_position=(
            round((sum(ranked) + not_found * (depth + 1)) / valid, 2) if valid else None
        ),
        median_position=float(median(ranked)) if ranked else None,
        best_position=min(ranked) if ranked else None,
        worst_position=max(ranked) if ranked else None,
        top3_count=top(3),
        top10_count=top(10),
        top20_count=top(20),
        top3_coverage=_pct(top(3), valid),
        top10_coverage=_pct(top(10), valid),
        top20_coverage=_pct(top(20), valid),
        not_found_pct=_pct(not_found, valid),
    )


class ChangeType(str, Enum):
    IMPROVED = "improved"
    DECLINED = "declined"
    UNCHANGED = "unchanged"
    NEWLY_FOUND = "newly_found"
    LOST_VISIBILITY = "lost_visibility"
    NOT_FOUND_BOTH = "not_found_both"
    NOT_COMPARABLE = "not_comparable"


@dataclass(frozen=True)
class PointChange:
    point_index: int
    change: ChangeType
    previous_position: Optional[int]
    current_position: Optional[int]
    delta: Optional[int]  # previous - current; positive = improved; only when ranked in both


@dataclass(frozen=True)
class ScanComparison:
    points: list[PointChange]
    comparable_points: int
    counts: Mapping[str, int] = field(default_factory=dict)
    average_delta: Optional[float] = None  # over points ranked in both scans


class GridMismatchError(ValueError):
    """The two scans do not share the same grid geometry / search configuration."""


def compare_scans(
    previous: Iterable[PointResult],
    current: Iterable[PointResult],
    *,
    previous_signature: Optional[str] = None,
    current_signature: Optional[str] = None,
) -> ScanComparison:
    if previous_signature != current_signature:
        raise GridMismatchError("scans use different grids or search settings and cannot be compared point by point")
    prev = {r.point_index: r for r in previous}
    curr = {r.point_index: r for r in current}
    R, N = ResultStatus.RANKED, ResultStatus.NOT_FOUND
    changes: list[PointChange] = []
    for idx in sorted(set(prev) | set(curr)):
        p, c = prev.get(idx), curr.get(idx)
        pp = p.position if p else None
        cp = c.position if c else None
        delta = None
        if p is None or c is None or ResultStatus.ERROR in (p.status, c.status):
            kind = ChangeType.NOT_COMPARABLE
        elif p.status is R and c.status is R:
            delta = pp - cp
            kind = ChangeType.IMPROVED if delta > 0 else ChangeType.DECLINED if delta < 0 else ChangeType.UNCHANGED
        elif p.status is N and c.status is R:
            kind = ChangeType.NEWLY_FOUND
        elif p.status is R and c.status is N:
            kind = ChangeType.LOST_VISIBILITY
        else:
            kind = ChangeType.NOT_FOUND_BOTH
        changes.append(PointChange(idx, kind, pp, cp, delta))
    counts = {k.value: 0 for k in ChangeType}
    for ch in changes:
        counts[ch.change.value] += 1
    deltas = [ch.delta for ch in changes if ch.delta is not None]
    return ScanComparison(
        points=changes,
        comparable_points=len(changes) - counts[ChangeType.NOT_COMPARABLE.value],
        counts=counts,
        average_delta=round(sum(deltas) / len(deltas), 2) if deltas else None,
    )


def rank_color(result: PointResult) -> str:
    """Marker colour bucket.  ERROR is deliberately distinct from NOT_FOUND."""
    if result.status is ResultStatus.ERROR:
        return "error"
    if result.status is ResultStatus.NOT_FOUND:
        return "gray"
    p = result.position
    return "green" if p <= 3 else "yellow" if p <= 10 else "orange" if p <= 20 else "red"
