"""DataForSEO Google Maps SERP provider (Live mode).

Verified against the official documentation on 2026-11-17:
* POST https://api.dataforseo.com/v3/serp/google/maps/live/advanced
  - HTTP Basic auth (login / password), JSON array body with exactly ONE task.
  - fields used: keyword, language_code, location_coordinate ("lat,lng,ZZz",
    max 7 decimals, zoom 3z-21z), depth (default 100, max 700), device,
    se_domain, tag (max 255 chars).
  - response: top-level status_code, tasks[0].status_code (20000 = Ok),
    tasks[0].cost, tasks[0].result[0].items[] with type "maps_search",
    rank_group, place_id, cid, title, ...
  - 40102 "No Search Results." = the search ran and returned nothing.
* GET https://api.dataforseo.com/v3/appendix/user_data  (free; credential check)

NOT YET VERIFIED AGAINST A LIVE ACCOUNT: no credentials were available when
this was written, so no real request has succeeded.  Response parsing is
tested against a fixture shaped per the documentation.

The Standard/Priority queue (task_post / task_get) is not implemented yet.
"""
from __future__ import annotations

import math
import time
from decimal import Decimal
from typing import Any, Callable, Optional

import requests

from app.providers.base import (
    ExecutionMode,
    Listing,
    PointOutcome,
    ProviderError,
    RankingProvider,
    SearchConfig,
)

BASE_URL = "https://api.dataforseo.com"
MAPS_LIVE_PATH = "/v3/serp/google/maps/live/advanced"
USER_DATA_PATH = "/v3/appendix/user_data"
STATUS_OK = 20000
STATUS_NO_RESULTS = 40102
RESULTS_PER_BILLED_SERP = 100
MAX_DEPTH = 700
RETRYABLE_HTTP = {429, 500, 502, 503, 504}


class DataForSEOProvider(RankingProvider):
    name = "dataforseo"

    def __init__(
        self,
        login: str,
        password: str,
        price_lookup: Callable[[ExecutionMode], Decimal],
        *,
        session: Optional[requests.Session] = None,
        base_url: str = BASE_URL,
        timeout: float = 60.0,
        max_retries: int = 2,
        backoff_seconds: float = 2.0,
        sleep: Callable[[float], None] = time.sleep,
    ) -> None:
        if not login or not password:
            raise ProviderError("DataForSEO credentials are not configured")
        self._auth = (login, password)
        self._price_lookup = price_lookup  # prices come from the admin pricing table, never hardcoded
        self._http = session or requests.Session()
        self._base = base_url.rstrip("/")
        self._timeout = timeout
        self._max_retries = max_retries
        self._backoff = backoff_seconds
        self._sleep = sleep

    # -- credentials ---------------------------------------------------
    def validate_credentials(self) -> bool:
        try:
            r = self._http.get(self._base + USER_DATA_PATH, auth=self._auth, timeout=self._timeout)
        except requests.RequestException as exc:
            raise ProviderError(f"could not reach DataForSEO: {exc}") from exc
        if r.status_code == 401:
            return False
        try:
            return r.status_code == 200 and r.json().get("status_code") == STATUS_OK
        except ValueError:
            return False

    # -- cost ----------------------------------------------------------
    def estimate_cost(self, points: int, config: SearchConfig, mode: ExecutionMode) -> Decimal:
        """requests x billed SERPs per request x unit price.

        DataForSEO bills one SERP per 100 results (depth rounded up to the next
        hundred).  Competitors add no cost: they are read from the same response.
        """
        billed_serps = math.ceil(config.depth / RESULTS_PER_BILLED_SERP)
        return Decimal(points) * Decimal(billed_serps) * self._price_lookup(mode)

    # -- request -------------------------------------------------------
    def build_task(self, lat: float, lng: float, config: SearchConfig, tag: Optional[str]) -> dict[str, Any]:
        if not (3 <= config.zoom <= 21):
            raise ProviderError("zoom must be between 3 and 21")
        if not (1 <= config.depth <= MAX_DEPTH):
            raise ProviderError(f"depth must be between 1 and {MAX_DEPTH}")
        task: dict[str, Any] = {
            "keyword": config.keyword,
            "language_code": config.language_code,
            "location_coordinate": f"{lat:.7f},{lng:.7f},{config.zoom}z",
            "depth": config.depth,
            "device": config.device,
        }
        if config.se_domain:
            task["se_domain"] = config.se_domain
        if tag:
            task["tag"] = tag[:255]
        return task

    def fetch_point(self, lat: float, lng: float, config: SearchConfig, tag: Optional[str] = None) -> PointOutcome:
        body = [self.build_task(lat, lng, config, tag)]
        last_error = ("unknown", "no attempt made")
        for attempt in range(self._max_retries + 1):
            if attempt:
                self._sleep(self._backoff * (2 ** (attempt - 1)))
            try:
                r = self._http.post(self._base + MAPS_LIVE_PATH, json=body, auth=self._auth, timeout=self._timeout)
            except requests.Timeout:
                last_error = ("timeout", "request to provider timed out")
                continue
            except requests.RequestException as exc:
                last_error = ("network", str(exc))
                continue
            if r.status_code in RETRYABLE_HTTP:
                last_error = (f"http_{r.status_code}", "provider temporarily unavailable or rate limited")
                continue
            if r.status_code != 200:
                return PointOutcome(False, depth_requested=config.depth, error_code=f"http_{r.status_code}",
                                    error_message=r.text[:300])
            try:
                return self.normalize_results(r.json(), config.depth)
            except ValueError:
                return PointOutcome(False, depth_requested=config.depth, error_code="bad_json",
                                    error_message="provider returned a non-JSON body")
        return PointOutcome(False, depth_requested=config.depth, error_code=last_error[0], error_message=last_error[1])

    # -- response ------------------------------------------------------
    def normalize_results(self, raw: dict, depth_requested: int) -> PointOutcome:
        def fail(code: Any, msg: Any, **kw: Any) -> PointOutcome:
            return PointOutcome(False, depth_requested=depth_requested, error_code=str(code),
                                error_message=str(msg)[:300], **kw)

        if not isinstance(raw, dict):
            return fail("bad_shape", "unexpected response shape")
        if raw.get("status_code") != STATUS_OK:
            return fail(raw.get("status_code"), raw.get("status_message"))
        tasks = raw.get("tasks") or []
        if len(tasks) != 1:
            return fail("bad_shape", f"expected exactly one task, got {len(tasks)}")
        task = tasks[0]
        code = task.get("status_code")
        cost = Decimal(str(task["cost"])) if task.get("cost") is not None else None
        meta = {
            "task_status_code": code,
            "task_status_message": task.get("status_message"),
            "task_time": task.get("time"),
            "request": task.get("data"),
        }
        common = dict(cost=cost, provider_task_id=task.get("id"), meta=meta)
        if code == STATUS_NO_RESULTS:
            # A successful search with zero listings: every subject is NOT_FOUND here.
            return PointOutcome(True, (), depth_requested, **common)
        if code != STATUS_OK:
            return fail(code, task.get("status_message"), **common)
        results = task.get("result") or []
        if not results:
            return fail("empty_result", "task succeeded but carried no result object", **common)
        result = results[0]
        meta.update(items_count=result.get("items_count"), se_domain=result.get("se_domain"),
                    item_types=result.get("item_types"))
        listings = []
        for item in result.get("items") or []:
            if item.get("type") != "maps_search":  # ignore paid items
                continue
            rank = item.get("rank_group")
            if not isinstance(rank, int) or rank < 1:
                continue
            rating = item.get("rating") or {}
            listings.append(Listing(
                position=rank,
                title=item.get("title"),
                place_id=item.get("place_id"),
                cid=str(item["cid"]) if item.get("cid") is not None else None,
                domain=item.get("domain"),
                address=item.get("address"),
                category=item.get("category"),
                rating=rating.get("value"),
                reviews=rating.get("votes_count"),
                latitude=item.get("latitude"),
                longitude=item.get("longitude"),
            ))
        listings.sort(key=lambda l: l.position)
        return PointOutcome(True, tuple(listings), depth_requested, check_url=result.get("check_url"),
                            fetched_at=result.get("datetime"), **common)
