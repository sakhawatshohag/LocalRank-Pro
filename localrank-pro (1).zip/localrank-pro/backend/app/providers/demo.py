"""DEMO MODE provider.

Produces deterministic SYNTHETIC rankings so the product can be explored
without API credentials.  Every outcome is flagged ``is_demo=True``; scans
created with it are stored with ``is_demo = true`` and must be labelled
"Demo data" everywhere they are shown.  It is refused when APP_ENV=production
unless DEMO_MODE is explicitly enabled.
"""
from __future__ import annotations

import hashlib
from decimal import Decimal
from typing import Optional, Sequence

from app.providers.base import ExecutionMode, Listing, PointOutcome, RankingProvider, SearchConfig, Subject


class DemoProvider(RankingProvider):
    name = "demo"
    is_demo = True

    def __init__(self, subjects: Sequence[Subject] = (), epoch: str = "0") -> None:
        self._subjects = list(subjects)
        self._epoch = epoch  # change per scan date to simulate movement

    def validate_credentials(self) -> bool:
        return True

    def estimate_cost(self, points: int, config: SearchConfig, mode: ExecutionMode) -> Decimal:
        return Decimal(0)

    def fetch_point(self, lat: float, lng: float, config: SearchConfig, tag: Optional[str] = None) -> PointOutcome:
        ranked = []
        for s in self._subjects:
            h = hashlib.sha256(f"{s.key}|{config.keyword}|{lat:.5f}|{lng:.5f}|{self._epoch}".encode()).digest()
            score = int.from_bytes(h[:4], "big")
            if score % 10 == 0:      # ~10% of points: not in results
                continue
            ranked.append((score, s))
        ranked.sort(key=lambda t: t[0])
        listings = tuple(
            Listing(position=i + 1 + (score % 7), title=f"[DEMO] {s.key}", place_id=s.place_id, cid=s.cid)
            for i, (score, s) in enumerate(ranked)
        )
        # positions must be unique and increasing
        fixed, last = [], 0
        for l in sorted(listings, key=lambda l: l.position):
            pos = max(l.position, last + 1)
            last = pos
            fixed.append(Listing(pos, l.title, l.place_id, l.cid))
        return PointOutcome(True, tuple(fixed), config.depth, cost=Decimal(0), is_demo=True,
                            meta={"demo": True})

    def normalize_results(self, raw: dict, depth_requested: int) -> PointOutcome:  # pragma: no cover
        raise NotImplementedError("demo provider has no raw responses")
