"""Provider-independent ranking interface.

One provider request = one keyword searched from one grid coordinate.  The
response lists every business the search engine returned there, so the target
business AND all competitors are resolved from the same response: same
keyword, same coordinate, same moment, same search configuration.
"""
from __future__ import annotations

import abc
from dataclasses import dataclass, field
from decimal import Decimal
from enum import Enum
from typing import Any, Optional, Sequence

from app.engine.analytics import PointResult, ResultStatus


class ProviderError(Exception):
    """Configuration / credential problem (not a per-point failure)."""


class ExecutionMode(str, Enum):
    LIVE = "live"
    PRIORITY = "priority"
    STANDARD = "standard"


@dataclass(frozen=True)
class SearchConfig:
    keyword: str
    language_code: str = "en"
    zoom: int = 15            # map zoom level sent with each coordinate
    depth: int = 100          # how many results to request
    device: str = "desktop"
    se_domain: Optional[str] = None


@dataclass(frozen=True)
class Listing:
    position: int             # 1-based rank among organic map results
    title: Optional[str]
    place_id: Optional[str]
    cid: Optional[str]
    domain: Optional[str] = None
    address: Optional[str] = None
    category: Optional[str] = None
    rating: Optional[float] = None
    reviews: Optional[int] = None
    latitude: Optional[float] = None
    longitude: Optional[float] = None


@dataclass(frozen=True)
class PointOutcome:
    """Result of querying one coordinate.  ``ok=False`` is an API failure and
    must never be turned into a ranking."""
    ok: bool
    listings: Sequence[Listing] = ()
    depth_requested: int = 0
    cost: Optional[Decimal] = None
    provider_task_id: Optional[str] = None
    check_url: Optional[str] = None
    fetched_at: Optional[str] = None
    error_code: Optional[str] = None
    error_message: Optional[str] = None
    is_demo: bool = False
    meta: dict[str, Any] = field(default_factory=dict)  # original provider metadata


@dataclass(frozen=True)
class Subject:
    """A business to locate in the results (the client or a competitor)."""
    key: str                          # internal id, e.g. "location:<uuid>" / "competitor:<uuid>"
    place_id: Optional[str] = None
    cid: Optional[str] = None

    def __post_init__(self) -> None:
        if not (self.place_id or self.cid):
            raise ValueError("a subject needs a verified place_id or cid; names are not matched")


def resolve_subject(outcome: PointOutcome, subject: Subject, point_index: int) -> PointResult:
    """Translate a provider outcome into RANKED / NOT_FOUND / ERROR for a subject.

    Matching is by Google Place ID, falling back to CID.  Business names are
    never used: similar names would produce wrong rankings.
    """
    if not outcome.ok:
        return PointResult(point_index, ResultStatus.ERROR)
    for item in outcome.listings:
        if (subject.place_id and item.place_id == subject.place_id) or (
            subject.cid and item.cid and str(item.cid) == str(subject.cid)
        ):
            return PointResult(point_index, ResultStatus.RANKED, item.position)
    return PointResult(point_index, ResultStatus.NOT_FOUND)


class RankingProvider(abc.ABC):
    name: str
    is_demo: bool = False

    @abc.abstractmethod
    def validate_credentials(self) -> bool: ...

    @abc.abstractmethod
    def estimate_cost(self, points: int, config: SearchConfig, mode: ExecutionMode) -> Decimal: ...

    @abc.abstractmethod
    def fetch_point(self, lat: float, lng: float, config: SearchConfig, tag: Optional[str] = None) -> PointOutcome:
        """Synchronous (live) retrieval for one coordinate."""

    # Asynchronous queue workflow (submit -> poll -> retrieve).  Providers that
    # do not implement it yet raise NotImplementedError; the scan runner then
    # uses ``fetch_point``.
    def submit_scan(self, points, config: SearchConfig):  # pragma: no cover - interface
        raise NotImplementedError

    def get_scan_status(self, handle):  # pragma: no cover - interface
        raise NotImplementedError

    def retrieve_results(self, handle):  # pragma: no cover - interface
        raise NotImplementedError

    @abc.abstractmethod
    def normalize_results(self, raw: dict, depth_requested: int) -> PointOutcome: ...
