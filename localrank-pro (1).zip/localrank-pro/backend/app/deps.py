"""FastAPI dependencies: authentication, tenant context, RBAC, plan limits."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Callable

import jwt
from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from sqlalchemy import text
from sqlalchemy.engine import Connection

from app.config import get_settings
from app.db import system_tx
from app.security import decode_access_token, role_at_least

_bearer = HTTPBearer(auto_error=False)


@dataclass(frozen=True)
class Principal:
    user_id: str
    org_id: str
    role: str


def current_principal(creds: HTTPAuthorizationCredentials | None = Depends(_bearer)) -> Principal:
    if creds is None:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Not authenticated")
    try:
        claims = decode_access_token(creds.credentials, get_settings().jwt_secret)
    except jwt.InvalidTokenError:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Invalid or expired token")
    # Re-check membership on every request so removed members lose access immediately.
    with system_tx() as conn:
        row = conn.execute(
            text("""SELECT m.role::text FROM organization_members m JOIN users u ON u.id = m.user_id
                    WHERE m.org_id = :o AND m.user_id = :u AND u.is_active"""),
            {"o": claims["org"], "u": claims["sub"]},
        ).first()
    if row is None:
        raise HTTPException(status.HTTP_403_FORBIDDEN, "No access to this organization")
    return Principal(claims["sub"], claims["org"], row[0])


def require_role(minimum: str) -> Callable[[Principal], Principal]:
    def dep(p: Principal = Depends(current_principal)) -> Principal:
        if not role_at_least(p.role, minimum):
            raise HTTPException(status.HTTP_403_FORBIDDEN, f"Requires role '{minimum}' or higher")
        return p
    return dep


def enforce_plan_limit(conn: Connection, org_id: str, limit_key: str, current_count: int) -> None:
    """Limits live only in plans.limits (JSON).  A missing key means 'not allowed'."""
    limit = conn.execute(
        text("SELECT (p.limits ->> :k)::int FROM organizations o JOIN plans p ON p.id = o.plan_id WHERE o.id = :o"),
        {"k": limit_key, "o": org_id},
    ).scalar()
    if limit is None or current_count >= limit:
        raise HTTPException(status.HTTP_402_PAYMENT_REQUIRED,
                            f"Plan limit reached for '{limit_key}' ({limit or 0}). Upgrade to add more.")
