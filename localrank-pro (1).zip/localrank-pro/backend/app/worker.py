"""Celery worker and scheduler.

Worker:  celery -A app.worker worker --loglevel=info
Beat:    celery -A app.worker beat --loglevel=info     (run exactly ONE beat process)
"""
from __future__ import annotations

import logging

from celery import Celery

from app.config import get_settings
from app.services.billing import expire_trials
from app.services.notifications import after_scan
from app.services.reports import dispatch_report_schedules, generate_report
from app.services.scans import ScanSetupError, mark_scan_failed, run_scan
from app.services.schedules import dispatch_due, maintenance

log = logging.getLogger("localrank.worker")
celery_app = Celery("localrank", broker=get_settings().redis_url)
celery_app.conf.update(
    task_acks_late=True,
    worker_prefetch_multiplier=1,
    task_ignore_result=True,
    timezone="UTC",
    beat_schedule={
        "dispatch-due-schedules": {"task": "schedules.dispatch", "schedule": 60.0},
        "scan-maintenance": {"task": "scans.maintenance", "schedule": 300.0},
        "dispatch-report-schedules": {"task": "reports.dispatch", "schedule": 300.0},
        "expire-trials": {"task": "billing.expire_trials", "schedule": 3600.0},
    },
)


def enqueue(org_id: str, scan_id: str) -> None:
    run_scan_task.delay(org_id, scan_id)


@celery_app.task(name="scans.run")
def run_scan_task(org_id: str, scan_id: str) -> str:
    # No Celery-level retry: per-request retries happen inside the provider, and a scan that was
    # already started is never executed a second time (run_scan claims it atomically).
    try:
        status = run_scan(org_id, scan_id, get_settings())
        log.info("scan %s finished with status %s", scan_id, status)
        if status != "skipped":
            after_scan(org_id, scan_id)
        return status
    except ScanSetupError as exc:
        log.error("scan %s could not run: %s", scan_id, exc)
    except Exception:
        log.exception("scan %s crashed", scan_id)
    mark_scan_failed(org_id, scan_id)
    after_scan(org_id, scan_id)
    return "failed"


@celery_app.task(name="schedules.dispatch")
def dispatch_task() -> int:
    return dispatch_due(get_settings(), enqueue)


@celery_app.task(name="scans.maintenance")
def maintenance_task() -> dict:
    return maintenance(enqueue, after_scan)


def enqueue_report(org_id: str, report_id: str) -> None:
    generate_report_task.delay(org_id, report_id)


@celery_app.task(name="reports.generate")
def generate_report_task(org_id: str, report_id: str) -> str:
    return generate_report(org_id, report_id)


@celery_app.task(name="reports.dispatch")
def dispatch_reports_task() -> int:
    return dispatch_report_schedules(enqueue_report)


@celery_app.task(name="billing.expire_trials")
def expire_trials_task() -> int:
    return expire_trials()
