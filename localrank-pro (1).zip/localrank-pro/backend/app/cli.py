"""Operator commands (run inside the api container):

  python -m app.cli create-account --email a@b.com --name "Jane" --org "Acme Plumbing" [--plan standard] [--role owner]
  python -m app.cli add-member     --email b@b.com --name "Sam" --org-id <uuid> --role seo_specialist
  python -m app.cli set-plan       --org-id <uuid> --plan standard
  python -m app.cli reset-password --email a@b.com
  python -m app.cli list           (organizations with plan and members)
  python -m app.cli plans

A strong password is generated and printed once; give it to the person and ask them to keep it safe.
"""
from __future__ import annotations

import argparse
import secrets
import string
import sys
from typing import Optional

from sqlalchemy import text

from app.db import system_tx
from app.security import hash_password

ROLES = ("owner", "admin", "manager", "seo_specialist", "client_viewer")


class CliError(Exception):
    pass


def generate_password(length: int = 16) -> str:
    alphabet = string.ascii_letters + string.digits
    while True:
        pw = "".join(secrets.choice(alphabet) for _ in range(length))
        if any(c.isdigit() for c in pw) and any(c.isupper() for c in pw) and any(c.islower() for c in pw):
            return pw


def _plan_id(conn, code: str) -> str:
    pid = conn.execute(text("SELECT id::text FROM plans WHERE code = :c AND is_active"), {"c": code}).scalar()
    if pid is None:
        raise CliError(f"plan '{code}' does not exist (see: python -m app.cli plans)")
    return pid


def create_account(email: str, name: str, org: str, plan: str = "standard", role: str = "owner",
                   password: Optional[str] = None) -> dict:
    email = email.strip()
    if "@" not in email:
        raise CliError("invalid email")
    password = password or generate_password()
    with system_tx() as conn:
        if conn.execute(text("SELECT 1 FROM users WHERE lower(email) = lower(:e)"), {"e": email}).first():
            raise CliError(f"an account with {email} already exists (use add-member to add it to another organization)")
        plan_id = _plan_id(conn, plan)
        user_id = conn.execute(text("""INSERT INTO users (email, password_hash, full_name, email_verified_at)
                                       VALUES (:e, :p, :n, now()) RETURNING id::text"""),
                               {"e": email, "p": hash_password(password), "n": name.strip()}).scalar_one()
        org_id = conn.execute(text("INSERT INTO organizations (name, plan_id) VALUES (:n, CAST(:p AS uuid)) RETURNING id::text"),
                              {"n": org.strip(), "p": plan_id}).scalar_one()
        conn.execute(text("INSERT INTO organization_members (org_id, user_id, role) VALUES (:o, :u, CAST(:r AS member_role))"),
                     {"o": org_id, "u": user_id, "r": role})
    return {"email": email, "password": password, "org_id": org_id, "user_id": user_id, "plan": plan}


def add_member(email: str, name: str, org_id: str, role: str) -> dict:
    email = email.strip()
    password = None
    with system_tx() as conn:
        if conn.execute(text("SELECT 1 FROM organizations WHERE id = CAST(:o AS uuid)"), {"o": org_id}).first() is None:
            raise CliError("organization not found")
        user_id = conn.execute(text("SELECT id::text FROM users WHERE lower(email) = lower(:e)"), {"e": email}).scalar()
        if user_id is None:
            password = generate_password()
            user_id = conn.execute(text("""INSERT INTO users (email, password_hash, full_name, email_verified_at)
                                           VALUES (:e, :p, :n, now()) RETURNING id::text"""),
                                   {"e": email, "p": hash_password(password), "n": name.strip()}).scalar_one()
        n = conn.execute(text("""INSERT INTO organization_members (org_id, user_id, role) VALUES (CAST(:o AS uuid), :u, CAST(:r AS member_role))
                                 ON CONFLICT (org_id, user_id) DO NOTHING"""), {"o": org_id, "u": user_id, "r": role}).rowcount
        if n == 0:
            raise CliError(f"{email} is already a member of this organization")
    return {"email": email, "password": password, "user_id": user_id, "org_id": org_id, "role": role}


def set_plan(org_id: str, plan: str) -> None:
    with system_tx() as conn:
        n = conn.execute(text("UPDATE organizations SET plan_id = CAST(:p AS uuid), trial_ends_at = NULL WHERE id = CAST(:o AS uuid)"),
                         {"p": _plan_id(conn, plan), "o": org_id}).rowcount
    if n == 0:
        raise CliError("organization not found")


def reset_password(email: str) -> str:
    password = generate_password()
    with system_tx() as conn:
        n = conn.execute(text("UPDATE users SET password_hash = :p WHERE lower(email) = lower(:e)"),
                         {"p": hash_password(password), "e": email.strip()}).rowcount
    if n == 0:
        raise CliError(f"no account with {email}")
    return password


def list_orgs() -> list[dict]:
    with system_tx() as conn:
        return [dict(r) for r in conn.execute(text("""
            SELECT o.id::text, o.name, p.code AS plan,
                   (SELECT string_agg(u.email || ' (' || m.role || ')', ', ' ORDER BY m.created_at)
                      FROM organization_members m JOIN users u ON u.id = m.user_id WHERE m.org_id = o.id) AS members
            FROM organizations o LEFT JOIN plans p ON p.id = o.plan_id ORDER BY o.created_at""")).mappings()]


def list_plans() -> list[dict]:
    with system_tx() as conn:
        return [dict(r) for r in conn.execute(text("SELECT code, name, limits FROM plans WHERE is_active ORDER BY sort_order, code")).mappings()]


def main(argv: Optional[list[str]] = None) -> int:
    ap = argparse.ArgumentParser(prog="python -m app.cli", description="LocalRank Pro operator commands")
    sub = ap.add_subparsers(dest="cmd", required=True)
    c = sub.add_parser("create-account", help="new organization with its first user")
    c.add_argument("--email", required=True); c.add_argument("--name", required=True); c.add_argument("--org", required=True)
    c.add_argument("--plan", default="standard"); c.add_argument("--role", default="owner", choices=ROLES)
    m = sub.add_parser("add-member", help="add a user to an existing organization")
    m.add_argument("--email", required=True); m.add_argument("--name", default=""); m.add_argument("--org-id", required=True)
    m.add_argument("--role", default="seo_specialist", choices=ROLES)
    s = sub.add_parser("set-plan"); s.add_argument("--org-id", required=True); s.add_argument("--plan", required=True)
    r = sub.add_parser("reset-password"); r.add_argument("--email", required=True)
    sub.add_parser("list"); sub.add_parser("plans")
    a = ap.parse_args(argv)
    try:
        if a.cmd == "create-account":
            out = create_account(a.email, a.name, a.org, a.plan, a.role)
            print(f"Created {out['email']} (organization {out['org_id']}, plan {out['plan']})\nPassword: {out['password']}\n"
                  "Give this password to the person; it is not shown again.")
        elif a.cmd == "add-member":
            out = add_member(a.email, a.name, a.org_id, a.role)
            print(f"Added {out['email']} as {out['role']}" + (f"\nNew account password: {out['password']}" if out["password"] else
                                                               " (existing account, password unchanged)"))
        elif a.cmd == "set-plan":
            set_plan(a.org_id, a.plan); print("Plan updated")
        elif a.cmd == "reset-password":
            print(f"New password: {reset_password(a.email)}")
        elif a.cmd == "list":
            for o in list_orgs():
                print(f"{o['id']}  {o['name']}  [{o['plan']}]  {o['members'] or ''}")
        elif a.cmd == "plans":
            for p in list_plans():
                print(f"{p['code']:<12} {p['name']:<20} {p['limits']}")
    except CliError as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
