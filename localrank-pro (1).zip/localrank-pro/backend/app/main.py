from __future__ import annotations

import logging

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from sqlalchemy import text

from app.config import get_settings
from app.db import system_tx
import time

import jwt

from app.routers import admin, auth, billing, campaigns, clients, grid, locations, notifications, reports, scans, schedules, team
from app.security import decode_access_token

log = logging.getLogger("localrank")


def create_app() -> FastAPI:
    s = get_settings()
    app = FastAPI(title="LocalRank Pro API", version="0.1.0",
                  docs_url=None if s.app_env == "production" else "/docs")
    if s.cors_origins:
        app.add_middleware(CORSMiddleware, allow_origins=s.cors_origins, allow_credentials=False,
                           allow_methods=["GET", "POST", "PUT", "PATCH", "DELETE"], allow_headers=["Authorization", "Content-Type"])

    maintenance_cache = {"at": 0.0, "value": {"enabled": False}}
    open_paths = ("/health", "/api/v1/auth/login", "/api/v1/auth/me", "/api/v1/billing/webhook/stripe", "/api/v1/admin")

    def _maintenance() -> dict:
        if time.monotonic() - maintenance_cache["at"] > 30:
            try:
                with system_tx() as conn:
                    maintenance_cache["value"] = conn.execute(
                        text("SELECT value FROM system_settings WHERE key = 'maintenance'")).scalar() or {"enabled": False}
            except Exception:
                log.exception("could not read the maintenance setting")
            maintenance_cache["at"] = time.monotonic()
        return maintenance_cache["value"]

    def _is_super_admin(request: Request) -> bool:
        header = request.headers.get("authorization", "")
        if not header.lower().startswith("bearer "):
            return False
        try:
            uid = decode_access_token(header[7:], s.jwt_secret)["sub"]
        except jwt.InvalidTokenError:
            return False
        with system_tx() as conn:
            return bool(conn.execute(text("SELECT is_super_admin FROM users WHERE id = :u AND is_active"), {"u": uid}).scalar())

    @app.middleware("http")
    async def maintenance_mode(request: Request, call_next):
        state = _maintenance()
        # super admins keep access so they can switch maintenance off again
        if state.get("enabled") and not request.url.path.startswith(open_paths) and not _is_super_admin(request):
            return JSONResponse(status_code=503, content={
                "detail": state.get("message") or "LocalRank Pro is under maintenance. Please try again shortly."})
        return await call_next(request)

    @app.exception_handler(Exception)
    async def unhandled(request: Request, exc: Exception) -> JSONResponse:
        log.exception("unhandled error on %s %s", request.method, request.url.path)  # logged, never swallowed
        return JSONResponse(status_code=500, content={"detail": "Internal server error"})

    @app.get("/health", tags=["system"])
    def health() -> dict:
        with system_tx() as conn:
            conn.execute(text("SELECT 1"))
        return {"status": "ok", "env": s.app_env, "demo_mode": s.demo_mode,
                "ranking_provider_configured": s.dataforseo_configured}

    for r in (auth.router, clients.router, locations.router, grid.router, campaigns.router, scans.router,
              schedules.router, notifications.router, reports.router, billing.router, team.router, admin.router):
        app.include_router(r, prefix="/api/v1")
    return app


app = create_app()
