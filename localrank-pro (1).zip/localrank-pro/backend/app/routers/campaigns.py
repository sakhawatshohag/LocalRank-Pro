"""Campaigns, their keywords and competitors."""
from __future__ import annotations

from typing import Optional
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, Field, model_validator
from sqlalchemy import text
from sqlalchemy.engine import Connection
from sqlalchemy.exc import IntegrityError

from app.db import tenant_tx
from app.deps import Principal, current_principal, enforce_plan_limit, require_role
from app.engine.geogrid import GridError, generate_grid, radius_from_spacing

router = APIRouter(prefix="/campaigns", tags=["campaigns"])

C_COLS = """c.id::text, c.location_id::text, l.name AS location_name, c.name, c.grid_size, c.spacing_m::float8 AS spacing_m,
            c.center_lat, c.center_lng, c.language_code, c.se_domain, c.device, c.zoom, c.depth, c.is_active, c.created_at"""


class CampaignIn(BaseModel):
    location_id: UUID
    name: str = Field(min_length=1, max_length=160)
    grid_size: int = Field(ge=1, le=21)
    spacing_m: float = Field(ge=50, le=50_000)
    center_lat: Optional[float] = None       # default: the location's coordinates
    center_lng: Optional[float] = None
    language_code: str = Field(default="en", min_length=2, max_length=10)
    se_domain: Optional[str] = Field(default=None, max_length=60, pattern=r"^google\.[a-z.]{2,10}$")
    device: str = Field(default="desktop", pattern="^(desktop|mobile)$")
    zoom: int = Field(default=15, ge=3, le=21)
    depth: int = Field(default=100, ge=1, le=700)

    @model_validator(mode="after")
    def _centre_pair(self):
        if (self.center_lat is None) != (self.center_lng is None):
            raise ValueError("center_lat and center_lng must be given together")
        return self


class CampaignPatch(BaseModel):
    name: Optional[str] = Field(default=None, min_length=1, max_length=160)
    is_active: Optional[bool] = None


class KeywordIn(BaseModel):
    keyword: str = Field(min_length=1, max_length=700)


class KeywordPatch(BaseModel):
    is_paused: bool


class CompetitorIn(BaseModel):
    name: str = Field(min_length=1, max_length=200)
    gbp_url: Optional[str] = Field(default=None, max_length=2000)
    place_id: Optional[str] = Field(default=None, max_length=300)
    cid: Optional[str] = Field(default=None, max_length=40)
    address: Optional[str] = Field(default=None, max_length=500)
    website: Optional[str] = Field(default=None, max_length=2000)
    primary_category: Optional[str] = Field(default=None, max_length=200)
    latitude: Optional[float] = Field(default=None, ge=-90, le=90)
    longitude: Optional[float] = Field(default=None, ge=-180, le=180)

    @model_validator(mode="after")
    def _identifier(self):
        if not (self.place_id or self.cid):
            raise ValueError("a competitor needs a Google Place ID or CID; rankings are never matched by name")
        return self


def _plan_limit(conn: Connection, org_id: str, key: str) -> Optional[int]:
    return conn.execute(text("""SELECT (p.limits ->> :k)::int FROM organizations o JOIN plans p ON p.id = o.plan_id
                                WHERE o.id = :o"""), {"k": key, "o": org_id}).scalar()


def _require_campaign(conn: Connection, campaign_id: UUID) -> None:
    if conn.execute(text("SELECT 1 FROM campaigns WHERE id = :c"), {"c": str(campaign_id)}).first() is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Campaign not found")


# ---------------- campaigns ----------------
@router.get("")
def list_campaigns(location_id: Optional[UUID] = None, p: Principal = Depends(current_principal)) -> list[dict]:
    with tenant_tx(p.org_id) as conn:
        rows = conn.execute(text(f"""SELECT {C_COLS},
                   (SELECT count(*) FROM keywords k WHERE k.campaign_id = c.id) AS keyword_count,
                   (SELECT count(*) FROM competitors x WHERE x.campaign_id = c.id) AS competitor_count,
                   (SELECT max(completed_at) FROM scans s WHERE s.campaign_id = c.id) AS last_scan_at
                FROM campaigns c JOIN business_locations l ON l.id = c.location_id
                WHERE (CAST(:l AS uuid) IS NULL OR c.location_id = CAST(:l AS uuid)) ORDER BY c.created_at DESC"""),
                {"l": str(location_id) if location_id else None}).mappings().all()
    return [dict(r) for r in rows]


@router.post("", status_code=status.HTTP_201_CREATED)
def create_campaign(body: CampaignIn, p: Principal = Depends(require_role("seo_specialist"))) -> dict:
    with tenant_tx(p.org_id) as conn:
        loc = conn.execute(text("SELECT latitude, longitude FROM business_locations WHERE id = :l AND archived_at IS NULL"),
                           {"l": str(body.location_id)}).first()
        if loc is None:
            raise HTTPException(status.HTTP_422_UNPROCESSABLE_ENTITY, "Location not found or archived")
        lat = body.center_lat if body.center_lat is not None else loc[0]
        lng = body.center_lng if body.center_lng is not None else loc[1]
        try:
            generate_grid(lat, lng, body.grid_size, body.spacing_m)
        except GridError as exc:
            raise HTTPException(status.HTTP_422_UNPROCESSABLE_ENTITY, str(exc))
        max_grid = _plan_limit(conn, p.org_id, "max_grid_size")
        if max_grid is None or body.grid_size > max_grid:
            raise HTTPException(status.HTTP_402_PAYMENT_REQUIRED,
                                f"Your plan allows grids up to {max_grid or 0}x{max_grid or 0}")
        count = conn.execute(text("SELECT count(*) FROM campaigns WHERE is_active")).scalar_one()
        enforce_plan_limit(conn, p.org_id, "campaigns", count)
        cid = conn.execute(text("""INSERT INTO campaigns (org_id, location_id, name, grid_size, spacing_m, center_lat,
                    center_lng, language_code, se_domain, device, zoom, depth)
                VALUES (:org, :loc, :name, :gs, :sp, :lat, :lng, :lang, :dom, :dev, :zoom, :depth) RETURNING id::text"""),
                {"org": p.org_id, "loc": str(body.location_id), "name": body.name, "gs": body.grid_size,
                 "sp": body.spacing_m, "lat": lat, "lng": lng, "lang": body.language_code, "dom": body.se_domain,
                 "dev": body.device, "zoom": body.zoom, "depth": body.depth}).scalar_one()
        row = conn.execute(text(f"""SELECT {C_COLS} FROM campaigns c JOIN business_locations l ON l.id = c.location_id
                                    WHERE c.id = :c"""), {"c": cid}).mappings().one()
    return dict(row) | {"radius_m": radius_from_spacing(body.spacing_m, body.grid_size)}


@router.get("/{campaign_id}")
def get_campaign(campaign_id: UUID, p: Principal = Depends(current_principal)) -> dict:
    with tenant_tx(p.org_id) as conn:
        row = conn.execute(text(f"""SELECT {C_COLS} FROM campaigns c JOIN business_locations l ON l.id = c.location_id
                                    WHERE c.id = :c"""), {"c": str(campaign_id)}).mappings().first()
        if row is None:
            raise HTTPException(status.HTTP_404_NOT_FOUND, "Campaign not found")
        kws = conn.execute(text("""SELECT id::text, keyword, is_paused, created_at FROM keywords
                                   WHERE campaign_id = :c ORDER BY created_at"""), {"c": str(campaign_id)}).mappings().all()
        comps = conn.execute(text("""SELECT id::text, name, place_id, cid, gbp_url, address, website, primary_category,
                                            latitude, longitude, identity_verified_at FROM competitors
                                     WHERE campaign_id = :c ORDER BY created_at"""), {"c": str(campaign_id)}).mappings().all()
    return dict(row) | {"radius_m": radius_from_spacing(row["spacing_m"], row["grid_size"]),
                        "keywords": [dict(k) for k in kws], "competitors": [dict(c) for c in comps]}


@router.patch("/{campaign_id}")
def patch_campaign(campaign_id: UUID, body: CampaignPatch, p: Principal = Depends(require_role("seo_specialist"))) -> dict:
    """Only name and active state can change.  Grid and search settings are fixed so that every scan
    of a campaign stays comparable; create a new campaign for a different grid."""
    with tenant_tx(p.org_id) as conn:
        row = conn.execute(text("""UPDATE campaigns SET name = coalesce(CAST(:n AS text), name),
                                       is_active = coalesce(CAST(:a AS boolean), is_active)
                                   WHERE id = :c RETURNING id::text, name, is_active"""),
                           {"n": body.name, "a": body.is_active, "c": str(campaign_id)}).mappings().first()
    if row is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Campaign not found")
    return dict(row)


# ---------------- keywords ----------------
@router.post("/{campaign_id}/keywords", status_code=status.HTTP_201_CREATED)
def add_keyword(campaign_id: UUID, body: KeywordIn, p: Principal = Depends(require_role("seo_specialist"))) -> dict:
    kw = " ".join(body.keyword.split())
    try:
        with tenant_tx(p.org_id) as conn:
            _require_campaign(conn, campaign_id)
            count = conn.execute(text("SELECT count(*) FROM keywords WHERE NOT is_paused")).scalar_one()
            enforce_plan_limit(conn, p.org_id, "keywords", count)
            row = conn.execute(text("""INSERT INTO keywords (org_id, campaign_id, keyword) VALUES (:o, :c, :k)
                                       RETURNING id::text, keyword, is_paused, created_at"""),
                               {"o": p.org_id, "c": str(campaign_id), "k": kw}).mappings().one()
    except IntegrityError:
        raise HTTPException(status.HTTP_409_CONFLICT, "This keyword is already tracked in the campaign")
    return dict(row)


@router.patch("/{campaign_id}/keywords/{keyword_id}")
def pause_keyword(campaign_id: UUID, keyword_id: UUID, body: KeywordPatch,
                  p: Principal = Depends(require_role("seo_specialist"))) -> dict:
    with tenant_tx(p.org_id) as conn:
        row = conn.execute(text("""UPDATE keywords SET is_paused = :p WHERE id = :k AND campaign_id = :c
                                   RETURNING id::text, keyword, is_paused"""),
                           {"p": body.is_paused, "k": str(keyword_id), "c": str(campaign_id)}).mappings().first()
    if row is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Keyword not found")
    return dict(row)


@router.delete("/{campaign_id}/keywords/{keyword_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_keyword(campaign_id: UUID, keyword_id: UUID, p: Principal = Depends(require_role("manager"))) -> None:
    try:
        with tenant_tx(p.org_id) as conn:
            n = conn.execute(text("DELETE FROM keywords WHERE id = :k AND campaign_id = :c"),
                             {"k": str(keyword_id), "c": str(campaign_id)}).rowcount
    except IntegrityError:
        raise HTTPException(status.HTTP_409_CONFLICT, "This keyword has scan history; pause it instead")
    if n == 0:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Keyword not found")


# ---------------- competitors ----------------
@router.post("/{campaign_id}/competitors", status_code=status.HTTP_201_CREATED)
def add_competitor(campaign_id: UUID, body: CompetitorIn, p: Principal = Depends(require_role("seo_specialist"))) -> dict:
    with tenant_tx(p.org_id) as conn:
        _require_campaign(conn, campaign_id)
        count = conn.execute(text("SELECT count(*) FROM competitors WHERE campaign_id = :c"),
                             {"c": str(campaign_id)}).scalar_one()
        enforce_plan_limit(conn, p.org_id, "competitors", count)   # limit is per campaign
        dup = conn.execute(text("""SELECT 1 FROM competitors WHERE campaign_id = :c AND
                    ((CAST(:pid AS text) IS NOT NULL AND place_id = CAST(:pid AS text)) OR
                     (CAST(:cid AS text) IS NOT NULL AND cid = CAST(:cid AS text)))"""),
                    {"c": str(campaign_id), "pid": body.place_id, "cid": body.cid}).first()
        if dup:
            raise HTTPException(status.HTTP_409_CONFLICT, "This competitor is already in the campaign")
        row = conn.execute(text("""INSERT INTO competitors (org_id, campaign_id, name, gbp_url, place_id, cid, address,
                    website, primary_category, latitude, longitude)
                VALUES (:o, :c, :name, :gbp_url, :place_id, :cid, :address, :website, :primary_category, :latitude,
                        :longitude)
                RETURNING id::text, name, place_id, cid, identity_verified_at"""),
                {"o": p.org_id, "c": str(campaign_id), **body.model_dump()}).mappings().one()
    return dict(row)


@router.delete("/{campaign_id}/competitors/{competitor_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_competitor(campaign_id: UUID, competitor_id: UUID, p: Principal = Depends(require_role("manager"))) -> None:
    try:
        with tenant_tx(p.org_id) as conn:
            n = conn.execute(text("DELETE FROM competitors WHERE id = :x AND campaign_id = :c"),
                             {"x": str(competitor_id), "c": str(campaign_id)}).rowcount
    except IntegrityError:
        raise HTTPException(status.HTTP_409_CONFLICT,
                            "This competitor has ranking history and cannot be deleted")
    if n == 0:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Competitor not found")
