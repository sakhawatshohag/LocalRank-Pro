"""Super Admin: platform overview, organizations, users, plans, API pricing, providers, maintenance.

Every call goes through a SECURITY DEFINER function that re-checks users.is_super_admin in the
database and writes admin_audit for changes.
"""
from __future__ import annotations

import json
from datetime import datetime
from typing import Literal, Optional
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Query, status
from pydantic import BaseModel, Field
from sqlalchemy import text
from sqlalchemy.exc import DBAPIError

from app.db import system_tx
from app.deps import Principal, current_principal

router = APIRouter(prefix="/admin", tags=["admin"])
LIMIT_KEYS = ("locations", "keywords", "campaigns", "competitors", "max_grid_size", "monthly_scan_points", "team_members")


def super_admin(p: Principal = Depends(current_principal)) -> Principal:
    with system_tx() as conn:
        ok = conn.execute(text("SELECT is_super_admin FROM users WHERE id = :u AND is_active"), {"u": p.user_id}).scalar()
    if not ok:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Not found")    # do not reveal that the admin area exists
    return p


def _call(sql: str, params: dict):
    try:
        with system_tx() as conn:
            return conn.execute(text(sql), params)
    except DBAPIError as exc:
        msg = str(getattr(exc, "orig", exc)).split("\n")[0]
        raise HTTPException(status.HTTP_422_UNPROCESSABLE_ENTITY, msg)


class Limits(BaseModel):
    locations: int = Field(ge=0, le=100_000)
    keywords: int = Field(ge=0, le=1_000_000)
    campaigns: int = Field(ge=0, le=100_000)
    competitors: int = Field(ge=0, le=100)
    max_grid_size: int = Field(ge=0, le=21)
    monthly_scan_points: int = Field(ge=0, le=100_000_000)
    team_members: int = Field(ge=1, le=10_000)
    white_label: bool = False


class PlanIn(BaseModel):
    code: str = Field(pattern=r"^[a-z0-9_-]{2,40}$")
    name: str = Field(min_length=1, max_length=80)
    description: Optional[str] = Field(default=None, max_length=500)
    limits: Limits
    monthly_price_cents: Optional[int] = Field(default=None, ge=0)
    currency: str = Field(default="usd", pattern=r"^[a-z]{3}$")
    stripe_price_id: Optional[str] = Field(default=None, pattern=r"^price_[A-Za-z0-9]+$")
    is_public: bool = False
    sort_order: int = 100
    is_active: bool = True


class OrgPlanIn(BaseModel):
    plan_code: str
    trial_ends_at: Optional[datetime] = None


class PriceIn(BaseModel):
    provider: str
    mode: Literal["live", "priority", "standard"]
    unit_price_usd: float = Field(ge=0, le=100)
    results_per_unit: int = Field(default=100, ge=1, le=1000)
    source_url: str = Field(min_length=8, max_length=500)


class MaintenanceIn(BaseModel):
    enabled: bool
    message: Optional[str] = Field(default=None, max_length=300)


@router.get("/overview")
def overview(p: Principal = Depends(super_admin)) -> dict:
    return _call("SELECT admin_overview(:u)", {"u": p.user_id}).scalar()


@router.get("/organizations")
def organizations(q: Optional[str] = Query(default=None, max_length=100), p: Principal = Depends(super_admin)) -> list[dict]:
    return [dict(r) for r in _call("SELECT * FROM admin_organizations(:u, :q)", {"u": p.user_id, "q": q or None}).mappings()]


@router.put("/organizations/{org_id}/plan")
def set_org_plan(org_id: UUID, body: OrgPlanIn, p: Principal = Depends(super_admin)) -> dict:
    _call("SELECT admin_set_org_plan(:u, CAST(:o AS uuid), :c, :t)", {"u": p.user_id, "o": str(org_id), "c": body.plan_code, "t": body.trial_ends_at})
    return {"ok": True}


@router.get("/users")
def users(q: Optional[str] = Query(default=None, max_length=100), p: Principal = Depends(super_admin)) -> list[dict]:
    return [dict(r) for r in _call("SELECT * FROM admin_users(:u, :q)", {"u": p.user_id, "q": q or None}).mappings()]


@router.put("/users/{user_id}/active")
def set_user_active(user_id: UUID, active: bool, p: Principal = Depends(super_admin)) -> dict:
    _call("SELECT admin_set_user_active(:u, CAST(:t AS uuid), :a)", {"u": p.user_id, "t": str(user_id), "a": active})
    return {"ok": True}


@router.get("/plans")
def plans(p: Principal = Depends(super_admin)) -> list[dict]:
    with system_tx() as conn:
        rows = conn.execute(text("""SELECT p.code, p.name, p.description, p.limits, p.monthly_price_cents, p.currency, p.stripe_price_id,
                   p.is_public, p.sort_order, p.is_active, (SELECT count(*) FROM organizations o WHERE o.plan_id = p.id) AS organizations
                FROM plans p ORDER BY p.sort_order, p.code""")).mappings().all()
    return [dict(r) for r in rows]


@router.put("/plans/{code}")
def upsert_plan(code: str, body: PlanIn, p: Principal = Depends(super_admin)) -> dict:
    if code != body.code:
        raise HTTPException(status.HTTP_422_UNPROCESSABLE_ENTITY, "The code in the URL and body differ")
    if code in ("trial", "inactive") and body.stripe_price_id:
        raise HTTPException(status.HTTP_422_UNPROCESSABLE_ENTITY, "System plans cannot be sold")
    _call("""SELECT admin_upsert_plan(:u, :code, :name, CAST(:limits AS jsonb), :d, :price, :cur, :sp, :pub, :sort, :act)""",
          {"u": p.user_id, "code": body.code, "name": body.name, "limits": json.dumps(body.limits.model_dump()), "d": body.description,
           "price": body.monthly_price_cents, "cur": body.currency, "sp": body.stripe_price_id, "pub": body.is_public,
           "sort": body.sort_order, "act": body.is_active})
    return {"ok": True}


@router.get("/api-pricing")
def api_pricing(p: Principal = Depends(super_admin)) -> dict:
    with system_tx() as conn:
        prices = conn.execute(text("""SELECT provider_code, mode::text, unit_price_usd::float8 AS unit_price_usd, results_per_unit,
                                             source_url, verified_on FROM api_pricing ORDER BY provider_code, mode""")).mappings().all()
        providers = conn.execute(text("SELECT code, name, is_enabled FROM api_providers ORDER BY code")).mappings().all()
    return {"prices": [dict(r) for r in prices], "providers": [dict(r) for r in providers]}


@router.put("/api-pricing")
def set_api_price(body: PriceIn, p: Principal = Depends(super_admin)) -> dict:
    _call("SELECT admin_set_api_price(:u, :p, CAST(:m AS execution_mode), :price, :n, :src)",
          {"u": p.user_id, "p": body.provider, "m": body.mode, "price": body.unit_price_usd, "n": body.results_per_unit, "src": body.source_url})
    return {"ok": True}


@router.put("/providers/{code}")
def set_provider(code: str, enabled: bool, p: Principal = Depends(super_admin)) -> dict:
    _call("SELECT admin_set_provider_enabled(:u, :c, :e)", {"u": p.user_id, "c": code, "e": enabled})
    return {"ok": True}


@router.get("/maintenance")
def get_maintenance(p: Principal = Depends(super_admin)) -> dict:
    with system_tx() as conn:
        return conn.execute(text("SELECT value FROM system_settings WHERE key = 'maintenance'")).scalar() or {"enabled": False}


@router.put("/maintenance")
def set_maintenance(body: MaintenanceIn, p: Principal = Depends(super_admin)) -> dict:
    _call("SELECT admin_set_setting(:u, 'maintenance', CAST(:v AS jsonb))", {"u": p.user_id, "v": json.dumps(body.model_dump())})
    return body.model_dump()


@router.get("/audit")
def audit(p: Principal = Depends(super_admin)) -> list[dict]:
    with system_tx() as conn:
        rows = conn.execute(text("""SELECT a.created_at, u.email AS admin, a.action, a.target, a.detail
                                    FROM admin_audit a JOIN users u ON u.id = a.admin_id ORDER BY a.id DESC LIMIT 200""")).mappings().all()
    return [dict(r) for r in rows]
