from __future__ import annotations

from typing import Optional
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Query, status
from pydantic import BaseModel, Field
from sqlalchemy import text

from app.db import tenant_tx
from app.deps import Principal, current_principal, require_role

router = APIRouter(prefix="/clients", tags=["clients"])
COLS = "id::text, name, contact_email, notes, archived_at, created_at"


class ClientIn(BaseModel):
    name: str = Field(min_length=1, max_length=160)
    contact_email: Optional[str] = Field(default=None, max_length=254)
    notes: Optional[str] = Field(default=None, max_length=5000)


@router.get("")
def list_clients(q: Optional[str] = Query(default=None, max_length=100), include_archived: bool = False,
                 p: Principal = Depends(current_principal)) -> list[dict]:
    with tenant_tx(p.org_id) as conn:
        rows = conn.execute(text(f"""SELECT {COLS} FROM clients
                WHERE (CAST(:q AS text) IS NULL OR name ILIKE '%' || CAST(:q AS text) || '%') AND (CAST(:arch AS boolean) OR archived_at IS NULL)
                ORDER BY name"""), {"q": q, "arch": include_archived}).mappings().all()
    return [dict(r) for r in rows]


@router.post("", status_code=status.HTTP_201_CREATED)
def create_client(body: ClientIn, p: Principal = Depends(require_role("manager"))) -> dict:
    with tenant_tx(p.org_id) as conn:
        row = conn.execute(text(f"""INSERT INTO clients (org_id, name, contact_email, notes)
                VALUES (:o, :name, :contact_email, :notes) RETURNING {COLS}"""),
                {"o": p.org_id, **body.model_dump()}).mappings().one()
    return dict(row)


@router.put("/{client_id}")
def update_client(client_id: UUID, body: ClientIn, p: Principal = Depends(require_role("manager"))) -> dict:
    with tenant_tx(p.org_id) as conn:
        row = conn.execute(text(f"""UPDATE clients SET name = :name, contact_email = :contact_email, notes = :notes
                WHERE id = :id RETURNING {COLS}"""), {"id": str(client_id), **body.model_dump()}).mappings().first()
    if row is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Client not found")
    return dict(row)


@router.post("/{client_id}/archive")
def archive_client(client_id: UUID, archived: bool = True, p: Principal = Depends(require_role("manager"))) -> dict:
    with tenant_tx(p.org_id) as conn:
        row = conn.execute(text(f"""UPDATE clients SET archived_at = CASE WHEN CAST(:a AS boolean) THEN now() END
                WHERE id = :id RETURNING {COLS}"""), {"id": str(client_id), "a": archived}).mappings().first()
    if row is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Client not found")
    return dict(row)
