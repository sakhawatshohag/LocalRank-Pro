"""Registration, login, current user, organization switching, invitation acceptance.
Email verification and password reset are PENDING (they need the transactional email integration)."""
from __future__ import annotations

from datetime import datetime, timezone
from typing import Optional
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, Field
from sqlalchemy import text
from sqlalchemy.exc import IntegrityError

from app.config import get_settings
from app.db import system_tx, tenant_tx
from app.deps import Principal, current_principal
from app.security import MIN_PASSWORD_LENGTH, create_access_token, hash_password, token_hash, verify_password

router = APIRouter(prefix="/auth", tags=["auth"])
EMAIL_RE = r"^[^@\s]+@[^@\s]+\.[^@\s]+$"


class RegisterIn(BaseModel):
    email: str = Field(pattern=EMAIL_RE, max_length=254)
    password: str = Field(min_length=MIN_PASSWORD_LENGTH, max_length=128)
    full_name: str = Field(min_length=1, max_length=120)
    organization_name: str = Field(min_length=1, max_length=120)


class LoginIn(BaseModel):
    email: str = Field(max_length=254)
    password: str = Field(max_length=128)


class TokenOut(BaseModel):
    access_token: str
    token_type: str = "bearer"
    org_id: str
    role: str


class SwitchIn(BaseModel):
    org_id: UUID


class AcceptIn(BaseModel):
    token: str = Field(min_length=20, max_length=200)
    password: str = Field(min_length=1, max_length=128)
    full_name: Optional[str] = Field(default=None, max_length=120)


def _token(user_id: str, org_id: str, role: str) -> TokenOut:
    s = get_settings()
    return TokenOut(
        access_token=create_access_token(secret=s.jwt_secret, user_id=user_id, org_id=org_id, role=role,
                                         ttl_minutes=s.access_token_ttl_minutes),
        org_id=org_id, role=role)


@router.post("/register", response_model=TokenOut, status_code=status.HTTP_201_CREATED)
def register(body: RegisterIn) -> TokenOut:
    if not get_settings().allow_signup:
        raise HTTPException(status.HTTP_403_FORBIDDEN, "Sign-up is closed. Please ask your account manager for access.")
    try:
        with system_tx() as conn:
            user_id = conn.execute(
                text("INSERT INTO users (email, password_hash, full_name, last_login_at) VALUES (:e, :p, :n, now()) RETURNING id::text"),
                {"e": body.email.strip(), "p": hash_password(body.password), "n": body.full_name.strip()},
            ).scalar_one()
            org_id = conn.execute(
                text("""INSERT INTO organizations (name, plan_id, trial_ends_at)
                        VALUES (:n, (SELECT id FROM plans WHERE code = 'trial'), now() + make_interval(days => :days))
                        RETURNING id::text"""),
                {"n": body.organization_name.strip(), "days": get_settings().trial_days},
            ).scalar_one()
            conn.execute(text("INSERT INTO organization_members (org_id, user_id, role) VALUES (:o, :u, 'owner')"),
                         {"o": org_id, "u": user_id})
    except IntegrityError:
        raise HTTPException(status.HTTP_409_CONFLICT, "An account with this email already exists")
    return _token(user_id, org_id, "owner")


@router.post("/login", response_model=TokenOut)
def login(body: LoginIn) -> TokenOut:
    with system_tx() as conn:
        user = conn.execute(
            text("SELECT id::text, password_hash FROM users WHERE lower(email) = lower(:e) AND is_active"),
            {"e": body.email.strip()},
        ).first()
        # same error for unknown email and wrong password
        if user is None or not verify_password(body.password, user[1]):
            raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Incorrect email or password")
        conn.execute(text("UPDATE users SET last_login_at = now() WHERE id = :u"), {"u": user[0]})
        member = conn.execute(
            text("SELECT org_id::text, role::text FROM organization_members WHERE user_id = :u ORDER BY created_at LIMIT 1"),
            {"u": user[0]},
        ).first()
    if member is None:
        raise HTTPException(status.HTTP_403_FORBIDDEN, "This account does not belong to an organization")
    return _token(user[0], member[0], member[1])


@router.get("/me")
def me(p: Principal = Depends(current_principal)) -> dict:
    with system_tx() as conn:
        row = conn.execute(
            text("""SELECT u.email, u.full_name, o.name, u.is_super_admin FROM users u, organizations o
                    WHERE u.id = :u AND o.id = :o"""), {"u": p.user_id, "o": p.org_id}).one()
        orgs = conn.execute(text("""SELECT o.id::text, o.name, m.role::text FROM organization_members m
                                    JOIN organizations o ON o.id = m.org_id WHERE m.user_id = :u ORDER BY o.name"""),
                            {"u": p.user_id}).mappings().all()
    return {"user_id": p.user_id, "email": row[0], "full_name": row[1], "org_id": p.org_id, "organization": row[2],
            "role": p.role, "is_super_admin": bool(row[3]), "organizations": [dict(o) for o in orgs]}


@router.post("/switch-org", response_model=TokenOut)
def switch_org(body: SwitchIn, p: Principal = Depends(current_principal)) -> TokenOut:
    with system_tx() as conn:
        role = conn.execute(text("SELECT role::text FROM organization_members WHERE org_id = :o AND user_id = :u"),
                            {"o": str(body.org_id), "u": p.user_id}).scalar()
    if role is None:
        raise HTTPException(status.HTTP_403_FORBIDDEN, "You are not a member of that organization")
    return _token(p.user_id, str(body.org_id), role)


def _invitation(conn, token: str):
    inv = conn.execute(text("SELECT * FROM invitation_by_token(:h)"), {"h": token_hash(token)}).mappings().first()
    if inv is None or inv["accepted_at"] is not None or inv["expires_at"] < datetime.now(timezone.utc):
        raise HTTPException(status.HTTP_404_NOT_FOUND, "This invitation is invalid, expired or already used")
    return inv


@router.get("/invitations/{token}")
def invitation_preview(token: str) -> dict:
    with system_tx() as conn:
        inv = _invitation(conn, token)
        exists = conn.execute(text("SELECT 1 FROM users WHERE lower(email) = lower(:e)"), {"e": inv["email"]}).first() is not None
    return {"organization": inv["org_name"], "email": inv["email"], "role": inv["role"], "account_exists": exists}


@router.post("/accept-invite", response_model=TokenOut)
def accept_invite(body: AcceptIn) -> TokenOut:
    """New email: creates the account with this password.  Existing account: the password must match."""
    with system_tx() as conn:
        inv = _invitation(conn, body.token)
        user = conn.execute(text("SELECT id::text, password_hash, is_active FROM users WHERE lower(email) = lower(:e)"),
                            {"e": inv["email"]}).first()
        if user is None:
            if len(body.password) < MIN_PASSWORD_LENGTH:
                raise HTTPException(status.HTTP_422_UNPROCESSABLE_ENTITY, f"Use at least {MIN_PASSWORD_LENGTH} characters")
            user_id = conn.execute(text("INSERT INTO users (email, password_hash, full_name) VALUES (:e, :p, :n) RETURNING id::text"),
                                   {"e": inv["email"], "p": hash_password(body.password),
                                    "n": (body.full_name or "").strip() or None}).scalar_one()
        else:
            if not user[2] or not verify_password(body.password, user[1]):
                raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Incorrect password for this account")
            user_id = user[0]
    with tenant_tx(str(inv["org_id"])) as conn:
        claimed = conn.execute(text("UPDATE invitations SET accepted_at = now() WHERE id = :i AND accepted_at IS NULL"),
                               {"i": str(inv["id"])}).rowcount
        if claimed == 0:
            raise HTTPException(status.HTTP_404_NOT_FOUND, "This invitation was already used")
        conn.execute(text("""INSERT INTO organization_members (org_id, user_id, role) VALUES (:o, :u, CAST(:r AS member_role))
                             ON CONFLICT (org_id, user_id) DO NOTHING"""),
                     {"o": str(inv["org_id"]), "u": user_id, "r": str(inv["role"])})
    return _token(user_id, str(inv["org_id"]), str(inv["role"]))
