from __future__ import annotations

from typing import Optional
from uuid import UUID
from zoneinfo import available_timezones

from fastapi import APIRouter, Depends, HTTPException, Query, status
from pydantic import BaseModel, Field, field_validator
from sqlalchemy import text
from sqlalchemy.exc import IntegrityError

from app.db import tenant_tx
from app.deps import Principal, current_principal, enforce_plan_limit, require_role

router = APIRouter(prefix="/locations", tags=["locations"])

FIELDS = ["client_id", "name", "gbp_url", "place_id", "cid", "address", "latitude", "longitude", "website", "phone",
          "primary_category", "additional_categories", "country", "state", "city", "postal_code", "time_zone",
          "language_code"]
COLS = "id::text, client_id::text, " + ", ".join(FIELDS[1:]) + ", identity_verified_at, archived_at, created_at"


class LocationIn(BaseModel):
    client_id: Optional[UUID] = None
    name: str = Field(min_length=1, max_length=200)
    gbp_url: Optional[str] = Field(default=None, max_length=2000)
    place_id: Optional[str] = Field(default=None, max_length=300)
    cid: Optional[str] = Field(default=None, max_length=40)
    address: Optional[str] = Field(default=None, max_length=500)
    latitude: float = Field(ge=-85, le=85)
    longitude: float = Field(ge=-180, le=180)
    website: Optional[str] = Field(default=None, max_length=2000)
    phone: Optional[str] = Field(default=None, max_length=40)
    primary_category: Optional[str] = Field(default=None, max_length=200)
    additional_categories: list[str] = Field(default_factory=list, max_length=20)
    country: Optional[str] = Field(default=None, max_length=100)
    state: Optional[str] = Field(default=None, max_length=100)
    city: Optional[str] = Field(default=None, max_length=100)
    postal_code: Optional[str] = Field(default=None, max_length=20)
    time_zone: str = "UTC"
    language_code: str = Field(default="en", min_length=2, max_length=10)

    @field_validator("time_zone")
    @classmethod
    def _tz(cls, v: str) -> str:
        if v not in available_timezones():
            raise ValueError("unknown IANA time zone")
        return v

    def params(self) -> dict:
        d = self.model_dump()
        d["client_id"] = str(d["client_id"]) if d["client_id"] else None
        return d


@router.get("")
def list_locations(client_id: Optional[UUID] = None, q: Optional[str] = Query(default=None, max_length=100),
                   include_archived: bool = False, p: Principal = Depends(current_principal)) -> list[dict]:
    with tenant_tx(p.org_id) as conn:
        rows = conn.execute(text(f"""SELECT {COLS} FROM business_locations
                WHERE (CAST(:c AS uuid) IS NULL OR client_id = CAST(:c AS uuid))
                  AND (CAST(:q AS text) IS NULL OR name ILIKE '%' || CAST(:q AS text) || '%' OR city ILIKE '%' || CAST(:q AS text) || '%')
                  AND (CAST(:arch AS boolean) OR archived_at IS NULL)
                ORDER BY name"""),
                {"c": str(client_id) if client_id else None, "q": q, "arch": include_archived}).mappings().all()
    return [dict(r) for r in rows]


@router.post("", status_code=status.HTTP_201_CREATED)
def create_location(body: LocationIn, p: Principal = Depends(require_role("seo_specialist"))) -> dict:
    names = ", ".join(FIELDS)
    binds = ", ".join(f":{f}" for f in FIELDS)
    try:
        with tenant_tx(p.org_id) as conn:
            count = conn.execute(text("SELECT count(*) FROM business_locations WHERE archived_at IS NULL")).scalar_one()
            enforce_plan_limit(conn, p.org_id, "locations", count)
            # identity_verified_at stays NULL: a Place ID / profile URL is not trusted
            # until it has been confirmed against a provider response.
            row = conn.execute(text(f"""INSERT INTO business_locations (org_id, {names})
                    VALUES (:org, {binds}) RETURNING {COLS}"""), {"org": p.org_id, **body.params()}).mappings().one()
    except IntegrityError:
        raise HTTPException(status.HTTP_422_UNPROCESSABLE_ENTITY, "client_id does not exist in this organization")
    return dict(row)


@router.put("/{location_id}")
def update_location(location_id: UUID, body: LocationIn, p: Principal = Depends(require_role("seo_specialist"))) -> dict:
    sets = ", ".join(f"{f} = :{f}" for f in FIELDS)
    try:
        with tenant_tx(p.org_id) as conn:
            # changing an identifier invalidates any earlier verification
            row = conn.execute(text(f"""UPDATE business_locations SET {sets},
                    identity_verified_at = CASE WHEN place_id IS NOT DISTINCT FROM CAST(:place_id AS text)
                                                 AND cid IS NOT DISTINCT FROM CAST(:cid AS text) THEN identity_verified_at END
                    WHERE id = :id RETURNING {COLS}"""), {"id": str(location_id), **body.params()}).mappings().first()
    except IntegrityError:
        raise HTTPException(status.HTTP_422_UNPROCESSABLE_ENTITY, "client_id does not exist in this organization")
    if row is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Location not found")
    return dict(row)


@router.post("/{location_id}/archive")
def archive_location(location_id: UUID, archived: bool = True, p: Principal = Depends(require_role("manager"))) -> dict:
    with tenant_tx(p.org_id) as conn:
        row = conn.execute(text(f"""UPDATE business_locations SET archived_at = CASE WHEN CAST(:a AS boolean) THEN now() END
                WHERE id = :id RETURNING {COLS}"""), {"id": str(location_id), "a": archived}).mappings().first()
    if row is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Location not found")
    return dict(row)


@router.delete("/{location_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_location(location_id: UUID, p: Principal = Depends(require_role("admin"))) -> None:
    """Only locations without campaigns can be deleted; ranked history is kept, so archive instead."""
    try:
        with tenant_tx(p.org_id) as conn:
            n = conn.execute(text("DELETE FROM business_locations WHERE id = :id"), {"id": str(location_id)}).rowcount
    except IntegrityError:
        raise HTTPException(status.HTTP_409_CONFLICT, "Location has campaigns or scan history; archive it instead")
    if n == 0:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Location not found")
