"""Plans, usage, subscription checkout/portal (Stripe) and the Stripe webhook."""
from __future__ import annotations

import json
import logging

from fastapi import APIRouter, Depends, HTTPException, Request, status
from pydantic import BaseModel, Field
from sqlalchemy import text

from app.billing.stripe import SignatureError, StripeClient, StripeError, verify_signature
from app.config import get_settings
from app.db import tenant_tx
from app.deps import Principal, current_principal, require_role
from app.services.billing import apply_event
from app.services.scans import monthly_usage

router = APIRouter(prefix="/billing", tags=["billing"])
log = logging.getLogger("localrank.billing")
PLAN_FIELDS = ("code", "name", "description", "limits", "monthly_price_cents", "currency", "is_public", "sort_order")
PLAN_COLS = ", ".join(PLAN_FIELDS) + ", (stripe_price_id IS NOT NULL) AS purchasable"
ORG_PLAN_COLS = ", ".join(f"p.{f}" for f in PLAN_FIELDS) + ", (p.stripe_price_id IS NOT NULL) AS purchasable"


class CheckoutIn(BaseModel):
    plan_code: str = Field(min_length=1, max_length=60)


def _client() -> StripeClient:
    s = get_settings()
    if not s.stripe_configured:
        raise HTTPException(status.HTTP_503_SERVICE_UNAVAILABLE, "Online payments are not set up yet. Please contact support.")
    return StripeClient(s.stripe_secret_key, s.stripe_api_version)


@router.get("")
def overview(p: Principal = Depends(current_principal)) -> dict:
    with tenant_tx(p.org_id) as conn:
        org = conn.execute(text(f"""SELECT o.trial_ends_at, {ORG_PLAN_COLS}
                FROM organizations o JOIN plans p ON p.id = o.plan_id WHERE o.id = :o"""), {"o": p.org_id}).mappings().one()
        sub = conn.execute(text("""SELECT status, current_period_end, cancel_at_period_end, (customer_id IS NOT NULL) AS has_customer
                                   FROM subscriptions""")).mappings().first()
        usage = conn.execute(text("""SELECT
                (SELECT count(*) FROM business_locations WHERE archived_at IS NULL) AS locations,
                (SELECT count(*) FROM campaigns WHERE is_active) AS campaigns,
                (SELECT count(*) FROM keywords WHERE NOT is_paused) AS keywords,
                (SELECT coalesce(max(n), 0) FROM (SELECT count(*) n FROM competitors GROUP BY campaign_id) x) AS competitors,
                (SELECT count(*) FROM organization_members WHERE org_id = :o)
                  + (SELECT count(*) FROM invitations WHERE accepted_at IS NULL AND expires_at > now()) AS team_members"""),
                {"o": p.org_id}).mappings().one()
        used, limit = monthly_usage(conn, p.org_id)
        plans = conn.execute(text(f"SELECT {PLAN_COLS} FROM plans WHERE is_public AND is_active ORDER BY sort_order, monthly_price_cents")).mappings().all()
        invoices = conn.execute(text("""SELECT number, status, amount_due_cents, amount_paid_cents, currency, hosted_invoice_url,
                                               invoice_pdf_url, period_start, period_end, created_at
                                        FROM invoices ORDER BY created_at DESC LIMIT 24""")).mappings().all()
    org = dict(org)
    return {"plan": {k: org[k] for k in org if k != "trial_ends_at"}, "trial_ends_at": org["trial_ends_at"],
            "subscription": dict(sub) if sub else None,
            "usage": dict(usage) | {"monthly_scan_points": used}, "monthly_scan_points_limit": limit,
            "plans": [dict(x) for x in plans], "invoices": [dict(i) for i in invoices],
            "payments_enabled": get_settings().stripe_configured}


@router.post("/checkout")
def checkout(body: CheckoutIn, p: Principal = Depends(require_role("owner"))) -> dict:
    client = _client()
    with tenant_tx(p.org_id) as conn:
        plan = conn.execute(text("SELECT stripe_price_id FROM plans WHERE code = :c AND is_public AND is_active"),
                            {"c": body.plan_code}).first()
        if plan is None or not plan[0]:
            raise HTTPException(status.HTTP_422_UNPROCESSABLE_ENTITY, "This plan cannot be bought online")
        sub = conn.execute(text("SELECT customer_id, status FROM subscriptions")).first()
        email = conn.execute(text("SELECT email FROM users WHERE id = :u"), {"u": p.user_id}).scalar()
    if sub and sub[1] in ("active", "trialing", "past_due"):
        raise HTTPException(status.HTTP_409_CONFLICT, "You already have a subscription. Use 'Manage billing' to change plan.")
    base = get_settings().app_url.rstrip("/")
    try:
        session = client.create_checkout_session(
            price=plan[0], success_url=f"{base}/billing?checkout=success&session_id={{CHECKOUT_SESSION_ID}}",
            cancel_url=f"{base}/billing?checkout=cancelled", client_reference_id=p.org_id,
            customer=sub[0] if sub else None, customer_email=None if sub else email,
            metadata={"org_id": p.org_id, "plan_code": body.plan_code})
    except StripeError as exc:
        log.error("checkout failed for org %s: %s", p.org_id, exc)
        raise HTTPException(status.HTTP_502_BAD_GATEWAY, "The payment page could not be opened. Please try again.")
    return {"url": session["url"]}


@router.post("/portal")
def portal(p: Principal = Depends(require_role("owner"))) -> dict:
    client = _client()
    with tenant_tx(p.org_id) as conn:
        customer = conn.execute(text("SELECT customer_id FROM subscriptions")).scalar()
    if not customer:
        raise HTTPException(status.HTTP_409_CONFLICT, "There is no billing account yet. Choose a plan first.")
    try:
        session = client.create_portal_session(customer=customer, return_url=get_settings().app_url.rstrip("/") + "/billing")
    except StripeError as exc:
        log.error("portal failed for org %s: %s", p.org_id, exc)
        raise HTTPException(status.HTTP_502_BAD_GATEWAY, "The billing portal could not be opened. Please try again.")
    return {"url": session["url"]}


@router.post("/webhook/stripe", include_in_schema=False)
async def stripe_webhook(request: Request) -> dict:
    payload = await request.body()            # raw bytes: the signature covers the exact body
    try:
        verify_signature(payload, request.headers.get("stripe-signature"), get_settings().stripe_webhook_secret or "")
        event = json.loads(payload)
    except (SignatureError, ValueError) as exc:
        log.warning("rejected Stripe webhook: %s", exc)
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "Invalid webhook")
    result = apply_event(event)
    if result == "unknown_customer":
        raise HTTPException(status.HTTP_409_CONFLICT, "Customer not linked yet; retry later")
    return {"received": True, "result": result}
