"""Scheduled scans: one schedule per campaign."""
from __future__ import annotations

from datetime import datetime, time, timezone
from decimal import Decimal
from typing import Literal, Optional
from uuid import UUID
from zoneinfo import ZoneInfo

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, Field
from sqlalchemy import text
from sqlalchemy.engine import Connection

from app.config import get_settings
from app.db import tenant_tx
from app.deps import Principal, current_principal, require_role
from app.engine.schedule import ScheduleError, interval_for, next_run, runs_per_month
from app.services.scans import ScanSetupError, active_keyword_count, choose_provider_code, estimate, monthly_usage

router = APIRouter(tags=["schedules"])
Frequency = Literal["daily", "every_2_days", "weekly", "biweekly", "monthly", "custom"]
COLS = """s.id::text, s.campaign_id::text, s.frequency::text, s.interval_days, to_char(s.local_time, 'HH24:MI') AS local_time,
          s.anchor_date, s.is_paused, s.next_run_at, s.last_run_at, s.last_occurrence, s.last_error, s.updated_at"""


class ScheduleIn(BaseModel):
    frequency: Frequency
    interval_days: Optional[int] = Field(default=None, ge=1, le=90)
    local_time: time = time(6, 0)
    is_paused: bool = False


def _campaign(conn: Connection, campaign_id: UUID):
    row = conn.execute(text("""SELECT c.id::text, c.grid_size, c.depth, l.time_zone FROM campaigns c
                               JOIN business_locations l ON l.id = c.location_id WHERE c.id = :c"""),
                       {"c": str(campaign_id)}).mappings().first()
    if row is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Campaign not found")
    return row


def _projection(conn: Connection, org_id: str, campaign, frequency: str, interval_days: Optional[int]) -> dict:
    """Cost and allowance estimate for the schedule (per run and per month)."""
    keywords = active_keyword_count(conn, campaign["id"])
    points = campaign["grid_size"] ** 2
    runs = runs_per_month(frequency, interval_days)
    used, limit = monthly_usage(conn, org_id)
    try:
        per_run = estimate(conn, choose_provider_code(get_settings()), points, keywords, campaign["depth"]).estimated_cost_usd
        per_run_s, per_month_s = str(per_run), str((per_run * Decimal(str(runs))).quantize(Decimal("0.0001")))
    except ScanSetupError:
        per_run_s = per_month_s = None   # no provider configured: cost unknown, never guessed
    return {"active_keywords": keywords, "points_per_run": points * keywords, "runs_per_month": runs,
            "points_per_month": round(points * keywords * runs), "estimated_cost_per_run_usd": per_run_s,
            "estimated_cost_per_month_usd": per_month_s, "monthly_points_used": used, "monthly_points_limit": limit}


@router.get("/schedules")
def list_schedules(p: Principal = Depends(current_principal)) -> list[dict]:
    with tenant_tx(p.org_id) as conn:
        rows = conn.execute(text(f"""SELECT {COLS}, c.name AS campaign_name, c.is_active AS campaign_active,
                   l.name AS location_name, l.time_zone,
                   (SELECT count(*) FROM keywords k WHERE k.campaign_id = c.id AND NOT k.is_paused) AS active_keywords,
                   (SELECT json_agg(json_build_object('id', x.id, 'keyword', x.keyword_text, 'status', x.status))
                      FROM scans x WHERE x.schedule_id = s.id AND x.idempotency_key LIKE '%:' || s.last_occurrence) AS last_scans
                FROM scan_schedules s JOIN campaigns c ON c.id = s.campaign_id
                JOIN business_locations l ON l.id = c.location_id
                ORDER BY s.is_paused, s.next_run_at""")).mappings().all()
    return [dict(r) for r in rows]


@router.get("/campaigns/{campaign_id}/schedule")
def get_schedule(campaign_id: UUID, frequency: Optional[Frequency] = None, interval_days: Optional[int] = None,
                 p: Principal = Depends(current_principal)) -> dict:
    """Current schedule (or null) plus a projection.  Pass frequency/interval_days to preview
    the projection for a schedule that is not saved yet."""
    with tenant_tx(p.org_id) as conn:
        c = _campaign(conn, campaign_id)
        s = conn.execute(text(f"SELECT {COLS} FROM scan_schedules s WHERE s.campaign_id = :c"), {"c": str(campaign_id)}).mappings().first()
        freq = frequency or (s["frequency"] if s else "weekly")
        days = interval_days if frequency else (s["interval_days"] if s else None)
        try:
            interval_for(freq, days)
        except ScheduleError as exc:
            raise HTTPException(status.HTTP_422_UNPROCESSABLE_ENTITY, str(exc))
        return {"schedule": dict(s) if s else None, "time_zone": c["time_zone"],
                "projection": _projection(conn, p.org_id, c, freq, days)}


@router.put("/campaigns/{campaign_id}/schedule")
def put_schedule(campaign_id: UUID, body: ScheduleIn, p: Principal = Depends(require_role("seo_specialist"))) -> dict:
    now = datetime.now(timezone.utc)
    with tenant_tx(p.org_id) as conn:
        c = _campaign(conn, campaign_id)
        existing = conn.execute(text("""SELECT frequency::text, interval_days, local_time, anchor_date FROM scan_schedules
                                        WHERE campaign_id = :c FOR UPDATE"""), {"c": str(campaign_id)}).mappings().first()
        # keep the rhythm when only pausing/resuming; a new frequency or time starts from today
        same_rhythm = existing is not None and existing["frequency"] == body.frequency and \
            existing["interval_days"] == body.interval_days and existing["local_time"] == body.local_time
        anchor = existing["anchor_date"] if same_rhythm else now.astimezone(ZoneInfo(c["time_zone"])).date()
        try:
            nxt = next_run(body.frequency, body.local_time, c["time_zone"], anchor, now, interval_days=body.interval_days)
        except ScheduleError as exc:
            raise HTTPException(status.HTTP_422_UNPROCESSABLE_ENTITY, str(exc))
        conn.execute(text("""
            INSERT INTO scan_schedules (org_id, campaign_id, frequency, interval_days, local_time, anchor_date, is_paused, next_run_at)
            VALUES (:o, :c, CAST(:f AS schedule_freq), :d, :t, :a, :paused, :n)
            ON CONFLICT (campaign_id) DO UPDATE SET frequency = EXCLUDED.frequency, interval_days = EXCLUDED.interval_days,
                local_time = EXCLUDED.local_time, anchor_date = EXCLUDED.anchor_date, is_paused = EXCLUDED.is_paused,
                next_run_at = EXCLUDED.next_run_at, last_error = NULL, updated_at = now()"""),
            {"o": p.org_id, "c": str(campaign_id), "f": body.frequency, "d": body.interval_days, "t": body.local_time,
             "a": anchor, "paused": body.is_paused, "n": nxt})
        s = conn.execute(text(f"SELECT {COLS} FROM scan_schedules s WHERE s.campaign_id = :c"), {"c": str(campaign_id)}).mappings().one()
        return {"schedule": dict(s), "time_zone": c["time_zone"],
                "projection": _projection(conn, p.org_id, c, body.frequency, body.interval_days)}


@router.delete("/campaigns/{campaign_id}/schedule", status_code=status.HTTP_204_NO_CONTENT)
def delete_schedule(campaign_id: UUID, p: Principal = Depends(require_role("manager"))) -> None:
    """Stops future scans.  Scans that already ran stay in history."""
    with tenant_tx(p.org_id) as conn:
        n = conn.execute(text("DELETE FROM scan_schedules WHERE campaign_id = :c"), {"c": str(campaign_id)}).rowcount
    if n == 0:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "This campaign has no schedule")
