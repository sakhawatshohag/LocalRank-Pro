"""In-app notifications for the signed-in user, and their preferences."""
from __future__ import annotations

from typing import Literal
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Query, status
from pydantic import BaseModel
from sqlalchemy import text

from app.db import tenant_tx
from app.deps import Principal, current_principal
from app.services.notifications import TYPES

router = APIRouter(prefix="/notifications", tags=["notifications"])
NotificationType = Literal["scan_completed", "scan_failed", "ranking_improved", "ranking_declined", "competitor_change",
                           "usage_warning", "schedule_problem", "report_ready", "report_failed",
                           "billing_problem"]


class PreferenceIn(BaseModel):
    type: NotificationType
    in_app: bool
    email: bool


@router.get("")
def list_notifications(unread_only: bool = False, limit: int = Query(default=30, ge=1, le=100),
                       p: Principal = Depends(current_principal)) -> dict:
    with tenant_tx(p.org_id) as conn:
        rows = conn.execute(text("""SELECT id::text, type::text, title, body, link, data, read_at, created_at
                FROM notifications WHERE user_id = :u AND (NOT CAST(:unread AS boolean) OR read_at IS NULL)
                ORDER BY created_at DESC LIMIT :l"""), {"u": p.user_id, "unread": unread_only, "l": limit}).mappings().all()
        unread = conn.execute(text("SELECT count(*) FROM notifications WHERE user_id = :u AND read_at IS NULL"),
                              {"u": p.user_id}).scalar_one()
    return {"unread_count": unread, "items": [dict(r) for r in rows]}


@router.post("/{notification_id}/read")
def mark_read(notification_id: UUID, p: Principal = Depends(current_principal)) -> dict:
    with tenant_tx(p.org_id) as conn:
        n = conn.execute(text("""UPDATE notifications SET read_at = coalesce(read_at, now())
                                 WHERE id = :id AND user_id = :u"""), {"id": str(notification_id), "u": p.user_id}).rowcount
    if n == 0:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Notification not found")
    return {"ok": True}


@router.post("/read-all")
def mark_all_read(p: Principal = Depends(current_principal)) -> dict:
    with tenant_tx(p.org_id) as conn:
        n = conn.execute(text("UPDATE notifications SET read_at = now() WHERE user_id = :u AND read_at IS NULL"),
                         {"u": p.user_id}).rowcount
    return {"marked": n}


@router.get("/preferences")
def get_preferences(p: Principal = Depends(current_principal)) -> list[dict]:
    with tenant_tx(p.org_id) as conn:
        saved = {r[0]: (r[1], r[2]) for r in conn.execute(text(
            "SELECT type::text, in_app, email FROM notification_preferences WHERE user_id = :u"), {"u": p.user_id})}
    return [{"type": t, "in_app": saved.get(t, (True, False))[0], "email": saved.get(t, (True, False))[1]} for t in TYPES]


@router.put("/preferences")
def put_preferences(body: list[PreferenceIn], p: Principal = Depends(current_principal)) -> list[dict]:
    with tenant_tx(p.org_id) as conn:
        for pref in body:
            conn.execute(text("""INSERT INTO notification_preferences (org_id, user_id, type, in_app, email)
                    VALUES (:o, :u, CAST(:t AS notification_type), :a, :e)
                    ON CONFLICT (org_id, user_id, type) DO UPDATE SET in_app = EXCLUDED.in_app, email = EXCLUDED.email"""),
                    {"o": p.org_id, "u": p.user_id, "t": pref.type, "a": pref.in_app, "e": pref.email})
    return get_preferences(p)
