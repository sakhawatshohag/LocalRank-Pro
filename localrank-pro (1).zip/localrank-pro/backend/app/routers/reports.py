"""Reports, report schedules, white-label branding and client logos."""
from __future__ import annotations

import base64
from datetime import date, datetime, time, timezone
from typing import Literal, Optional
from uuid import UUID
from zoneinfo import ZoneInfo, available_timezones

from fastapi import APIRouter, Depends, HTTPException, Response, status
from pydantic import BaseModel, Field, field_validator, model_validator
from sqlalchemy import text

from app.db import tenant_tx
from app.deps import Principal, current_principal, require_role
from app.engine.schedule import next_run
from app.reporting.images import LogoError, clean_logo
from app.services.reports import ReportError, create_report

router = APIRouter(tags=["reports"])
ReportType = Literal["weekly", "monthly", "geogrid_comparison", "competitor_comparison", "performance", "custom"]
LIST_COLS = """r.id::text, r.client_id::text, c.name AS client_name, r.report_type::text, r.title, r.period_start, r.period_end,
               r.status::text, r.is_demo, r.page_count, r.error, r.created_at, r.generated_at, r.schedule_id::text, r.options"""


def enqueue_report(org_id: str, report_id: str) -> None:
    from app.worker import generate_report_task      # lazy: the API starts without a broker
    generate_report_task.delay(org_id, report_id)


class ReportIn(BaseModel):
    client_id: UUID
    report_type: ReportType
    title: Optional[str] = Field(default=None, max_length=200)
    period_start: date
    period_end: date
    campaign_ids: Optional[list[UUID]] = None
    previous_scan_id: Optional[UUID] = None
    current_scan_id: Optional[UUID] = None
    include_competitors: bool = True
    include_history: bool = True
    recommendations: Optional[str] = Field(default=None, max_length=5000)

    @model_validator(mode="after")
    def _check(self):
        if self.period_end < self.period_start:
            raise ValueError("period_end must not be before period_start")
        if (self.period_end - self.period_start).days > 400:
            raise ValueError("a report can cover at most 400 days")
        if self.report_type == "geogrid_comparison" and not (self.previous_scan_id and self.current_scan_id):
            raise ValueError("a GeoGrid comparison needs previous_scan_id and current_scan_id")
        return self


class ReportScheduleIn(BaseModel):
    report_type: Literal["weekly", "monthly"]
    title: Optional[str] = Field(default=None, max_length=200)
    campaign_ids: Optional[list[UUID]] = None
    time_zone: str = "UTC"
    local_time: time = time(7, 0)
    is_paused: bool = False

    @field_validator("time_zone")
    @classmethod
    def _tz(cls, v: str) -> str:
        if v not in available_timezones():
            raise ValueError("unknown IANA time zone")
        return v


class BrandingIn(BaseModel):
    agency_name: Optional[str] = Field(default=None, max_length=120)
    website: Optional[str] = Field(default=None, max_length=200)
    email: Optional[str] = Field(default=None, max_length=200)
    phone: Optional[str] = Field(default=None, max_length=40)
    primary_color: str = Field(default="#0b1f3a", pattern=r"^#[0-9a-fA-F]{6}$")
    footer_text: Optional[str] = Field(default=None, max_length=200)


class LogoIn(BaseModel):
    data_base64: str = Field(max_length=1_500_000)   # ~1 MB image; data: URLs accepted


# ------------------------------------------------------------------ reports
@router.get("/reports")
def list_reports(client_id: Optional[UUID] = None, p: Principal = Depends(current_principal)) -> list[dict]:
    with tenant_tx(p.org_id) as conn:
        rows = conn.execute(text(f"""SELECT {LIST_COLS} FROM reports r JOIN clients c ON c.id = r.client_id
                WHERE (CAST(:c AS uuid) IS NULL OR r.client_id = CAST(:c AS uuid))
                ORDER BY r.created_at DESC LIMIT 200"""), {"c": str(client_id) if client_id else None}).mappings().all()
    return [dict(r) for r in rows]


@router.post("/reports", status_code=status.HTTP_202_ACCEPTED)
def create(body: ReportIn, p: Principal = Depends(require_role("seo_specialist"))) -> dict:
    opts = body.model_dump(include={"include_competitors", "include_history", "recommendations"})
    opts["campaign_ids"] = [str(x) for x in body.campaign_ids] if body.campaign_ids else None
    if body.report_type == "geogrid_comparison":
        opts |= {"previous_scan_id": str(body.previous_scan_id), "current_scan_id": str(body.current_scan_id)}
    if body.report_type == "competitor_comparison":
        opts["include_competitors"] = True
    with tenant_tx(p.org_id) as conn:
        if conn.execute(text("SELECT 1 FROM clients WHERE id = :c"), {"c": str(body.client_id)}).first() is None:
            raise HTTPException(status.HTTP_404_NOT_FOUND, "Client not found")
        try:
            rid = create_report(conn, p.org_id, str(body.client_id), body.report_type, body.period_start, body.period_end,
                                opts, body.title, created_by=p.user_id)
        except ReportError as exc:
            raise HTTPException(status.HTTP_422_UNPROCESSABLE_ENTITY, str(exc))
    enqueue_report(p.org_id, rid)
    return {"id": rid, "status": "queued"}


def _file(org_id: str, report_id: UUID, column: str):
    expr = "encode(pdf, 'base64')" if column == "pdf" else "csv"
    with tenant_tx(org_id) as conn:
        r = conn.execute(text(f"SELECT status::text, title, period_end, {expr} FROM reports WHERE id = :r"), {"r": str(report_id)}).first()
    if r is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Report not found")
    if r[0] != "ready":
        raise HTTPException(status.HTTP_409_CONFLICT, f"The report is {r[0]}")
    safe = "".join(ch if ch.isalnum() or ch in "-_" else "-" for ch in r[1])[:60].strip("-") or "report"
    return r[3], f"{safe}-{r[2]}"


@router.get("/reports/{report_id}/pdf")
def download_pdf(report_id: UUID, p: Principal = Depends(current_principal)) -> Response:
    data, name = _file(p.org_id, report_id, "pdf")
    return Response(base64.b64decode(data), media_type="application/pdf",
                    headers={"Content-Disposition": f'attachment; filename="{name}.pdf"', "Cache-Control": "private, no-store"})


@router.get("/reports/{report_id}/csv")
def download_csv(report_id: UUID, p: Principal = Depends(current_principal)) -> Response:
    data, name = _file(p.org_id, report_id, "csv")
    return Response(data, media_type="text/csv; charset=utf-8",
                    headers={"Content-Disposition": f'attachment; filename="{name}.csv"', "Cache-Control": "private, no-store"})


@router.post("/reports/{report_id}/retry", status_code=status.HTTP_202_ACCEPTED)
def retry(report_id: UUID, p: Principal = Depends(require_role("seo_specialist"))) -> dict:
    with tenant_tx(p.org_id) as conn:
        n = conn.execute(text("""UPDATE reports SET status = 'queued', error = NULL WHERE id = :r AND status = 'failed'"""),
                         {"r": str(report_id)}).rowcount
    if n == 0:
        raise HTTPException(status.HTTP_409_CONFLICT, "Only failed reports can be retried")
    enqueue_report(p.org_id, str(report_id))
    return {"id": str(report_id), "status": "queued"}


@router.delete("/reports/{report_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete(report_id: UUID, p: Principal = Depends(require_role("manager"))) -> None:
    with tenant_tx(p.org_id) as conn:
        n = conn.execute(text("DELETE FROM reports WHERE id = :r AND status <> 'generating'"), {"r": str(report_id)}).rowcount
    if n == 0:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Report not found or still generating")


# ------------------------------------------------------------------ report schedules
SCHED_COLS = """s.id::text, s.client_id::text, s.report_type::text, s.title, s.campaign_ids, s.time_zone,
                to_char(s.local_time, 'HH24:MI') AS local_time, s.is_paused, s.next_run_at, s.last_run_at, s.last_error"""


@router.get("/clients/{client_id}/report-schedules")
def list_report_schedules(client_id: UUID, p: Principal = Depends(current_principal)) -> list[dict]:
    with tenant_tx(p.org_id) as conn:
        rows = conn.execute(text(f"SELECT {SCHED_COLS} FROM report_schedules s WHERE s.client_id = :c ORDER BY s.report_type"),
                            {"c": str(client_id)}).mappings().all()
    return [dict(r) for r in rows]


@router.put("/clients/{client_id}/report-schedules")
def put_report_schedule(client_id: UUID, body: ReportScheduleIn, p: Principal = Depends(require_role("seo_specialist"))) -> dict:
    """Weekly reports run on the weekday of the day they are set up and cover the previous 7 days;
    monthly reports run on the 1st of each month and cover the previous calendar month."""
    now = datetime.now(timezone.utc)
    anchor = now.astimezone(ZoneInfo(body.time_zone)).date()
    if body.report_type == "monthly":
        anchor = anchor.replace(day=1)                     # first of the month: the month just ended is complete
    nxt = next_run("weekly" if body.report_type == "weekly" else "monthly", body.local_time, body.time_zone, anchor, now)
    with tenant_tx(p.org_id) as conn:
        if conn.execute(text("SELECT 1 FROM clients WHERE id = :c"), {"c": str(client_id)}).first() is None:
            raise HTTPException(status.HTTP_404_NOT_FOUND, "Client not found")
        conn.execute(text("""
            INSERT INTO report_schedules (org_id, client_id, report_type, title, campaign_ids, time_zone, local_time, anchor_date,
                                          is_paused, next_run_at)
            VALUES (:o, :c, CAST(:t AS report_type), :title, CAST(:ids AS uuid[]), :tz, :lt, :a, :paused, :n)
            ON CONFLICT (client_id, report_type) DO UPDATE SET title = EXCLUDED.title, campaign_ids = EXCLUDED.campaign_ids,
                time_zone = EXCLUDED.time_zone, local_time = EXCLUDED.local_time, anchor_date = EXCLUDED.anchor_date,
                is_paused = EXCLUDED.is_paused, next_run_at = EXCLUDED.next_run_at, last_error = NULL"""),
            {"o": p.org_id, "c": str(client_id), "t": body.report_type, "title": body.title,
             "ids": [str(x) for x in body.campaign_ids] if body.campaign_ids else None, "tz": body.time_zone,
             "lt": body.local_time, "a": anchor, "paused": body.is_paused, "n": nxt})
        row = conn.execute(text(f"SELECT {SCHED_COLS} FROM report_schedules s WHERE s.client_id = :c AND s.report_type = CAST(:t AS report_type)"),
                           {"c": str(client_id), "t": body.report_type}).mappings().one()
    return dict(row)


@router.delete("/clients/{client_id}/report-schedules/{report_type}", status_code=status.HTTP_204_NO_CONTENT)
def delete_report_schedule(client_id: UUID, report_type: Literal["weekly", "monthly"],
                           p: Principal = Depends(require_role("manager"))) -> None:
    with tenant_tx(p.org_id) as conn:
        n = conn.execute(text("DELETE FROM report_schedules WHERE client_id = :c AND report_type = CAST(:t AS report_type)"),
                         {"c": str(client_id), "t": report_type}).rowcount
    if n == 0:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "No such report schedule")


# ------------------------------------------------------------------ branding and logos
@router.get("/branding")
def get_branding(p: Principal = Depends(current_principal)) -> dict:
    with tenant_tx(p.org_id) as conn:
        b = conn.execute(text("""SELECT agency_name, website, email, phone, primary_color, footer_text,
                                        logo_png IS NOT NULL AS has_logo FROM report_branding""")).mappings().first()
        wl = conn.execute(text("""SELECT coalesce((pl.limits ->> 'white_label')::boolean, false) FROM organizations o
                                  JOIN plans pl ON pl.id = o.plan_id WHERE o.id = :o"""), {"o": p.org_id}).scalar()
    return (dict(b) if b else BrandingIn().model_dump() | {"has_logo": False}) | {"white_label_enabled": bool(wl)}


@router.put("/branding")
def put_branding(body: BrandingIn, p: Principal = Depends(require_role("admin"))) -> dict:
    with tenant_tx(p.org_id) as conn:
        conn.execute(text("""INSERT INTO report_branding (org_id, agency_name, website, email, phone, primary_color, footer_text)
                VALUES (:o, :agency_name, :website, :email, :phone, :primary_color, :footer_text)
                ON CONFLICT (org_id) DO UPDATE SET agency_name = EXCLUDED.agency_name, website = EXCLUDED.website,
                    email = EXCLUDED.email, phone = EXCLUDED.phone, primary_color = EXCLUDED.primary_color,
                    footer_text = EXCLUDED.footer_text, updated_at = now()"""), {"o": p.org_id, **body.model_dump()})
    return get_branding(p)


def _logo_response(data: Optional[str]) -> Response:
    if not data:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "No logo uploaded")
    return Response(base64.b64decode(data), media_type="image/png", headers={"Cache-Control": "private, max-age=60"})


@router.put("/branding/logo")
def put_agency_logo(body: LogoIn, p: Principal = Depends(require_role("admin"))) -> dict:
    try:
        png = clean_logo(body.data_base64)
    except LogoError as exc:
        raise HTTPException(status.HTTP_422_UNPROCESSABLE_ENTITY, str(exc))
    with tenant_tx(p.org_id) as conn:
        conn.execute(text("""INSERT INTO report_branding (org_id, logo_png) VALUES (:o, decode(:png, 'base64'))
                             ON CONFLICT (org_id) DO UPDATE SET logo_png = EXCLUDED.logo_png, updated_at = now()"""),
                     {"o": p.org_id, "png": base64.b64encode(png).decode()})
    return {"ok": True, "bytes": len(png)}


@router.get("/branding/logo")
def get_agency_logo(p: Principal = Depends(current_principal)) -> Response:
    with tenant_tx(p.org_id) as conn:
        return _logo_response(conn.execute(text("SELECT encode(logo_png, 'base64') FROM report_branding")).scalar())


@router.delete("/branding/logo", status_code=status.HTTP_204_NO_CONTENT)
def delete_agency_logo(p: Principal = Depends(require_role("admin"))) -> None:
    with tenant_tx(p.org_id) as conn:
        conn.execute(text("UPDATE report_branding SET logo_png = NULL, updated_at = now()"))


@router.put("/clients/{client_id}/logo")
def put_client_logo(client_id: UUID, body: LogoIn, p: Principal = Depends(require_role("manager"))) -> dict:
    try:
        png = clean_logo(body.data_base64)
    except LogoError as exc:
        raise HTTPException(status.HTTP_422_UNPROCESSABLE_ENTITY, str(exc))
    with tenant_tx(p.org_id) as conn:
        n = conn.execute(text("UPDATE clients SET logo_png = decode(:png, 'base64') WHERE id = :c"),
                         {"png": base64.b64encode(png).decode(), "c": str(client_id)}).rowcount
    if n == 0:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Client not found")
    return {"ok": True, "bytes": len(png)}


@router.get("/clients/{client_id}/logo")
def get_client_logo(client_id: UUID, p: Principal = Depends(current_principal)) -> Response:
    with tenant_tx(p.org_id) as conn:
        return _logo_response(conn.execute(text("SELECT encode(logo_png, 'base64') FROM clients WHERE id = :c"),
                                           {"c": str(client_id)}).scalar())


@router.delete("/clients/{client_id}/logo", status_code=status.HTTP_204_NO_CONTENT)
def delete_client_logo(client_id: UUID, p: Principal = Depends(require_role("manager"))) -> None:
    with tenant_tx(p.org_id) as conn:
        conn.execute(text("UPDATE clients SET logo_png = NULL WHERE id = :c"), {"c": str(client_id)})
