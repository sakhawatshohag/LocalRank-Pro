"""Team members, roles and invitations.

Invitations are links (the token is shown once, only its SHA-256 is stored).  Email delivery is
not connected yet, so the inviter shares the link.
"""
from __future__ import annotations

import secrets
from datetime import datetime, timedelta, timezone
from typing import Literal
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, Field
from sqlalchemy import text
from sqlalchemy.engine import Connection
from sqlalchemy.exc import IntegrityError

from app.config import get_settings
from app.db import tenant_tx
from app.deps import Principal, current_principal, enforce_plan_limit, require_role
from app.security import ROLE_RANK, token_hash

router = APIRouter(prefix="/team", tags=["team"])
AssignableRole = Literal["admin", "manager", "seo_specialist", "client_viewer"]
INVITE_DAYS = 7


class InviteIn(BaseModel):
    email: str = Field(pattern=r"^[^@\s]+@[^@\s]+\.[^@\s]+$", max_length=254)
    role: AssignableRole


class RoleIn(BaseModel):
    role: Literal["owner", "admin", "manager", "seo_specialist", "client_viewer"]


def _can_manage(actor: str, target: str) -> bool:
    """Admins manage roles below admin; only owners manage admins and owners."""
    return actor == "owner" or (actor == "admin" and ROLE_RANK[target] < ROLE_RANK["admin"])


def _owners(conn: Connection, org_id: str) -> int:
    return conn.execute(text("SELECT count(*) FROM organization_members WHERE org_id = :o AND role = 'owner'"), {"o": org_id}).scalar_one()


@router.get("")
def team(p: Principal = Depends(current_principal)) -> dict:
    with tenant_tx(p.org_id) as conn:
        members = conn.execute(text("""SELECT u.id::text AS user_id, u.email, u.full_name, m.role::text, m.created_at, u.last_login_at
                FROM organization_members m JOIN users u ON u.id = m.user_id WHERE m.org_id = :o
                ORDER BY CASE m.role WHEN 'owner' THEN 0 WHEN 'admin' THEN 1 WHEN 'manager' THEN 2 WHEN 'seo_specialist' THEN 3 ELSE 4 END, u.email"""),
                {"o": p.org_id}).mappings().all()
        invites = conn.execute(text("""SELECT id::text, email, role::text, expires_at, created_at FROM invitations
                WHERE accepted_at IS NULL ORDER BY created_at DESC""")).mappings().all()
    return {"members": [dict(m) for m in members], "invitations": [dict(i) for i in invites]}


@router.post("/invitations", status_code=status.HTTP_201_CREATED)
def invite(body: InviteIn, p: Principal = Depends(require_role("admin"))) -> dict:
    if not _can_manage(p.role, body.role):
        raise HTTPException(status.HTTP_403_FORBIDDEN, "Only owners can invite admins")
    token = secrets.token_urlsafe(32)
    try:
        with tenant_tx(p.org_id) as conn:
            if conn.execute(text("""SELECT 1 FROM organization_members m JOIN users u ON u.id = m.user_id
                                    WHERE m.org_id = :o AND lower(u.email) = lower(:e)"""), {"o": p.org_id, "e": body.email}).first():
                raise HTTPException(status.HTTP_409_CONFLICT, "This person is already a member")
            conn.execute(text("DELETE FROM invitations WHERE accepted_at IS NULL AND expires_at < now()"))
            seats = conn.execute(text("""SELECT (SELECT count(*) FROM organization_members WHERE org_id = :o)
                                              + (SELECT count(*) FROM invitations WHERE accepted_at IS NULL)"""), {"o": p.org_id}).scalar_one()
            enforce_plan_limit(conn, p.org_id, "team_members", seats)
            row = conn.execute(text("""INSERT INTO invitations (org_id, email, role, token_hash, invited_by, expires_at)
                    VALUES (:o, :e, CAST(:r AS member_role), :h, :u, :exp) RETURNING id::text, expires_at"""),
                    {"o": p.org_id, "e": body.email.strip(), "r": body.role, "h": token_hash(token), "u": p.user_id,
                     "exp": datetime.now(timezone.utc) + timedelta(days=INVITE_DAYS)}).one()
    except IntegrityError:
        raise HTTPException(status.HTTP_409_CONFLICT, "There is already a pending invitation for this email")
    return {"id": row[0], "expires_at": row[1], "invite_url": f"{get_settings().app_url.rstrip('/')}/invite/{token}",
            "note": "Share this link with the person. It is shown only once and works for 7 days."}


@router.delete("/invitations/{invitation_id}", status_code=status.HTTP_204_NO_CONTENT)
def revoke(invitation_id: UUID, p: Principal = Depends(require_role("admin"))) -> None:
    with tenant_tx(p.org_id) as conn:
        n = conn.execute(text("DELETE FROM invitations WHERE id = :i AND accepted_at IS NULL"), {"i": str(invitation_id)}).rowcount
    if n == 0:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Invitation not found")


@router.patch("/members/{user_id}")
def change_role(user_id: UUID, body: RoleIn, p: Principal = Depends(require_role("admin"))) -> dict:
    if str(user_id) == p.user_id:
        raise HTTPException(status.HTTP_409_CONFLICT, "You cannot change your own role")
    with tenant_tx(p.org_id) as conn:
        current = conn.execute(text("SELECT role::text FROM organization_members WHERE org_id = :o AND user_id = :u FOR UPDATE"),
                               {"o": p.org_id, "u": str(user_id)}).scalar()
        if current is None:
            raise HTTPException(status.HTTP_404_NOT_FOUND, "Member not found")
        if not (_can_manage(p.role, current) and _can_manage(p.role, body.role)):
            raise HTTPException(status.HTTP_403_FORBIDDEN, "Only owners can change admins and owners")
        if current == "owner" and body.role != "owner" and _owners(conn, p.org_id) <= 1:
            raise HTTPException(status.HTTP_409_CONFLICT, "The organization must keep at least one owner")
        conn.execute(text("UPDATE organization_members SET role = CAST(:r AS member_role) WHERE org_id = :o AND user_id = :u"),
                     {"r": body.role, "o": p.org_id, "u": str(user_id)})
        conn.execute(text("""INSERT INTO audit_logs (org_id, user_id, action, entity, entity_id, detail)
                             VALUES (:o, :a, 'member.role_changed', 'user', :u, CAST(:d AS jsonb))"""),
                     {"o": p.org_id, "a": p.user_id, "u": str(user_id), "d": f'{{"from": "{current}", "to": "{body.role}"}}'})
    return {"user_id": str(user_id), "role": body.role}


@router.delete("/members/{user_id}", status_code=status.HTTP_204_NO_CONTENT)
def remove_member(user_id: UUID, p: Principal = Depends(require_role("admin"))) -> None:
    with tenant_tx(p.org_id) as conn:
        current = conn.execute(text("SELECT role::text FROM organization_members WHERE org_id = :o AND user_id = :u FOR UPDATE"),
                               {"o": p.org_id, "u": str(user_id)}).scalar()
        if current is None:
            raise HTTPException(status.HTTP_404_NOT_FOUND, "Member not found")
        if str(user_id) != p.user_id and not _can_manage(p.role, current):
            raise HTTPException(status.HTTP_403_FORBIDDEN, "Only owners can remove admins and owners")
        if current == "owner" and _owners(conn, p.org_id) <= 1:
            raise HTTPException(status.HTTP_409_CONFLICT, "The organization must keep at least one owner")
        conn.execute(text("DELETE FROM organization_members WHERE org_id = :o AND user_id = :u"), {"o": p.org_id, "u": str(user_id)})
        conn.execute(text("""INSERT INTO audit_logs (org_id, user_id, action, entity, entity_id)
                             VALUES (:o, :a, 'member.removed', 'user', :u)"""), {"o": p.org_id, "a": p.user_id, "u": str(user_id)})
