"""Launching scans, reading GeoGrid results, history and two-scan comparison."""
from __future__ import annotations

from dataclasses import asdict
from decimal import Decimal
from typing import Optional
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel
from sqlalchemy import text
from sqlalchemy.engine import Connection

from app.config import get_settings
from app.db import tenant_tx
from app.deps import Principal, current_principal, require_role
from app.engine.analytics import GridMismatchError, PointResult, ResultStatus, compare_scans, rank_color
from app.engine.dominance import compare_businesses
from app.services.notifications import warn_usage
from app.services.scans import (
    ScanSetupError, UsageLimitError, active_keyword_count, check_monthly_limit, choose_provider_code, create_scans, estimate,
)

router = APIRouter(tags=["scans"])
FINISHED = ("completed", "partial")


class LaunchIn(BaseModel):
    keyword_ids: Optional[list[UUID]] = None     # default: all active keywords
    confirm_cost: bool = False


def enqueue(org_id: str, scan_id: str) -> None:
    from app.worker import run_scan_task         # imported lazily so the API starts without a broker
    run_scan_task.delay(org_id, scan_id)


@router.post("/campaigns/{campaign_id}/scans", status_code=status.HTTP_202_ACCEPTED)
def launch_scans(campaign_id: UUID, body: LaunchIn, p: Principal = Depends(require_role("seo_specialist"))) -> dict:
    settings = get_settings()
    ids = [str(k) for k in body.keyword_ids] if body.keyword_ids else None
    try:
        with tenant_tx(p.org_id) as conn:
            c = conn.execute(text("SELECT grid_size, depth FROM campaigns WHERE id = :c"),
                             {"c": str(campaign_id)}).first()
            if c is None:
                raise HTTPException(status.HTTP_404_NOT_FOUND, "Campaign not found")
            n_kw = active_keyword_count(conn, str(campaign_id), ids)
            points = c[0] ** 2
            est = estimate(conn, choose_provider_code(settings), points, n_kw, c[1])
            used, limit = check_monthly_limit(conn, p.org_id, est.api_requests)
            if float(est.estimated_cost_usd) > settings.scan_cost_confirm_threshold_usd and not body.confirm_cost:
                raise HTTPException(status.HTTP_409_CONFLICT, {
                    "message": "This scan exceeds the cost threshold. Resend with confirm_cost=true to proceed.",
                    "api_requests": est.api_requests, "estimated_cost_usd": str(est.estimated_cost_usd)})
            created = create_scans(conn, p.org_id, str(campaign_id), ids, settings)
    except ScanSetupError as exc:
        raise HTTPException(status.HTTP_422_UNPROCESSABLE_ENTITY, str(exc))
    except UsageLimitError as exc:
        raise HTTPException(status.HTTP_402_PAYMENT_REQUIRED, str(exc))
    # enqueue only after the transaction committed, so the worker can see the rows
    for s in created:
        enqueue(p.org_id, s["scan_id"])
    warn_usage(p.org_id, used + est.api_requests, limit)
    return {"scans": created, "api_requests": est.api_requests, "estimated_cost_usd": str(est.estimated_cost_usd)}


SCAN_COLS = """s.id::text, s.campaign_id::text, s.keyword_id::text, s.keyword_text, s.provider_code, s.is_demo,
               s.status::text, s.grid_size, s.spacing_m::float8 AS spacing_m, s.center_lat, s.center_lng,
               s.grid_signature, s.search_config, s.depth, s.points_total, s.points_failed,
               s.estimated_cost_usd::text, s.actual_cost_usd::text, s.created_at, s.started_at, s.completed_at"""


def _subject_filter(competitor_id: Optional[UUID]) -> tuple[str, dict]:
    if competitor_id:
        return "competitor_id = :subject", {"subject": str(competitor_id)}
    return "subject_type = 'location'", {}


def _metrics(conn: Connection, scan_id: str, competitor_id: Optional[UUID]) -> Optional[dict]:
    where, params = _subject_filter(competitor_id)
    row = conn.execute(text(f"""SELECT total_points, valid_points, ranked_points, not_found_points, error_points,
            average_position::float8 AS average_position, capped_average_position::float8 AS capped_average_position,
            median_position::float8 AS median_position, best_position, worst_position, top3_count, top10_count,
            top20_count, top3_coverage::float8 AS top3_coverage, top10_coverage::float8 AS top10_coverage,
            top20_coverage::float8 AS top20_coverage, not_found_pct::float8 AS not_found_pct
        FROM historical_metrics WHERE scan_id = :s AND {where}"""), {"s": scan_id, **params}).mappings().first()
    return dict(row) if row else None


def _results(conn: Connection, scan_id: str, competitor_id: Optional[UUID]) -> list[PointResult]:
    where, params = _subject_filter(competitor_id)
    rows = conn.execute(text(f"""SELECT g.point_index, r.result_status::text, r.position
            FROM ranking_results r JOIN grid_points g ON g.id = r.grid_point_id
            WHERE r.scan_id = :s AND r.{where} ORDER BY g.point_index"""), {"s": scan_id, **params}).all()
    return [PointResult(i, ResultStatus(st), pos) for i, st, pos in rows]


@router.get("/scans/{scan_id}")
def get_scan(scan_id: UUID, competitor_id: Optional[UUID] = None, p: Principal = Depends(current_principal)) -> dict:
    """One GeoGrid: every point with its coordinate and the selected business's result.
    Without competitor_id the tracked business is returned."""
    where, params = _subject_filter(competitor_id)
    with tenant_tx(p.org_id) as conn:
        scan = conn.execute(text(f"SELECT {SCAN_COLS} FROM scans s WHERE s.id = :s"), {"s": str(scan_id)}).mappings().first()
        if scan is None:
            raise HTTPException(status.HTTP_404_NOT_FOUND, "Scan not found")
        points = conn.execute(text(f"""SELECT g.point_index, g.row_no, g.col_no, g.latitude, g.longitude,
                    g.status::text AS point_status, g.error_code, g.error_message, g.check_url, g.fetched_at,
                    r.result_status::text AS result_status, r.position
                FROM grid_points g
                LEFT JOIN ranking_results r ON r.grid_point_id = g.id AND r.{where}
                WHERE g.scan_id = :s ORDER BY g.point_index"""), {"s": str(scan_id), **params}).mappings().all()
        metrics = _metrics(conn, str(scan_id), competitor_id)
    out = []
    for pt in points:
        d = dict(pt)
        if d["result_status"]:
            d["color"] = rank_color(PointResult(d["point_index"], ResultStatus(d["result_status"]), d["position"]))
        else:
            d["color"] = None          # scan still running, or this business was not part of the scan
        out.append(d)
    return {"scan": dict(scan), "metrics": metrics, "points": out,
            "data_notice": "DEMO DATA - synthetic rankings, not real search results" if scan["is_demo"] else None}


@router.get("/scans/{scan_id}/points/{point_index}")
def get_point(scan_id: UUID, point_index: int, p: Principal = Depends(current_principal)) -> dict:
    """Marker detail: all businesses evaluated at this coordinate plus the top listings seen there."""
    with tenant_tx(p.org_id) as conn:
        pt = conn.execute(text("""SELECT g.id::text, g.point_index, g.latitude, g.longitude, g.status::text AS point_status,
                    g.error_code, g.error_message, g.check_url, g.fetched_at, g.top_listings
                FROM grid_points g WHERE g.scan_id = :s AND g.point_index = :i"""),
                {"s": str(scan_id), "i": point_index}).mappings().first()
        if pt is None:
            raise HTTPException(status.HTTP_404_NOT_FOUND, "Grid point not found")
        subjects = conn.execute(text("""SELECT r.subject_type::text, coalesce(l.name, c.name) AS name,
                    coalesce(r.location_id, r.competitor_id)::text AS subject_id, r.result_status::text, r.position
                FROM ranking_results r
                LEFT JOIN business_locations l ON l.id = r.location_id
                LEFT JOIN competitors c ON c.id = r.competitor_id
                WHERE r.grid_point_id = CAST(:g AS uuid) ORDER BY r.subject_type, r.position NULLS LAST"""),
                {"g": pt["id"]}).mappings().all()
    return dict(pt) | {"businesses": [dict(s) for s in subjects]}


@router.get("/campaigns/{campaign_id}/history")
def history(campaign_id: UUID, keyword_id: UUID, competitor_id: Optional[UUID] = None, days: Optional[int] = None,
            p: Principal = Depends(current_principal)) -> list[dict]:
    """All stored scans of one keyword, oldest first, with metrics for the selected business.
    Scans without usable data are listed with metrics = null; nothing is interpolated."""
    with tenant_tx(p.org_id) as conn:
        scans = conn.execute(text(f"""SELECT {SCAN_COLS} FROM scans s
                WHERE s.campaign_id = :c AND s.keyword_id = :k
                  AND (CAST(:d AS int) IS NULL OR s.created_at >= now() - make_interval(days => CAST(:d AS int)))
                ORDER BY s.created_at"""),
                {"c": str(campaign_id), "k": str(keyword_id), "d": days}).mappings().all()
        return [dict(s) | {"metrics": _metrics(conn, s["id"], competitor_id)} for s in scans]


@router.get("/scans/compare/{previous_id}/{current_id}")
def compare(previous_id: UUID, current_id: UUID, competitor_id: Optional[UUID] = None,
            p: Principal = Depends(current_principal)) -> dict:
    with tenant_tx(p.org_id) as conn:
        rows = conn.execute(text(f"""SELECT {SCAN_COLS} FROM scans s WHERE s.id IN (:a, :b)"""),
                            {"a": str(previous_id), "b": str(current_id)}).mappings().all()
        by_id = {r["id"]: r for r in rows}
        prev, curr = by_id.get(str(previous_id)), by_id.get(str(current_id))
        if prev is None or curr is None:
            raise HTTPException(status.HTTP_404_NOT_FOUND, "Scan not found")
        for s in (prev, curr):
            if s["status"] not in FINISHED:
                raise HTTPException(status.HTTP_409_CONFLICT, f"Scan {s['id']} has no usable results (status {s['status']})")
        if prev["keyword_id"] != curr["keyword_id"] or prev["search_config"] != curr["search_config"]:
            raise HTTPException(status.HTTP_422_UNPROCESSABLE_ENTITY,
                                "Scans use a different keyword or search configuration and cannot be compared")
        if prev["is_demo"] != curr["is_demo"]:
            raise HTTPException(status.HTTP_422_UNPROCESSABLE_ENTITY, "Demo scans cannot be compared with real scans")
        try:
            cmp = compare_scans(_results(conn, prev["id"], competitor_id), _results(conn, curr["id"], competitor_id),
                                previous_signature=prev["grid_signature"], current_signature=curr["grid_signature"])
        except GridMismatchError as exc:
            raise HTTPException(status.HTTP_422_UNPROCESSABLE_ENTITY, str(exc))
        coords = conn.execute(text("SELECT point_index, latitude, longitude FROM grid_points WHERE scan_id = :s"),
                              {"s": curr["id"]}).all()
        metrics = {"previous": _metrics(conn, prev["id"], competitor_id),
                   "current": _metrics(conn, curr["id"], competitor_id)}
    where = {i: (lat, lng) for i, lat, lng in coords}
    return {
        "previous": dict(prev), "current": dict(curr), "metrics": metrics,
        "comparable_points": cmp.comparable_points, "total_points": len(cmp.points),
        "counts": dict(cmp.counts), "average_delta": cmp.average_delta,
        "points": [asdict(c) | {"change": c.change.value, "latitude": where.get(c.point_index, (None, None))[0],
                                "longitude": where.get(c.point_index, (None, None))[1]} for c in cmp.points],
        "data_notice": "DEMO DATA - synthetic rankings, not real search results" if curr["is_demo"] else None,
    }


DEMO_NOTICE = "DEMO DATA - synthetic rankings, not real search results"
METRIC_COLS = """m.total_points, m.valid_points, m.ranked_points, m.not_found_points, m.error_points,
    m.average_position::float8 AS average_position, m.capped_average_position::float8 AS capped_average_position,
    m.median_position::float8 AS median_position, m.best_position, m.worst_position,
    m.top3_count, m.top10_count, m.top20_count, m.top3_coverage::float8 AS top3_coverage,
    m.top10_coverage::float8 AS top10_coverage, m.top20_coverage::float8 AS top20_coverage,
    m.not_found_pct::float8 AS not_found_pct"""


@router.get("/scans/{scan_id}/competitors")
def competitor_comparison(scan_id: UUID, tolerance: int = 2, p: Principal = Depends(current_principal)) -> dict:
    """Comparison table (average rank, Top 3/10/20) for every business in the scan, plus a per-point
    dominance map.  All businesses come from the same responses, so coordinates, keyword, date and
    search configuration match by construction."""
    if not 0 <= tolerance <= 20:
        raise HTTPException(status.HTTP_422_UNPROCESSABLE_ENTITY, "tolerance must be between 0 and 20")
    with tenant_tx(p.org_id) as conn:
        scan = conn.execute(text(f"SELECT {SCAN_COLS} FROM scans s WHERE s.id = :s"), {"s": str(scan_id)}).mappings().first()
        if scan is None:
            raise HTTPException(status.HTTP_404_NOT_FOUND, "Scan not found")
        if scan["status"] not in FINISHED:
            raise HTTPException(status.HTTP_409_CONFLICT, f"Scan has no usable results (status {scan['status']})")
        businesses = conn.execute(text(f"""SELECT m.subject_type::text, coalesce(m.location_id, m.competitor_id)::text AS subject_id,
                    coalesce(l.name, c.name) AS name, {METRIC_COLS}
                FROM historical_metrics m
                LEFT JOIN business_locations l ON l.id = m.location_id
                LEFT JOIN competitors c ON c.id = m.competitor_id
                WHERE m.scan_id = :s ORDER BY m.subject_type, m.average_position NULLS LAST"""),
                {"s": str(scan_id)}).mappings().all()
        rows = conn.execute(text("""SELECT r.subject_type::text, coalesce(r.location_id, r.competitor_id)::text AS subject_id,
                    g.point_index, g.latitude, g.longitude, r.result_status::text, r.position
                FROM ranking_results r JOIN grid_points g ON g.id = r.grid_point_id
                WHERE r.scan_id = :s ORDER BY g.point_index"""), {"s": str(scan_id)}).all()
    mine: list[PointResult] = []
    comps: dict[str, list[PointResult]] = {}
    coords: dict[int, tuple[float, float]] = {}
    for kind, sid, idx, lat, lng, st, pos in rows:
        coords[idx] = (lat, lng)
        result = PointResult(idx, ResultStatus(st), pos)
        if kind == "location":
            mine.append(result)
        else:
            comps.setdefault(sid, []).append(result)
    dominance = None
    if comps:
        summary = compare_businesses(mine, comps, tolerance=tolerance)
        dominance = {
            "tolerance": tolerance, "valid_points": summary.valid_points, "counts": summary.counts,
            "points": [{"point_index": d.point_index, "dominance": d.dominance.value, "my_position": d.my_position,
                        "leader_id": d.leader_key, "leader_position": d.leader_position,
                        "latitude": coords[d.point_index][0], "longitude": coords[d.point_index][1]}
                       for d in summary.points],
        }
    return {"scan": dict(scan), "businesses": [dict(b) for b in businesses], "dominance": dominance,
            "data_source": f"{scan['provider_code']} - scanned {scan['completed_at']}",
            "data_notice": DEMO_NOTICE if scan["is_demo"] else None}


@router.get("/campaigns/{campaign_id}/trend")
def trend(campaign_id: UUID, keyword_id: UUID, days: Optional[int] = None,
          p: Principal = Depends(current_principal)) -> list[dict]:
    """Metrics of every business for each stored scan of a keyword, oldest first.  Scans without
    usable data appear with an empty business list; no value is interpolated."""
    with tenant_tx(p.org_id) as conn:
        scans = conn.execute(text("""SELECT s.id::text, s.status::text, s.is_demo, s.grid_signature, s.created_at, s.completed_at
                FROM scans s WHERE s.campaign_id = :c AND s.keyword_id = :k
                  AND (CAST(:d AS int) IS NULL OR s.created_at >= now() - make_interval(days => CAST(:d AS int)))
                ORDER BY s.created_at"""), {"c": str(campaign_id), "k": str(keyword_id), "d": days}).mappings().all()
        metrics = conn.execute(text(f"""SELECT m.scan_id::text, m.subject_type::text,
                    coalesce(m.location_id, m.competitor_id)::text AS subject_id, coalesce(l.name, c.name) AS name, {METRIC_COLS}
                FROM historical_metrics m JOIN scans s ON s.id = m.scan_id
                LEFT JOIN business_locations l ON l.id = m.location_id
                LEFT JOIN competitors c ON c.id = m.competitor_id
                WHERE s.campaign_id = :c AND s.keyword_id = :k"""), {"c": str(campaign_id), "k": str(keyword_id)}).mappings().all()
    by_scan: dict[str, list[dict]] = {}
    for m in metrics:
        d = dict(m)
        by_scan.setdefault(d.pop("scan_id"), []).append(d)
    return [dict(s) | {"businesses": by_scan.get(s["id"], [])} for s in scans]


@router.post("/scans/{scan_id}/retry", status_code=status.HTTP_202_ACCEPTED)
def retry_scan(scan_id: UUID, p: Principal = Depends(require_role("seo_specialist"))) -> dict:
    """Runs a failed or partial scan again as a NEW scan.  The original stays in history unchanged."""
    settings = get_settings()
    try:
        with tenant_tx(p.org_id) as conn:
            s = conn.execute(text("SELECT campaign_id::text, keyword_id::text, status::text, points_total FROM scans WHERE id = :s"),
                             {"s": str(scan_id)}).first()
            if s is None:
                raise HTTPException(status.HTTP_404_NOT_FOUND, "Scan not found")
            if s[2] not in ("failed", "partial"):
                raise HTTPException(status.HTTP_409_CONFLICT, "Only failed or partial scans can be retried")
            used, limit = check_monthly_limit(conn, p.org_id, s[3])
            created = create_scans(conn, p.org_id, s[0], [s[1]], settings)
    except ScanSetupError as exc:
        raise HTTPException(status.HTTP_422_UNPROCESSABLE_ENTITY, str(exc))
    except UsageLimitError as exc:
        raise HTTPException(status.HTTP_402_PAYMENT_REQUIRED, str(exc))
    if not created:
        raise HTTPException(status.HTTP_422_UNPROCESSABLE_ENTITY, "The keyword is paused; resume it to retry")
    for c in created:
        enqueue(p.org_id, c["scan_id"])
    warn_usage(p.org_id, used + s[3], limit)
    return {"scans": created}
