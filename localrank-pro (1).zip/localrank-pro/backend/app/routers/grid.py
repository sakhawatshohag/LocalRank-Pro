"""Grid preview and scan cost estimate (no provider call, no charge)."""
from __future__ import annotations

from decimal import Decimal

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, Field
from sqlalchemy import text

from app.config import get_settings
from app.db import system_tx
from app.deps import Principal, current_principal
from app.engine.geogrid import GridError, generate_grid, radius_from_spacing
from app.providers.base import ExecutionMode

router = APIRouter(prefix="/grid", tags=["geogrid"])


class GridPreviewIn(BaseModel):
    center_lat: float
    center_lng: float
    grid_size: int = Field(ge=1, le=21)
    spacing_m: float = Field(ge=50, le=50_000)
    keywords: int = Field(default=1, ge=1, le=500)
    depth: int = Field(default=100, ge=1, le=700)
    mode: ExecutionMode = ExecutionMode.LIVE
    provider: str = "dataforseo"


@router.post("/preview")
def preview(body: GridPreviewIn, p: Principal = Depends(current_principal)) -> dict:
    try:
        points = generate_grid(body.center_lat, body.center_lng, body.grid_size, body.spacing_m)
    except GridError as exc:
        raise HTTPException(status.HTTP_422_UNPROCESSABLE_ENTITY, str(exc))
    with system_tx() as conn:
        price = conn.execute(text("""SELECT unit_price_usd, results_per_unit, source_url, verified_on FROM api_pricing
                                     WHERE provider_code = :p AND mode = CAST(:m AS execution_mode)"""),
                             {"p": body.provider, "m": body.mode.value}).first()
    if price is None:
        raise HTTPException(status.HTTP_422_UNPROCESSABLE_ENTITY, "No price configured for this provider and mode")
    requests_needed = len(points) * body.keywords
    billed_units = -(-body.depth // price[1])                       # ceil(depth / results_per_unit)
    cost = Decimal(requests_needed) * billed_units * price[0]
    return {
        "points": [p_.__dict__ for p_ in points],
        "radius_m": radius_from_spacing(body.spacing_m, body.grid_size),
        "estimate": {
            "api_requests": requests_needed,
            "estimated_cost_usd": str(cost),
            "unit_price_usd": str(price[0]),
            "price_source": price[2],
            "price_verified_on": str(price[3]) if price[3] else None,
            "requires_confirmation": float(cost) > get_settings().scan_cost_confirm_threshold_usd,
            "note": "Competitors do not add requests: they are read from the same response as the tracked business.",
        },
    }
