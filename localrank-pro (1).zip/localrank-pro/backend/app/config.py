"""Environment-based configuration.  No secrets live in code; see .env.example."""
from __future__ import annotations

import os
from functools import lru_cache
from typing import Mapping, Optional

from pydantic import BaseModel, field_validator, model_validator


class Settings(BaseModel):
    app_env: str = "development"                 # development | test | production
    database_url: str
    redis_url: str = "redis://redis:6379/0"
    jwt_secret: str
    access_token_ttl_minutes: int = 60
    cors_origins: list[str] = []
    demo_mode: bool = False                      # allows the synthetic demo provider
    dataforseo_login: Optional[str] = None
    dataforseo_password: Optional[str] = None
    scan_cost_confirm_threshold_usd: float = 1.0
    app_url: str = "http://localhost:3000"           # public URL of the web app (links, Stripe return URLs)
    stripe_secret_key: Optional[str] = None
    stripe_webhook_secret: Optional[str] = None
    stripe_api_version: str = "2026-02-25.clover"
    trial_days: int = 14
    allow_signup: bool = True                    # false = accounts are created by the operator (scripts/create_account.sh)

    @field_validator("cors_origins", mode="before")
    @classmethod
    def _split(cls, v):
        return [o.strip() for o in v.split(",") if o.strip()] if isinstance(v, str) else v

    @model_validator(mode="after")
    def _production_rules(self):
        if len(self.jwt_secret) < 32:
            raise ValueError("JWT_SECRET must be at least 32 characters")
        if self.app_env == "production" and self.demo_mode:
            raise ValueError("DEMO_MODE cannot be enabled when APP_ENV=production")
        return self

    @property
    def stripe_configured(self) -> bool:
        return bool(self.stripe_secret_key and self.stripe_webhook_secret)

    @property
    def dataforseo_configured(self) -> bool:
        return bool(self.dataforseo_login and self.dataforseo_password)


def load_settings(env: Optional[Mapping[str, str]] = None) -> Settings:
    env = os.environ if env is None else env
    return Settings(**{k.lower(): v for k, v in env.items() if k.lower() in Settings.model_fields and v != ""})


@lru_cache
def get_settings() -> Settings:
    return load_settings()
