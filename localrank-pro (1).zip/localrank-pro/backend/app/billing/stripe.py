"""Minimal Stripe REST client (no SDK) and webhook signature verification.

Checked against Stripe's documentation on 2026-11-17:
* API base https://api.stripe.com/v1, secret key as HTTP Basic user, form-encoded bodies with
  bracket notation (line_items[0][price]).  The API version is pinned with the Stripe-Version
  header (STRIPE_API_VERSION, default 2026-02-25.clover).
* Checkout:  POST /v1/checkout/sessions  mode=subscription, line_items[0][price], [0][quantity],
  success_url, cancel_url, client_reference_id, customer or customer_email; the response has `url`.
* Customer portal:  POST /v1/billing_portal/sessions  customer, return_url; the response has `url`.
* Webhooks: header ``Stripe-Signature: t=<unix>,v1=<hex>[,v1=...]``; signed string is
  ``"{t}.{raw body}"``, HMAC-SHA256 with the endpoint secret; only v1 signatures count.
* Since 2025-03-31.basil a subscription's billing period is on its items
  (items.data[].current_period_end), not on the subscription.

NOT VERIFIED AGAINST A LIVE ACCOUNT: no Stripe keys were available.  Only signing and parsing are
tested, with locally signed fixtures.
"""
from __future__ import annotations

import hashlib
import hmac
import time
from datetime import datetime, timezone
from typing import Any, Mapping, Optional

import requests

API_BASE = "https://api.stripe.com/v1"
DEFAULT_API_VERSION = "2026-02-25.clover"
SIGNATURE_TOLERANCE_SECONDS = 300


class StripeError(Exception):
    def __init__(self, message: str, status: int = 0) -> None:
        super().__init__(message)
        self.status = status


class SignatureError(Exception):
    pass


def encode_form(params: Mapping[str, Any], prefix: str = "") -> list[tuple[str, str]]:
    """Stripe form encoding: nested dicts and lists use brackets; None is omitted; bools are true/false."""
    out: list[tuple[str, str]] = []
    for key, value in params.items():
        name = f"{prefix}[{key}]" if prefix else str(key)
        if value is None:
            continue
        if isinstance(value, Mapping):
            out += encode_form(value, name)
        elif isinstance(value, (list, tuple)):
            for i, item in enumerate(value):
                if isinstance(item, Mapping):
                    out += encode_form(item, f"{name}[{i}]")
                else:
                    out.append((f"{name}[{i}]", _scalar(item)))
        else:
            out.append((name, _scalar(value)))
    return out


def _scalar(v: Any) -> str:
    return ("true" if v else "false") if isinstance(v, bool) else str(v)


def verify_signature(payload: bytes, header: Optional[str], secret: str, *, now: Optional[float] = None,
                     tolerance: int = SIGNATURE_TOLERANCE_SECONDS) -> None:
    if not secret:
        raise SignatureError("webhook secret is not configured")
    if not header:
        raise SignatureError("missing Stripe-Signature header")
    timestamp, signatures = None, []
    for part in header.split(","):
        k, _, v = part.strip().partition("=")
        if k == "t":
            timestamp = v
        elif k == "v1":
            signatures.append(v)
    if not timestamp or not timestamp.isdigit() or not signatures:
        raise SignatureError("malformed Stripe-Signature header")
    expected = hmac.new(secret.encode(), timestamp.encode() + b"." + payload, hashlib.sha256).hexdigest()
    if not any(hmac.compare_digest(expected, s) for s in signatures):
        raise SignatureError("signature does not match")
    if abs((now if now is not None else time.time()) - int(timestamp)) > tolerance:
        raise SignatureError("timestamp outside the tolerance window")


def sign(payload: bytes, secret: str, timestamp: Optional[int] = None) -> str:
    """Builds a Stripe-Signature header (tests and local tooling)."""
    t = str(timestamp if timestamp is not None else int(time.time()))
    return f"t={t},v1=" + hmac.new(secret.encode(), t.encode() + b"." + payload, hashlib.sha256).hexdigest()


def period_end(subscription: Mapping[str, Any]) -> Optional[datetime]:
    """Billing period end: item level (basil and later), else the legacy subscription field."""
    items = ((subscription.get("items") or {}).get("data")) or []
    ends = [i.get("current_period_end") for i in items if i.get("current_period_end")]
    ts = min(ends) if ends else subscription.get("current_period_end")
    return datetime.fromtimestamp(ts, timezone.utc) if ts else None


def price_id(subscription: Mapping[str, Any]) -> Optional[str]:
    items = ((subscription.get("items") or {}).get("data")) or []
    for i in items:
        price = i.get("price") or {}
        if isinstance(price, Mapping) and price.get("id"):
            return price["id"]
        if isinstance(price, str):
            return price
    return None


class StripeClient:
    def __init__(self, secret_key: str, api_version: str = DEFAULT_API_VERSION, *, session: Optional[requests.Session] = None,
                 base: str = API_BASE, timeout: float = 20.0) -> None:
        if not secret_key:
            raise StripeError("Stripe is not configured")
        self._key, self._version, self._base, self._timeout = secret_key, api_version, base.rstrip("/"), timeout
        self._http = session or requests.Session()

    def _post(self, path: str, params: Mapping[str, Any], idempotency_key: Optional[str] = None) -> dict:
        headers = {"Stripe-Version": self._version}
        if idempotency_key:
            headers["Idempotency-Key"] = idempotency_key
        try:
            r = self._http.post(self._base + path, data=encode_form(params), auth=(self._key, ""), headers=headers,
                                timeout=self._timeout)
        except requests.RequestException as exc:
            raise StripeError(f"could not reach Stripe: {exc}") from exc
        try:
            body = r.json()
        except ValueError:
            raise StripeError(f"Stripe returned a non-JSON response ({r.status_code})", r.status_code)
        if r.status_code >= 400:
            msg = (body.get("error") or {}).get("message") or f"Stripe error {r.status_code}"
            raise StripeError(msg, r.status_code)
        return body

    def create_checkout_session(self, *, price: str, success_url: str, cancel_url: str, client_reference_id: str,
                                customer: Optional[str] = None, customer_email: Optional[str] = None,
                                metadata: Optional[Mapping[str, str]] = None, idempotency_key: Optional[str] = None) -> dict:
        params: dict[str, Any] = {
            "mode": "subscription",
            "line_items": [{"price": price, "quantity": 1}],
            "success_url": success_url,
            "cancel_url": cancel_url,
            "client_reference_id": client_reference_id,
            "metadata": dict(metadata or {}),
            "subscription_data": {"metadata": dict(metadata or {})},
            "allow_promotion_codes": True,
        }
        if customer:
            params["customer"] = customer
        elif customer_email:
            params["customer_email"] = customer_email
        return self._post("/checkout/sessions", params, idempotency_key)

    def create_portal_session(self, *, customer: str, return_url: str) -> dict:
        return self._post("/billing_portal/sessions", {"customer": customer, "return_url": return_url})
