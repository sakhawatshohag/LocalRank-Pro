"""Applies Stripe webhook events to subscriptions, plans and invoices.

Rules (documented business logic)
* The subscription's own state is the source of truth; events older than the newest one
  already applied for that organization are ignored (Stripe does not guarantee order).
* active / trialing / past_due + a price that maps to a plan  -> the organization gets that plan.
  past_due keeps the plan while Stripe retries the payment; a billing notification is sent.
* canceled / unpaid / incomplete_expired                        -> the 'inactive' plan.
  Data is kept; nothing new can be added and no scans run until a plan is active again.
* Downgrades never delete data: items above the new limits stay, new ones are blocked.
* Every event id is recorded; a re-delivered event is not applied twice.
"""
from __future__ import annotations

import logging
from datetime import datetime, timezone
from typing import Any, Mapping, Optional

from sqlalchemy import text
from sqlalchemy.engine import Connection

from app.billing.stripe import period_end, price_id
from app.db import system_tx, tenant_tx
from app.services.notifications import notify

log = logging.getLogger("localrank.billing")
ACTIVE = ("active", "trialing", "past_due")
ENDED = ("canceled", "unpaid", "incomplete_expired")
HANDLED = {"checkout.session.completed", "customer.subscription.created", "customer.subscription.updated",
           "customer.subscription.deleted", "invoice.paid", "invoice.payment_failed", "invoice.finalized", "invoice.updated"}


def _ts(v: Optional[int]) -> Optional[datetime]:
    return datetime.fromtimestamp(v, timezone.utc) if v else None


def _org_for_customer(customer: Optional[str]) -> Optional[str]:
    if not customer:
        return None
    with system_tx() as conn:
        org = conn.execute(text("SELECT org_for_billing_customer('stripe', :c)"), {"c": customer}).scalar()
    return str(org) if org else None


def _apply_subscription(conn: Connection, org_id: str, sub: Mapping[str, Any], event_at: datetime) -> Optional[str]:
    newest = conn.execute(text("SELECT last_event_at FROM subscriptions WHERE org_id = :o"), {"o": org_id}).scalar()
    if newest and event_at < newest:
        return "stale"
    status = sub.get("status") or "unknown"
    price = price_id(sub)
    plan = conn.execute(text("SELECT id::text, code FROM plans WHERE stripe_price_id = :p"), {"p": price}).first() if price else None
    conn.execute(text("""
        INSERT INTO subscriptions (org_id, provider, customer_id, subscription_id, status, plan_id, price_id, current_period_end,
                                   cancel_at_period_end, last_event_at, updated_at)
        VALUES (:o, 'stripe', :cust, :sid, :st, CAST(:plan AS uuid), :price, :end, :cancel, :at, now())
        ON CONFLICT (org_id) DO UPDATE SET customer_id = EXCLUDED.customer_id, subscription_id = EXCLUDED.subscription_id,
            status = EXCLUDED.status, plan_id = coalesce(EXCLUDED.plan_id, subscriptions.plan_id), price_id = EXCLUDED.price_id,
            current_period_end = EXCLUDED.current_period_end, cancel_at_period_end = EXCLUDED.cancel_at_period_end,
            last_event_at = EXCLUDED.last_event_at, updated_at = now()"""),
        {"o": org_id, "cust": sub.get("customer"), "sid": sub.get("id"), "st": status, "plan": plan[0] if plan else None,
         "price": price, "end": period_end(sub), "cancel": bool(sub.get("cancel_at_period_end")), "at": event_at})
    if status in ACTIVE:
        if plan is None:
            log.error("subscription %s uses price %s that matches no plan", sub.get("id"), price)
            notify(conn, org_id, "billing_problem", "Subscription could not be matched to a plan",
                   body="Your payment went through, but the plan could not be applied automatically. Please contact support.",
                   link="/billing", dedupe_key=f"billing:unmapped:{sub.get('id')}:{price}", min_role="owner")
            return "unmapped_price"
        conn.execute(text("UPDATE organizations SET plan_id = CAST(:p AS uuid) WHERE id = :o"), {"p": plan[0], "o": org_id})
        if status == "past_due":
            notify(conn, org_id, "billing_problem", "Payment failed: please update your payment method",
                   body="Your plan stays active while the payment is retried.", link="/billing",
                   dedupe_key=f"billing:past_due:{sub.get('id')}:{event_at.date()}", min_role="owner")
        return f"plan:{plan[1]}"
    if status in ENDED:
        conn.execute(text("UPDATE organizations SET plan_id = (SELECT id FROM plans WHERE code = 'inactive') WHERE id = :o"), {"o": org_id})
        notify(conn, org_id, "billing_problem", "Subscription ended",
               body="Your data is kept. Choose a plan to continue tracking.", link="/billing",
               dedupe_key=f"billing:ended:{sub.get('id')}", min_role="owner")
        return "inactive"
    return "unchanged"


def _apply_invoice(conn: Connection, org_id: str, inv: Mapping[str, Any]) -> str:
    conn.execute(text("""
        INSERT INTO invoices (org_id, provider, provider_invoice_id, number, status, amount_due_cents, amount_paid_cents, currency,
                              hosted_invoice_url, invoice_pdf_url, period_start, period_end, created_at)
        VALUES (:o, 'stripe', :id, :num, :st, :due, :paid, :cur, :url, :pdf, :ps, :pe, coalesce(:created, now()))
        ON CONFLICT (provider, provider_invoice_id) DO UPDATE SET number = EXCLUDED.number, status = EXCLUDED.status,
            amount_due_cents = EXCLUDED.amount_due_cents, amount_paid_cents = EXCLUDED.amount_paid_cents,
            hosted_invoice_url = EXCLUDED.hosted_invoice_url, invoice_pdf_url = EXCLUDED.invoice_pdf_url"""),
        {"o": org_id, "id": inv.get("id"), "num": inv.get("number"), "st": inv.get("status"), "due": inv.get("amount_due"),
         "paid": inv.get("amount_paid"), "cur": inv.get("currency"), "url": inv.get("hosted_invoice_url"),
         "pdf": inv.get("invoice_pdf"), "ps": _ts(inv.get("period_start")), "pe": _ts(inv.get("period_end")),
         "created": _ts(inv.get("created"))})
    return "invoice"


def apply_event(event: Mapping[str, Any]) -> str:
    """Returns what happened, for logging and tests."""
    event_id, etype = event.get("id"), event.get("type")
    if not event_id or not etype:
        raise ValueError("not a Stripe event")
    with system_tx() as conn:
        if conn.execute(text("SELECT 1 FROM billing_events WHERE provider = 'stripe' AND event_id = :e"), {"e": event_id}).first():
            return "duplicate"
    obj = (event.get("data") or {}).get("object") or {}
    event_at = _ts(event.get("created")) or datetime.now(timezone.utc)
    org_id: Optional[str] = None
    result = "ignored"
    if etype in HANDLED:
        if etype == "checkout.session.completed":
            org_id = obj.get("client_reference_id") or (obj.get("metadata") or {}).get("org_id")
            if org_id and obj.get("customer"):
                with tenant_tx(org_id) as conn:
                    conn.execute(text("""
                        INSERT INTO subscriptions (org_id, provider, customer_id, subscription_id, status)
                        VALUES (:o, 'stripe', :c, :s, 'incomplete')
                        ON CONFLICT (org_id) DO UPDATE SET customer_id = EXCLUDED.customer_id,
                            subscription_id = coalesce(EXCLUDED.subscription_id, subscriptions.subscription_id), updated_at = now()"""),
                        {"o": org_id, "c": obj.get("customer"), "s": obj.get("subscription")})
                result = "linked"
        else:
            org_id = _org_for_customer(obj.get("customer")) or (obj.get("metadata") or {}).get("org_id")
            if org_id is None:
                result = "unknown_customer"
            else:
                with tenant_tx(org_id) as conn:
                    if etype.startswith("customer.subscription."):
                        result = _apply_subscription(conn, org_id, obj, event_at)
                    else:
                        result = _apply_invoice(conn, org_id, obj)
                        if etype == "invoice.payment_failed":
                            notify(conn, org_id, "billing_problem", "Payment failed", link="/billing",
                                   body="Stripe could not collect the payment. Please update your payment method.",
                                   dedupe_key=f"billing:invoice_failed:{obj.get('id')}", min_role="owner")
    if result == "unknown_customer":
        # not recorded: the webhook answers with an error so Stripe delivers it again later,
        # by which time checkout.session.completed has linked the customer
        log.warning("stripe event %s (%s) for an unknown customer; will be retried", event_id, etype)
        return result
    with system_tx() as conn:
        conn.execute(text("""INSERT INTO billing_events (provider, event_id, type, org_id) VALUES ('stripe', :e, :t, CAST(:o AS uuid))
                             ON CONFLICT DO NOTHING"""), {"e": event_id, "t": etype, "o": org_id})
    log.info("stripe event %s (%s): %s", event_id, etype, result)
    return result


def expire_trials() -> int:
    """Organizations whose trial ended without a subscription move to the 'inactive' plan."""
    with system_tx() as conn:
        orgs = [str(r[0]) for r in conn.execute(text("SELECT * FROM expire_trials()"))]
    for org_id in orgs:
        with tenant_tx(org_id) as conn:
            notify(conn, org_id, "billing_problem", "Your free trial has ended",
                   body="Your data is kept. Choose a plan to continue tracking.", link="/billing",
                   dedupe_key="billing:trial_ended", min_role="owner")
    return len(orgs)
