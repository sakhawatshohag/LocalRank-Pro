"""Report generation: stored scan data -> ReportModel -> PDF + CSV, kept for download.

Which scans a report uses (documented business logic)
* current scan  = the latest finished scan (completed or partial) of the keyword whose completion
                  date (UTC) falls in the reporting period;
* previous scan = the latest comparable scan finished BEFORE the period starts; if there is none,
                  the earliest comparable scan inside the period (when it is not the current one).
  "Comparable" = same keyword, grid, search settings and data type (demo or real).
* GeoGrid comparison reports use the two scans the user picked instead.
* Keywords without a finished scan in the period are listed as "no data", never filled in.
"""
from __future__ import annotations

import base64
import json
import logging
from datetime import date, datetime, timezone
from typing import Callable, Optional

from sqlalchemy import text
from sqlalchemy.engine import Connection

from app.db import system_tx, tenant_tx
from app.engine.analytics import PointResult, ResultStatus, compare_scans
from app.engine.report_model import (
    Branding, BusinessRow, KeywordSection, PointView, ReportModel, ScanRef, TYPE_TITLES, report_period,
)
from app.engine.schedule import next_run
from app.reporting.pdf import render_csv, render_pdf
from app.services.notifications import notify

log = logging.getLogger("localrank.reports")
FINISHED = ("completed", "partial")
METRIC_KEYS = ("total_points", "valid_points", "ranked_points", "not_found_points", "error_points", "average_position",
               "median_position", "best_position", "worst_position", "top3_count", "top10_count", "top20_count",
               "top3_coverage", "top10_coverage", "top20_coverage", "not_found_pct")


class ReportError(Exception):
    pass


def _b64(v: Optional[str]) -> Optional[bytes]:
    return base64.b64decode(v) if v else None


def _f(v):
    return float(v) if v is not None else None


def _metrics(conn: Connection, scan_id: str) -> dict[str, dict]:
    rows = conn.execute(text(f"""SELECT coalesce(location_id, competitor_id)::text AS sid, {', '.join(METRIC_KEYS)}
                                 FROM historical_metrics WHERE scan_id = :s"""), {"s": scan_id}).mappings().all()
    out = {}
    for r in rows:
        d = dict(r)
        sid = d.pop("sid")
        out[sid] = {k: (_f(v) if k.endswith(("_position", "_coverage", "_pct")) else v) for k, v in d.items()}
    return out


def _points(conn: Connection, scan_id: str, subject_id: str) -> list[PointView]:
    rows = conn.execute(text("""SELECT g.point_index, g.row_no, g.col_no, g.latitude, g.longitude, r.result_status::text, r.position
            FROM grid_points g JOIN ranking_results r ON r.grid_point_id = g.id
            WHERE g.scan_id = :s AND coalesce(r.location_id, r.competitor_id) = CAST(:sub AS uuid)
            ORDER BY g.point_index"""), {"s": scan_id, "sub": subject_id}).all()
    return [PointView(i, r, c, float(lat), float(lng), st, pos) for i, r, c, lat, lng, st, pos in rows]


def _scan_ref(conn: Connection, scan_id: str, location_id: str) -> ScanRef:
    r = conn.execute(text("""SELECT s.id::text, s.completed_at, s.status::text, m.valid_points, m.total_points
            FROM scans s LEFT JOIN historical_metrics m ON m.scan_id = s.id AND m.location_id = CAST(:l AS uuid)
            WHERE s.id = :s"""), {"s": scan_id, "l": location_id}).one()
    return ScanRef(r[0], r[1], r[2], r[3] or 0, r[4] or 0)


def _section(conn: Connection, camp: dict, keyword: str, current_id: str, previous_id: Optional[str],
             history_ids: list[str]) -> KeywordSection:
    loc = camp["location_id"]
    cur_m, prev_m = _metrics(conn, current_id), (_metrics(conn, previous_id) if previous_id else {})
    cur_pts = _points(conn, current_id, loc)
    prev_pts = _points(conn, previous_id, loc) if previous_id else []
    s = conn.execute(text("SELECT is_demo, grid_size, spacing_m, depth FROM scans WHERE id = :s"), {"s": current_id}).one()
    section = KeywordSection(
        campaign_name=camp["name"], location_name=camp["location_name"], keyword=keyword, grid_size=s[1],
        spacing_m=float(s[2]), depth=s[3], current=_scan_ref(conn, current_id, loc),
        previous=_scan_ref(conn, previous_id, loc) if previous_id else None,
        current_points=cur_pts, previous_points=prev_pts, is_demo=bool(s[0]))
    if previous_id:
        as_results = lambda pts: [PointResult(p.index, ResultStatus(p.status), p.position) for p in pts]  # noqa: E731
        cmp = compare_scans(as_results(prev_pts), as_results(cur_pts))
        section.change_counts, section.comparable_points, section.average_delta = dict(cmp.counts), cmp.comparable_points, cmp.average_delta
    names = {r[0]: (r[1], r[2]) for r in conn.execute(text("""
            SELECT l.id::text, l.name, true FROM business_locations l WHERE l.id = CAST(:l AS uuid)
            UNION ALL SELECT c.id::text, c.name, false FROM competitors c WHERE c.campaign_id = CAST(:c AS uuid)"""),
            {"l": loc, "c": camp["id"]})}
    for sid, cur in cur_m.items():
        if sid not in names:
            continue
        name, mine = names[sid]
        section.businesses.append(BusinessRow(name, mine, prev_m.get(sid), cur,
                                              cur_pts if mine else _points(conn, current_id, sid)))
    for hid in history_ids:
        m = _metrics(conn, hid).get(loc)
        when = conn.execute(text("SELECT completed_at FROM scans WHERE id = :s"), {"s": hid}).scalar()
        section.history.append({"date": when, **(m or {"valid_points": None})})
    return section


def build_model(conn: Connection, report: dict, now: Optional[datetime] = None) -> ReportModel:
    org_id, opts = report["org_id"], report["options"] or {}
    # bytea is read as base64 text so the code does not depend on how a driver returns binary data
    client = conn.execute(text("SELECT name, encode(logo_png, 'base64') FROM clients WHERE id = :c"), {"c": report["client_id"]}).first()
    if client is None:
        raise ReportError("Client not found")
    b = conn.execute(text("""SELECT agency_name, website, email, phone, primary_color, footer_text,
                                    encode(logo_png, 'base64') AS logo_png FROM report_branding""")).mappings().first()
    white_label = bool(conn.execute(text("""SELECT coalesce((p.limits ->> 'white_label')::boolean, false) FROM organizations o
                                            JOIN plans p ON p.id = o.plan_id WHERE o.id = :o"""), {"o": org_id}).scalar())
    branding = Branding(**{k: (_b64(v) if k == "logo_png" else v) for k, v in (b or {}).items()},
                        white_label=white_label)
    campaigns = [dict(r) for r in conn.execute(text("""
            SELECT c.id::text, c.name, c.location_id::text, l.name AS location_name
            FROM campaigns c JOIN business_locations l ON l.id = c.location_id
            WHERE l.client_id = CAST(:client AS uuid)
              AND (CAST(:ids AS uuid[]) IS NULL OR c.id = ANY(CAST(:ids AS uuid[])))
            ORDER BY c.name"""), {"client": report["client_id"], "ids": opts.get("campaign_ids") or None}).mappings()]
    sections, without = [], []
    start, end = report["period_start"], report["period_end"]

    if report["report_type"] == "geogrid_comparison":
        prev_id, cur_id = opts.get("previous_scan_id"), opts.get("current_scan_id")
        rows = {r[0]: r for r in conn.execute(text("""SELECT s.id::text, s.campaign_id::text, s.keyword_text, s.status::text,
                    s.grid_signature, s.search_config, s.is_demo, s.keyword_id::text
                FROM scans s WHERE s.id IN (CAST(:a AS uuid), CAST(:b AS uuid))"""), {"a": prev_id, "b": cur_id})}
        if prev_id not in rows or cur_id not in rows:
            raise ReportError("The selected scans were not found")
        p, c = rows[prev_id], rows[cur_id]
        if p[3] not in FINISHED or c[3] not in FINISHED:
            raise ReportError("Both scans must have finished with results")
        if (p[7], p[4], p[5], p[6]) != (c[7], c[4], c[5], c[6]):
            raise ReportError("The scans use a different keyword, grid or search settings and cannot be compared")
        camp = next((x for x in campaigns if x["id"] == c[1]), None)
        if camp is None:
            raise ReportError("The scans do not belong to this client's campaigns")
        sections.append(_section(conn, camp, c[2], cur_id, prev_id, [prev_id, cur_id]))
    else:
        for camp in campaigns:
            for kw_id, kw, paused in conn.execute(text("""SELECT id::text, keyword, is_paused FROM keywords
                                                         WHERE campaign_id = :c ORDER BY keyword"""), {"c": camp["id"]}):
                in_period = [r[0] for r in conn.execute(text("""SELECT id::text FROM scans
                        WHERE keyword_id = :k AND status IN ('completed','partial')
                          AND (completed_at AT TIME ZONE 'UTC')::date BETWEEN :a AND :b ORDER BY completed_at"""),
                        {"k": kw_id, "a": start, "b": end})]
                if not in_period:
                    if not paused:
                        without.append(f"{camp['name']} · {kw}")
                    continue
                current = in_period[-1]
                cur = conn.execute(text("SELECT grid_signature, search_config, is_demo FROM scans WHERE id = :s"),
                                   {"s": current}).one()
                comparable = """keyword_id = :k AND status IN ('completed','partial') AND grid_signature = :g
                                AND search_config = CAST(:cfg AS jsonb) AND is_demo = :demo"""
                params = {"k": kw_id, "g": cur[0], "cfg": json.dumps(cur[1]), "demo": cur[2], "a": start}
                previous = conn.execute(text(f"""SELECT id::text FROM scans WHERE {comparable}
                        AND (completed_at AT TIME ZONE 'UTC')::date < :a ORDER BY completed_at DESC LIMIT 1"""), params).scalar()
                same = [r[0] for r in conn.execute(text(f"""SELECT id::text FROM scans WHERE {comparable}
                        AND id = ANY(CAST(:ids AS uuid[])) ORDER BY completed_at"""), params | {"ids": in_period})]
                if previous is None and len(same) > 1:
                    previous = same[0]
                history = ([previous] if previous and previous not in same else []) + same
                sections.append(_section(conn, camp, kw, current, previous, history))

    return ReportModel(
        title=report["title"], report_type=report["report_type"], client_name=client[0],
        client_logo_png=_b64(client[1]),
        period_start=start, period_end=end, generated_at=now or datetime.now(timezone.utc),
        branding=branding, sections=sections, recommendations=(opts.get("recommendations") or None),
        without_data=without, include_competitors=opts.get("include_competitors", True),
        include_history=opts.get("include_history", True),
        data_source=", ".join(sorted({"demo data (synthetic)" if s.is_demo else "DataForSEO Google Maps SERP API" for s in sections})))


def create_report(conn: Connection, org_id: str, client_id: str, report_type: str, period_start: date, period_end: date,
                  options: dict, title: Optional[str] = None, created_by: Optional[str] = None,
                  schedule_id: Optional[str] = None, idempotency_key: Optional[str] = None) -> Optional[str]:
    if period_end < period_start:
        raise ReportError("The period ends before it starts")
    return conn.execute(text("""INSERT INTO reports (org_id, client_id, report_type, title, period_start, period_end, options,
                                   created_by, schedule_id, idempotency_key)
            VALUES (:o, :c, CAST(:t AS report_type), :title, :a, :b, CAST(:opts AS jsonb), :u, :sch, :key)
            ON CONFLICT (org_id, idempotency_key) DO NOTHING RETURNING id::text"""),
            {"o": org_id, "c": client_id, "t": report_type, "title": (title or TYPE_TITLES[report_type])[:200],
             "a": period_start, "b": period_end, "opts": json.dumps(options), "u": created_by, "sch": schedule_id,
             "key": idempotency_key}).scalar()


def generate_report(org_id: str, report_id: str, now: Optional[datetime] = None) -> str:
    """queued -> generating -> ready | failed.  Safe to call twice (atomic claim)."""
    with tenant_tx(org_id) as conn:
        r = conn.execute(text("""UPDATE reports SET status = 'generating' WHERE id = :r AND status = 'queued'
                                 RETURNING id::text, org_id::text, client_id::text, report_type::text, title, period_start,
                                           period_end, options"""), {"r": report_id}).mappings().first()
    if r is None:
        return "skipped"
    try:
        with tenant_tx(org_id) as conn:
            model = build_model(conn, dict(r), now)
        pdf, pages = render_pdf(model)
        csv_text = render_csv(model)
    except Exception as exc:
        log.exception("report %s failed", report_id)
        msg = str(exc) if isinstance(exc, ReportError) else "The report could not be generated. The error was logged."
        with tenant_tx(org_id) as conn:
            conn.execute(text("UPDATE reports SET status = 'failed', error = :e, generated_at = now() WHERE id = :r"),
                         {"e": msg, "r": report_id})
            notify(conn, org_id, "report_failed", f"Report failed: {r['title']}", body=msg, link="/reports",
                   dedupe_key=f"report:{report_id}:failed", min_role="seo_specialist")
        return "failed"
    with tenant_tx(org_id) as conn:
        conn.execute(text("""UPDATE reports SET status = 'ready', pdf = decode(:pdf, 'base64'), csv = :csv, page_count = :n,
                                    is_demo = :demo, error = NULL, generated_at = now() WHERE id = :r"""),
                     {"pdf": base64.b64encode(pdf).decode(), "csv": csv_text, "n": pages, "demo": model.is_demo,
                      "r": report_id})
        notify(conn, org_id, "report_ready", f"Report ready: {r['title']}",
               body=f"{model.client_name} · {r['period_start']:%d %b %Y} – {r['period_end']:%d %b %Y}",
               link=f"/reports?highlight={report_id}", dedupe_key=f"report:{report_id}:ready", min_role="seo_specialist")
    return "ready"


def run_report_schedule(org_id: str, schedule_id: str, enqueue: Callable[[str, str], None],
                        now: Optional[datetime] = None) -> Optional[str]:
    now = now or datetime.now(timezone.utc)
    from zoneinfo import ZoneInfo
    created = None
    with tenant_tx(org_id) as conn:
        s = conn.execute(text("""SELECT id::text, client_id::text, report_type::text, title, campaign_ids, time_zone, local_time,
                                        anchor_date, next_run_at
                                 FROM report_schedules WHERE id = :id AND NOT is_paused AND next_run_at <= :now
                                 FOR UPDATE SKIP LOCKED"""), {"id": schedule_id, "now": now}).mappings().first()
        if s is None:
            return None
        run_day = s["next_run_at"].astimezone(ZoneInfo(s["time_zone"])).date()
        start, end = report_period(s["report_type"], run_day)
        opts = {"campaign_ids": [str(x) for x in s["campaign_ids"]] if s["campaign_ids"] else None}
        created = create_report(conn, org_id, s["client_id"], s["report_type"], start, end, opts, s["title"],
                                schedule_id=s["id"], idempotency_key=f"report-schedule:{s['id']}:{start}:{end}")
        frequency = "weekly" if s["report_type"] == "weekly" else "monthly"
        nxt = next_run(frequency, s["local_time"], s["time_zone"], s["anchor_date"], now)
        conn.execute(text("UPDATE report_schedules SET next_run_at = :n, last_run_at = :now, last_error = NULL WHERE id = :id"),
                     {"n": nxt, "now": now, "id": s["id"]})
    if created:
        enqueue(org_id, created)
    return created


def dispatch_report_schedules(enqueue: Callable[[str, str], None]) -> int:
    with system_tx() as conn:
        due = conn.execute(text("SELECT schedule_id::text, org_id::text FROM due_report_schedules(100)")).all()
        stale = conn.execute(text("SELECT report_id::text, org_id::text FROM stale_queued_reports(10)")).all()
    n = 0
    for schedule_id, org_id in due:
        try:
            n += 1 if run_report_schedule(org_id, schedule_id, enqueue) else 0
        except Exception:
            log.exception("report schedule %s failed", schedule_id)
    for report_id, org_id in stale:
        enqueue(org_id, report_id)
    return n
