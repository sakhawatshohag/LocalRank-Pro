"""Scan lifecycle: create (queued) -> run provider -> store atomically.

Used by the API (create) and by the Celery worker (run).
"""
from __future__ import annotations

import json
import math
from dataclasses import dataclass
from decimal import Decimal
from typing import Optional, Sequence

from sqlalchemy import text
from sqlalchemy.engine import Connection

from app.config import Settings
from app.db import tenant_tx
from app.engine.geogrid import generate_grid, grid_signature
from app.engine.payload import scan_result_to_payload
from app.engine.scan_runner import execute_scan
from app.providers.base import ExecutionMode, RankingProvider, SearchConfig, Subject
from app.providers.dataforseo import DataForSEOProvider
from app.providers.demo import DemoProvider


class ScanSetupError(Exception):
    """The scan cannot be created or run (configuration problem, shown to the user)."""


class UsageLimitError(Exception):
    """The organization's monthly scan allowance would be exceeded."""

    def __init__(self, used: int, limit: int, needed: int) -> None:
        self.used, self.limit, self.needed = used, limit, needed
        super().__init__(f"Monthly scan limit reached ({used}/{limit} grid points used; this scan needs {needed}).")


def monthly_usage(conn: Connection, org_id: str) -> tuple[int, int]:
    """(grid points scanned this calendar month, plan limit).  A missing limit counts as 0."""
    used = conn.execute(text("""SELECT coalesce(sum(points_total), 0) FROM scans
                                WHERE created_at >= date_trunc('month', now()) AND status <> 'cancelled'""")).scalar_one()
    limit = conn.execute(text("""SELECT (pl.limits ->> 'monthly_scan_points')::int FROM organizations o
                                 JOIN plans pl ON pl.id = o.plan_id WHERE o.id = :o"""), {"o": org_id}).scalar()
    return int(used), int(limit or 0)


def check_monthly_limit(conn: Connection, org_id: str, needed: int) -> tuple[int, int]:
    used, limit = monthly_usage(conn, org_id)
    if used + needed > limit:
        raise UsageLimitError(used, limit, needed)
    return used, limit


def active_keyword_count(conn: Connection, campaign_id: str, keyword_ids: Optional[Sequence[str]] = None) -> int:
    return conn.execute(text("""SELECT count(*) FROM keywords WHERE campaign_id = :c AND NOT is_paused
                AND (CAST(:ids AS uuid[]) IS NULL OR id = ANY(CAST(:ids AS uuid[])))"""),
                {"c": campaign_id, "ids": list(keyword_ids) if keyword_ids else None}).scalar_one()


@dataclass(frozen=True)
class CostEstimate:
    api_requests: int
    estimated_cost_usd: Decimal
    unit_price_usd: Decimal


def choose_provider_code(settings: Settings) -> str:
    if settings.dataforseo_configured:
        return "dataforseo"
    if settings.demo_mode:
        return "demo"
    raise ScanSetupError("No ranking provider is configured. Add DataForSEO credentials, "
                         "or enable DEMO_MODE outside production for synthetic demo data.")


def unit_price(conn: Connection, provider_code: str, mode: ExecutionMode) -> tuple[Decimal, int]:
    row = conn.execute(text("""SELECT unit_price_usd, results_per_unit FROM api_pricing
                               WHERE provider_code = :p AND mode = CAST(:m AS execution_mode)"""),
                       {"p": provider_code, "m": mode.value}).first()
    if row is None:
        raise ScanSetupError(f"No price configured for provider '{provider_code}' in {mode.value} mode")
    return Decimal(row[0]), int(row[1])


def estimate(conn: Connection, provider_code: str, points: int, keywords: int, depth: int,
             mode: ExecutionMode = ExecutionMode.LIVE) -> CostEstimate:
    price, per_unit = unit_price(conn, provider_code, mode)
    requests_needed = points * keywords
    return CostEstimate(requests_needed, Decimal(requests_needed) * math.ceil(depth / per_unit) * price, price)


def load_subjects(conn: Connection, campaign_id: str) -> list[Subject]:
    loc = conn.execute(text("""SELECT l.id::text, l.place_id, l.cid FROM campaigns c
                               JOIN business_locations l ON l.id = c.location_id WHERE c.id = :c"""),
                       {"c": campaign_id}).first()
    if loc is None:
        raise ScanSetupError("Campaign not found")
    if not (loc[1] or loc[2]):
        raise ScanSetupError("The business location needs a Google Place ID or CID before it can be tracked. "
                             "Rankings are matched by identifier, never by business name.")
    subjects = [Subject(f"location:{loc[0]}", loc[1], loc[2])]
    for cid_, place_id, cid in conn.execute(
            text("SELECT id::text, place_id, cid FROM competitors WHERE campaign_id = :c ORDER BY created_at"),
            {"c": campaign_id}):
        subjects.append(Subject(f"competitor:{cid_}", place_id, cid))
    return subjects


def create_scans(conn: Connection, org_id: str, campaign_id: str, keyword_ids: Optional[Sequence[str]],
                 settings: Settings, *, schedule_id: Optional[str] = None,
                 occurrence: Optional[str] = None) -> list[dict]:
    """Insert one queued scan per active keyword.  Snapshots grid and search settings.

    For scheduled runs pass ``schedule_id`` and ``occurrence`` (local date): the unique
    idempotency key makes a repeated trigger for the same occurrence a no-op.
    """
    c = conn.execute(text("""SELECT grid_size, spacing_m, center_lat, center_lng, language_code, se_domain, device,
                                    zoom, depth, is_active FROM campaigns WHERE id = :c"""),
                     {"c": campaign_id}).mappings().first()
    if c is None:
        raise ScanSetupError("Campaign not found")
    if not c["is_active"]:
        raise ScanSetupError("Campaign is paused")
    load_subjects(conn, campaign_id)  # validates that the location can be matched
    provider_code = choose_provider_code(settings)
    if not conn.execute(text("SELECT is_enabled FROM api_providers WHERE code = :p"), {"p": provider_code}).scalar():
        raise ScanSetupError("The ranking provider is temporarily disabled by the platform administrator.")
    keywords = conn.execute(text("""SELECT id::text, keyword FROM keywords
            WHERE campaign_id = :c AND NOT is_paused
              AND (CAST(:ids AS uuid[]) IS NULL OR id = ANY(CAST(:ids AS uuid[]))) ORDER BY created_at"""),
            {"c": campaign_id, "ids": list(keyword_ids) if keyword_ids else None}).all()
    if not keywords:
        raise ScanSetupError("No active keywords to scan")
    points = c["grid_size"] ** 2
    per_scan = estimate(conn, provider_code, points, 1, c["depth"]).estimated_cost_usd
    signature = grid_signature(c["center_lat"], c["center_lng"], c["grid_size"], float(c["spacing_m"]))
    search_config = {k: c[k] for k in ("language_code", "se_domain", "device", "zoom", "depth")}
    created = []
    for kw_id, kw_text in keywords:
        key = f"{schedule_id}:{kw_id}:{occurrence}" if schedule_id and occurrence else None
        row = conn.execute(text("""
            INSERT INTO scans (org_id, campaign_id, keyword_id, keyword_text, provider_code, is_demo, grid_size,
                               spacing_m, center_lat, center_lng, grid_signature, search_config, depth,
                               schedule_id, idempotency_key, estimated_cost_usd, points_total)
            VALUES (:org, :c, :kw, :kwt, :prov, :demo, :gs, :sp, :lat, :lng, :sig, CAST(:cfg AS jsonb), :depth,
                    :sched, :key, :est, :pts)
            ON CONFLICT (org_id, idempotency_key) DO NOTHING
            RETURNING id::text"""),
            {"org": org_id, "c": campaign_id, "kw": kw_id, "kwt": kw_text, "prov": provider_code,
             "demo": provider_code == "demo", "gs": c["grid_size"], "sp": c["spacing_m"], "lat": c["center_lat"],
             "lng": c["center_lng"], "sig": signature, "cfg": json.dumps(search_config), "depth": c["depth"],
             "sched": schedule_id, "key": key, "est": per_scan, "pts": points}).first()
        if row:  # None = this scheduled occurrence already exists
            created.append({"scan_id": row[0], "keyword_id": kw_id, "keyword": kw_text,
                            "estimated_cost_usd": str(per_scan), "provider": provider_code,
                            "is_demo": provider_code == "demo"})
    return created


def build_provider(conn: Connection, provider_code: str, settings: Settings,
                   subjects: Sequence[Subject], epoch: str) -> RankingProvider:
    if provider_code == "dataforseo":
        if not settings.dataforseo_configured:
            raise ScanSetupError("DataForSEO credentials are not configured")
        prices = {m: unit_price(conn, "dataforseo", m)[0] for m in ExecutionMode}
        return DataForSEOProvider(settings.dataforseo_login, settings.dataforseo_password, prices.__getitem__)
    if provider_code == "demo":
        if not settings.demo_mode:
            raise ScanSetupError("Demo mode is disabled")
        return DemoProvider(subjects, epoch=epoch)
    raise ScanSetupError(f"Unknown provider '{provider_code}'")


def run_scan(org_id: str, scan_id: str, settings: Settings) -> str:
    """Execute a queued scan.  Safe to call twice: only the caller that moves the scan from
    'queued' to 'running' proceeds, and results can be stored only once."""
    with tenant_tx(org_id) as conn:
        s = conn.execute(text("""UPDATE scans SET status = 'running', started_at = now()
                                 WHERE id = :s AND status = 'queued'
                                 RETURNING campaign_id::text, keyword_text, provider_code, grid_size, spacing_m,
                                           center_lat, center_lng, grid_signature, search_config, created_at"""),
                         {"s": scan_id}).mappings().first()
        if s is None:
            return "skipped"  # already running/finished or not visible to this organization
        subjects = load_subjects(conn, s["campaign_id"])
        provider = build_provider(conn, s["provider_code"], settings, subjects, epoch=str(s["created_at"].date()))
    cfg = s["search_config"]
    points = generate_grid(s["center_lat"], s["center_lng"], s["grid_size"], float(s["spacing_m"]))
    config = SearchConfig(keyword=s["keyword_text"], language_code=cfg["language_code"], zoom=cfg["zoom"],
                          depth=cfg["depth"], device=cfg["device"], se_domain=cfg.get("se_domain"))
    # Provider calls happen OUTSIDE any database transaction (they can take minutes).
    result = execute_scan(provider, points, config, subjects, scan_id=scan_id)
    payload = scan_result_to_payload(points, result, s["grid_signature"])
    with tenant_tx(org_id) as conn:
        return conn.execute(text("SELECT store_scan_result(CAST(:s AS uuid), CAST(:p AS jsonb))::text"),
                            {"s": scan_id, "p": json.dumps(payload)}).scalar_one()


def mark_scan_failed(org_id: str, scan_id: str) -> None:
    """Called when the worker itself crashes: the scan must not stay 'running' forever."""
    with tenant_tx(org_id) as conn:
        conn.execute(text("""UPDATE scans SET status = 'failed', completed_at = now()
                             WHERE id = :s AND status IN ('queued', 'running')"""), {"s": scan_id})
