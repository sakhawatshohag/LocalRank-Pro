"""Creates in-app notifications.  Email is prepared only: rows for users who opted in are marked
``email_status = 'pending'`` for a future mailer.

Notification failures are logged and never fail the scan or request that triggered them.
"""
from __future__ import annotations

import json
import logging
from datetime import datetime, timezone
from typing import Optional

from sqlalchemy import text
from sqlalchemy.engine import Connection

from app.db import tenant_tx
from app.engine.alerts import detect_change

log = logging.getLogger("localrank.notifications")

TYPES = ("scan_completed", "scan_failed", "ranking_improved", "ranking_declined", "competitor_change",
         "usage_warning", "schedule_problem", "report_ready", "report_failed",
         "billing_problem")
USAGE_WARNING_RATIO = 0.8
ROLE_RANK_SQL = """CASE m.role WHEN 'owner' THEN 50 WHEN 'admin' THEN 40 WHEN 'manager' THEN 30
                   WHEN 'seo_specialist' THEN 20 ELSE 10 END"""
ROLE_RANK = {"client_viewer": 10, "seo_specialist": 20, "manager": 30, "admin": 40, "owner": 50}


def notify(conn: Connection, org_id: str, type_: str, title: str, *, body: Optional[str] = None,
           link: Optional[str] = None, data: Optional[dict] = None, dedupe_key: Optional[str] = None,
           min_role: str = "client_viewer") -> int:
    """One row per member of the organization who has this type switched on (default: on).
    ``dedupe_key`` makes repeated calls for the same event a no-op."""
    if type_ not in TYPES:
        raise ValueError(f"unknown notification type {type_}")
    return conn.execute(text(f"""
        INSERT INTO notifications (org_id, user_id, type, title, body, link, data, dedupe_key, email_status)
        SELECT :org, m.user_id, CAST(:t AS notification_type), :title, :body, :link, CAST(:data AS jsonb), :key,
               CASE WHEN coalesce(p.email, false) THEN 'pending' ELSE 'not_requested' END
        FROM organization_members m
        JOIN users u ON u.id = m.user_id AND u.is_active
        LEFT JOIN notification_preferences p
               ON p.org_id = m.org_id AND p.user_id = m.user_id AND p.type = CAST(:t AS notification_type)
        WHERE m.org_id = :org AND coalesce(p.in_app, true) AND {ROLE_RANK_SQL} >= :min_rank
        ON CONFLICT (user_id, dedupe_key) WHERE dedupe_key IS NOT NULL DO NOTHING"""),
        {"org": org_id, "t": type_, "title": title[:200], "body": body, "link": link,
         "data": json.dumps(data) if data is not None else None, "key": dedupe_key,
         "min_rank": ROLE_RANK[min_role]}).rowcount


def _metrics(conn: Connection, scan_id: str) -> dict[str, dict]:
    rows = conn.execute(text("""SELECT coalesce(m.location_id, m.competitor_id)::text AS sid, m.subject_type::text AS kind,
                                       coalesce(l.name, c.name) AS name,
                                       m.average_position::float8 AS average_position, m.top10_coverage::float8 AS top10_coverage,
                                       m.valid_points
                                FROM historical_metrics m
                                LEFT JOIN business_locations l ON l.id = m.location_id
                                LEFT JOIN competitors c ON c.id = m.competitor_id
                                WHERE m.scan_id = :s"""), {"s": scan_id}).mappings().all()
    return {r["sid"]: dict(r) for r in rows}


def scan_notifications(conn: Connection, org_id: str, scan_id: str) -> int:
    s = conn.execute(text("""SELECT id::text, campaign_id::text, keyword_id::text, keyword_text, status::text, is_demo,
                                    grid_signature, search_config, points_failed, points_total, created_at
                             FROM scans WHERE id = :s"""), {"s": scan_id}).mappings().first()
    if s is None or s["status"] in ("queued", "running"):
        return 0
    link = f"/scans/{scan_id}"
    kw = f"“{s['keyword_text']}”"
    demo = " (demo data)" if s["is_demo"] else ""
    if s["status"] in ("failed", "cancelled"):
        return notify(conn, org_id, "scan_failed", f"Scan failed: {kw}{demo}",
                      body="No usable data was returned, so no rankings were recorded. You can retry the scan.",
                      link=link, dedupe_key=f"scan:{scan_id}:failed", min_role="seo_specialist")
    body = (f"{s['points_failed']} of {s['points_total']} points returned no data and are excluded from metrics."
            if s["status"] == "partial" else None)
    n = notify(conn, org_id, "scan_completed", f"Scan completed: {kw}{demo}", body=body, link=link,
               dedupe_key=f"scan:{scan_id}:completed")

    # previous comparable scan: same keyword, grid, search settings and data source type
    prev = conn.execute(text("""SELECT id::text FROM scans
            WHERE keyword_id = :k AND id <> :s AND status IN ('completed','partial') AND grid_signature = :g
              AND search_config = CAST(:cfg AS jsonb) AND is_demo = :demo AND created_at < :created
            ORDER BY created_at DESC LIMIT 1"""),
            {"k": s["keyword_id"], "s": scan_id, "g": s["grid_signature"], "cfg": json.dumps(s["search_config"]),
             "demo": s["is_demo"], "created": s["created_at"]}).scalar()
    if prev is None:
        return n
    before, after = _metrics(conn, prev), _metrics(conn, scan_id)
    compare_link = f"/campaigns/{s['campaign_id']}/compare"
    for sid, cur in after.items():
        change = detect_change(before.get(sid), cur)
        if change is None:
            continue
        reasons = "; ".join(change.reasons)
        if cur["kind"] == "location":
            n += notify(conn, org_id, f"ranking_{change.direction}",
                        f"Rankings {change.direction} for {kw}{demo}", body=reasons, link=compare_link,
                        data=change.data | {"previous_scan_id": prev, "scan_id": scan_id},
                        dedupe_key=f"scan:{scan_id}:{change.direction}")
        elif change.direction == "improved":   # a competitor gaining ground is what needs attention
            n += notify(conn, org_id, "competitor_change", f"{cur['name']} gained ground on {kw}{demo}",
                        body=reasons, link=f"/scans/{scan_id}/competitors",
                        data=change.data | {"competitor_id": sid, "previous_scan_id": prev, "scan_id": scan_id},
                        dedupe_key=f"scan:{scan_id}:competitor:{sid}")
    return n


def after_scan(org_id: str, scan_id: str) -> None:
    try:
        with tenant_tx(org_id) as conn:
            scan_notifications(conn, org_id, scan_id)
    except Exception:
        log.exception("could not create notifications for scan %s", scan_id)


def usage_notification(conn: Connection, org_id: str, used: int, limit: int, now: Optional[datetime] = None) -> int:
    if limit <= 0 or used < USAGE_WARNING_RATIO * limit:
        return 0
    month = (now or datetime.now(timezone.utc)).strftime("%Y-%m")
    full = used >= limit
    return notify(conn, org_id, "usage_warning",
                  "Monthly scan allowance used up" if full else f"{round(100 * used / limit)}% of monthly scan allowance used",
                  body=f"{used} of {limit} grid points used this month." + (" New scans are blocked until next month or an upgrade." if full else ""),
                  data={"used": used, "limit": limit}, dedupe_key=f"usage:{month}:{'100' if full else '80'}", min_role="manager")


def warn_usage(org_id: str, used: int, limit: int) -> None:
    try:
        with tenant_tx(org_id) as conn:
            usage_notification(conn, org_id, used, limit)
    except Exception:
        log.exception("could not create usage notification for org %s", org_id)
