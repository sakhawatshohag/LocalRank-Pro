"""Scheduled scan dispatch.  Called every minute by Celery beat (see app/worker.py).

Guarantees
* one scan per keyword per scheduled occurrence: the occurrence key (local date) is part of the
  scans' unique idempotency key, so a repeated or concurrent dispatch creates nothing new;
* a schedule row is locked (FOR UPDATE SKIP LOCKED) while it is processed, so two dispatchers
  never handle the same schedule at once;
* problems (no keywords, missing Place ID, plan limit) are recorded on the schedule and sent as a
  notification; the schedule then moves on to its next occurrence instead of retrying forever.
"""
from __future__ import annotations

import logging
from datetime import datetime, timezone
from typing import Callable, Optional

from sqlalchemy import text

from app.config import Settings
from app.db import system_tx, tenant_tx
from app.engine.schedule import next_run, occurrence_key
from app.services.notifications import notify, usage_notification
from app.services.scans import (
    ScanSetupError, UsageLimitError, active_keyword_count, check_monthly_limit, create_scans,
)

log = logging.getLogger("localrank.schedules")


def run_schedule(org_id: str, schedule_id: str, settings: Settings, enqueue: Callable[[str, str], None],
                 now: Optional[datetime] = None) -> int:
    now = now or datetime.now(timezone.utc)
    created: list[dict] = []
    with tenant_tx(org_id) as conn:
        s = conn.execute(text("""
            SELECT s.id::text, s.campaign_id::text, s.frequency::text, s.interval_days, s.local_time, s.anchor_date,
                   s.next_run_at, c.name AS campaign_name, c.grid_size, l.time_zone
            FROM scan_schedules s JOIN campaigns c ON c.id = s.campaign_id
            JOIN business_locations l ON l.id = c.location_id
            WHERE s.id = :id AND NOT s.is_paused AND s.next_run_at <= :now
            FOR UPDATE OF s SKIP LOCKED"""), {"id": schedule_id, "now": now}).mappings().first()
        if s is None:
            return 0          # not due any more, paused, or being handled by another dispatcher
        occurrence = occurrence_key(s["next_run_at"], s["time_zone"])
        error = None
        try:
            needed = active_keyword_count(conn, s["campaign_id"]) * s["grid_size"] ** 2
            if needed == 0:
                raise ScanSetupError("The campaign has no active keywords")
            used, limit = check_monthly_limit(conn, org_id, needed)
            created = create_scans(conn, org_id, s["campaign_id"], None, settings,
                                   schedule_id=s["id"], occurrence=occurrence)
            usage_notification(conn, org_id, used + needed, limit, now)
        except (ScanSetupError, UsageLimitError) as exc:
            error = str(exc)
            notify(conn, org_id, "schedule_problem", f"Scheduled scan skipped: {s['campaign_name']}",
                   body=error, link=f"/campaigns/{s['campaign_id']}",
                   dedupe_key=f"schedule:{s['id']}:{occurrence}", min_role="seo_specialist")
        nxt = next_run(s["frequency"], s["local_time"], s["time_zone"], s["anchor_date"], now,
                       interval_days=s["interval_days"])
        conn.execute(text("""UPDATE scan_schedules SET next_run_at = :n, last_run_at = :now, last_occurrence = :o,
                                    last_error = :e, updated_at = :now WHERE id = :id"""),
                     {"n": nxt, "now": now, "o": occurrence, "e": error, "id": s["id"]})
    for c in created:        # only after commit, so workers can see the rows
        enqueue(org_id, c["scan_id"])
    return len(created)


def dispatch_due(settings: Settings, enqueue: Callable[[str, str], None], limit: int = 100) -> int:
    with system_tx() as conn:
        due = conn.execute(text("SELECT schedule_id::text, org_id::text FROM due_schedules(:l)"), {"l": limit}).all()
    total = 0
    for schedule_id, org_id in due:
        try:
            total += run_schedule(org_id, schedule_id, settings, enqueue)
        except Exception:     # one broken schedule must not stop the others
            log.exception("schedule %s failed to dispatch", schedule_id)
    return total


def maintenance(enqueue: Callable[[str, str], None], after_scan: Callable[[str, str], None]) -> dict:
    """Re-enqueue scans that were never picked up; fail scans stuck in 'running'."""
    with system_tx() as conn:
        stale = conn.execute(text("SELECT scan_id::text, org_id::text FROM stale_queued_scans(10)")).all()
        stuck = conn.execute(text("SELECT scan_id::text, org_id::text FROM fail_stuck_scans(180)")).all()
    for scan_id, org_id in stale:
        enqueue(org_id, scan_id)      # safe: a scan is claimed atomically and runs at most once
    for scan_id, org_id in stuck:
        after_scan(org_id, scan_id)
    return {"requeued": len(stale), "failed_stuck": len(stuck)}
