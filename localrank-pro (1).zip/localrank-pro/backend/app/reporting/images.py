"""Logo upload validation.  Uploads arrive as base64 JSON (no multipart dependency), are decoded
by Pillow, size-checked and re-encoded as PNG, so only clean image data is ever stored."""
from __future__ import annotations

import base64
import binascii
import io

from PIL import Image, UnidentifiedImageError

MAX_UPLOAD_BYTES = 1_000_000
MAX_SIDE = 1200          # stored logos are scaled down to fit
ALLOWED = {"PNG", "JPEG", "WEBP"}


class LogoError(ValueError):
    pass


def clean_logo(data_b64: str) -> bytes:
    try:
        raw = base64.b64decode(data_b64.split(",", 1)[-1], validate=True)   # accepts data: URLs too
    except (binascii.Error, ValueError):
        raise LogoError("The logo is not valid base64 data")
    if len(raw) > MAX_UPLOAD_BYTES:
        raise LogoError("The logo must be 1 MB or smaller")
    Image.MAX_IMAGE_PIXELS = 25_000_000
    try:
        img = Image.open(io.BytesIO(raw))
        fmt = img.format
        img.load()
    except (UnidentifiedImageError, OSError, Image.DecompressionBombError):
        raise LogoError("The logo must be a PNG, JPEG or WebP image")
    if fmt not in ALLOWED:
        raise LogoError("The logo must be a PNG, JPEG or WebP image")
    img = img.convert("RGBA")
    img.thumbnail((MAX_SIDE, MAX_SIDE))
    out = io.BytesIO()
    img.save(out, "PNG", optimize=True)
    return out.getvalue()
