"""PDF and CSV rendering of a ReportModel (reportlab).

GeoGrid maps are drawn as vector grids (north at the top) rather than Google map images: map
tiles in a PDF would need the Maps Static API and its terms, and the grid itself carries the
ranking information.
"""
from __future__ import annotations

import csv
import io
from typing import Optional

from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.lib.utils import ImageReader
from reportlab.platypus import (
    Flowable, Image, KeepTogether, PageBreak, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle,
)
from xml.sax.saxutils import escape as _xml_escape

from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

from app.engine.report_model import KeywordSection, PointView, ReportModel, TYPE_TITLES, executive_summary, fmt, section_observations

BUCKETS = {  # same colours as the web app (frontend/src/lib/geogrid.ts)
    "green": ("#16a34a", "#ffffff"), "yellow": ("#facc15", "#1f2937"), "orange": ("#f97316", "#ffffff"),
    "red": ("#dc2626", "#ffffff"), "gray": ("#9ca3af", "#ffffff"), "error": ("#ffffff", "#b91c1c"),
}
LEGEND = [("green", "1–3"), ("yellow", "4–10"), ("orange", "11–20"), ("red", "21+"), ("gray", "Not found"), ("error", "No data")]
PAGE_W, PAGE_H = A4
FONT_DIRS = ("/usr/share/fonts/truetype/dejavu", "/usr/share/fonts/dejavu", "/usr/local/share/fonts")


def _register_fonts() -> tuple[str, str, bool]:
    """DejaVu Sans (Unicode: arrows, minus sign, accented business names) when installed,
    otherwise the built-in Helvetica with ASCII substitutes.  The Docker image installs
    fonts-dejavu-core."""
    import os
    for d in (os.getenv("REPORT_FONT_DIR"), *FONT_DIRS):
        if d and os.path.exists(os.path.join(d, "DejaVuSans.ttf")) and os.path.exists(os.path.join(d, "DejaVuSans-Bold.ttf")):
            pdfmetrics.registerFont(TTFont("LRP-Sans", os.path.join(d, "DejaVuSans.ttf")))
            pdfmetrics.registerFont(TTFont("LRP-Sans-Bold", os.path.join(d, "DejaVuSans-Bold.ttf")))
            return "LRP-Sans", "LRP-Sans-Bold", True
    return "Helvetica", "Helvetica-Bold", False


FONT, FONT_BOLD, UNICODE = _register_fonts()
_ASCII = {"→": "->", "−": "-", "↑": "^", "“": '"', "”": '"', "–": "-", "—": "-", "…": "...", "★": "*"}


def t(text: str) -> str:
    """Text safe for the active font."""
    if UNICODE:
        return text
    return "".join(_ASCII.get(ch, ch) for ch in text).encode("latin-1", "replace").decode("latin-1")


def escape(text: str) -> str:
    return _xml_escape(t(text))
MARGIN = 16 * mm


def bucket(p: PointView) -> str:
    if p.status == "error":
        return "error"
    if p.status == "not_found" or p.position is None:
        return "gray"
    return "green" if p.position <= 3 else "yellow" if p.position <= 10 else "orange" if p.position <= 20 else "red"


def label(p: PointView, depth: int) -> str:
    b = bucket(p)
    return "!" if b == "error" else f"{depth}+" if b == "gray" else str(p.position)


class GridFlowable(Flowable):
    """Square GeoGrid: one coloured circle per point with its position."""

    def __init__(self, points: list[PointView], size: int, depth: int, width: float, caption: str) -> None:
        super().__init__()
        self.points, self.size, self.depth, self.caption = points, size, depth, caption
        self.width = width
        self.height = width + 14

    def draw(self) -> None:
        c = self.canv
        cell = self.width / self.size
        r = cell * 0.42
        c.setStrokeColor(colors.HexColor("#e2e8f0"))
        c.setFillColor(colors.HexColor("#f8fafc"))
        c.rect(0, 14, self.width, self.width, stroke=1, fill=1)
        font = max(4.5, min(9.0, cell * 0.34))
        for p in self.points:
            x = (p.col + 0.5) * cell
            y = 14 + self.width - (p.row + 0.5) * cell
            bg, fg = BUCKETS[bucket(p)]
            c.setFillColor(colors.HexColor(bg))
            if bucket(p) == "error":
                c.setStrokeColor(colors.HexColor("#b91c1c"))
                c.setDash(1.5, 1.5)
            else:
                c.setStrokeColor(colors.white)
                c.setDash()
            c.circle(x, y, r, stroke=1, fill=1)
            c.setDash()
            c.setFillColor(colors.HexColor(fg))
            c.setFont(FONT_BOLD, font)
            c.drawCentredString(x, y - font * 0.35, label(p, self.depth))
        c.setFillColor(colors.HexColor("#475569"))
        c.setFont(FONT_BOLD, 7)
        c.drawRightString(self.width - 2, 14 + self.width + 2, t("N ↑"))
        c.setFont(FONT, 7.5)
        c.drawString(0, 3, t(self.caption))


class Legend(Flowable):
    def __init__(self, width: float) -> None:
        super().__init__()
        self.width, self.height = width, 10

    def draw(self) -> None:
        c, x = self.canv, 0
        c.setFont(FONT, 7.5)
        for key, text in LEGEND:
            bg, _ = BUCKETS[key]
            c.setFillColor(colors.HexColor(bg))
            c.setStrokeColor(colors.HexColor("#b91c1c") if key == "error" else colors.HexColor("#94a3b8"))
            c.circle(x + 4, 4, 3.5, stroke=1, fill=1)
            c.setFillColor(colors.HexColor("#334155"))
            c.drawString(x + 10, 1.5, t(text))
            x += 14 + c.stringWidth(t(text), FONT, 7.5) + 10


def _styles(primary: str):
    ss = getSampleStyleSheet()
    base = ParagraphStyle("base", parent=ss["Normal"], fontName=FONT, fontSize=9.5, leading=13, textColor=colors.HexColor("#1e293b"))
    return {
        "base": base,
        "small": ParagraphStyle("small", parent=base, fontSize=8, leading=10.5, textColor=colors.HexColor("#475569")),
        "h1": ParagraphStyle("h1", parent=base, fontName=FONT_BOLD, fontSize=22, leading=27, textColor=colors.HexColor(primary)),
        "h2": ParagraphStyle("h2", parent=base, fontName=FONT_BOLD, fontSize=14, leading=18, spaceBefore=6, spaceAfter=6,
                             textColor=colors.HexColor(primary)),
        "h3": ParagraphStyle("h3", parent=base, fontName=FONT_BOLD, fontSize=11, leading=14, spaceBefore=6, spaceAfter=3),
        "bullet": ParagraphStyle("bullet", parent=base, leftIndent=10, bulletIndent=0, spaceAfter=2, alignment=TA_LEFT),
    }


def _p(text: str, style) -> Paragraph:
    return Paragraph(escape(text).replace("\n", "<br/>"), style)


def _logo(data: Optional[bytes], max_w: float, max_h: float) -> Optional[Image]:
    if not data:
        return None
    reader = ImageReader(io.BytesIO(data))
    w, h = reader.getSize()
    scale = min(max_w / w, max_h / h)
    return Image(io.BytesIO(data), width=w * scale, height=h * scale)


def _table(rows: list[list], widths: list[float], primary: str, header_rows: int = 1) -> Table:
    rows = [[t(c) if isinstance(c, str) else c for c in r] for r in rows]
    tbl = Table(rows, colWidths=widths, repeatRows=header_rows)
    tbl.setStyle(TableStyle([
        ("FONT", (0, 0), (-1, -1), FONT, 8.5),
        ("FONT", (0, 0), (-1, header_rows - 1), FONT_BOLD, 8.5),
        ("TEXTCOLOR", (0, 0), (-1, header_rows - 1), colors.white),
        ("BACKGROUND", (0, 0), (-1, header_rows - 1), colors.HexColor(primary)),
        ("ROWBACKGROUNDS", (0, header_rows), (-1, -1), [colors.white, colors.HexColor("#f1f5f9")]),
        ("GRID", (0, 0), (-1, -1), 0.25, colors.HexColor("#cbd5e1")),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("ALIGN", (1, 0), (-1, -1), "CENTER"),
        ("TOPPADDING", (0, 0), (-1, -1), 3), ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
    ]))
    return tbl


def _arrow(prev, cur, suffix: str = "") -> str:
    if prev is None or cur is None:
        return fmt(cur, suffix)
    return f"{fmt(prev, suffix)} → {fmt(cur, suffix)}"


def _section(s: KeywordSection, model: ReportModel, st, primary: str) -> list:
    out: list = [_p(f"“{s.keyword}”", st["h2"]),
                 _p(f"{s.campaign_name} · {s.location_name} · {s.grid_size}×{s.grid_size} grid, {fmt(s.spacing_m)} m between points · "
                    f"results checked to depth {s.depth}", st["small"]),
                 Spacer(1, 4)]
    cur_date = s.current.completed_at.strftime("%d %b %Y %H:%M UTC")
    prev_date = s.previous.completed_at.strftime("%d %b %Y %H:%M UTC") if s.previous else None
    mine = next((b for b in s.businesses if b.is_mine), None)
    pm, cm = (mine.previous if mine else None), (mine.current if mine else None)
    g = lambda m, k: (m or {}).get(k)  # noqa: E731
    rows = [["Metric", "Previous" if s.previous else "—", "Current", "Change"]]
    for key, name, suffix, lower_better in (("average_position", "Average position", "", True),
                                            ("top3_coverage", "Top 3 coverage", "%", False),
                                            ("top10_coverage", "Top 10 coverage", "%", False),
                                            ("top20_coverage", "Top 20 coverage", "%", False),
                                            ("not_found_pct", "Not found", "%", True)):
        pv, cv = g(pm, key), g(cm, key)
        if pv is None or cv is None:
            change = "—"
        else:
            d = float(cv) - float(pv)
            better = (d < 0) if lower_better else (d > 0)
            unit = " pts" if suffix == "%" else ""      # coverage changes are percentage points
            change = "no change" if d == 0 else f"{'+' if d > 0 else '−'}{fmt(abs(d))}{unit} ({'better' if better else 'worse'})"
        rows.append([name, fmt(pv, suffix) if s.previous else "—", fmt(cv, suffix), change])
    rows.append(["Valid points", f"{s.previous.valid_points} of {s.previous.total_points}" if s.previous else "—",
                 f"{s.current.valid_points} of {s.current.total_points}", ""])
    out.append(_table(rows, [48 * mm, 36 * mm, 36 * mm, 58 * mm], primary))
    out.append(Spacer(1, 6))

    grid_w = (PAGE_W - 2 * MARGIN - 10 * mm) / 2
    if s.previous:
        grids = Table([[GridFlowable(s.previous_points, s.grid_size, s.depth, grid_w, f"Previous · {prev_date}"),
                        GridFlowable(s.current_points, s.grid_size, s.depth, grid_w, f"Current · {cur_date}")]],
                      colWidths=[grid_w + 5 * mm, grid_w + 5 * mm])
    else:
        grids = Table([[GridFlowable(s.current_points, s.grid_size, s.depth, grid_w, f"Current · {cur_date}"),
                        _p("No earlier comparable scan exists yet, so no change is shown for this keyword.", st["small"])]],
                      colWidths=[grid_w + 5 * mm, grid_w + 5 * mm])
    grids.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "TOP"), ("LEFTPADDING", (0, 0), (-1, -1), 0)]))
    out += [KeepTogether([grids, Spacer(1, 3), Legend(PAGE_W - 2 * MARGIN)]), Spacer(1, 8)]

    obs = section_observations(s)
    if obs:
        out.append(_p("Observations", st["h3"]))
        out += [Paragraph(escape(o), st["bullet"], bulletText="•") for o in obs]

    if model.include_competitors and len(s.businesses) > 1:
        rows = [["Business", "Avg. position", "Top 3", "Top 10", "Top 20", "Valid points"]]
        for b in sorted(s.businesses, key=lambda b: (not b.is_mine, (b.current or {}).get("average_position") is None,
                                                    float((b.current or {}).get("average_position") or 0))):
            m = b.current or {}
            rows.append([f"{b.name}{' (you)' if b.is_mine else ''}", fmt(m.get("average_position")),
                         f"{fmt(m.get('top3_coverage'), '%')} ({m.get('top3_count', '—')})",
                         f"{fmt(m.get('top10_coverage'), '%')} ({m.get('top10_count', '—')})",
                         f"{fmt(m.get('top20_coverage'), '%')} ({m.get('top20_count', '—')})",
                         f"{m.get('valid_points', '—')} of {m.get('total_points', '—')}"])
        out += [_p("Competitor comparison (latest scan, same grid points)", st["h3"]),
                _table(rows, [56 * mm, 24 * mm, 25 * mm, 25 * mm, 25 * mm, 23 * mm], primary)]

    if model.include_history and len(s.history) > 1:
        rows = [["Scan date", "Avg. position", "Top 3", "Top 10", "Valid points"]]
        for h in s.history[-12:]:
            rows.append([h["date"].strftime("%d %b %Y"), fmt(h.get("average_position")), fmt(h.get("top3_coverage"), "%"),
                         fmt(h.get("top10_coverage"), "%"), f"{h['valid_points']} of {h['total_points']}" if h.get("valid_points") is not None else "no data"])
        out += [_p("Scan history in this period", st["h3"]), _table(rows, [40 * mm, 30 * mm, 30 * mm, 30 * mm, 30 * mm], primary)]
    out.append(PageBreak())
    return out


def render_pdf(model: ReportModel) -> tuple[bytes, int]:
    b = model.branding
    primary = b.primary_color or "#0b1f3a"
    st = _styles(primary)
    buf = io.BytesIO()
    agency = b.agency_name or "Your agency"
    pages = {"n": 0}

    def decorate(canvas, doc) -> None:
        pages["n"] = doc.page
        canvas.saveState()
        canvas.setFillColor(colors.HexColor(primary))
        canvas.rect(0, PAGE_H - 6, PAGE_W, 6, stroke=0, fill=1)
        canvas.setFont(FONT, 7.5)
        canvas.setFillColor(colors.HexColor("#64748b"))
        left = " · ".join(x for x in (agency, b.website, b.email, b.phone) if x)
        canvas.drawString(MARGIN, 9 * mm, t(left[:120]))
        canvas.drawRightString(PAGE_W - MARGIN, 9 * mm, f"Page {doc.page}")
        foot = b.footer_text or ""
        if not b.white_label:
            foot = (foot + "   " if foot else "") + "Generated with LocalRank Pro"
        if foot:
            canvas.drawString(MARGIN, 5.5 * mm, t(foot[:140]))
        if model.is_demo:
            canvas.setFont(FONT_BOLD, 8)
            canvas.setFillColor(colors.HexColor("#b91c1c"))
            canvas.drawRightString(PAGE_W - MARGIN, PAGE_H - 12 * mm + 22, t("DEMO DATA – synthetic rankings, not real search results"))
            canvas.setFont(FONT_BOLD, 54)
            canvas.setFillColor(colors.Color(0.86, 0.15, 0.15, alpha=0.12))
            canvas.translate(PAGE_W / 2, PAGE_H / 2)
            canvas.rotate(35)
            canvas.drawCentredString(0, 0, "DEMO DATA")
        canvas.restoreState()

    doc = SimpleDocTemplate(buf, pagesize=A4, leftMargin=MARGIN, rightMargin=MARGIN, topMargin=MARGIN, bottomMargin=18 * mm,
                            title=model.title, author=agency, subject=f"{model.client_name} · {model.period_start} – {model.period_end}",
                            creator="LocalRank Pro" if not b.white_label else agency)
    story: list = []
    logos = [x for x in (_logo(b.logo_png, 60 * mm, 22 * mm), _logo(model.client_logo_png, 50 * mm, 22 * mm)) if x]
    if logos:
        logo_row = Table([logos], colWidths=[(PAGE_W - 2 * MARGIN) / len(logos)] * len(logos))
        logo_row.setStyle(TableStyle([("ALIGN", (-1, 0), (-1, 0), "RIGHT" if len(logos) > 1 else "LEFT"),
                                      ("VALIGN", (0, 0), (-1, -1), "MIDDLE"), ("LEFTPADDING", (0, 0), (-1, -1), 0)]))
        story += [logo_row, Spacer(1, 18 * mm)]
    else:
        story.append(Spacer(1, 30 * mm))
    story += [_p(model.title, st["h1"]), Spacer(1, 4),
              _p(f"Prepared for {model.client_name}", st["h3"]),
              _p(f"Reporting period: {model.period_start:%d %b %Y} – {model.period_end:%d %b %Y}", st["base"]),
              _p(f"Prepared by {agency} · generated {model.generated_at:%d %b %Y %H:%M} UTC", st["small"]),
              Spacer(1, 10)]
    if model.is_demo:
        story.append(_p("This report contains DEMO DATA: synthetic rankings, not real search results.", st["h3"]))
    story += [_p("Executive summary", st["h2"])]
    story += [Paragraph(escape(line), st["bullet"], bulletText="•") for line in executive_summary(model)]
    if model.sections:
        rows = [["Keyword", "Campaign", "Avg. position", "Top 3", "Top 10", "Latest scan"]]
        for s in model.sections:
            m = next((x.current for x in s.businesses if x.is_mine), None) or {}
            p = next((x.previous for x in s.businesses if x.is_mine), None)
            rows.append([s.keyword[:40], s.campaign_name[:30],
                         _arrow((p or {}).get("average_position"), m.get("average_position")),
                         _arrow((p or {}).get("top3_coverage"), m.get("top3_coverage"), "%"),
                         _arrow((p or {}).get("top10_coverage"), m.get("top10_coverage"), "%"),
                         s.current.completed_at.strftime("%d %b %Y")])
        story += [Spacer(1, 6), _table(rows, [44 * mm, 36 * mm, 26 * mm, 24 * mm, 24 * mm, 24 * mm], primary)]
        story.append(_p("Previous → current. Coverage percentages are shares of valid grid points.", st["small"]))
    if model.without_data:
        story += [Spacer(1, 6), _p("No finished scan in this period: " + "; ".join(model.without_data), st["small"])]
    if model.recommendations:
        story += [_p("Recommendations", st["h2"]), _p(model.recommendations, st["base"])]
    story.append(PageBreak())
    for s in model.sections:
        story += _section(s, model, st, primary)

    story += [_p("How to read this report", st["h2"])]
    for line in (
        "Each grid point is a location from which the keyword was searched on Google Maps. The number is the business's position among the organic map results at that point; ads are excluded.",
        "Grey “N+” means the business was not within the first N results at that point. It is not treated as position 0 and is not included in the average position.",
        "“!” means the data provider returned no usable result for that point. These points are excluded from every figure; they are never counted as rankings.",
        "Average position is the mean over points where the business was found. Top 3 / Top 10 / Top 20 coverage is the share of valid points where it ranks within that range.",
        "Changes compare points that are valid in both scans. All businesses in a scan are read from the same search results, so competitors are compared at identical coordinates and times.",
        f"Data source: {model.data_source or 'stored scans'}. Rankings reflect what the data provider observed for each coordinate at scan time.",
    ):
        story.append(Paragraph(escape(line), st["bullet"], bulletText="•"))

    doc.build(story, onFirstPage=decorate, onLaterPages=decorate)
    return buf.getvalue(), pages["n"]


def render_csv(model: ReportModel) -> str:
    out = io.StringIO()
    w = csv.writer(out)
    w.writerow(["report", "client", "period_start", "period_end", "campaign", "keyword", "scan", "scan_date", "business",
                "point", "row", "col", "latitude", "longitude", "status", "position", "demo_data"])
    for s in model.sections:
        for b in s.businesses:
            for p in b.current_points:
                w.writerow([model.title, model.client_name, model.period_start, model.period_end, s.campaign_name, s.keyword,
                            "current", s.current.completed_at.isoformat(), b.name, p.index + 1, p.row, p.col, p.lat, p.lng,
                            p.status, p.position if p.position is not None else "", "yes" if s.is_demo else "no"])
        if s.previous:
            for p in s.previous_points:
                w.writerow([model.title, model.client_name, model.period_start, model.period_end, s.campaign_name, s.keyword,
                            "previous", s.previous.completed_at.isoformat(), next((b.name for b in s.businesses if b.is_mine), ""),
                            p.index + 1, p.row, p.col, p.lat, p.lng, p.status, p.position if p.position is not None else "",
                            "yes" if s.is_demo else "no"])
    return out.getvalue()


def default_title(report_type: str) -> str:
    return TYPE_TITLES.get(report_type, "Ranking Report")
