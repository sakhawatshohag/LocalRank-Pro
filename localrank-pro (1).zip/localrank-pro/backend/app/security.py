"""Password hashing (scrypt, stdlib) and JWT access tokens (PyJWT, HS256)."""
from __future__ import annotations

import base64
import hashlib
import hmac
import secrets
from datetime import datetime, timedelta, timezone
from typing import Any, Optional

import jwt

_N, _R, _P, _DKLEN = 2**15, 8, 1, 32
MIN_PASSWORD_LENGTH = 10


def hash_password(password: str) -> str:
    if len(password) < MIN_PASSWORD_LENGTH:
        raise ValueError(f"password must be at least {MIN_PASSWORD_LENGTH} characters")
    salt = secrets.token_bytes(16)
    dk = hashlib.scrypt(password.encode(), salt=salt, n=_N, r=_R, p=_P, dklen=_DKLEN, maxmem=128 * 1024 * 1024)
    b64 = lambda b: base64.b64encode(b).decode()  # noqa: E731
    return f"scrypt${_N}${_R}${_P}${b64(salt)}${b64(dk)}"


def verify_password(password: str, stored: str) -> bool:
    try:
        scheme, n, r, p, salt, dk = stored.split("$")
        if scheme != "scrypt":
            return False
        expected = base64.b64decode(dk)
        got = hashlib.scrypt(password.encode(), salt=base64.b64decode(salt), n=int(n), r=int(r), p=int(p),
                             dklen=len(expected), maxmem=128 * 1024 * 1024)
        return hmac.compare_digest(got, expected)
    except (ValueError, TypeError):
        return False


def create_access_token(*, secret: str, user_id: str, org_id: str, role: str, ttl_minutes: int = 60,
                        now: Optional[datetime] = None) -> str:
    now = now or datetime.now(timezone.utc)
    payload = {"sub": user_id, "org": org_id, "role": role, "iat": now, "exp": now + timedelta(minutes=ttl_minutes),
               "typ": "access"}
    return jwt.encode(payload, secret, algorithm="HS256")


def decode_access_token(token: str, secret: str) -> dict[str, Any]:
    """Raises jwt.InvalidTokenError on any problem (expired, bad signature, wrong type)."""
    payload = jwt.decode(token, secret, algorithms=["HS256"], options={"require": ["exp", "sub", "org", "role"]})
    if payload.get("typ") != "access":
        raise jwt.InvalidTokenError("wrong token type")
    return payload


# Role hierarchy for RBAC.  Higher number = more privileges.
ROLE_RANK = {"client_viewer": 10, "seo_specialist": 20, "manager": 30, "admin": 40, "owner": 50}


def role_at_least(role: str, minimum: str) -> bool:
    return ROLE_RANK.get(role, 0) >= ROLE_RANK[minimum]


def token_hash(token: str) -> str:
    """Stored form of one-time tokens (invitations): SHA-256 hex; the token itself is never stored."""
    return hashlib.sha256(token.encode()).hexdigest()
