from datetime import date, datetime, time, timezone

import pytest

from app.engine.alerts import Thresholds, detect_change
from app.engine.schedule import ScheduleError, interval_for, next_run, occurrence_key, runs_per_month

UTC = timezone.utc
TOR = "America/Toronto"


def at(*a):
    return datetime(*a, tzinfo=UTC)


def test_daily_runs_at_local_time_and_is_strictly_after():
    # 06:00 Toronto in November (EST, UTC-5) = 11:00 UTC
    r = next_run("daily", time(6, 0), TOR, date(2026, 11, 1), at(2026, 11, 17, 10, 0))
    assert r == at(2026, 11, 17, 11, 0)
    assert next_run("daily", time(6, 0), TOR, date(2026, 11, 1), r) == at(2026, 11, 18, 11, 0)


def test_interval_keeps_rhythm_from_anchor():
    anchor = date(2026, 11, 2)  # Monday
    r = next_run("every_2_days", time(6), TOR, anchor, at(2026, 11, 5, 0))
    assert occurrence_key(r, TOR) == "2026-11-06"
    w = next_run("weekly", time(6), TOR, anchor, at(2026, 11, 10, 12))
    assert occurrence_key(w, TOR) == "2026-11-16" and w.astimezone().weekday() == 0
    b = next_run("biweekly", time(6), TOR, anchor, at(2026, 11, 3))
    assert occurrence_key(b, TOR) == "2026-11-16"
    c = next_run("custom", time(6), TOR, anchor, at(2026, 11, 3), interval_days=5)
    assert occurrence_key(c, TOR) == "2026-11-07"
    first = next_run("weekly", time(6), TOR, date(2026, 12, 1), at(2026, 11, 17))
    assert occurrence_key(first, TOR) == "2026-12-01"   # anchor in the future = first run


def test_monthly_clamps_to_month_end():
    anchor = date(2026, 1, 31)
    r1 = next_run("monthly", time(6), TOR, anchor, at(2026, 2, 1))
    assert occurrence_key(r1, TOR) == "2026-02-28"
    r2 = next_run("monthly", time(6), TOR, anchor, r1)
    assert occurrence_key(r2, TOR) == "2026-03-31"
    r3 = next_run("monthly", time(6), TOR, date(2027, 1, 31), at(2028, 2, 1))
    assert occurrence_key(r3, TOR) == "2028-02-29"


def test_daylight_saving_edges():
    # 2026-03-08 02:30 does not exist in Toronto: runs 03:30 EDT = 07:30 UTC
    r = next_run("daily", time(2, 30), TOR, date(2026, 3, 1), at(2026, 3, 8, 0))
    assert r == at(2026, 3, 8, 7, 30)
    # 2026-11-01 01:30 happens twice: first occurrence (EDT, UTC-4) = 05:30 UTC
    r = next_run("daily", time(1, 30), TOR, date(2026, 10, 1), at(2026, 11, 1, 0))
    assert r == at(2026, 11, 1, 5, 30)
    # summer vs winter offset
    assert next_run("daily", time(6), TOR, date(2026, 7, 1), at(2026, 7, 15)) == at(2026, 7, 15, 10)


def test_time_zone_decides_the_occurrence_date():
    r = next_run("daily", time(0, 30), "Asia/Dhaka", date(2026, 11, 1), at(2026, 11, 17, 12))
    assert r == at(2026, 11, 17, 18, 30) and occurrence_key(r, "Asia/Dhaka") == "2026-11-18"


def test_validation_and_runs_per_month():
    with pytest.raises(ScheduleError):
        interval_for("hourly", None)
    with pytest.raises(ScheduleError):
        interval_for("custom", 0)
    with pytest.raises(ScheduleError):
        interval_for("daily", 3)
    with pytest.raises(ScheduleError):
        next_run("daily", time(6), "Mars/Base", date(2026, 1, 1), at(2026, 1, 2))
    with pytest.raises(ScheduleError):
        next_run("daily", time(6), TOR, date(2026, 1, 1), datetime(2026, 1, 2))
    assert runs_per_month("daily") == 30.44 and runs_per_month("weekly") == 4.35 and runs_per_month("monthly") == 1.0
    assert runs_per_month("custom", 10) == 3.04


def test_alerts():
    m = lambda avg, t10: {"average_position": avg, "top10_coverage": t10}  # noqa: E731
    assert detect_change(m(9, 40), m(5, 45)).direction == "improved"
    assert detect_change(m(5, 60), m(5.5, 40)).direction == "declined"
    assert detect_change(m(5, 50), m(6, 55)) is None
    mixed = detect_change(m(9, 60), m(4, 30))          # ranks higher but on far fewer points
    assert mixed.direction == "declined" and "Top 10 coverage 60% → 30%" in mixed.reasons
    assert detect_change(m(None, 0), m(None, 20)).direction == "improved"
    assert detect_change(None, m(5, 50)) is None
    assert detect_change(m(None, None), m(None, None)) is None
    assert detect_change(m(10, 50), m(8, 50), Thresholds(average_position=2)).direction == "improved"
