"""LIVE integration test - makes ONE real, billable DataForSEO request (about $0.002).

Run:  DATAFORSEO_LOGIN=... DATAFORSEO_PASSWORD=... pytest tests/live -q
The DataForSEO integration may only be described as "connected" after this passes.
"""
import os
from decimal import Decimal

import pytest

from app.providers.base import SearchConfig
from app.providers.dataforseo import DataForSEOProvider

LOGIN, PASSWORD = os.getenv("DATAFORSEO_LOGIN"), os.getenv("DATAFORSEO_PASSWORD")
pytestmark = pytest.mark.skipif(not (LOGIN and PASSWORD), reason="DataForSEO credentials not provided")


def test_live_credentials_and_one_maps_request():
    p = DataForSEOProvider(LOGIN, PASSWORD, lambda mode: Decimal("0"))
    assert p.validate_credentials() is True
    out = p.fetch_point(43.6532, -79.3832, SearchConfig("plumber", "en", zoom=15, depth=20), tag="live-test")
    assert out.ok, f"{out.error_code}: {out.error_message}"
    assert out.listings and out.listings[0].position == 1
    assert any(l.place_id or l.cid for l in out.listings)
    assert out.cost is not None and out.check_url
