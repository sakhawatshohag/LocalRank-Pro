from decimal import Decimal

import pytest

from app.engine.analytics import (
    ChangeType, GridMismatchError, PointResult, ResultStatus, compare_scans, compute_scan_metrics, rank_color,
)
from app.engine.geogrid import (
    GridError, STANDARD_SIZES, generate_grid, grid_signature, haversine_m, radius_from_spacing, spacing_from_radius,
)
from app.engine.scan_runner import execute_scan
from app.providers.base import (
    ExecutionMode, Listing, PointOutcome, RankingProvider, SearchConfig, Subject, resolve_subject,
)
from app.providers.demo import DemoProvider

R, N, E = ResultStatus.RANKED, ResultStatus.NOT_FOUND, ResultStatus.ERROR
TORONTO = (43.6532, -79.3832)


# ---------------- geogrid ----------------
@pytest.mark.parametrize("size", STANDARD_SIZES)
def test_grid_has_unique_points_and_centre(size):
    pts = generate_grid(*TORONTO, size, 1000)
    assert len(pts) == size * size
    assert len({(p.lat, p.lng) for p in pts}) == size * size
    assert [p.index for p in pts] == list(range(size * size))
    centre = pts[(size * size) // 2]
    assert (centre.lat, centre.lng) == TORONTO


def test_grid_spacing_is_metric_in_both_directions():
    pts = generate_grid(*TORONTO, 5, 1000)
    by = {(p.row, p.col): p for p in pts}
    ew = haversine_m(by[2, 2].lat, by[2, 2].lng, by[2, 3].lat, by[2, 3].lng)
    ns = haversine_m(by[2, 2].lat, by[2, 2].lng, by[1, 2].lat, by[1, 2].lng)
    assert ew == pytest.approx(1000, abs=1) and ns == pytest.approx(1000, abs=1)
    assert by[0, 0].lat > by[4, 0].lat      # row 0 is north
    assert by[0, 0].lng < by[0, 4].lng      # col 0 is west


def test_grid_validation():
    for bad in [dict(size=4), dict(size=23), dict(spacing_m=10), dict(center_lat=89)]:
        kw = dict(center_lat=43.0, center_lng=-79.0, size=5, spacing_m=500) | bad
        with pytest.raises(GridError):
            generate_grid(**kw)


def test_radius_spacing_roundtrip_and_signature():
    assert spacing_from_radius(2000, 5) == 1000
    assert radius_from_spacing(1000, 5) == 2000
    assert grid_signature(*TORONTO, 5, 1000) == grid_signature(*TORONTO, 5, 1000.0)
    assert grid_signature(*TORONTO, 5, 1000) != grid_signature(*TORONTO, 7, 1000)


# ---------------- analytics ----------------
def test_point_result_invariants():
    with pytest.raises(ValueError):
        PointResult(0, R)                 # ranked without a position
    with pytest.raises(ValueError):
        PointResult(0, R, 0)              # position 0 is never valid
    with pytest.raises(ValueError):
        PointResult(0, N, 0)              # not-found is not position 0
    with pytest.raises(ValueError):
        PointResult(0, E, 5)              # an error never carries a rank


def test_scan_metrics_exclude_errors_and_never_treat_not_found_as_zero():
    res = [PointResult(0, R, 1), PointResult(1, R, 3), PointResult(2, R, 8), PointResult(3, R, 25),
           PointResult(4, N), PointResult(5, E)]
    m = compute_scan_metrics(res, depth=100)
    assert (m.total_points, m.valid_points, m.ranked_points, m.not_found_points, m.error_points) == (6, 5, 4, 1, 1)
    assert m.average_position == 9.25                       # (1+3+8+25)/4
    assert m.capped_average_position == 27.6                # (37 + 101)/5
    assert m.median_position == 5.5 and m.best_position == 1 and m.worst_position == 25
    assert (m.top3_count, m.top10_count, m.top20_count) == (2, 3, 3)
    assert (m.top3_coverage, m.top10_coverage, m.not_found_pct) == (40.0, 60.0, 20.0)


def test_scan_metrics_with_no_valid_data_are_null_not_zero():
    m = compute_scan_metrics([PointResult(0, E), PointResult(1, E)], depth=100)
    assert m.valid_points == 0 and m.average_position is None and m.top3_coverage is None
    m = compute_scan_metrics([PointResult(0, N)], depth=20)
    assert m.average_position is None and m.capped_average_position == 21 and m.not_found_pct == 100.0


def test_comparison_matches_specification_examples():
    prev = [PointResult(0, R, 15), PointResult(1, R, 5), PointResult(2, R, 8), PointResult(3, R, 25),
            PointResult(4, N), PointResult(5, R, 4), PointResult(6, N), PointResult(7, E), PointResult(8, R, 2)]
    curr = [PointResult(0, R, 8), PointResult(1, R, 12), PointResult(2, R, 8), PointResult(3, R, 15),
            PointResult(4, R, 9), PointResult(5, N), PointResult(6, N), PointResult(7, R, 1), PointResult(8, E)]
    c = compare_scans(prev, curr, previous_signature="g", current_signature="g")
    by = {p.point_index: p for p in c.points}
    assert (by[0].change, by[0].delta) == (ChangeType.IMPROVED, 7)
    assert (by[1].change, by[1].delta) == (ChangeType.DECLINED, -7)
    assert (by[2].change, by[2].delta) == (ChangeType.UNCHANGED, 0)
    assert (by[3].change, by[3].delta) == (ChangeType.IMPROVED, 10)
    assert by[4].change is ChangeType.NEWLY_FOUND and by[4].delta is None
    assert by[5].change is ChangeType.LOST_VISIBILITY
    assert by[6].change is ChangeType.NOT_FOUND_BOTH
    assert by[7].change is ChangeType.NOT_COMPARABLE and by[8].change is ChangeType.NOT_COMPARABLE
    assert c.comparable_points == 7
    assert c.counts["improved"] == 2 and c.counts["declined"] == 1 and c.counts["unchanged"] == 1
    assert c.average_delta == 2.5                           # (7-7+0+10)/4


def test_comparison_refuses_different_grids_and_handles_missing_points():
    with pytest.raises(GridMismatchError):
        compare_scans([], [], previous_signature="a", current_signature="b")
    c = compare_scans([PointResult(0, R, 3)], [PointResult(0, R, 3), PointResult(1, R, 2)])
    assert c.counts["not_comparable"] == 1 and c.comparable_points == 1


def test_rank_colours():
    cases = {1: "green", 3: "green", 4: "yellow", 10: "yellow", 11: "orange", 20: "orange", 21: "red", 99: "red"}
    for pos, colour in cases.items():
        assert rank_color(PointResult(0, R, pos)) == colour
    assert rank_color(PointResult(0, N)) == "gray"
    assert rank_color(PointResult(0, E)) == "error"


# ---------------- subject resolution / scan runner ----------------
ME = Subject("location:me", place_id="ChIJ_me")
COMP = Subject("competitor:a", cid="111")
ABSENT = Subject("competitor:b", place_id="ChIJ_absent")


def test_subjects_require_identifier_and_names_are_never_matched():
    with pytest.raises(ValueError):
        Subject("x")
    out = PointOutcome(True, (Listing(1, "My Business", "ChIJ_other", "9"),), 100)
    assert resolve_subject(out, ME, 0).status is N


class ScriptedProvider(RankingProvider):
    name = "scripted"

    def __init__(self, script):
        self.script, self.calls = script, []

    def validate_credentials(self): return True
    def estimate_cost(self, points, config, mode): return Decimal(0)
    def normalize_results(self, raw, depth_requested): raise NotImplementedError

    def fetch_point(self, lat, lng, config, tag=None):
        self.calls.append((lat, lng, config, tag))
        out = self.script[len(self.calls) - 1]
        if isinstance(out, Exception):
            raise out
        return out


def test_scan_evaluates_all_businesses_from_the_same_response_per_coordinate():
    ok = lambda *ls: PointOutcome(True, ls, 100, cost=Decimal("0.002"))  # noqa: E731
    script = [
        ok(Listing(1, "c", None, "111"), Listing(4, "me", "ChIJ_me", "5")),
        ok(Listing(2, "me", "ChIJ_me", "5")),
        PointOutcome(False, depth_requested=100, error_code="timeout", error_message="t"),
        RuntimeError("boom"),
    ]
    provider = ScriptedProvider(script)
    pts = generate_grid(*TORONTO, 3, 500)[:4]
    cfg = SearchConfig("plumber")
    res = execute_scan(provider, pts, cfg, [ME, COMP, ABSENT], scan_id="s1")

    assert len(provider.calls) == 4                       # one request per point, regardless of competitor count
    assert [(c[0], c[1]) for c in provider.calls] == [(p.lat, p.lng) for p in pts]
    assert provider.calls[0][3] == "s1:0"
    me, comp, absent = (res.rankings[k] for k in ("location:me", "competitor:a", "competitor:b"))
    assert [(r.status, r.position) for r in me] == [(R, 4), (R, 2), (E, None), (E, None)]
    assert [(r.status, r.position) for r in comp] == [(R, 1), (N, None), (E, None), (E, None)]
    assert [r.status for r in absent] == [N, N, E, E]     # API failures are errors, never rankings
    assert res.failed_points == 2 and res.actual_cost == Decimal("0.004")
    assert res.metrics["location:me"].valid_points == 2 and res.metrics["location:me"].average_position == 3.0
    assert res.is_demo is False


def test_demo_provider_is_deterministic_and_flagged():
    pts = generate_grid(*TORONTO, 5, 500)
    cfg = SearchConfig("plumber")
    a = execute_scan(DemoProvider([ME, COMP], epoch="2026-11-07"), pts, cfg, [ME, COMP])
    b = execute_scan(DemoProvider([ME, COMP], epoch="2026-11-07"), pts, cfg, [ME, COMP])
    assert a.rankings == b.rankings and a.is_demo is True
    assert all(o.is_demo for o in a.outcomes.values())
    for o in a.outcomes.values():
        positions = [l.position for l in o.listings]
        assert positions == sorted(set(positions))
