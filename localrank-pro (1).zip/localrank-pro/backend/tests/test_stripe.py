import json
from datetime import datetime, timezone

import pytest
import requests

from app.billing.stripe import (
    SignatureError, StripeClient, StripeError, encode_form, period_end, price_id, sign, verify_signature,
)

SECRET = "whsec_test_secret"


def test_form_encoding_uses_bracket_notation():
    assert encode_form({"mode": "subscription", "line_items": [{"price": "price_1", "quantity": 1}],
                        "metadata": {"org_id": "o1"}, "customer": None, "allow_promotion_codes": True}) == [
        ("mode", "subscription"), ("line_items[0][price]", "price_1"), ("line_items[0][quantity]", "1"),
        ("metadata[org_id]", "o1"), ("allow_promotion_codes", "true")]


def test_signature_verification():
    body = json.dumps({"id": "evt_1"}).encode()
    header = sign(body, SECRET, timestamp=1_700_000_000)
    verify_signature(body, header, SECRET, now=1_700_000_100)
    verify_signature(body, "t=1700000000,v0=deadbeef," + header.split(",")[1] + ",v1=00", SECRET, now=1_700_000_000)  # extra/old schemes ignored
    bad = [
        (body + b" ", header, 1_700_000_000, "does not match"),                 # body changed
        (body, header, 1_700_000_301, "tolerance"),                             # replayed later
        (body, header.replace("v1=", "v0="), 1_700_000_000, "malformed"),       # no v1 signature
        (body, None, 1_700_000_000, "missing"),
        (body, "garbage", 1_700_000_000, "malformed"),
    ]
    for payload, hdr, now, msg in bad:
        with pytest.raises(SignatureError, match=msg):
            verify_signature(payload, hdr, SECRET, now=now)
    with pytest.raises(SignatureError):
        verify_signature(body, sign(body, "other"), SECRET)
    with pytest.raises(SignatureError, match="not configured"):
        verify_signature(body, header, "")


def test_subscription_fields_for_current_and_legacy_api_versions():
    basil = {"items": {"data": [{"current_period_end": 1_767_225_600, "price": {"id": "price_pro"}}]}}
    legacy = {"current_period_end": 1_767_225_600, "items": {"data": [{"price": "price_old"}]}}
    assert period_end(basil) == period_end(legacy) == datetime(2026, 1, 1, tzinfo=timezone.utc)
    assert price_id(basil) == "price_pro" and price_id(legacy) == "price_old"
    assert period_end({}) is None and price_id({}) is None


class FakeResp:
    def __init__(self, status, body):
        self.status_code, self._body = status, body

    def json(self):
        if self._body is None:
            raise ValueError
        return self._body


class FakeSession:
    def __init__(self, resp):
        self.resp, self.calls = resp, []

    def post(self, url, **kw):
        self.calls.append((url, kw))
        if isinstance(self.resp, Exception):
            raise self.resp
        return self.resp


def test_client_requests_and_errors():
    s = FakeSession(FakeResp(200, {"id": "cs_1", "url": "https://checkout.stripe.com/c/pay/cs_1"}))
    c = StripeClient("sk_test_x", session=s)
    out = c.create_checkout_session(price="price_pro", success_url="https://app/b?ok", cancel_url="https://app/b",
                                    client_reference_id="org1", customer_email="a@b.co", metadata={"org_id": "org1"},
                                    idempotency_key="k1")
    url, kw = s.calls[0]
    assert out["url"].startswith("https://checkout.stripe.com") and url == "https://api.stripe.com/v1/checkout/sessions"
    assert kw["auth"] == ("sk_test_x", "") and kw["headers"] == {"Stripe-Version": "2026-02-25.clover", "Idempotency-Key": "k1"}
    data = dict(kw["data"])
    assert data["mode"] == "subscription" and data["line_items[0][price]"] == "price_pro"
    assert data["client_reference_id"] == "org1" and data["customer_email"] == "a@b.co" and "customer" not in data
    assert data["subscription_data[metadata][org_id]"] == "org1"
    with pytest.raises(StripeError, match="No such price"):
        StripeClient("sk", session=FakeSession(FakeResp(400, {"error": {"message": "No such price"}}))).create_portal_session(
            customer="cus_1", return_url="https://app")
    with pytest.raises(StripeError, match="could not reach"):
        StripeClient("sk", session=FakeSession(requests.ConnectionError("down"))).create_portal_session(customer="c", return_url="u")
    with pytest.raises(StripeError, match="not configured"):
        StripeClient("")
