"""Guards against lists that must stay in step across modules."""
import ast
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]


def literal_values(path: Path, name: str) -> set[str]:
    tree = ast.parse(path.read_text())
    for node in tree.body:
        if isinstance(node, ast.Assign) and any(getattr(t, "id", None) == name for t in node.targets):
            return {n.value for n in ast.walk(node.value) if isinstance(n, ast.Constant) and isinstance(n.value, str) and n.value != "Literal"}
    raise AssertionError(f"{name} not found in {path}")


def test_notification_types_match_everywhere():
    service = set(literal_values(ROOT / "app/services/notifications.py", "TYPES"))
    router = literal_values(ROOT / "app/routers/notifications.py", "NotificationType")
    sql = "\n".join(p.read_text() for p in sorted((ROOT / "migrations").glob("*.sql")))
    enum = set(re.findall(r"'(\w+)'", re.search(r"CREATE TYPE notification_type AS ENUM\s*\(([^)]*)\)", sql).group(1)))
    enum |= set(re.findall(r"ADD VALUE IF NOT EXISTS '(\w+)'", sql))
    frontend = (ROOT.parent / "frontend/src/lib/schedule.ts").read_text()
    labels = set(re.findall(r"(\w+): \"", frontend.split("NOTIFICATION_LABELS")[1].split("};")[0]))
    assert service == router == enum == labels
