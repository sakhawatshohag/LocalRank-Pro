from datetime import datetime, timedelta, timezone

import jwt
import pytest

from app.security import (
    create_access_token, decode_access_token, hash_password, role_at_least, verify_password,
)


def test_password_hash_roundtrip():
    h = hash_password("correct horse battery")
    assert h.startswith("scrypt$") and "correct horse" not in h
    assert verify_password("correct horse battery", h)
    assert not verify_password("wrong password!!", h)
    assert not verify_password("x", "garbage")
    assert hash_password("correct horse battery") != h          # unique salt
    with pytest.raises(ValueError):
        hash_password("short")


def test_token_roundtrip_expiry_and_tampering():
    t = create_access_token(secret="s" * 32, user_id="u1", org_id="o1", role="admin")
    p = decode_access_token(t, "s" * 32)
    assert (p["sub"], p["org"], p["role"]) == ("u1", "o1", "admin")
    with pytest.raises(jwt.InvalidTokenError):
        decode_access_token(t, "x" * 32)
    old = create_access_token(secret="s" * 32, user_id="u1", org_id="o1", role="admin",
                              now=datetime.now(timezone.utc) - timedelta(hours=2))
    with pytest.raises(jwt.ExpiredSignatureError):
        decode_access_token(old, "s" * 32)


def test_role_hierarchy():
    assert role_at_least("owner", "admin") and role_at_least("manager", "manager")
    assert not role_at_least("client_viewer", "seo_specialist")
    assert not role_at_least("unknown", "client_viewer")
