import pytest
from pydantic import ValidationError

from app.config import load_settings

BASE = {"DATABASE_URL": "postgresql+psycopg://x", "JWT_SECRET": "s" * 32}


def test_loads_from_environment():
    s = load_settings(BASE | {"CORS_ORIGINS": "https://a.com, https://b.com", "DATAFORSEO_LOGIN": "l",
                              "DATAFORSEO_PASSWORD": "p", "UNRELATED": "x"})
    assert s.cors_origins == ["https://a.com", "https://b.com"] and s.dataforseo_configured


def test_rejects_weak_secret_and_demo_in_production():
    with pytest.raises(ValidationError):
        load_settings(BASE | {"JWT_SECRET": "short"})
    with pytest.raises(ValidationError):
        load_settings(BASE | {"APP_ENV": "production", "DEMO_MODE": "true"})
    with pytest.raises(ValidationError):
        load_settings({"JWT_SECRET": "s" * 32})          # DATABASE_URL is required
    assert load_settings(BASE).dataforseo_configured is False
