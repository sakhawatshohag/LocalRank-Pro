import pytest

from app.engine.analytics import PointResult, ResultStatus
from app.engine.dominance import Dominance, compare_businesses

R, N, E = ResultStatus.RANKED, ResultStatus.NOT_FOUND, ResultStatus.ERROR


def rows(*specs):
    return [PointResult(i, R, s) if isinstance(s, int) else PointResult(i, s) for i, s in enumerate(specs)]


def test_dominance_rules():
    #            0   1   2   3   4   5   6   7   8
    mine = rows(1,  10, 5,  N,  N,  25, E,  4,  3)
    a = rows(   8,  2,  6,  3,  N,  30, E,  N,  40)
    b = rows(   N,  9,  20, 15, 60, N,  E,  N,  2)
    s = compare_businesses(mine, {"a": a, "b": b})
    kinds = [p.dominance for p in s.points]
    assert kinds == [
        Dominance.MINE,         # 1 vs best 8
        Dominance.COMPETITOR,   # 10 vs best 2
        Dominance.SIMILAR,      # 5 vs 6 (within 2)
        Dominance.COMPETITOR,   # not found vs 3
        Dominance.ALL_WEAK,     # not found vs best 60
        Dominance.ALL_WEAK,     # 25 vs 30: nobody inside top 20
        Dominance.NO_DATA,      # failed point
        Dominance.MINE,         # 4, no competitor found
        Dominance.SIMILAR,      # 3 vs 2
    ]
    assert (s.points[1].leader_key, s.points[1].leader_position) == ("a", 2)
    assert (s.points[8].leader_key, s.points[8].leader_position) == ("b", 2)
    assert s.points[7].leader_key is None and s.points[6].my_position is None
    assert s.counts == {"mine": 2, "competitor": 2, "similar": 2, "all_weak": 2, "no_data": 1}
    assert s.valid_points == 8


def test_tolerance_and_missing_rows():
    s = compare_businesses(rows(5), {"a": rows(7)}, tolerance=1)
    assert s.points[0].dominance is Dominance.MINE
    s = compare_businesses(rows(5, 5), {"a": rows(7)})            # competitor has no row for point 1
    assert [p.dominance for p in s.points] == [Dominance.SIMILAR, Dominance.NO_DATA]
    s = compare_businesses(rows(5), {"a": rows(E)})               # never infer from a failed competitor row
    assert s.points[0].dominance is Dominance.NO_DATA
    with pytest.raises(ValueError):
        compare_businesses(rows(1), {})
    with pytest.raises(ValueError):
        compare_businesses(rows(1), {"a": rows(1)}, tolerance=-1)
