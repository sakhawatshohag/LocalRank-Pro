"""DataForSEO provider tests.

The HTTP layer is faked; the fixture follows the response structure in the
official docs (docs.dataforseo.com/v3/serp/google/maps/live/advanced).
These tests do NOT prove the live integration works - see
tests/live/test_dataforseo_live.py, which runs only with real credentials.
"""
from decimal import Decimal

import pytest
import requests

from app.providers.base import ExecutionMode, ProviderError, SearchConfig, Subject, resolve_subject
from app.providers.dataforseo import DataForSEOProvider, MAPS_LIVE_PATH
from app.engine.analytics import ResultStatus

PRICES = {ExecutionMode.LIVE: Decimal("0.002"), ExecutionMode.STANDARD: Decimal("0.0006")}


def response_fixture(items, task_code=20000, top_code=20000, cost=0.002):
    return {
        "version": "0.1", "status_code": top_code, "status_message": "Ok.", "cost": cost, "tasks_count": 1,
        "tasks": [{
            "id": "11161551-1535-0139-0000-27f0d6f2d3a3", "status_code": task_code,
            "status_message": "Ok." if task_code == 20000 else "No Search Results.", "time": "5.1 sec.",
            "cost": cost, "result_count": 1, "path": ["v3", "serp", "google", "maps", "live", "advanced"],
            "data": {"keyword": "plumber", "tag": "s1:0"},
            "result": None if task_code != 20000 else [{
                "keyword": "plumber", "type": "maps", "se_domain": "google.ca", "language_code": "en",
                "check_url": "https://google.ca/maps/search/plumber/@43.6532,-79.3832,15z",
                "datetime": "2026-11-17 04:00:00 +00:00", "item_types": ["maps_search"],
                "items_count": len(items or []), "items": items,
            }],
        }],
    }


ITEMS = [
    {"type": "maps_paid_item", "rank_group": 1, "rank_absolute": 1, "title": "Ad", "place_id": "ChIJ_ad", "cid": "1"},
    {"type": "maps_search", "rank_group": 1, "rank_absolute": 2, "title": "Rival", "place_id": "ChIJ_rival",
     "cid": "222", "rating": {"value": 4.8, "votes_count": 120}},
    {"type": "maps_search", "rank_group": 2, "rank_absolute": 3, "title": "Me", "place_id": "ChIJ_me", "cid": 333},
]


class FakeResp:
    def __init__(self, status=200, payload=None, text=""):
        self.status_code, self._payload, self.text = status, payload, text

    def json(self):
        if self._payload is None:
            raise ValueError("no json")
        return self._payload


class FakeSession:
    def __init__(self, responses):
        self.responses, self.posts, self.gets = list(responses), [], []

    def post(self, url, **kw):
        self.posts.append((url, kw))
        r = self.responses.pop(0)
        if isinstance(r, Exception):
            raise r
        return r

    def get(self, url, **kw):
        self.gets.append((url, kw))
        return self.responses.pop(0)


def make(responses, **kw):
    s = FakeSession(responses)
    return DataForSEOProvider("login", "pw", PRICES.__getitem__, session=s, sleep=lambda _: None, **kw), s


def test_request_matches_documented_format():
    p, s = make([FakeResp(payload=response_fixture(ITEMS))])
    p.fetch_point(43.6532, -79.3832, SearchConfig("plumber", "en", zoom=15, depth=100, se_domain="google.ca"), "s1:0")
    url, kw = s.posts[0]
    assert url.endswith(MAPS_LIVE_PATH) and kw["auth"] == ("login", "pw")
    assert kw["json"] == [{                      # exactly one task per live request
        "keyword": "plumber", "language_code": "en", "location_coordinate": "43.6532000,-79.3832000,15z",
        "depth": 100, "device": "desktop", "se_domain": "google.ca", "tag": "s1:0"}]


def test_parses_organic_positions_and_ignores_paid_items():
    p, _ = make([FakeResp(payload=response_fixture(ITEMS))])
    out = p.fetch_point(43.6, -79.3, SearchConfig("plumber"))
    assert out.ok and [(l.position, l.place_id, l.cid) for l in out.listings] == [(1, "ChIJ_rival", "222"),
                                                                                   (2, "ChIJ_me", "333")]
    assert out.cost == Decimal("0.002") and out.provider_task_id and out.check_url.startswith("https://google.ca")
    assert out.meta["task_status_code"] == 20000
    assert resolve_subject(out, Subject("me", place_id="ChIJ_me"), 0).position == 2
    assert resolve_subject(out, Subject("c", cid="222"), 0).position == 1
    assert resolve_subject(out, Subject("x", place_id="ChIJ_ad"), 0).status is ResultStatus.NOT_FOUND


def test_no_search_results_is_a_valid_empty_serp_not_an_error():
    p, _ = make([FakeResp(payload=response_fixture(None, task_code=40102))])
    out = p.fetch_point(43.6, -79.3, SearchConfig("plumber"))
    assert out.ok and out.listings == ()
    assert resolve_subject(out, Subject("me", place_id="ChIJ_me"), 0).status is ResultStatus.NOT_FOUND


@pytest.mark.parametrize("resp", [
    FakeResp(payload=response_fixture(ITEMS, top_code=40100)),          # auth error envelope
    FakeResp(payload={"status_code": 20000, "tasks": [{"status_code": 50000, "status_message": "Internal"}]}),
    FakeResp(payload={"status_code": 20000, "tasks": []}),
    FakeResp(status=401, text="unauthorized"),
    FakeResp(status=200, payload=None),                                 # not JSON
])
def test_api_failures_become_errors_never_rankings(resp):
    p, _ = make([resp])
    out = p.fetch_point(43.6, -79.3, SearchConfig("plumber"))
    assert out.ok is False and out.error_code and out.listings == ()
    assert resolve_subject(out, Subject("me", place_id="ChIJ_me"), 0).status is ResultStatus.ERROR


def test_retries_timeouts_and_rate_limits_then_succeeds():
    p, s = make([requests.Timeout(), FakeResp(status=429), FakeResp(payload=response_fixture(ITEMS))])
    assert p.fetch_point(43.6, -79.3, SearchConfig("plumber")).ok and len(s.posts) == 3


def test_gives_up_after_max_retries_with_error():
    p, s = make([requests.Timeout()] * 3)
    out = p.fetch_point(43.6, -79.3, SearchConfig("plumber"))
    assert not out.ok and out.error_code == "timeout" and len(s.posts) == 3


def test_cost_estimate_uses_pricing_table_and_depth_billing():
    p, _ = make([])
    assert p.estimate_cost(49, SearchConfig("k", depth=100), ExecutionMode.LIVE) == Decimal("0.098")
    assert p.estimate_cost(49, SearchConfig("k", depth=20), ExecutionMode.STANDARD) == Decimal("0.0294")
    assert p.estimate_cost(49, SearchConfig("k", depth=150), ExecutionMode.LIVE) == Decimal("0.196")  # 2 SERPs


def test_validation_and_credentials():
    with pytest.raises(ProviderError):
        DataForSEOProvider("", "", PRICES.__getitem__)
    p, _ = make([])
    with pytest.raises(ProviderError):
        p.build_task(1, 1, SearchConfig("k", zoom=22), None)
    with pytest.raises(ProviderError):
        p.build_task(1, 1, SearchConfig("k", depth=701), None)
    p, s = make([FakeResp(payload={"status_code": 20000})])
    assert p.validate_credentials() is True and s.gets[0][0].endswith("/v3/appendix/user_data")
    p, _ = make([FakeResp(status=401)])
    assert p.validate_credentials() is False
