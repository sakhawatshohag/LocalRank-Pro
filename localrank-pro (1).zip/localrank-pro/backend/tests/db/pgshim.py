"""Minimal synchronous PostgreSQL connection over a ``psql`` subprocess, for tests only.

It lets the REAL service code (app/services/*) run against a REAL database in environments
without a Python PostgreSQL driver.  It implements just the slice of the SQLAlchemy Connection /
Result API that the services use.  Binds are rendered as SQL literals; rows come back through
row_to_json so types survive (numbers as Decimal/int, timestamps/dates/times parsed).
"""
from __future__ import annotations

import json
import re
import subprocess
from contextlib import contextmanager
from datetime import date, datetime, time
from decimal import Decimal
from typing import Any, Iterator
from uuid import UUID

BIND = re.compile(r"(?<![:\w\\]):(\w+)(?!:)")   # same rule as sqlalchemy.text()
SENTINEL = "__PGSHIM_END__"
TS = re.compile(r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(\.\d+)?([+-]\d{2}:\d{2})?$")
DATE = re.compile(r"^\d{4}-\d{2}-\d{2}$")
TIME = re.compile(r"^\d{2}:\d{2}:\d{2}$")


class DBError(Exception):
    pass


def literal(v: Any) -> str:
    if v is None:
        return "NULL"
    if isinstance(v, bool):
        return "true" if v else "false"
    if isinstance(v, (int, float, Decimal)):
        return str(v)
    if isinstance(v, (datetime, date, time)):
        return f"'{v.isoformat()}'"
    if isinstance(v, (list, tuple)):
        return "ARRAY[" + ",".join(literal(x) for x in v) + "]" if v else "NULL"
    return "'" + str(v).replace("'", "''") + "'"


def _convert(v: Any) -> Any:
    if isinstance(v, str):
        if TS.match(v):
            return datetime.fromisoformat(v)
        if DATE.match(v):
            return date.fromisoformat(v)
        if TIME.match(v):
            return time.fromisoformat(v)
    return v


def _typed(v: Any, pgtype: str) -> Any:
    if v is None:
        return None
    if pgtype in ("double precision", "real"):
        return float(v)
    if pgtype.startswith("numeric"):
        return Decimal(str(v))
    if pgtype.startswith(("timestamp", "date", "time")):
        return _convert(v)
    return v


class Row(tuple):
    _mapping: dict


class Result:
    def __init__(self, rows: list[dict], rowcount: int) -> None:
        self._rows, self.rowcount = rows, rowcount

    def _tuples(self) -> list[Row]:
        out = []
        for r in self._rows:
            t = Row(r.values())
            t._mapping = r
            out.append(t)
        return out

    def __iter__(self):
        return iter(self._tuples())

    def all(self):
        return self._tuples()

    def first(self):
        t = self._tuples()
        return t[0] if t else None

    def one(self):
        t = self._tuples()
        if len(t) != 1:
            raise DBError(f"expected one row, got {len(t)}")
        return t[0]

    def scalar(self):
        r = self.first()
        return r[0] if r else None

    def scalar_one(self):
        return self.one()[0]

    def mappings(self):
        rows = self._rows

        class M:
            def __iter__(self_):
                return iter(rows)

            def all(self_):
                return list(rows)

            def first(self_):
                return rows[0] if rows else None

            def one(self_):
                if len(rows) != 1:
                    raise DBError(f"expected one row, got {len(rows)}")
                return rows[0]
        return M()


class PsqlConnection:
    def __init__(self, url: str, role: str | None = "localrank_app") -> None:
        self.p = subprocess.Popen(["psql", url, "-X", "-q", "-A", "-t", "-v", "ON_ERROR_STOP=0"],
                                  stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, bufsize=1)
        if role:
            self.raw(f"SET ROLE {role}")

    def raw(self, sql: str, terminate: bool = True) -> list[str]:
        body = sql.rstrip().rstrip(";") + (";" if terminate else "")
        self.p.stdin.write(body + "\n\\echo " + SENTINEL + "\n")
        self.p.stdin.flush()
        lines = []
        while True:
            line = self.p.stdout.readline()
            if not line:
                raise DBError("psql exited")
            line = line.rstrip("\n")
            if line == SENTINEL:
                break
            lines.append(line)
        errors = [l for l in lines if "ERROR:" in l]
        if errors:
            raise DBError("\n".join(errors))
        return lines

    def execute(self, stmt: Any, params: dict | None = None) -> Result:
        sql = BIND.sub(lambda m: literal((params or {})[m.group(1)]), str(stmt)).strip().rstrip(";")
        head = sql.lstrip("( \n").split(None, 1)[0].upper()
        if head in ("SELECT", "WITH") or re.search(r"\bRETURNING\b", sql, re.I):
            # column types, so double precision comes back as float and numeric as Decimal (like psycopg)
            desc = self.raw(sql + " \\gdesc", terminate=False)
            types = dict(l.split("|", 1) for l in desc if "|" in l)
            lines = self.raw(f"WITH __q AS ({sql}) SELECT row_to_json(__q) FROM __q")
            rows = []
            for l in lines:
                if not l.startswith("{"):
                    continue
                raw = json.loads(l, parse_float=Decimal)
                rows.append({k: _typed(v, types.get(k, "")) for k, v in raw.items()})
            return Result(rows, len(rows))
        lines = self.raw("\\set QUIET off\n" + sql + ";\n\\set QUIET on")
        tags = [l for l in lines if re.match(r"^(INSERT \d+ |UPDATE |DELETE |SELECT )\d*", l)]
        count = int(tags[-1].split()[-1]) if tags else 0
        return Result([], count)

    def close(self) -> None:
        try:
            self.p.stdin.write("\\q\n")
            self.p.stdin.flush()
        except Exception:
            pass
        self.p.wait(timeout=10)


class ShimDB:
    """Drop-in replacements for app.db.tenant_tx / system_tx."""

    def __init__(self, url: str) -> None:
        self.url = url

    @contextmanager
    def tx(self, org_id: str | None) -> Iterator[PsqlConnection]:
        conn = PsqlConnection(self.url)
        try:
            conn.raw("BEGIN")
            if org_id:
                conn.raw(f"SELECT set_config('app.current_org', {literal(str(org_id))}, true)")
            yield conn
            conn.raw("COMMIT")
        except BaseException:
            try:
                conn.raw("ROLLBACK")
            except DBError:
                pass
            raise
        finally:
            conn.close()

    def tenant_tx(self, org_id):
        return self.tx(org_id)

    def system_tx(self):
        return self.tx(None)

    def superuser(self) -> PsqlConnection:
        return PsqlConnection(self.url, role=None)


def as_uuid(v: Any) -> str:
    return str(UUID(str(v)))
