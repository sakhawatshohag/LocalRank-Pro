"""Executes every SQL statement written in selected router modules against a real database.

FastAPI is not needed: statements are extracted from the source with ``ast`` (f-strings are
evaluated with the module's string constants), bound with realistic values and run inside a
tenant transaction.  This catches SQL syntax, type and permission errors in endpoint code.
"""
import ast
from datetime import datetime, time, timezone
from pathlib import Path

import pytest

from pgshim import BIND
from test_services_db import world  # noqa: F401  (fixture)

ROUTERS = Path(__file__).resolve().parents[2] / "app" / "routers"


def statements(module: str) -> list[str]:
    tree = ast.parse((ROUTERS / f"{module}.py").read_text())
    consts = {t.id: n.value.value for n in tree.body if isinstance(n, ast.Assign)
              for t in n.targets if isinstance(t, ast.Name) and isinstance(n.value, ast.Constant) and isinstance(n.value.value, str)}
    consts["where"] = "competitor_id = :subject"      # runtime filter used by the scan endpoints
    consts["expr"] = "encode(pdf, 'base64')"           # runtime column used by the report download endpoint
    if "PLAN_FIELDS" in (ROUTERS / f"{module}.py").read_text():   # computed column lists in billing.py
        fields = ("code", "name", "description", "limits", "monthly_price_cents", "currency", "is_public", "sort_order")
        consts["PLAN_COLS"] = ", ".join(fields) + ", (stripe_price_id IS NOT NULL) AS purchasable"
        consts["ORG_PLAN_COLS"] = ", ".join(f"p.{f}" for f in fields) + ", (p.stripe_price_id IS NOT NULL) AS purchasable"
    out = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Call) and getattr(node.func, "id", None) == "text" and node.args:
            a = node.args[0]
            if isinstance(a, ast.Constant):
                out.append(a.value)
            elif isinstance(a, ast.JoinedStr):
                out.append("".join(v.value if isinstance(v, ast.Constant) else str(eval(compile(ast.Expression(v.value), "<f>", "eval"), {}, dict(consts)))
                                   for v in a.values))
    return out


def params(w, scan_id):
    now = datetime.now(timezone.utc)
    common = {"c": w["camp"], "k": w["kw1"], "s": scan_id, "u": w["owner"], "o": w["org"], "org": w["org"], "d": 30,
              "l": 10, "unread": False, "n": now, "e": None, "id": scan_id, "a": now.date(), "paused": False,
              "subject": w["comp"], "ids": None, "pid": None, "cid": None, "x": w["comp"]}
    return {
        "schedules": common | {"f": "weekly", "t": time(6, 0), "id": w["camp"], "d": None},
        "notifications": common | {"t": "scan_failed", "a": True, "e": False, "id": "00000000-0000-0000-0000-000000000000"},
        "scans": common | {"a": scan_id, "b": scan_id, "i": 0, "g": "00000000-0000-0000-0000-000000000000"},
        "reports": common | {"r": "00000000-0000-0000-0000-000000000000", "t": "weekly", "title": None, "tz": "UTC",
                             "lt": time(7, 0), "a": now.date(), "c": w["client"], "agency_name": "A", "website": None,
                             "email": None, "phone": None, "primary_color": "#123456", "footer_text": None,
                             "png": "iVBORw0KGgo="},
    }


def extra_params(db, w):
    """Values for the account/billing routers: a user who is not yet a member, a fresh email."""
    import uuid
    from test_services_db import sql_su
    fresh = str(uuid.uuid4())
    sql_su(db, f"INSERT INTO users (id, email, password_hash) VALUES ('{fresh}', '{fresh}@x.test', 'x') RETURNING id")
    now = datetime.now(timezone.utc)
    return {
        "billing": {"o": w["org"], "u": w["owner"], "c": "pro"},
        "team": {"o": w["org"], "u": w["viewer"], "a": w["owner"], "d": '{"from": "client_viewer", "to": "manager"}',
                 "e": "invitee@x.test", "exp": now, "h": "hash-" + fresh, "i": "00000000-0000-0000-0000-000000000000",
                 "r": "manager"},
        "auth": {"o": w["org"], "u": fresh, "e": f"new-{fresh}@x.test", "p": "x", "n": "New Person", "days": 14,
                 "h": "nohash", "i": "00000000-0000-0000-0000-000000000000", "r": "manager"},
    }


@pytest.mark.parametrize("module", ["schedules", "notifications", "scans", "reports", "billing", "team", "auth"])
def test_router_sql_runs(db, world, monkeypatch, module):
    from test_services_db import Scripted, run_one
    scan_id, _ = run_one(db, world, monkeypatch, Scripted(me=2, rival=5))
    p = (params(world, scan_id) | extra_params(db, world))[module]
    stmts = statements(module)
    assert stmts, "no SQL found"
    ran = 0
    for sql in stmts:
        names = set(BIND.findall(sql))
        if not names <= p.keys():
            pytest.fail(f"no test value for binds {names - p.keys()} in:\n{sql[:200]}")
        try:
            with db.tenant_tx(world["org"]) as conn:
                conn.execute(sql, {k: p[k] for k in names})
        except Exception as exc:
            # the SQL is valid when the only problem is a row an earlier statement of this test already inserted
            if "duplicate key value" not in str(exc):
                raise
        ran += 1
    assert ran == len(stmts)
