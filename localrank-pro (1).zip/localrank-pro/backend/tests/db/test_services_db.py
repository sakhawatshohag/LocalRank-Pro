"""Real service code (scan pipeline, schedules, notifications) against a real PostgreSQL database."""
import uuid
from datetime import datetime, time, timedelta, timezone
from decimal import Decimal

import pytest

from app.config import load_settings
from app.engine.schedule import occurrence_key
from app.providers.base import Listing, PointOutcome, RankingProvider
from app.services import notifications as notif
from app.services import scans as scan_svc
from app.services import schedules as sched_svc
from pgshim import literal

SETTINGS = load_settings({"DATABASE_URL": "unused", "JWT_SECRET": "s" * 32, "DEMO_MODE": "true"})
UTC = timezone.utc


def sql_su(db, sql):
    c = db.superuser()
    try:
        return c.execute(sql)
    finally:
        c.close()


@pytest.fixture
def world(db):
    """One organization with an owner, a client viewer, a 3x3 campaign, 2 keywords, 1 competitor."""
    ids = {k: str(uuid.uuid4()) for k in ("org", "owner", "viewer", "client", "loc", "camp", "kw1", "kw2", "comp")}
    i = {k: literal(v) for k, v in ids.items()}
    c = db.superuser()
    try:
        c.execute(f"""INSERT INTO plans (code, name, limits) VALUES ('it-{ids['org'][:8]}', 'IT',
                      '{{"monthly_scan_points": 1000, "max_grid_size": 15}}') RETURNING id""")
        c.execute(f"""INSERT INTO organizations (id, name, plan_id) VALUES ({i['org']}, 'IT Agency',
                      (SELECT id FROM plans WHERE code = 'it-{ids['org'][:8]}')) RETURNING id""")
        for k, role in (("owner", "owner"), ("viewer", "client_viewer")):
            c.execute(f"INSERT INTO users (id, email, password_hash) VALUES ({i[k]}, '{ids[k]}@x.test', 'x') RETURNING id")
            c.execute(f"INSERT INTO organization_members (org_id, user_id, role) VALUES ({i['org']}, {i[k]}, '{role}') RETURNING org_id")
        c.execute(f"INSERT INTO clients (id, org_id, name) VALUES ({i['client']}, {i['org']}, 'C') RETURNING id")
        c.execute(f"""INSERT INTO business_locations (id, org_id, client_id, name, place_id, latitude, longitude, time_zone)
                      VALUES ({i['loc']}, {i['org']}, {i['client']}, 'Tub Pros', 'ChIJ_me', 43.6532, -79.3832, 'America/Toronto') RETURNING id""")
        c.execute(f"""INSERT INTO campaigns (id, org_id, location_id, name, grid_size, spacing_m, center_lat, center_lng)
                      VALUES ({i['camp']}, {i['org']}, {i['loc']}, 'Main', 3, 500, 43.6532, -79.3832) RETURNING id""")
        c.execute(f"""INSERT INTO keywords (id, org_id, campaign_id, keyword) VALUES
                      ({i['kw1']}, {i['org']}, {i['camp']}, 'bathtub refinishing'),
                      ({i['kw2']}, {i['org']}, {i['camp']}, 'tub reglazing') RETURNING id""")
        c.execute(f"""INSERT INTO competitors (id, org_id, campaign_id, name, cid)
                      VALUES ({i['comp']}, {i['org']}, {i['camp']}, 'Rival', '222') RETURNING id""")
    finally:
        c.close()
    return ids


class Scripted(RankingProvider):
    """Every point returns the same listings: me at ``me``, rival at ``rival`` (None = absent)."""
    name = "scripted"
    is_demo = True          # scans are created in demo mode in these tests

    def __init__(self, me, rival, fail_every=0):
        self.me, self.rival, self.fail_every, self.n = me, rival, fail_every, 0

    def validate_credentials(self): return True
    def estimate_cost(self, points, config, mode): return Decimal(0)
    def normalize_results(self, raw, depth_requested): raise NotImplementedError

    def fetch_point(self, lat, lng, config, tag=None):
        self.n += 1
        if self.fail_every and self.n % self.fail_every == 0:
            return PointOutcome(False, depth_requested=config.depth, error_code="timeout", error_message="t")
        ls = [Listing(p, t, pid, cid) for p, t, pid, cid in ((self.me, "Me", "ChIJ_me", "1"), (self.rival, "Rival", "ChIJ_r", "222")) if p]
        return PointOutcome(True, tuple(sorted(ls, key=lambda l: l.position)), config.depth, cost=Decimal("0.002"))


def run_one(db, w, monkeypatch, provider, keyword="kw1"):
    with db.tenant_tx(w["org"]) as conn:
        created = scan_svc.create_scans(conn, w["org"], w["camp"], [w[keyword]], SETTINGS)
    assert len(created) == 1 and created[0]["is_demo"] is True
    monkeypatch.setattr(scan_svc, "build_provider", lambda *a, **k: provider)
    status = scan_svc.run_scan(w["org"], created[0]["scan_id"], SETTINGS)
    notif.after_scan(w["org"], created[0]["scan_id"])
    return created[0]["scan_id"], status


def notifications_for(db, w, user="owner"):
    with db.tenant_tx(w["org"]) as conn:
        return conn.execute(f"""SELECT type::text, title, body, email_status, dedupe_key FROM notifications
                                WHERE user_id = {literal(w[user])} ORDER BY created_at, type""").mappings().all()


# ------------------------------------------------------------------ scan pipeline
def test_scan_pipeline_stores_history_and_notifies(db, world, monkeypatch):
    w = world
    s1, st1 = run_one(db, w, monkeypatch, Scripted(me=12, rival=2))
    s2, st2 = run_one(db, w, monkeypatch, Scripted(me=3, rival=9, fail_every=9))
    assert (st1, st2) == ("completed", "partial")
    with db.tenant_tx(w["org"]) as conn:
        rows = conn.execute(f"""SELECT s.status::text, s.points_failed, m.average_position, m.valid_points
                FROM scans s JOIN historical_metrics m ON m.scan_id = s.id AND m.location_id IS NOT NULL
                WHERE s.id IN ({literal(s1)}, {literal(s2)}) ORDER BY s.created_at""").all()
        assert [tuple(r) for r in rows] == [("completed", 0, Decimal("12.00"), 9), ("partial", 1, Decimal("3.00"), 8)]
        assert conn.execute(f"SELECT count(*) FROM api_usage WHERE scan_id IN ({literal(s1)}, {literal(s2)})").scalar() == 18
    # second run of the same scan id does nothing (atomic claim)
    assert scan_svc.run_scan(w["org"], s2, SETTINGS) == "skipped"

    kinds = [n["type"] for n in notifications_for(db, w)]
    assert kinds.count("scan_completed") == 2
    assert "ranking_improved" in kinds            # 12 -> 3 average position
    assert "competitor_change" not in kinds       # rival got worse (2 -> 9)
    improved = next(n for n in notifications_for(db, w) if n["type"] == "ranking_improved")
    assert "average position 12 → 3" in improved["body"]
    partial = [n for n in notifications_for(db, w) if n["type"] == "scan_completed"][-1]
    assert "1 of 9 points returned no data" in partial["body"]
    # notifications are idempotent per event
    notif.after_scan(w["org"], s2)
    assert len(notifications_for(db, w)) == len(kinds)


def test_competitor_gain_and_failed_scan_notifications(db, world, monkeypatch):
    w = world
    run_one(db, w, monkeypatch, Scripted(me=4, rival=None))
    run_one(db, w, monkeypatch, Scripted(me=4, rival=1))       # rival appears everywhere at #1
    failed, st = run_one(db, w, monkeypatch, Scripted(me=1, rival=1, fail_every=1))
    assert st == "failed"
    n = notifications_for(db, w)
    assert any(x["type"] == "competitor_change" and x["title"].startswith("Rival gained ground") for x in n)
    assert any(x["type"] == "scan_failed" for x in n)
    # client viewers get completed scans but not operational failures
    v = [x["type"] for x in notifications_for(db, w, "viewer")]
    assert "scan_completed" in v and "scan_failed" not in v
    with db.tenant_tx(w["org"]) as conn:
        assert conn.execute(f"SELECT count(*) FROM ranking_results WHERE scan_id = {literal(failed)} AND result_status <> 'error'").scalar() == 0


def test_preferences_disable_and_request_email(db, world, monkeypatch):
    w = world
    with db.tenant_tx(w["org"]) as conn:
        conn.execute(f"""INSERT INTO notification_preferences (org_id, user_id, type, in_app, email) VALUES
                         ({literal(w['org'])}, {literal(w['owner'])}, 'scan_completed', false, false),
                         ({literal(w['org'])}, {literal(w['owner'])}, 'scan_failed', true, true)""")
    run_one(db, w, monkeypatch, Scripted(me=1, rival=None, fail_every=1))
    run_one(db, w, monkeypatch, Scripted(me=1, rival=None))
    n = notifications_for(db, w)
    assert [x["type"] for x in n] == ["scan_failed"] and n[0]["email_status"] == "pending"


# ------------------------------------------------------------------ schedules
def put_schedule(db, w, next_run_at, frequency="daily", paused=False):
    with db.tenant_tx(w["org"]) as conn:
        conn.execute(f"""INSERT INTO scan_schedules (org_id, campaign_id, frequency, local_time, anchor_date, is_paused, next_run_at)
                         VALUES ({literal(w['org'])}, {literal(w['camp'])}, '{frequency}', '06:00', '2026-11-01', {literal(paused)},
                                 {literal(next_run_at)})
                         ON CONFLICT (campaign_id) DO UPDATE SET next_run_at = EXCLUDED.next_run_at, is_paused = EXCLUDED.is_paused""")
        return conn.execute(f"SELECT id FROM scan_schedules WHERE campaign_id = {literal(w['camp'])}").scalar()


def test_schedule_dispatch_runs_each_occurrence_once(db, world):
    w = world
    due_at = datetime.now(UTC) - timedelta(minutes=5)
    sid = str(put_schedule(db, w, due_at))
    queued = []
    created = sched_svc.dispatch_due(SETTINGS, lambda org, scan: queued.append((org, scan)))
    assert created == 2 and len(queued) == 2 and {o for o, _ in queued} == {w["org"]}
    with db.tenant_tx(w["org"]) as conn:
        s = conn.execute(f"SELECT next_run_at, last_occurrence, last_error FROM scan_schedules WHERE id = {literal(sid)}").mappings().one()
        keys = [r[0] for r in conn.execute(f"SELECT idempotency_key FROM scans WHERE schedule_id = {literal(sid)}")]
    occ = occurrence_key(due_at, "America/Toronto")
    assert s["next_run_at"] > datetime.now(UTC) and s["last_occurrence"] == occ and s["last_error"] is None
    assert s["next_run_at"].astimezone(__import__("zoneinfo").ZoneInfo("America/Toronto")).time() == time(6, 0)
    assert sorted(keys) == sorted(f"{sid}:{w[k]}:{occ}" for k in ("kw1", "kw2"))

    # nothing is due any more
    assert sched_svc.dispatch_due(SETTINGS, lambda *a: queued.append(a)) == 0
    # the same occurrence triggered again (e.g. a second dispatcher or a reset clock) creates nothing
    put_schedule(db, w, due_at)
    assert sched_svc.run_schedule(w["org"], sid, SETTINGS, lambda *a: queued.append(a)) == 0
    assert len(queued) == 2
    with db.tenant_tx(w["org"]) as conn:
        assert conn.execute(f"SELECT count(*) FROM scans WHERE schedule_id = {literal(sid)}").scalar() == 2


def test_schedule_problems_are_reported_and_skipped(db, world):
    w = world
    sid = str(put_schedule(db, w, datetime.now(UTC) - timedelta(minutes=1)))
    with db.tenant_tx(w["org"]) as conn:
        conn.execute(f"UPDATE keywords SET is_paused = true WHERE campaign_id = {literal(w['camp'])}")
    assert sched_svc.dispatch_due(SETTINGS, lambda *a: None) == 0
    with db.tenant_tx(w["org"]) as conn:
        s = conn.execute(f"SELECT next_run_at, last_error FROM scan_schedules WHERE id = {literal(sid)}").mappings().one()
    assert s["last_error"] == "The campaign has no active keywords" and s["next_run_at"] > datetime.now(UTC)
    n = notifications_for(db, w)
    assert [x["type"] for x in n] == ["schedule_problem"] and "no active keywords" in n[0]["body"]
    assert notifications_for(db, w, "viewer") == []


def test_schedule_respects_monthly_allowance_and_warns(db, world):
    w = world
    sql_su(db, f"UPDATE plans SET limits = '{{\"monthly_scan_points\": 20}}' WHERE id = (SELECT plan_id FROM organizations WHERE id = {literal(w['org'])})")
    sid = str(put_schedule(db, w, datetime.now(UTC) - timedelta(minutes=1)))
    assert sched_svc.run_schedule(w["org"], sid, SETTINGS, lambda *a: None) == 2      # 18 of 20 points: 90%
    assert [x["type"] for x in notifications_for(db, w)] == ["usage_warning"]
    assert "90% of monthly scan allowance used" == notifications_for(db, w)[0]["title"]
    put_schedule(db, w, datetime.now(UTC) - timedelta(minutes=1))
    with db.tenant_tx(w["org"]) as conn:                      # move the occurrence to another day
        conn.execute(f"UPDATE scan_schedules SET next_run_at = next_run_at - interval '1 day' WHERE id = {literal(sid)}")
    assert sched_svc.run_schedule(w["org"], sid, SETTINGS, lambda *a: None) == 0      # 18 + 18 > 20
    problem = [x for x in notifications_for(db, w) if x["type"] == "schedule_problem"]
    assert len(problem) == 1 and "Monthly scan limit reached (18/20" in problem[0]["body"]


def test_due_schedules_filters_and_isolation(db, world):
    w = world
    sid = str(put_schedule(db, w, datetime.now(UTC) - timedelta(minutes=1), paused=True))
    due = lambda: {str(r[0]) for r in sql_su(db, "SELECT schedule_id FROM due_schedules(1000)")}  # noqa: E731
    assert sid not in due()
    put_schedule(db, w, datetime.now(UTC) - timedelta(minutes=1))
    assert sid in due()
    with db.tenant_tx(w["org"]) as conn:
        conn.execute(f"UPDATE campaigns SET is_active = false WHERE id = {literal(w['camp'])}")
    assert sid not in due()
    # the app role cannot read schedules without tenant context, only through the function
    with db.system_tx() as conn:
        assert conn.execute("SELECT count(*) FROM scan_schedules").scalar() == 0
        assert sid not in {str(r[0]) for r in conn.execute("SELECT schedule_id FROM due_schedules(1000)")}


def test_deleting_a_schedule_keeps_finished_scans(db, world, monkeypatch):
    w = world
    sid = str(put_schedule(db, w, datetime.now(UTC) - timedelta(minutes=1)))
    queued = []
    sched_svc.run_schedule(w["org"], sid, SETTINGS, lambda o, s: queued.append(s))
    monkeypatch.setattr(scan_svc, "build_provider", lambda *a, **k: Scripted(me=2, rival=None))
    for s in queued:
        assert scan_svc.run_scan(w["org"], s, SETTINGS) == "completed"
    with db.tenant_tx(w["org"]) as conn:
        assert conn.execute(f"DELETE FROM scan_schedules WHERE id = {literal(sid)}").rowcount == 1
        rows = conn.execute(f"SELECT status::text, schedule_id FROM scans WHERE id IN ({','.join(literal(s) for s in queued)})").all()
    assert [tuple(r) for r in rows] == [("completed", None), ("completed", None)]


def test_maintenance_requeues_and_fails_stuck_scans(db, world):
    w = world
    with db.tenant_tx(w["org"]) as conn:
        a, b = (c["scan_id"] for c in scan_svc.create_scans(conn, w["org"], w["camp"], None, SETTINGS))
    sql_su(db, f"UPDATE scans SET created_at = now() - interval '1 hour' WHERE id = {literal(a)}")
    sql_su(db, f"UPDATE scans SET status = 'running', started_at = now() - interval '5 hours' WHERE id = {literal(b)}")
    requeued, notified = [], []
    out = sched_svc.maintenance(lambda o, s: requeued.append(s), lambda o, s: notified.append(s))
    assert a in requeued and b in notified and out["failed_stuck"] >= 1
    with db.tenant_tx(w["org"]) as conn:
        assert conn.execute(f"SELECT status::text FROM scans WHERE id = {literal(b)}").scalar() == "failed"
