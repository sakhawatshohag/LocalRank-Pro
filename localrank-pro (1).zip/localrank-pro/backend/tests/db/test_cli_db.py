"""Operator commands against PostgreSQL."""
import pytest

import app.cli as cli
from app.security import verify_password


@pytest.fixture
def clidb(db, monkeypatch):
    monkeypatch.setattr(cli, "system_tx", db.system_tx)
    return db


def test_create_account_add_member_plan_and_password(clidb, capsys):
    out = cli.create_account("Owner@Client.test", "Jane", "Acme Plumbing")
    assert len(out["password"]) == 16 and out["plan"] == "standard"
    with clidb.system_tx() as conn:
        row = conn.execute(f"SELECT u.password_hash, m.role::text, p.code, o.trial_ends_at FROM users u JOIN organization_members m ON m.user_id = u.id "
                           f"JOIN organizations o ON o.id = m.org_id JOIN plans p ON p.id = o.plan_id WHERE u.id = '{out['user_id']}'").one()
    assert verify_password(out["password"], row[0]) and row[1] == "owner" and row[2] == "standard" and row[3] is None
    with pytest.raises(cli.CliError, match="already exists"):
        cli.create_account("owner@client.test", "J", "Other")
    with pytest.raises(cli.CliError, match="does not exist"):
        cli.create_account("x@client.test", "X", "X", plan="nope")

    staff = cli.add_member("staff@client.test", "Sam", out["org_id"], "seo_specialist")
    assert staff["password"]
    again = cli.add_member("owner@client.test", "", (cli.create_account("o2@c.test", "O", "Second"))["org_id"], "client_viewer")
    assert again["password"] is None                       # existing account keeps its password
    with pytest.raises(cli.CliError, match="already a member"):
        cli.add_member("staff@client.test", "", out["org_id"], "manager")

    cli.set_plan(out["org_id"], "inactive")
    assert any(o["id"] == out["org_id"] and o["plan"] == "inactive" for o in cli.list_orgs())
    new_pw = cli.reset_password("OWNER@client.test")
    with clidb.system_tx() as conn:
        h = conn.execute(f"SELECT password_hash FROM users WHERE id = '{out['user_id']}'").scalar()
    assert verify_password(new_pw, h) and not verify_password(out["password"], h)
    assert "standard" in {p["code"] for p in cli.list_plans()}

    assert cli.main(["create-account", "--email", "cli@c.test", "--name", "C", "--org", "Cli Org"]) == 0
    assert "Password:" in capsys.readouterr().out
    assert cli.main(["reset-password", "--email", "nobody@c.test"]) == 1


def test_generated_passwords_are_strong():
    pws = {cli.generate_password() for _ in range(50)}
    assert len(pws) == 50 and all(len(p) == 16 and any(c.isdigit() for c in p) and any(c.isupper() for c in p) for p in pws)
