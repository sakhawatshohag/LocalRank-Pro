"""Billing webhooks, trial expiry, invitations and Super Admin functions against PostgreSQL."""
import json
import uuid
from datetime import datetime, timedelta, timezone

import pytest

from app.services import billing
from pgshim import DBError, literal
from test_services_db import sql_su, world  # noqa: F401  (world is a fixture)

T0 = 1_780_000_000


def plan_of(db, org):
    return sql_su(db, f"SELECT p.code FROM organizations o JOIN plans p ON p.id = o.plan_id WHERE o.id = {literal(org)}").scalar()


def event(etype, obj, created=T0, eid=None):
    return {"id": eid or f"evt_{uuid.uuid4().hex[:12]}", "type": etype, "created": created, "data": {"object": obj}}


def sub(status, price="price_pro_test", customer="cus_A", **extra):
    return {"id": "sub_A", "object": "subscription", "customer": customer, "status": status,
            "items": {"data": [{"price": {"id": price}, "current_period_end": T0 + 30 * 86400}]}, **extra}


@pytest.fixture
def pro_plan(db):
    sql_su(db, """INSERT INTO plans (code, name, limits, monthly_price_cents, stripe_price_id, is_public)
                  VALUES ('pro-test', 'Pro', '{"monthly_scan_points": 50000, "white_label": true}', 9900, 'price_pro_test', true)
                  ON CONFLICT (code) DO NOTHING RETURNING id""")


def owner_notifications(db, w):
    with db.tenant_tx(w["org"]) as conn:
        return [r[0] for r in conn.execute(f"""SELECT title FROM notifications WHERE type = 'billing_problem'
                                               AND user_id = {literal(w['owner'])} ORDER BY created_at""")]


def test_subscription_lifecycle_from_webhooks(db, world, pro_plan):
    w = world
    # subscription event before checkout links the customer: not applied, will be retried by Stripe
    early = event("customer.subscription.created", sub("active"))
    assert billing.apply_event(early) == "unknown_customer"
    assert billing.apply_event(event("checkout.session.completed",
        {"id": "cs_1", "client_reference_id": w["org"], "customer": "cus_A", "subscription": "sub_A"})) == "linked"
    assert billing.apply_event(early) == "plan:pro-test"            # the retry now applies
    assert plan_of(db, w["org"]) == "pro-test"
    assert billing.apply_event(early) == "duplicate"                # re-delivered event is ignored
    with db.tenant_tx(w["org"]) as conn:
        s = conn.execute("SELECT status, current_period_end, price_id FROM subscriptions").mappings().one()
    assert s["status"] == "active" and s["price_id"] == "price_pro_test"
    assert s["current_period_end"] == datetime.fromtimestamp(T0 + 30 * 86400, timezone.utc)

    # an older event arriving late does not roll the state back
    assert billing.apply_event(event("customer.subscription.updated", sub("past_due"), created=T0 + 100)) == "plan:pro-test"
    assert billing.apply_event(event("customer.subscription.updated", sub("active"), created=T0 + 50)) == "stale"
    with db.tenant_tx(w["org"]) as conn:
        assert conn.execute("SELECT status FROM subscriptions").scalar() == "past_due"
    assert "Payment failed: please update your payment method" in owner_notifications(db, w)

    # invoices are stored and updated in place
    inv = {"id": "in_1", "customer": "cus_A", "number": "A-001", "status": "open", "amount_due": 9900, "amount_paid": 0,
           "currency": "usd", "hosted_invoice_url": "https://invoice.stripe.com/i/1", "created": T0}
    assert billing.apply_event(event("invoice.payment_failed", inv)) == "invoice"
    assert billing.apply_event(event("invoice.paid", inv | {"status": "paid", "amount_paid": 9900})) == "invoice"
    with db.tenant_tx(w["org"]) as conn:
        assert [tuple(r) for r in conn.execute("SELECT number, status, amount_paid_cents FROM invoices")] == [("A-001", "paid", 9900)]
    assert "Payment failed" in owner_notifications(db, w)

    # cancellation: data kept, plan becomes inactive
    assert billing.apply_event(event("customer.subscription.deleted", sub("canceled"), created=T0 + 200)) == "inactive"
    assert plan_of(db, w["org"]) == "inactive"
    assert "Subscription ended" in owner_notifications(db, w)
    with db.tenant_tx(w["org"]) as conn:
        assert conn.execute("SELECT count(*) FROM keywords").scalar() == 2      # nothing deleted


def test_unknown_price_is_flagged_not_guessed(db, world, pro_plan):
    w = world
    billing.apply_event(event("checkout.session.completed", {"client_reference_id": w["org"], "customer": "cus_B"}))
    before = plan_of(db, w["org"])
    assert billing.apply_event(event("customer.subscription.updated", sub("active", price="price_unknown", customer="cus_B"))) == "unmapped_price"
    assert plan_of(db, w["org"]) == before
    assert "Subscription could not be matched to a plan" in owner_notifications(db, w)
    assert billing.apply_event(event("charge.refunded", {"customer": "cus_B"})) == "ignored"


def test_trials_expire_to_inactive_unless_subscribed(db, world):
    w = world
    sql_su(db, f"""UPDATE organizations SET plan_id = (SELECT id FROM plans WHERE code = 'trial'),
                   trial_ends_at = now() - interval '1 day' WHERE id = {literal(w['org'])}""")
    assert billing.expire_trials() >= 1
    assert plan_of(db, w["org"]) == "inactive"
    assert "Your free trial has ended" in owner_notifications(db, w)


def test_invitation_lookup_function(db, world):
    from app.security import token_hash
    w = world
    with db.tenant_tx(w["org"]) as conn:
        conn.execute(f"""INSERT INTO invitations (org_id, email, role, token_hash, expires_at)
                         VALUES ({literal(w['org'])}, 'new@x.test', 'manager', {literal(token_hash('tok-123'))}, now() + interval '7 days')""")
    with db.system_tx() as conn:
        assert conn.execute("SELECT count(*) FROM invitations").scalar() == 0         # hidden without tenant context
        inv = conn.execute(f"SELECT * FROM invitation_by_token({literal(token_hash('tok-123'))})").mappings().one()
        assert inv["email"] == "new@x.test" and inv["role"] == "manager" and inv["org_name"] == "IT Agency"
        assert conn.execute(f"SELECT * FROM invitation_by_token({literal(token_hash('wrong'))})").first() is None
    with db.tenant_tx(w["org"]) as conn:
        pass
    with pytest.raises(DBError, match="check constraint"):
        with db.tenant_tx(w["org"]) as conn:                                          # owners cannot be invited
            conn.execute(f"""INSERT INTO invitations (org_id, email, role, token_hash, expires_at)
                             VALUES ({literal(w['org'])}, 'x@x.test', 'owner', 'h2', now())""")


def test_super_admin_functions(db, world):
    w = world
    with pytest.raises(DBError, match="super admin privileges required"):
        with db.system_tx() as conn:
            conn.execute(f"SELECT admin_overview({literal(w['owner'])})")
    with pytest.raises(DBError, match="permission denied"):
        with db.system_tx() as conn:
            conn.execute("UPDATE plans SET limits = '{}' WHERE code = 'trial'")            # app role cannot edit plans directly
    sql_su(db, f"UPDATE users SET is_super_admin = true WHERE id = {literal(w['owner'])}")
    with db.system_tx() as conn:
        o = conn.execute(f"SELECT admin_overview({literal(w['owner'])})").scalar()
        o = json.loads(o) if isinstance(o, str) else o
        assert o["organizations"] >= 1 and "api_cost_30d_usd" in o and "provider_health_24h" in o
        conn.execute(f"""SELECT admin_upsert_plan({literal(w['owner'])}, 'agency-test', 'Agency', '{{"locations": 50}}'::jsonb, NULL,
                         19900, 'usd', 'price_agency_test', true, 30, true)""")
        conn.execute(f"SELECT admin_set_org_plan({literal(w['owner'])}, {literal(w['org'])}, 'agency-test', NULL)")
        rows = conn.execute(f"SELECT * FROM admin_organizations({literal(w['owner'])}, 'IT Agency')").mappings().all()
        assert any(r["plan_code"] == "agency-test" and r["members"] == 2 for r in rows)
        conn.execute(f"SELECT admin_set_setting({literal(w['owner'])}, 'maintenance', '{{\"enabled\": true}}'::jsonb)")
        assert conn.execute("SELECT value->>'enabled' FROM system_settings WHERE key = 'maintenance'").scalar() == "true"
        conn.execute(f"SELECT admin_set_setting({literal(w['owner'])}, 'maintenance', '{{\"enabled\": false}}'::jsonb)")
    with pytest.raises(DBError, match="your own account"):
        with db.system_tx() as conn:
            conn.execute(f"SELECT admin_set_user_active({literal(w['owner'])}, {literal(w['owner'])}, false)")
    with db.system_tx() as conn:
        actions = [r[0] for r in conn.execute("SELECT action FROM admin_audit ORDER BY id")]
    assert {"upsert_plan", "set_org_plan", "set_setting"} <= set(actions)
    sql_su(db, f"UPDATE users SET is_super_admin = false WHERE id = {literal(w['owner'])}")
