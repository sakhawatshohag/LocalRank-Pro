"""Database integration tests: run the real service code against a throw-away PostgreSQL
database through tests/db/pgshim.py.  Skipped unless TEST_PGURL points to a server where the
connecting user may create databases, e.g.  TEST_PGURL=postgresql://postgres@localhost:5432/postgres
"""
import os
import subprocess
import sys
import types
import uuid
from pathlib import Path

import pytest

HERE = Path(__file__).resolve().parent
MIGRATIONS = HERE.parents[1] / "migrations"
sys.path.insert(0, str(HERE))

# Provide a stand-in only if SQLAlchemy is not installed: services import it, the shim replaces it.
try:
    import sqlalchemy  # noqa: F401
except ImportError:
    sa = types.ModuleType("sqlalchemy")
    sa.text = lambda s: s
    sa.create_engine = lambda *a, **k: (_ for _ in ()).throw(RuntimeError("not available in shim tests"))
    eng, exc = types.ModuleType("sqlalchemy.engine"), types.ModuleType("sqlalchemy.exc")
    eng.Connection = eng.Engine = object
    exc.IntegrityError = type("IntegrityError", (Exception,), {})
    sa.engine, sa.exc = eng, exc
    sys.modules.update({"sqlalchemy": sa, "sqlalchemy.engine": eng, "sqlalchemy.exc": exc})

from pgshim import ShimDB  # noqa: E402

PGURL = os.getenv("TEST_PGURL")


def _psql(url, *args):
    subprocess.run(["psql", url, "-X", "-q", "-v", "ON_ERROR_STOP=1", *args], check=True, capture_output=True, text=True)


@pytest.fixture(scope="session")
def db_url():
    if not PGURL:
        pytest.skip("TEST_PGURL not set")
    name = f"lrp_it_{uuid.uuid4().hex[:8]}"
    _psql(PGURL, "-c", f"CREATE DATABASE {name}")
    url = PGURL.rsplit("/", 1)[0] + "/" + name
    try:
        for f in sorted(MIGRATIONS.glob("*.sql")):
            if f.name.startswith("0002"):
                avail = subprocess.run(["psql", url, "-XAtc", "SELECT count(*) FROM pg_available_extensions WHERE name='postgis'"],
                                       capture_output=True, text=True).stdout.strip()
                if avail != "1":
                    continue
            _psql(url, "-f", str(f))
        yield url
    finally:
        _psql(PGURL, "-c", f"DROP DATABASE IF EXISTS {name} WITH (FORCE)")


@pytest.fixture
def db(db_url, monkeypatch):
    shim = ShimDB(db_url)
    import app.db
    import app.services.notifications as n
    import app.services.scans as s
    import app.services.billing as bil
    import app.services.reports as rep
    import app.services.schedules as sch
    for mod in (app.db, n, s, sch, rep, bil):
        if hasattr(mod, "tenant_tx"):
            monkeypatch.setattr(mod, "tenant_tx", shim.tenant_tx)
        if hasattr(mod, "system_tx"):
            monkeypatch.setattr(mod, "system_tx", shim.system_tx)
    return shim
