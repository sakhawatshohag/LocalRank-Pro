"""Report generation from real stored scans in PostgreSQL."""
import base64
import io
from datetime import date, datetime, timedelta, timezone

import pdfplumber
import pytest

from app.reporting.images import clean_logo
from app.services import reports as rep
from pgshim import literal
from test_services_db import Scripted, run_one, sql_su, world  # noqa: F401  (world is a fixture)

UTC = timezone.utc


def pdf_text(db, org, report_id):
    with db.tenant_tx(org) as conn:
        r = conn.execute(f"SELECT status::text, encode(pdf, 'base64') AS pdf, csv, page_count, is_demo, error FROM reports WHERE id = {literal(report_id)}").mappings().one()
    if r["status"] != "ready":
        return r, ""
    with pdfplumber.open(io.BytesIO(base64.b64decode(r["pdf"]))) as doc:
        return r, "\n".join(p.filter(lambda o: o.get("size", 0) < 40).extract_text() or "" for p in doc.pages)  # skip the watermark


def new_report(db, w, report_type="weekly", start=None, end=None, options=None, key=None):
    today = datetime.now(UTC).date()
    with db.tenant_tx(w["org"]) as conn:
        return rep.create_report(conn, w["org"], w["client"], report_type, start or today - timedelta(days=6), end or today,
                                 options or {}, idempotency_key=key)


def backdate(db, scan_id, days):
    sql_su(db, f"""ALTER TABLE scans DISABLE TRIGGER scans_immutable;
                   UPDATE scans SET created_at = created_at - interval '{days} days', completed_at = completed_at - interval '{days} days'
                   WHERE id = {literal(scan_id)};
                   ALTER TABLE scans ENABLE TRIGGER scans_immutable""")


@pytest.fixture
def branded(db, world):
    import PIL.Image
    buf = io.BytesIO()
    PIL.Image.new("RGB", (200, 80), "navy").save(buf, "PNG")
    logo = base64.b64encode(clean_logo(base64.b64encode(buf.getvalue()).decode())).decode()
    with db.tenant_tx(world["org"]) as conn:
        conn.execute(f"""INSERT INTO report_branding (org_id, agency_name, primary_color, footer_text, logo_png)
                         VALUES ({literal(world['org'])}, 'Sohag Growth', '#12305a', 'Confidential', decode({literal(logo)}, 'base64'))""")
    return world


def test_weekly_report_from_stored_scans(db, branded, monkeypatch):
    w = branded
    old, _ = run_one(db, w, monkeypatch, Scripted(me=12, rival=2))          # baseline before the period
    backdate(db, old, 10)
    run_one(db, w, monkeypatch, Scripted(me=6, rival=3))                    # inside the period
    run_one(db, w, monkeypatch, Scripted(me=2, rival=4, fail_every=9))      # latest inside the period (partial)
    rid = new_report(db, w)
    assert rep.generate_report(w["org"], rid) == "ready"
    assert rep.generate_report(w["org"], rid) == "skipped"                  # claimed once
    r, text = pdf_text(db, w["org"], rid)
    assert r["page_count"] >= 3 and r["is_demo"] is True and r["error"] is None
    for expected in ("Weekly Ranking Report", "Prepared for C", "Sohag Growth", "Confidential", "Generated with LocalRank Pro",
                     "“bathtub refinishing”", "12 → 2", "Rival", "DEMO DATA", "1 of 9 points returned no data",
                     "No finished scan in this period: Main · tub reglazing", "1 improved significantly"):
        assert expected in text, expected
    # history table: baseline + the two scans in the period
    assert text.count("Scan history in this period") == 1
    # CSV: current (2 businesses x 9) + previous (9)
    assert len(r["csv"].strip().splitlines()) == 1 + 18 + 9
    with db.tenant_tx(w["org"]) as conn:
        n = conn.execute(f"SELECT title FROM notifications WHERE type = 'report_ready' AND user_id = {literal(w['owner'])}").all()
    assert len(n) == 1


def test_white_label_plan_and_empty_period(db, branded, monkeypatch):
    w = branded
    sql_su(db, f"""UPDATE plans SET limits = limits || '{{"white_label": true}}' WHERE id = (SELECT plan_id FROM organizations WHERE id = {literal(w['org'])})""")
    rid = new_report(db, w, "monthly", date(2026, 1, 1), date(2026, 1, 31))
    assert rep.generate_report(w["org"], rid) == "ready"
    r, text = pdf_text(db, w["org"], rid)
    assert "LocalRank Pro" not in text and "No finished scans fall within this reporting period" in text
    assert r["is_demo"] is False


def test_geogrid_comparison_report_and_invalid_selection(db, branded, monkeypatch):
    w = branded
    a, _ = run_one(db, w, monkeypatch, Scripted(me=15, rival=None))
    b, _ = run_one(db, w, monkeypatch, Scripted(me=8, rival=None))
    other, _ = run_one(db, w, monkeypatch, Scripted(me=1, rival=None), keyword="kw2")
    rid = new_report(db, w, "geogrid_comparison", options={"previous_scan_id": a, "current_scan_id": b})
    assert rep.generate_report(w["org"], rid) == "ready"
    _, text = pdf_text(db, w["org"], rid)
    assert "GeoGrid Comparison Report" in text and "15 → 8" in text and "improved at 9" in text
    bad = new_report(db, w, "geogrid_comparison", options={"previous_scan_id": a, "current_scan_id": other})
    assert rep.generate_report(w["org"], bad) == "failed"
    r, _ = pdf_text(db, w["org"], bad)
    assert "different keyword" in r["error"]
    with db.tenant_tx(w["org"]) as conn:
        assert conn.execute(f"SELECT count(*) FROM notifications WHERE type = 'report_failed' AND user_id = {literal(w['owner'])}").scalar() == 1


def test_report_schedule_creates_one_report_per_period(db, branded):
    w = branded
    due = datetime.now(UTC) - timedelta(minutes=1)
    with db.tenant_tx(w["org"]) as conn:
        sid = conn.execute(f"""INSERT INTO report_schedules (org_id, client_id, report_type, time_zone, anchor_date, next_run_at)
                               VALUES ({literal(w['org'])}, {literal(w['client'])}, 'weekly', 'America/Toronto', '2026-11-02', {literal(due)})
                               RETURNING id""").scalar()
    queued = []
    assert rep.dispatch_report_schedules(lambda o, r: queued.append(r)) == 1
    assert rep.dispatch_report_schedules(lambda o, r: queued.append(r)) == 0
    with db.tenant_tx(w["org"]) as conn:
        conn.execute(f"UPDATE report_schedules SET next_run_at = {literal(due)} WHERE id = {literal(sid)}")
    rep.run_report_schedule(w["org"], str(sid), lambda o, r: queued.append(r))    # same occurrence again
    with db.tenant_tx(w["org"]) as conn:
        rows = conn.execute(f"SELECT period_start, period_end FROM reports WHERE schedule_id = {literal(sid)}").all()
        nxt = conn.execute(f"SELECT next_run_at FROM report_schedules WHERE id = {literal(sid)}").scalar()
    assert len(rows) == 1 and len(queued) == 1
    start, end = rows[0]
    assert (end - start).days == 6 and nxt > datetime.now(UTC)


def test_reports_are_isolated_between_organizations(db, branded):
    w = branded
    rid = new_report(db, w)
    other = "bbbbbbbb-1111-2222-3333-444444444444"
    sql_su(db, f"INSERT INTO organizations (id, name) VALUES ({literal(other)}, 'Other') ON CONFLICT DO NOTHING RETURNING id")
    with db.tenant_tx(other) as conn:
        assert conn.execute("SELECT count(*) FROM reports").scalar() == 0
        assert conn.execute("SELECT count(*) FROM report_branding").scalar() == 0
    assert rep.generate_report(other, rid) == "skipped"
