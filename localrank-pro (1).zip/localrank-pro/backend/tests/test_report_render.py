"""Rendering tests: build a ReportModel from known numbers, render it, read the PDF back."""
import io
from datetime import date, datetime, timezone

import pdfplumber
import pytest
from PIL import Image

from app.engine.report_model import (
    Branding, BusinessRow, KeywordSection, PointView, ReportModel, ScanRef, executive_summary, quadrant_weakness,
    report_period, section_observations,
)
from app.reporting import pdf as pdfmod
from app.reporting.pdf import render_csv, render_pdf


def grid(size, fn):
    return [PointView(r * size + c, r, c, 43.6 + r / 100, -79.4 + c / 100, *fn(r, c)) for r in range(size) for c in range(size)]


def metrics(avg, top3, top10, valid=25, total=25, top3c=None, nf=0):
    return {"average_position": avg, "top3_coverage": top3, "top10_coverage": top10, "top20_coverage": top10,
            "not_found_pct": round(100 * nf / valid, 2) if valid else None, "top3_count": top3c if top3c is not None else round(top3 * valid / 100),
            "top10_count": round(top10 * valid / 100), "top20_count": round(top10 * valid / 100), "valid_points": valid,
            "total_points": total, "not_found_points": nf}


def logo_png(color):
    buf = io.BytesIO()
    Image.new("RGB", (300, 100), color).save(buf, "PNG")
    return buf.getvalue()


def model(white_label=False, demo=False, previous=True):
    # south-east quadrant weak: not found there, top 3 elsewhere
    cur = grid(5, lambda r, c: ("not_found", None) if (r > 2 and c > 2) else ("error", None) if (r, c) == (0, 4) else ("ranked", 1 + (r + c) % 3))
    prev = grid(5, lambda r, c: ("ranked", 8 + r + c))
    s = KeywordSection(
        campaign_name="Toronto core", location_name="Tub Pros", keyword="bathtub refinishing", grid_size=5, spacing_m=800, depth=100,
        current=ScanRef("s2", datetime(2026, 11, 14, 11, tzinfo=timezone.utc), "partial", 24, 25),
        previous=ScanRef("s1", datetime(2026, 11, 7, 11, tzinfo=timezone.utc), "completed", 25, 25) if previous else None,
        current_points=cur, previous_points=prev if previous else [],
        change_counts={"improved": 18, "declined": 0, "unchanged": 0, "newly_found": 0, "lost_visibility": 4} if previous else None,
        comparable_points=24 if previous else None, average_delta=9.5 if previous else None,
        businesses=[BusinessRow("Tub Pros", True, metrics(12, 0, 40) if previous else None, metrics(2, 70, 80, valid=24, top3c=17, nf=4), cur),
                    BusinessRow("Rival Reglazing", False, metrics(4, 50, 90), metrics(5, 40, 90, valid=24, top3c=10), cur)],
        history=[{"date": datetime(2026, 11, 7), "average_position": 12, "top3_coverage": 0, "top10_coverage": 40, "valid_points": 25, "total_points": 25},
                 {"date": datetime(2026, 11, 14), "average_position": 2, "top3_coverage": 70, "top10_coverage": 80, "valid_points": 24, "total_points": 25}],
        is_demo=demo)
    return ReportModel(title="Weekly Ranking Report", report_type="weekly", client_name="Tub Pros Inc.", period_start=date(2026, 11, 8),
                       period_end=date(2026, 11, 14), generated_at=datetime(2026, 11, 15, 7, tzinfo=timezone.utc),
                       branding=Branding(agency_name="Sohag Growth", website="example.com", primary_color="#12305a",
                                         footer_text="Confidential", logo_png=logo_png("navy"), white_label=white_label),
                       client_logo_png=logo_png("orange"), sections=[s], recommendations="Add service-area pages for the south-east.",
                       without_data=["Toronto core · tub reglazing"], data_source="DataForSEO Google Maps SERP API")


def text_of(pdf_bytes):
    with pdfplumber.open(io.BytesIO(pdf_bytes)) as doc:
        # skip the large rotated watermark
        return "\n".join(p.filter(lambda o: o.get("size", 0) < 40).extract_text() or "" for p in doc.pages), len(doc.pages)


def test_pdf_contains_the_reported_numbers_and_branding():
    data, pages = render_pdf(model())
    text, n = text_of(data)
    assert data.startswith(b"%PDF") and pages == n >= 3
    for expected in ("Weekly Ranking Report", "Prepared for Tub Pros Inc.", "08 Nov 2026 – 14 Nov 2026", "Sohag Growth",
                     "Executive summary", "1 improved significantly", "Average position", "12 → 2", "0% → 70%",
                     "Previous · 07 Nov 2026", "Current · 14 Nov 2026", "Rival Reglazing", "Top 3 at 17 of 24 valid points",
                     "Weakest area: the south-east of the grid", "lost at 4", "Recommendations", "service-area pages",
                     "1 of 25 points returned no data", "No finished scan in this period: Toronto core · tub reglazing",
                     "How to read this report", "Confidential", "Generated with LocalRank Pro", "100+"):
        assert expected in text, expected
    assert "DEMO DATA" not in text


def test_white_label_removes_platform_branding_and_demo_is_watermarked():
    text, _ = text_of(render_pdf(model(white_label=True))[0])
    assert "LocalRank Pro" not in text and "Sohag Growth" in text
    text, _ = text_of(render_pdf(model(demo=True))[0])
    assert "DEMO DATA" in text and "synthetic rankings" in text


def test_first_report_without_baseline_says_so():
    m = model(previous=False)
    text, _ = text_of(render_pdf(m)[0])
    assert "No earlier comparable scan exists yet" in text
    assert any("no earlier comparable scan" in line for line in executive_summary(m))


def test_empty_report_is_honest():
    m = model()
    m.sections = []
    text, _ = text_of(render_pdf(m)[0])
    assert "No finished scans fall within this reporting period" in text


def test_csv_lists_every_point_for_every_business():
    rows = render_csv(model()).strip().splitlines()
    assert rows[0].startswith("report,client,period_start")
    assert len(rows) == 1 + 25 * 2 + 25          # header + current x 2 businesses + previous
    assert any(",not_found," in r for r in rows) and any(",error," in r for r in rows)


def test_rules():
    weak = quadrant_weakness(model().sections[0].current_points, 5)
    assert weak.startswith("Weakest area: the south-east")
    assert quadrant_weakness(grid(5, lambda r, c: ("ranked", 2)), 5) is None
    assert quadrant_weakness(grid(3, lambda r, c: ("not_found", None)), 3) is None
    obs = section_observations(model().sections[0])
    assert any("more points than any tracked competitor" in o for o in obs)
    assert report_period("weekly", date(2026, 11, 16)) == (date(2026, 11, 9), date(2026, 11, 15))
    assert report_period("monthly", date(2026, 3, 1)) == (date(2026, 2, 1), date(2026, 2, 28))
    with pytest.raises(ValueError):
        report_period("custom", date(2026, 1, 1))


def test_ascii_fallback_font(monkeypatch):
    monkeypatch.setattr(pdfmod, "UNICODE", False)
    assert pdfmod.t("12 → 2 −3 “x”") == '12 -> 2 -3 "x"'


def test_logo_validation():
    import base64
    from app.reporting.images import LogoError, clean_logo
    png = clean_logo(base64.b64encode(logo_png("red")).decode())
    assert png.startswith(b"\x89PNG")
    big = io.BytesIO()
    Image.new("RGB", (3000, 1000), "blue").save(big, "JPEG")
    out = Image.open(io.BytesIO(clean_logo("data:image/jpeg;base64," + base64.b64encode(big.getvalue()).decode())))
    assert out.size == (1200, 400) and out.format == "PNG"
    for bad in ("not base64!!", base64.b64encode(b"<svg></svg>").decode(), base64.b64encode(b"x" * 1_000_001).decode()):
        with pytest.raises(LogoError):
            clean_logo(bad)
    gif = io.BytesIO()
    Image.new("RGB", (10, 10)).save(gif, "GIF")
    with pytest.raises(LogoError):
        clean_logo(base64.b64encode(gif.getvalue()).decode())
