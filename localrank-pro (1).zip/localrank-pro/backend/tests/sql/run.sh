#!/usr/bin/env bash
# Runs the SQL tests against a throw-away database.
# Usage (from backend/): PGURL=postgresql://postgres@localhost:5432/postgres tests/sql/run.sh
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
MIG="$HERE/../../migrations"
PGURL="${PGURL:-postgresql://postgres@localhost:5432/postgres}"
PYTHON="${PYTHON:-python3}"
DB="localrank_test_$$"
BASE="${PGURL%/*}"
run() { psql "$BASE/$DB" -v ON_ERROR_STOP=1 -q "$@"; }
psql "$PGURL" -v ON_ERROR_STOP=1 -qc "CREATE DATABASE $DB"
trap 'psql "$PGURL" -qc "DROP DATABASE IF EXISTS $DB" >/dev/null' EXIT
run -f "$MIG/0001_core.sql"
if [ "$(psql "$PGURL" -qAtc "SELECT count(*) FROM pg_available_extensions WHERE name = 'postgis'")" = "1" ]; then
  run -f "$MIG/0002_postgis.sql"
else
  echo "NOTE: PostGIS not installed on this server - 0002_postgis.sql was NOT tested"
fi
for f in "$MIG"/000[3-9]_*.sql; do run -f "$f"; done
run -f "$HERE/test_schema.sql" 2>&1
"$PYTHON" "$HERE/make_scan_storage_test.py" > "/tmp/scan_storage_$$.sql"
run -f "/tmp/scan_storage_$$.sql" 2>&1
rm -f "/tmp/scan_storage_$$.sql"
