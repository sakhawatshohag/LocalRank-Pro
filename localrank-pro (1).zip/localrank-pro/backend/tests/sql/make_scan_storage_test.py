"""Generates the SQL test for store_scan_result().

The payloads are produced by the REAL Python pipeline (grid -> scan runner -> payload), then
stored through the REAL SQL function, so this is an end-to-end test of scan persistence that
needs no Python database driver.  Run through tests/sql/run.sh (expects orgs from test_schema.sql).
"""
import copy
import json
import sys
from decimal import Decimal
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from app.engine.geogrid import generate_grid, grid_signature  # noqa: E402
from app.engine.payload import scan_result_to_payload  # noqa: E402
from app.engine.scan_runner import execute_scan  # noqa: E402
from app.providers.base import Listing, PointOutcome, RankingProvider, SearchConfig, Subject  # noqa: E402

ORG_A, ORG_B = "aaaaaaaa-0000-0000-0000-000000000001", "bbbbbbbb-0000-0000-0000-000000000002"
LOC, CAMP, KW, COMP = (f"c{n}000000-0000-0000-0000-000000000001" for n in (2, 3, 4, 5))
SCANS = [f"c6000000-0000-0000-0000-00000000000{n}" for n in range(1, 6)]
CENTER, SIZE, SPACING = (43.6532, -79.3832), 3, 500.0
ME, RIVAL = Subject(f"location:{LOC}", place_id="ChIJ_me"), Subject(f"competitor:{COMP}", cid="222")


class Scripted(RankingProvider):
    name = "scripted"

    def __init__(self, script):
        self.script, self.n = script, 0

    def validate_credentials(self): return True
    def estimate_cost(self, points, config, mode): return Decimal(0)
    def normalize_results(self, raw, depth_requested): raise NotImplementedError

    def fetch_point(self, lat, lng, config, tag=None):
        out = self.script[self.n]
        self.n += 1
        return out


def ok(me=None, rival=None):
    ls = []
    if me:
        ls.append(Listing(me, "Me", "ChIJ_me", "333"))
    if rival:
        ls.append(Listing(rival, "Rival", "ChIJ_r", "222"))
    return PointOutcome(True, tuple(sorted(ls, key=lambda l: l.position)), 100, cost=Decimal("0.002"),
                        provider_task_id="task", check_url="https://example.test/check", meta={"task_status_code": 20000})


ERR = PointOutcome(False, depth_requested=100, error_code="timeout", error_message="request timed out")
points = generate_grid(*CENTER, SIZE, SPACING)
sig = grid_signature(*CENTER, SIZE, SPACING)
cfg = SearchConfig("plumber")


def payload(script):
    return scan_result_to_payload(points, execute_scan(Scripted(script), points, cfg, [ME, RIVAL]), sig)


mixed = payload([ok(1, 2), ok(2), ok(3, 1), ok(4), ok(5), ok(None, 3), ok(), ERR, ok(12, 20)])
all_ok = payload([ok(1)] * 9)
all_failed = payload([ERR] * 9)
tampered = copy.deepcopy(mixed)          # a ranking invented for the failed point (index 7)
for r in tampered["rankings"]:
    if r["point_index"] == 7 and r["subject_type"] == "location":
        r.update(status="ranked", position=1)
foreign = copy.deepcopy(all_ok)          # a business that is not part of the campaign
foreign["rankings"][0]["subject_id"] = "a2000000-0000-0000-0000-000000000001"
wrong_grid = copy.deepcopy(all_ok) | {"grid_signature": "other"}


def q(p):
    return "$json$" + json.dumps(p) + "$json$::jsonb"


def store(scan, p):
    return f"SELECT store_scan_result('{scan}', {q(p)})"


def must_fail(sql, label):
    return f"SELECT pg_temp.must_fail($f${sql}$f$, '{label}');"


def eq(expr, want, label):
    return f"SELECT pg_temp.check_eq(({expr})::text, '{want}', '{label}');"


scan_rows = ",\n".join(
    f" ('{s}','{ORG_A}','{CAMP}','{KW}','plumber','dataforseo',{SIZE},{SPACING},{CENTER[0]},{CENTER[1]},'{sig}','{{}}',100,9,'running')"
    for s in SCANS)

print(f"""\\set ON_ERROR_STOP on
SET ROLE localrank_app;
CREATE FUNCTION pg_temp.must_fail(sql text, label text) RETURNS void LANGUAGE plpgsql AS $$
BEGIN
    BEGIN EXECUTE sql;
    EXCEPTION WHEN OTHERS THEN RAISE NOTICE 'PASS (rejected): % -> %', label, SQLERRM; RETURN;
    END;
    RAISE EXCEPTION 'FAIL: % was allowed', label;
END $$;
CREATE FUNCTION pg_temp.check_eq(got text, want text, label text) RETURNS void LANGUAGE plpgsql AS $$
BEGIN
    IF got IS DISTINCT FROM want THEN RAISE EXCEPTION 'FAIL: % (got %, want %)', label, got, want; END IF;
    RAISE NOTICE 'PASS: %', label;
END $$;

SELECT set_config('app.current_org','{ORG_A}', false);
INSERT INTO business_locations (id, org_id, client_id, name, place_id, latitude, longitude)
  VALUES ('{LOC}','{ORG_A}','a1000000-0000-0000-0000-000000000001','Storage Biz','ChIJ_me',{CENTER[0]},{CENTER[1]});
INSERT INTO campaigns (id, org_id, location_id, name, grid_size, spacing_m, center_lat, center_lng)
  VALUES ('{CAMP}','{ORG_A}','{LOC}','Storage',{SIZE},{SPACING},{CENTER[0]},{CENTER[1]});
INSERT INTO keywords (id, org_id, campaign_id, keyword) VALUES ('{KW}','{ORG_A}','{CAMP}','plumber');
INSERT INTO competitors (id, org_id, campaign_id, name, cid) VALUES ('{COMP}','{ORG_A}','{CAMP}','Rival','222');
INSERT INTO scans (id, org_id, campaign_id, keyword_id, keyword_text, provider_code, grid_size, spacing_m, center_lat,
                   center_lng, grid_signature, search_config, depth, points_total, status) VALUES
{scan_rows};

-- another organization cannot store into this scan
SELECT set_config('app.current_org','{ORG_B}', false);
{must_fail(store(SCANS[0], mixed), 'org B storing results into org A scan')}
SELECT set_config('app.current_org','{ORG_A}', false);

-- rejected payloads leave nothing behind (atomic)
{must_fail(store(SCANS[0], tampered), 'ranking invented for a failed grid point')}
{must_fail(store(SCANS[0], foreign), 'results for a business outside the campaign')}
{must_fail(store(SCANS[0], wrong_grid), 'results for a different grid')}
{eq(f"SELECT count(*) FROM grid_points WHERE scan_id = '{SCANS[0]}'", 0, 'rejected payloads stored no grid points')}
{eq(f"SELECT status FROM scans WHERE id = '{SCANS[0]}'", 'running', 'rejected payloads left the scan untouched')}

-- mixed scan: 8 good points, 1 failed
{eq(store(SCANS[0], mixed), 'partial', 'scan with one failed point is stored as partial')}
{eq(f"SELECT count(*) FROM grid_points WHERE scan_id = '{SCANS[0]}'", 9, '9 grid points stored')}
{eq(f"SELECT count(DISTINCT (latitude, longitude)) FROM grid_points WHERE scan_id = '{SCANS[0]}'", 9, 'every grid point has a unique coordinate')}
{eq(f"SELECT count(*) FROM ranking_results WHERE scan_id = '{SCANS[0]}'", 18, 'one ranking row per point per business')}
{eq(f"SELECT string_agg(coalesce(r.position::text, r.result_status::text), ',' ORDER BY g.point_index) FROM ranking_results r JOIN grid_points g ON g.id = r.grid_point_id WHERE r.scan_id = '{SCANS[0]}' AND r.subject_type = 'location'", '1,2,3,4,5,not_found,not_found,error,12', 'tracked business positions stored exactly')}
{eq(f"SELECT string_agg(coalesce(r.position::text, r.result_status::text), ',' ORDER BY g.point_index) FROM ranking_results r JOIN grid_points g ON g.id = r.grid_point_id WHERE r.scan_id = '{SCANS[0]}' AND r.competitor_id = '{COMP}'", '2,not_found,1,not_found,not_found,3,not_found,error,20', 'competitor positions from the same coordinates')}
{eq(f"SELECT average_position || '/' || valid_points || '/' || not_found_points || '/' || error_points || '/' || top3_coverage || '/' || top10_coverage FROM historical_metrics WHERE scan_id = '{SCANS[0]}' AND subject_type = 'location'", '4.50/8/2/1/37.50/62.50', 'derived metrics for tracked business')}
{eq(f"SELECT average_position || '/' || not_found_points FROM historical_metrics WHERE scan_id = '{SCANS[0]}' AND competitor_id = '{COMP}'", '6.50/4', 'derived metrics for competitor')}
{eq(f"SELECT points_failed || '/' || actual_cost_usd || '/' || (completed_at IS NOT NULL) FROM scans WHERE id = '{SCANS[0]}'", '1/0.016000/true', 'failed count, actual cost and completion time recorded')}
{eq(f"SELECT count(*) FILTER (WHERE success) || '/' || count(*) FILTER (WHERE NOT success) FROM api_usage WHERE scan_id = '{SCANS[0]}'", '8/1', 'API usage logged per request')}
{eq(f"SELECT error_code FROM grid_points WHERE scan_id = '{SCANS[0]}' AND point_index = 7", 'timeout', 'provider error kept on the failed point')}
{must_fail(store(SCANS[0], mixed), 'storing results for the same scan twice')}

-- second and third scans of the same keyword: history accumulates
{eq(store(SCANS[1], all_ok), 'completed', 'fully successful scan is stored as completed')}
{eq(store(SCANS[2], all_failed), 'failed', 'scan with no usable data is stored as failed')}
{eq(f"SELECT count(*) FROM ranking_results WHERE scan_id = '{SCANS[2]}' AND result_status <> 'error'", 0, 'failed scan holds no rankings, only errors')}
{eq(f"SELECT average_position IS NULL AND valid_points = 0 FROM historical_metrics WHERE scan_id = '{SCANS[2]}' AND subject_type = 'location'", 'true', 'failed scan has NULL average, not 0')}
{eq(f"SELECT count(*) FROM scans WHERE keyword_id = '{KW}' AND status IN ('completed','partial','failed')", 3, 'three scans of the keyword kept side by side')}
{eq(f"SELECT count(*) FROM ranking_results WHERE scan_id = '{SCANS[0]}'", 18, 'first scan unchanged after later scans')}

SELECT set_config('app.current_org','{ORG_B}', false);
{eq("SELECT count(*) FROM grid_points", 0, 'org B sees none of the stored grid points')}
{eq("SELECT count(*) FROM api_usage", 0, 'org B sees none of the API usage')}
\\echo ALL SCAN STORAGE TESTS PASSED
""")
