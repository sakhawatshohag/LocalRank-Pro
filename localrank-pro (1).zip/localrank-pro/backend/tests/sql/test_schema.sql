-- Database tests: tenant isolation (RLS), ranking integrity, immutable history,
-- scheduled-scan idempotency.  Run with tests/sql/run.sh.  Any failure aborts.
\set ON_ERROR_STOP on

-- fixture data is created by the superuser (bypasses RLS)
INSERT INTO organizations (id, name) VALUES
  ('aaaaaaaa-0000-0000-0000-000000000001','Agency A'),
  ('bbbbbbbb-0000-0000-0000-000000000002','Agency B');

SET ROLE localrank_app;

-- helper: expect a statement to fail
CREATE FUNCTION pg_temp.must_fail(sql text, label text) RETURNS void LANGUAGE plpgsql AS $$
BEGIN
    BEGIN
        EXECUTE sql;
    EXCEPTION WHEN OTHERS THEN
        RAISE NOTICE 'PASS (rejected): % -> %', label, SQLERRM;
        RETURN;
    END;
    RAISE EXCEPTION 'FAIL: % was allowed', label;
END $$;
CREATE FUNCTION pg_temp.check_eq(got bigint, want bigint, label text) RETURNS void LANGUAGE plpgsql AS $$
BEGIN
    IF got IS DISTINCT FROM want THEN RAISE EXCEPTION 'FAIL: % (got %, want %)', label, got, want; END IF;
    RAISE NOTICE 'PASS: %', label;
END $$;

-- ---- org A creates a full chain ----
SELECT set_config('app.current_org','aaaaaaaa-0000-0000-0000-000000000001', false);
INSERT INTO clients (id, org_id, name) VALUES ('a1000000-0000-0000-0000-000000000001','aaaaaaaa-0000-0000-0000-000000000001','Client A1');
INSERT INTO business_locations (id, org_id, client_id, name, place_id, latitude, longitude)
  VALUES ('a2000000-0000-0000-0000-000000000001','aaaaaaaa-0000-0000-0000-000000000001','a1000000-0000-0000-0000-000000000001','Biz A','ChIJ_a',43.65,-79.38);
INSERT INTO campaigns (id, org_id, location_id, name, grid_size, spacing_m, center_lat, center_lng)
  VALUES ('a3000000-0000-0000-0000-000000000001','aaaaaaaa-0000-0000-0000-000000000001','a2000000-0000-0000-0000-000000000001','Camp',3,500,43.65,-79.38);
INSERT INTO keywords (id, org_id, campaign_id, keyword)
  VALUES ('a4000000-0000-0000-0000-000000000001','aaaaaaaa-0000-0000-0000-000000000001','a3000000-0000-0000-0000-000000000001','plumber');
INSERT INTO competitors (id, org_id, campaign_id, name, cid)
  VALUES ('a5000000-0000-0000-0000-000000000001','aaaaaaaa-0000-0000-0000-000000000001','a3000000-0000-0000-0000-000000000001','Rival','222');

-- two scans of the same keyword/grid on different dates
INSERT INTO scans (id, org_id, campaign_id, keyword_id, keyword_text, provider_code, grid_size, spacing_m, center_lat, center_lng, grid_signature, search_config, depth, points_total, idempotency_key, status)
VALUES
 ('a6000000-0000-0000-0000-000000000001','aaaaaaaa-0000-0000-0000-000000000001','a3000000-0000-0000-0000-000000000001','a4000000-0000-0000-0000-000000000001','plumber','dataforseo',3,500,43.65,-79.38,'sig','{}',100,1,'sched1:kw1:2026-11-07','running'),
 ('a6000000-0000-0000-0000-000000000002','aaaaaaaa-0000-0000-0000-000000000001','a3000000-0000-0000-0000-000000000001','a4000000-0000-0000-0000-000000000001','plumber','dataforseo',3,500,43.65,-79.38,'sig','{}',100,1,'sched1:kw1:2026-11-14','running');
INSERT INTO grid_points (id, org_id, scan_id, point_index, row_no, col_no, latitude, longitude, status) VALUES
 ('a7000000-0000-0000-0000-000000000001','aaaaaaaa-0000-0000-0000-000000000001','a6000000-0000-0000-0000-000000000001',0,0,0,43.65,-79.38,'ok'),
 ('a7000000-0000-0000-0000-000000000002','aaaaaaaa-0000-0000-0000-000000000001','a6000000-0000-0000-0000-000000000002',0,0,0,43.65,-79.38,'ok');
INSERT INTO ranking_results (org_id, scan_id, grid_point_id, campaign_id, keyword_id, subject_type, location_id, result_status, position, depth_checked, scanned_at) VALUES
 ('aaaaaaaa-0000-0000-0000-000000000001','a6000000-0000-0000-0000-000000000001','a7000000-0000-0000-0000-000000000001','a3000000-0000-0000-0000-000000000001','a4000000-0000-0000-0000-000000000001','location','a2000000-0000-0000-0000-000000000001','ranked',15,100,'2026-11-07'),
 ('aaaaaaaa-0000-0000-0000-000000000001','a6000000-0000-0000-0000-000000000002','a7000000-0000-0000-0000-000000000002','a3000000-0000-0000-0000-000000000001','a4000000-0000-0000-0000-000000000001','location','a2000000-0000-0000-0000-000000000001','ranked',8,100,'2026-11-14');
INSERT INTO ranking_results (org_id, scan_id, grid_point_id, campaign_id, keyword_id, subject_type, competitor_id, result_status, position, depth_checked, scanned_at) VALUES
 ('aaaaaaaa-0000-0000-0000-000000000001','a6000000-0000-0000-0000-000000000002','a7000000-0000-0000-0000-000000000002','a3000000-0000-0000-0000-000000000001','a4000000-0000-0000-0000-000000000001','competitor','a5000000-0000-0000-0000-000000000001','not_found',NULL,100,'2026-11-14');
UPDATE scans SET status='completed', completed_at=now() WHERE org_id='aaaaaaaa-0000-0000-0000-000000000001';

SELECT pg_temp.check_eq((SELECT count(*) FROM scans), 2, 'second scan does not overwrite the first (2 scans stored)');
SELECT pg_temp.check_eq((SELECT count(*) FROM ranking_results WHERE subject_type='location'), 2, 'both historical rankings kept');

-- ---- ranking integrity ----
SELECT pg_temp.must_fail($$INSERT INTO ranking_results (org_id, scan_id, grid_point_id, campaign_id, keyword_id, subject_type, competitor_id, result_status, position, depth_checked, scanned_at) VALUES ('aaaaaaaa-0000-0000-0000-000000000001','a6000000-0000-0000-0000-000000000001','a7000000-0000-0000-0000-000000000001','a3000000-0000-0000-0000-000000000001','a4000000-0000-0000-0000-000000000001','competitor','a5000000-0000-0000-0000-000000000001','not_found',0,100,now())$$, 'not_found stored as position 0');
SELECT pg_temp.must_fail($$INSERT INTO ranking_results (org_id, scan_id, grid_point_id, campaign_id, keyword_id, subject_type, competitor_id, result_status, position, depth_checked, scanned_at) VALUES ('aaaaaaaa-0000-0000-0000-000000000001','a6000000-0000-0000-0000-000000000001','a7000000-0000-0000-0000-000000000001','a3000000-0000-0000-0000-000000000001','a4000000-0000-0000-0000-000000000001','competitor','a5000000-0000-0000-0000-000000000001','error',7,100,now())$$, 'API error stored with a ranking position');
SELECT pg_temp.must_fail($$INSERT INTO ranking_results (org_id, scan_id, grid_point_id, campaign_id, keyword_id, subject_type, competitor_id, result_status, position, depth_checked, scanned_at) VALUES ('aaaaaaaa-0000-0000-0000-000000000001','a6000000-0000-0000-0000-000000000001','a7000000-0000-0000-0000-000000000001','a3000000-0000-0000-0000-000000000001','a4000000-0000-0000-0000-000000000001','competitor','a5000000-0000-0000-0000-000000000001','ranked',NULL,100,now())$$, 'ranked without a position');
SELECT pg_temp.must_fail($$INSERT INTO ranking_results (org_id, scan_id, grid_point_id, campaign_id, keyword_id, subject_type, location_id, result_status, position, depth_checked, scanned_at) VALUES ('aaaaaaaa-0000-0000-0000-000000000001','a6000000-0000-0000-0000-000000000001','a7000000-0000-0000-0000-000000000001','a3000000-0000-0000-0000-000000000001','a4000000-0000-0000-0000-000000000001','location','a2000000-0000-0000-0000-000000000001','ranked',3,100,now())$$, 'duplicate result for same point and business');
SELECT pg_temp.must_fail($$INSERT INTO competitors (org_id, campaign_id, name) VALUES ('aaaaaaaa-0000-0000-0000-000000000001','a3000000-0000-0000-0000-000000000001','No identifier')$$, 'competitor without place_id/cid');

-- ---- immutable history ----
SELECT pg_temp.must_fail($$UPDATE ranking_results SET position = 1$$, 'updating a stored ranking');
SELECT pg_temp.must_fail($$DELETE FROM ranking_results$$, 'deleting stored rankings');
SELECT pg_temp.must_fail($$UPDATE scans SET keyword_text='x' WHERE id='a6000000-0000-0000-0000-000000000001'$$, 'modifying a completed scan');
SELECT pg_temp.must_fail($$DELETE FROM scans$$, 'deleting a scan');

-- ---- scheduled occurrence idempotency ----
SELECT pg_temp.must_fail($$INSERT INTO scans (org_id, campaign_id, keyword_id, keyword_text, provider_code, grid_size, spacing_m, center_lat, center_lng, grid_signature, search_config, depth, points_total, idempotency_key) VALUES ('aaaaaaaa-0000-0000-0000-000000000001','a3000000-0000-0000-0000-000000000001','a4000000-0000-0000-0000-000000000001','plumber','dataforseo',3,500,43.65,-79.38,'sig','{}',100,1,'sched1:kw1:2026-11-14')$$, 'second scan for the same scheduled occurrence');

-- ---- tenant isolation ----
SELECT set_config('app.current_org','bbbbbbbb-0000-0000-0000-000000000002', false);
SELECT pg_temp.check_eq((SELECT count(*) FROM clients), 0, 'org B sees no clients of org A');
SELECT pg_temp.check_eq((SELECT count(*) FROM business_locations), 0, 'org B sees no locations of org A');
SELECT pg_temp.check_eq((SELECT count(*) FROM scans), 0, 'org B sees no scans of org A');
SELECT pg_temp.check_eq((SELECT count(*) FROM ranking_results), 0, 'org B sees no rankings of org A');
SELECT pg_temp.must_fail($$INSERT INTO clients (org_id, name) VALUES ('aaaaaaaa-0000-0000-0000-000000000001','Injected')$$, 'org B inserting into org A');
WITH u AS (UPDATE clients SET name='hacked' WHERE id='a1000000-0000-0000-0000-000000000001' RETURNING 1)
SELECT pg_temp.check_eq((SELECT count(*) FROM u), 0, 'org B cannot update org A rows');
INSERT INTO clients (id, org_id, name) VALUES ('b1000000-0000-0000-0000-000000000001','bbbbbbbb-0000-0000-0000-000000000002','Client B1');
SELECT pg_temp.must_fail($$INSERT INTO business_locations (org_id, client_id, name, latitude, longitude) VALUES ('bbbbbbbb-0000-0000-0000-000000000002','a1000000-0000-0000-0000-000000000001','X',1,1)$$, 'org B attaching a location to org A client');

SELECT set_config('app.current_org','', false);
SELECT pg_temp.check_eq((SELECT count(*) FROM clients), 0, 'no tenant context = no rows');
SELECT pg_temp.must_fail($$INSERT INTO clients (org_id, name) VALUES ('bbbbbbbb-0000-0000-0000-000000000002','NoCtx')$$, 'write without tenant context');
SELECT pg_temp.must_fail($$UPDATE api_pricing SET unit_price_usd = 0$$, 'app role changing provider pricing');

SELECT set_config('app.current_org','aaaaaaaa-0000-0000-0000-000000000001', false);
SELECT pg_temp.check_eq((SELECT count(*) FROM clients WHERE name='Client A1'), 1, 'org A data intact and visible to org A');

\echo ALL SQL TESTS PASSED
