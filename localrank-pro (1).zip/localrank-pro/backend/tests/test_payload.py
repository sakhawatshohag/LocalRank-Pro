import json
from decimal import Decimal

import pytest

from app.engine.geogrid import generate_grid
from app.engine.payload import MAX_STORED_LISTINGS, scan_result_to_payload, split_subject_key
from app.engine.scan_runner import execute_scan
from app.providers.base import SearchConfig, Subject
from app.providers.demo import DemoProvider

L, C = "11111111-1111-1111-1111-111111111111", "22222222-2222-2222-2222-222222222222"
ME, RIVAL = Subject(f"location:{L}", place_id="ChIJ_me"), Subject(f"competitor:{C}", cid="9")


def test_payload_is_json_serialisable_and_complete():
    pts = generate_grid(43.65, -79.38, 3, 500)
    res = execute_scan(DemoProvider([ME, RIVAL]), pts, SearchConfig("k"), [ME, RIVAL])
    p = json.loads(json.dumps(scan_result_to_payload(pts, res, "sig")))
    assert p["is_demo"] is True and p["grid_signature"] == "sig"
    assert [x["index"] for x in p["points"]] == list(range(9))
    assert len(p["rankings"]) == 18 and len(p["metrics"]) == 2
    assert {(m["subject_type"], m["subject_id"]) for m in p["metrics"]} == {("location", L), ("competitor", C)}
    assert "depth" not in p["metrics"][0]
    for r in p["rankings"]:
        assert (r["status"] == "ranked") == (r["position"] is not None)
    assert all(len(x["listings"]) <= MAX_STORED_LISTINGS for x in p["points"])


def test_payload_rejects_mismatched_grid_and_bad_keys():
    pts = generate_grid(43.65, -79.38, 3, 500)
    res = execute_scan(DemoProvider([ME]), pts[:4], SearchConfig("k"), [ME])
    with pytest.raises(ValueError):
        scan_result_to_payload(pts, res, "sig")
    for bad in ("x:1", "location:", "nocolon"):
        with pytest.raises(ValueError):
            split_subject_key(bad)
    assert split_subject_key(f"competitor:{C}") == ("competitor", C)
