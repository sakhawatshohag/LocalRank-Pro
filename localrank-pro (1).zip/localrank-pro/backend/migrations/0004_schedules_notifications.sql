-- Scheduled scans (dispatch support) and in-app notifications.
BEGIN;

-- ---------- schedules ----------
-- custom schedules are "every N days" (cron expressions are not supported)
ALTER TABLE scan_schedules DROP CONSTRAINT IF EXISTS scan_schedules_check;
ALTER TABLE scan_schedules DROP COLUMN custom_cron;
ALTER TABLE scan_schedules
    ADD COLUMN interval_days   int CHECK (interval_days BETWEEN 1 AND 90),
    ADD COLUMN anchor_date     date NOT NULL DEFAULT current_date,
    ADD COLUMN last_run_at     timestamptz,
    ADD COLUMN last_occurrence text,
    ADD COLUMN last_error      text,
    ADD COLUMN updated_at      timestamptz NOT NULL DEFAULT now(),
    ADD CONSTRAINT scan_schedules_custom_interval CHECK ((frequency = 'custom') = (interval_days IS NOT NULL)),
    ADD CONSTRAINT scan_schedules_one_per_campaign UNIQUE (campaign_id);
CREATE INDEX scan_schedules_due_idx ON scan_schedules (next_run_at) WHERE NOT is_paused;

-- The dispatcher has no tenant context.  These functions run with the owner's rights and return
-- only identifiers; all real work then happens inside a tenant transaction under RLS.
-- They must be owned by a role that bypasses RLS (the migration superuser).
CREATE FUNCTION due_schedules(p_limit int DEFAULT 100) RETURNS TABLE (schedule_id uuid, org_id uuid)
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public, pg_temp AS $$
    SELECT s.id, s.org_id FROM scan_schedules s JOIN campaigns c ON c.id = s.campaign_id
    WHERE NOT s.is_paused AND c.is_active AND s.next_run_at <= now()
    ORDER BY s.next_run_at
    LIMIT least(greatest(p_limit, 1), 1000)
$$;

-- queued scans that were never picked up (e.g. the broker was down when they were enqueued)
CREATE FUNCTION stale_queued_scans(p_minutes int DEFAULT 10) RETURNS TABLE (scan_id uuid, org_id uuid)
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public, pg_temp AS $$
    SELECT id, org_id FROM scans
    WHERE status = 'queued' AND created_at < now() - make_interval(mins => greatest(p_minutes, 1))
    ORDER BY created_at LIMIT 500
$$;

-- scans stuck in 'running' because a worker died: marked failed so they never stay open
CREATE FUNCTION fail_stuck_scans(p_minutes int DEFAULT 180) RETURNS TABLE (scan_id uuid, org_id uuid)
LANGUAGE sql VOLATILE SECURITY DEFINER SET search_path = public, pg_temp AS $$
    UPDATE scans SET status = 'failed', completed_at = now()
    WHERE status = 'running' AND started_at < now() - make_interval(mins => greatest(p_minutes, 30))
    RETURNING id, org_id
$$;

REVOKE ALL ON FUNCTION due_schedules(int), stale_queued_scans(int), fail_stuck_scans(int) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION due_schedules(int), stale_queued_scans(int), fail_stuck_scans(int) TO localrank_app;

-- Deleting a schedule sets scans.schedule_id to NULL (ON DELETE SET NULL).  Allow exactly that
-- change on finished scans; every other change stays forbidden.
CREATE OR REPLACE FUNCTION forbid_finished_scan_change() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
    IF TG_OP = 'DELETE' THEN
        IF current_setting('app.allow_purge', true) = 'on' THEN RETURN OLD; END IF;
        RAISE EXCEPTION 'scans are immutable history (DELETE not allowed)' USING ERRCODE = 'integrity_constraint_violation';
    END IF;
    IF OLD.status IN ('completed','partial','failed','cancelled') THEN
        IF NEW.schedule_id IS NULL AND OLD.schedule_id IS NOT NULL
           AND (to_jsonb(NEW) - 'schedule_id') = (to_jsonb(OLD) - 'schedule_id') THEN
            RETURN NEW;
        END IF;
        RAISE EXCEPTION 'scan % is finished and cannot be modified', OLD.id USING ERRCODE = 'integrity_constraint_violation';
    END IF;
    RETURN NEW;
END $$;

-- ---------- notifications ----------
CREATE TYPE notification_type AS ENUM
    ('scan_completed','scan_failed','ranking_improved','ranking_declined','competitor_change','usage_warning','schedule_problem');

CREATE TABLE notifications (
    id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    org_id       uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    user_id      uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    type         notification_type NOT NULL,
    title        text NOT NULL,
    body         text,
    link         text,
    data         jsonb,
    dedupe_key   text,
    -- email delivery is prepared, not implemented: 'pending' rows are what a mailer would send
    email_status text NOT NULL DEFAULT 'not_requested' CHECK (email_status IN ('not_requested','pending','sent','failed')),
    read_at      timestamptz,
    created_at   timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX notifications_dedupe_uq ON notifications (user_id, dedupe_key) WHERE dedupe_key IS NOT NULL;
CREATE INDEX notifications_user_idx ON notifications (org_id, user_id, created_at DESC);

CREATE TABLE notification_preferences (
    org_id  uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    type    notification_type NOT NULL,
    in_app  boolean NOT NULL DEFAULT true,
    email   boolean NOT NULL DEFAULT false,
    PRIMARY KEY (org_id, user_id, type)
);

DO $$
DECLARE t text;
BEGIN
    FOREACH t IN ARRAY ARRAY['notifications','notification_preferences'] LOOP
        EXECUTE format('ALTER TABLE %I ENABLE ROW LEVEL SECURITY', t);
        EXECUTE format('ALTER TABLE %I FORCE ROW LEVEL SECURITY', t);
        EXECUTE format($p$CREATE POLICY tenant_isolation ON %I
            USING      (org_id = NULLIF(current_setting('app.current_org', true), '')::uuid)
            WITH CHECK (org_id = NULLIF(current_setting('app.current_org', true), '')::uuid)$p$, t);
    END LOOP;
END $$;

GRANT SELECT, INSERT, UPDATE, DELETE ON notifications, notification_preferences TO localrank_app;

INSERT INTO schema_migrations (version) VALUES ('0004_schedules_notifications');
COMMIT;
