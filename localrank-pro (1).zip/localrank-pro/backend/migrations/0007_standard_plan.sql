-- A hidden plan for accounts the operator creates by hand (no online billing).
-- PLACEHOLDER LIMITS: adjust to what you sell, in Super Admin -> Plans or with SQL.
BEGIN;
INSERT INTO plans (code, name, description, limits, is_public, sort_order) VALUES
    ('standard', 'Standard', 'Account set up by the operator.',
     '{"locations":10,"keywords":100,"campaigns":20,"competitors":5,"max_grid_size":15,"monthly_scan_points":20000,"team_members":5,"white_label":true}',
     false, 10)
ON CONFLICT (code) DO NOTHING;
INSERT INTO schema_migrations (version) VALUES ('0007_standard_plan');
COMMIT;
