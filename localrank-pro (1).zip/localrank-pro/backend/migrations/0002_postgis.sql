-- Spatial columns and indexes (requires the PostGIS extension).
-- STATUS: not yet executed in a test environment (PostGIS was unavailable where 0001 was tested).
BEGIN;
CREATE EXTENSION IF NOT EXISTS postgis;

ALTER TABLE business_locations ADD COLUMN geog geography(Point, 4326)
    GENERATED ALWAYS AS (ST_SetSRID(ST_MakePoint(longitude, latitude), 4326)::geography) STORED;
CREATE INDEX business_locations_geog_gix ON business_locations USING gist (geog);

ALTER TABLE grid_points ADD COLUMN geog geography(Point, 4326)
    GENERATED ALWAYS AS (ST_SetSRID(ST_MakePoint(longitude, latitude), 4326)::geography) STORED;
CREATE INDEX grid_points_geog_gix ON grid_points USING gist (geog);

INSERT INTO schema_migrations (version) VALUES ('0002_postgis');
COMMIT;
