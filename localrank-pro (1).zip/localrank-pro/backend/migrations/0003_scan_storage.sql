-- Atomic, validated storage of a finished scan.
-- The application calls store_scan_result(scan_id, payload) once per scan, inside a tenant
-- transaction.  Everything (grid points, rankings, metrics, usage, final status) is written
-- together or not at all.  Runs with the caller's rights, so Row Level Security applies.

BEGIN;

CREATE FUNCTION store_scan_result(p_scan uuid, p jsonb) RETURNS scan_status
LANGUAGE plpgsql AS $$
DECLARE
    s         scans%ROWTYPE;
    v_loc     uuid;
    v_client  uuid;
    v_total   int;
    v_failed  int;
    v_status  scan_status;
    v_now     timestamptz := now();
BEGIN
    SELECT * INTO s FROM scans WHERE id = p_scan FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'scan % not found in this organization', p_scan;
    END IF;
    IF s.status NOT IN ('queued', 'running') THEN
        RAISE EXCEPTION 'scan % is already finished; results are stored once', p_scan
            USING ERRCODE = 'integrity_constraint_violation';
    END IF;
    IF (p ->> 'is_demo')::boolean IS DISTINCT FROM s.is_demo THEN
        RAISE EXCEPTION 'demo flag of results does not match the scan';
    END IF;
    IF (p ->> 'grid_signature') IS DISTINCT FROM s.grid_signature THEN
        RAISE EXCEPTION 'results were produced for a different grid than the scan';
    END IF;
    v_total := jsonb_array_length(p -> 'points');
    IF v_total <> s.points_total THEN
        RAISE EXCEPTION 'expected % grid points, got %', s.points_total, v_total;
    END IF;

    SELECT c.location_id, l.client_id INTO v_loc, v_client
    FROM campaigns c JOIN business_locations l ON l.id = c.location_id WHERE c.id = s.campaign_id;

    -- 1. grid points
    INSERT INTO grid_points (org_id, scan_id, point_index, row_no, col_no, latitude, longitude, status,
                             provider_task_id, check_url, cost_usd, error_code, error_message,
                             provider_meta, top_listings, fetched_at)
    SELECT s.org_id, s.id, x.index, x."row", x.col, x.lat, x.lng,
           CASE WHEN x.ok THEN 'ok' ELSE 'error' END::point_status,
           x.task_id, x.check_url, x.cost,
           CASE WHEN x.ok THEN NULL ELSE coalesce(x.error_code, 'unknown') END,
           CASE WHEN x.ok THEN NULL ELSE x.error_message END,
           x.meta, x.listings, v_now
    FROM jsonb_to_recordset(p -> 'points')
         AS x(index int, "row" int, col int, lat float8, lng float8, ok boolean, task_id text, check_url text,
              cost numeric, error_code text, error_message text, meta jsonb, listings jsonb);

    -- 2. rankings must agree with the point outcome: a failed point can only hold 'error' rows,
    --    a successful point can never hold 'error' rows.
    IF EXISTS (
        SELECT 1 FROM jsonb_to_recordset(p -> 'rankings') AS r(point_index int, status text)
        JOIN grid_points g ON g.scan_id = s.id AND g.point_index = r.point_index
        WHERE (g.status = 'error') <> (r.status = 'error')
    ) THEN
        RAISE EXCEPTION 'ranking rows contradict the outcome of their grid point'
            USING ERRCODE = 'integrity_constraint_violation';
    END IF;
    -- subjects must be this campaign's location or one of its competitors
    IF EXISTS (
        SELECT 1 FROM jsonb_to_recordset(p -> 'rankings') AS r(subject_type text, subject_id uuid)
        WHERE (r.subject_type = 'location' AND r.subject_id <> v_loc)
           OR (r.subject_type = 'competitor' AND NOT EXISTS
                 (SELECT 1 FROM competitors c WHERE c.id = r.subject_id AND c.campaign_id = s.campaign_id))
           OR r.subject_type NOT IN ('location', 'competitor')
    ) THEN
        RAISE EXCEPTION 'results reference a business that is not part of this campaign'
            USING ERRCODE = 'integrity_constraint_violation';
    END IF;

    INSERT INTO ranking_results (org_id, scan_id, grid_point_id, campaign_id, keyword_id, subject_type,
                                 location_id, competitor_id, result_status, position, depth_checked, scanned_at)
    SELECT s.org_id, s.id, g.id, s.campaign_id, s.keyword_id, r.subject_type::subject_type,
           CASE WHEN r.subject_type = 'location'   THEN r.subject_id END,
           CASE WHEN r.subject_type = 'competitor' THEN r.subject_id END,
           r.status::result_status, r."position", s.depth, v_now
    FROM jsonb_to_recordset(p -> 'rankings')
         AS r(subject_type text, subject_id uuid, point_index int, status text, "position" int)
    JOIN grid_points g ON g.scan_id = s.id AND g.point_index = r.point_index;

    -- 3. derived metrics (raw rows above stay the source of truth)
    INSERT INTO historical_metrics (org_id, scan_id, subject_type, location_id, competitor_id,
        total_points, valid_points, ranked_points, not_found_points, error_points,
        average_position, capped_average_position, median_position, best_position, worst_position,
        top3_count, top10_count, top20_count, top3_coverage, top10_coverage, top20_coverage, not_found_pct)
    SELECT s.org_id, s.id, m.subject_type::subject_type,
           CASE WHEN m.subject_type = 'location'   THEN m.subject_id END,
           CASE WHEN m.subject_type = 'competitor' THEN m.subject_id END,
           m.total_points, m.valid_points, m.ranked_points, m.not_found_points, m.error_points,
           m.average_position, m.capped_average_position, m.median_position, m.best_position, m.worst_position,
           m.top3_count, m.top10_count, m.top20_count, m.top3_coverage, m.top10_coverage, m.top20_coverage,
           m.not_found_pct
    FROM jsonb_to_recordset(p -> 'metrics')
         AS m(subject_type text, subject_id uuid, total_points int, valid_points int, ranked_points int,
              not_found_points int, error_points int, average_position numeric, capped_average_position numeric,
              median_position numeric, best_position int, worst_position int, top3_count int, top10_count int,
              top20_count int, top3_coverage numeric, top10_coverage numeric, top20_coverage numeric,
              not_found_pct numeric);

    -- 4. API usage: one row per provider request
    INSERT INTO api_usage (org_id, provider_code, scan_id, campaign_id, client_id, success, cost_usd, created_at)
    SELECT s.org_id, s.provider_code, s.id, s.campaign_id, v_client, g.status = 'ok', g.cost_usd, v_now
    FROM grid_points g WHERE g.scan_id = s.id;

    -- 5. final status
    SELECT count(*) FILTER (WHERE status = 'error') INTO v_failed FROM grid_points WHERE scan_id = s.id;
    v_status := CASE WHEN v_failed = 0 THEN 'completed' WHEN v_failed = v_total THEN 'failed' ELSE 'partial' END;
    UPDATE scans SET status = v_status, points_failed = v_failed, completed_at = v_now,
                     started_at = coalesce(started_at, v_now),
                     actual_cost_usd = (SELECT coalesce(sum(cost_usd), 0) FROM grid_points WHERE scan_id = s.id)
    WHERE id = s.id;
    RETURN v_status;
END $$;

GRANT EXECUTE ON FUNCTION store_scan_result(uuid, jsonb) TO localrank_app;
GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO localrank_app;
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO localrank_app;
REVOKE INSERT, UPDATE, DELETE ON plans, api_providers, api_pricing, schema_migrations FROM localrank_app;

-- placeholder trial limits for campaigns (commercial values are a business decision)
UPDATE plans SET limits = limits || '{"campaigns": 2}'::jsonb WHERE code = 'trial';

INSERT INTO schema_migrations (version) VALUES ('0003_scan_storage');
COMMIT;
