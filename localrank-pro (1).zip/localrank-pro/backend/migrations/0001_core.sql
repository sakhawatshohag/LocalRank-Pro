-- LocalRank Pro - core schema (identity, tenancy, locations, campaigns, scans, rankings)
-- PostgreSQL 14+.  Spatial columns/indexes are added in 0002_postgis.sql.
--
-- Tenancy: every tenant table carries org_id and has FORCE ROW LEVEL SECURITY.
-- The application connects as role "localrank_app" (not superuser, not table
-- owner) and runs, inside each transaction:
--     SELECT set_config('app.current_org', '<org uuid>', true);
-- Without it, tenant tables return zero rows and reject writes.

BEGIN;

-- ---------- enums ----------
CREATE TYPE member_role      AS ENUM ('owner','admin','manager','seo_specialist','client_viewer');
CREATE TYPE scan_status      AS ENUM ('queued','running','completed','partial','failed','cancelled');
CREATE TYPE point_status     AS ENUM ('pending','ok','error');
CREATE TYPE result_status    AS ENUM ('ranked','not_found','error');
CREATE TYPE subject_type     AS ENUM ('location','competitor');
CREATE TYPE schedule_freq    AS ENUM ('daily','every_2_days','weekly','biweekly','monthly','custom');
CREATE TYPE execution_mode   AS ENUM ('live','priority','standard');

-- ---------- identity (not tenant-scoped) ----------
CREATE TABLE users (
    id                uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    email             text NOT NULL,
    password_hash     text NOT NULL,
    full_name         text,
    email_verified_at timestamptz,
    is_super_admin    boolean NOT NULL DEFAULT false,
    is_active         boolean NOT NULL DEFAULT true,
    created_at        timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX users_email_uq ON users (lower(email));

CREATE TABLE plans (
    id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    code       text NOT NULL UNIQUE,
    name       text NOT NULL,
    -- single source of truth for limits, e.g.
    -- {"locations":3,"keywords":20,"competitors":5,"max_grid_size":7,"monthly_scan_points":2000,
    --  "retention_days":90,"team_members":1,"white_label":false}
    limits     jsonb NOT NULL DEFAULT '{}'::jsonb,
    is_active  boolean NOT NULL DEFAULT true,
    created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE organizations (
    id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    name       text NOT NULL,
    plan_id    uuid REFERENCES plans(id),
    trial_ends_at timestamptz,
    created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE organization_members (
    org_id     uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    user_id    uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    role       member_role NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (org_id, user_id)
);
CREATE INDEX organization_members_user_idx ON organization_members (user_id);

-- ---------- provider configuration (platform-level) ----------
CREATE TABLE api_providers (
    code       text PRIMARY KEY,           -- 'dataforseo', 'demo'
    name       text NOT NULL,
    is_enabled boolean NOT NULL DEFAULT true
);
-- Administrator-maintained price list.  Never hardcode prices in code.
CREATE TABLE api_pricing (
    provider_code   text NOT NULL REFERENCES api_providers(code),
    mode            execution_mode NOT NULL,
    unit_price_usd  numeric(12,6) NOT NULL CHECK (unit_price_usd >= 0),
    results_per_unit int NOT NULL DEFAULT 100,   -- billing unit = one SERP of N results
    source_url      text,
    verified_on     date,
    PRIMARY KEY (provider_code, mode)
);

-- ---------- tenant tables ----------
CREATE TABLE clients (
    id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    org_id      uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    name        text NOT NULL,
    contact_email text,
    notes       text,
    archived_at timestamptz,
    created_at  timestamptz NOT NULL DEFAULT now(),
    UNIQUE (org_id, id)
);
CREATE INDEX clients_org_idx ON clients (org_id);

CREATE TABLE business_locations (
    id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    org_id        uuid NOT NULL,
    client_id     uuid,
    name          text NOT NULL,
    gbp_url       text,
    place_id      text,
    cid           text,
    -- set only after the identifier was confirmed against a provider response
    identity_verified_at timestamptz,
    address       text,
    latitude      double precision NOT NULL CHECK (latitude BETWEEN -90 AND 90),
    longitude     double precision NOT NULL CHECK (longitude BETWEEN -180 AND 180),
    website       text,
    phone         text,
    primary_category text,
    additional_categories text[] NOT NULL DEFAULT '{}',
    country       text,
    state         text,
    city          text,
    postal_code   text,
    time_zone     text NOT NULL DEFAULT 'UTC',
    language_code text NOT NULL DEFAULT 'en',
    archived_at   timestamptz,
    created_at    timestamptz NOT NULL DEFAULT now(),
    UNIQUE (org_id, id),
    FOREIGN KEY (org_id) REFERENCES organizations(id) ON DELETE CASCADE,
    FOREIGN KEY (org_id, client_id) REFERENCES clients(org_id, id)   -- client must belong to the same org
);
CREATE INDEX business_locations_org_idx ON business_locations (org_id, client_id);

CREATE TABLE grid_configurations (
    id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    org_id     uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    name       text NOT NULL,
    grid_size  int NOT NULL CHECK (grid_size BETWEEN 1 AND 21 AND grid_size % 2 = 1),
    spacing_m  numeric(10,2) NOT NULL CHECK (spacing_m >= 50),
    center_lat double precision,          -- NULL = use the location's coordinates
    center_lng double precision,
    created_at timestamptz NOT NULL DEFAULT now(),
    UNIQUE (org_id, id)
);

CREATE TABLE campaigns (
    id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    org_id        uuid NOT NULL,
    location_id   uuid NOT NULL,
    name          text NOT NULL,
    grid_size     int NOT NULL CHECK (grid_size BETWEEN 1 AND 21 AND grid_size % 2 = 1),
    spacing_m     numeric(10,2) NOT NULL CHECK (spacing_m >= 50),
    center_lat    double precision NOT NULL,
    center_lng    double precision NOT NULL,
    language_code text NOT NULL DEFAULT 'en',
    se_domain     text,
    device        text NOT NULL DEFAULT 'desktop' CHECK (device IN ('desktop','mobile')),
    zoom          int NOT NULL DEFAULT 15 CHECK (zoom BETWEEN 3 AND 21),
    depth         int NOT NULL DEFAULT 100 CHECK (depth BETWEEN 1 AND 700),
    is_active     boolean NOT NULL DEFAULT true,
    created_at    timestamptz NOT NULL DEFAULT now(),
    UNIQUE (org_id, id),
    FOREIGN KEY (org_id) REFERENCES organizations(id) ON DELETE CASCADE,
    FOREIGN KEY (org_id, location_id) REFERENCES business_locations(org_id, id)
);
CREATE INDEX campaigns_org_location_idx ON campaigns (org_id, location_id);

CREATE TABLE keywords (
    id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    org_id      uuid NOT NULL,
    campaign_id uuid NOT NULL,
    keyword     text NOT NULL CHECK (length(keyword) BETWEEN 1 AND 700),
    is_paused   boolean NOT NULL DEFAULT false,
    created_at  timestamptz NOT NULL DEFAULT now(),
    UNIQUE (org_id, id),
    FOREIGN KEY (org_id, campaign_id) REFERENCES campaigns(org_id, id) ON DELETE CASCADE
);
CREATE UNIQUE INDEX keywords_campaign_kw_uq ON keywords (campaign_id, lower(keyword));

CREATE TABLE competitors (
    id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    org_id      uuid NOT NULL,
    campaign_id uuid NOT NULL,
    name        text NOT NULL,
    gbp_url     text,
    place_id    text,
    cid         text,
    identity_verified_at timestamptz,
    address     text,
    website     text,
    primary_category text,
    latitude    double precision,
    longitude   double precision,
    created_at  timestamptz NOT NULL DEFAULT now(),
    UNIQUE (org_id, id),
    FOREIGN KEY (org_id, campaign_id) REFERENCES campaigns(org_id, id) ON DELETE CASCADE,
    CHECK (place_id IS NOT NULL OR cid IS NOT NULL)   -- rankings are matched by identifier, never by name
);
CREATE INDEX competitors_campaign_idx ON competitors (campaign_id);

CREATE TABLE scan_schedules (
    id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    org_id        uuid NOT NULL,
    campaign_id   uuid NOT NULL,
    frequency     schedule_freq NOT NULL,
    custom_cron   text,
    local_time    time NOT NULL DEFAULT '06:00',   -- in the location's time zone
    is_paused     boolean NOT NULL DEFAULT false,
    next_run_at   timestamptz,
    created_at    timestamptz NOT NULL DEFAULT now(),
    FOREIGN KEY (org_id, campaign_id) REFERENCES campaigns(org_id, id) ON DELETE CASCADE,
    CHECK (frequency <> 'custom' OR custom_cron IS NOT NULL)
);

-- A scan = one keyword searched across one grid at one moment.
-- The grid and search configuration are SNAPSHOTTED so later campaign edits
-- never change what a historical scan means.
CREATE TABLE scans (
    id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    org_id         uuid NOT NULL,
    campaign_id    uuid NOT NULL,
    keyword_id     uuid NOT NULL,
    keyword_text   text NOT NULL,
    provider_code  text NOT NULL REFERENCES api_providers(code),
    execution_mode execution_mode NOT NULL DEFAULT 'live',
    is_demo        boolean NOT NULL DEFAULT false,
    status         scan_status NOT NULL DEFAULT 'queued',
    grid_size      int NOT NULL,
    spacing_m      numeric(10,2) NOT NULL,
    center_lat     double precision NOT NULL,
    center_lng     double precision NOT NULL,
    grid_signature text NOT NULL,          -- scans are comparable point-by-point only if equal
    search_config  jsonb NOT NULL,         -- language, se_domain, device, zoom, depth
    depth          int NOT NULL,
    schedule_id    uuid REFERENCES scan_schedules(id) ON DELETE SET NULL,
    -- one row per scheduled occurrence: "<schedule_id>:<keyword_id>:<occurrence date>"
    idempotency_key text,
    estimated_cost_usd numeric(12,6),
    actual_cost_usd    numeric(12,6),
    points_total   int NOT NULL,
    points_failed  int NOT NULL DEFAULT 0,
    created_at     timestamptz NOT NULL DEFAULT now(),
    started_at     timestamptz,
    completed_at   timestamptz,
    UNIQUE (org_id, id),
    UNIQUE (org_id, idempotency_key),
    FOREIGN KEY (org_id, campaign_id) REFERENCES campaigns(org_id, id),
    FOREIGN KEY (org_id, keyword_id)  REFERENCES keywords(org_id, id)
);
CREATE INDEX scans_history_idx ON scans (org_id, campaign_id, keyword_id, completed_at DESC);

CREATE TABLE grid_points (
    id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    org_id        uuid NOT NULL,
    scan_id       uuid NOT NULL,
    point_index   int NOT NULL,
    row_no        int NOT NULL,
    col_no        int NOT NULL,
    latitude      double precision NOT NULL,
    longitude     double precision NOT NULL,
    status        point_status NOT NULL DEFAULT 'pending',
    provider_task_id text,
    check_url     text,
    cost_usd      numeric(12,6),
    error_code    text,
    error_message text,
    provider_meta jsonb,                  -- original provider metadata for troubleshooting
    top_listings  jsonb,                  -- normalised listings returned at this point
    fetched_at    timestamptz,
    UNIQUE (scan_id, point_index),
    UNIQUE (scan_id, latitude, longitude),
    UNIQUE (org_id, id),
    FOREIGN KEY (org_id, scan_id) REFERENCES scans(org_id, id) ON DELETE CASCADE,
    CHECK ((status = 'error') = (error_code IS NOT NULL))
);

CREATE TABLE ranking_results (
    id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    org_id        uuid NOT NULL,
    scan_id       uuid NOT NULL,
    grid_point_id uuid NOT NULL,
    campaign_id   uuid NOT NULL,
    keyword_id    uuid NOT NULL,
    subject_type  subject_type NOT NULL,
    location_id   uuid,
    competitor_id uuid,
    result_status result_status NOT NULL,
    position      int,
    depth_checked int NOT NULL,           -- "not_found" means "not in the first depth_checked results"
    scanned_at    timestamptz NOT NULL,
    FOREIGN KEY (org_id, scan_id)       REFERENCES scans(org_id, id) ON DELETE CASCADE,
    FOREIGN KEY (org_id, grid_point_id) REFERENCES grid_points(org_id, id) ON DELETE CASCADE,
    FOREIGN KEY (org_id, location_id)   REFERENCES business_locations(org_id, id),
    FOREIGN KEY (org_id, competitor_id) REFERENCES competitors(org_id, id),
    -- a position exists if and only if the business was actually ranked; never 0
    CHECK ((result_status = 'ranked') = (position IS NOT NULL)),
    CHECK (position IS NULL OR position >= 1),
    CHECK ((subject_type = 'location'   AND location_id   IS NOT NULL AND competitor_id IS NULL) OR
           (subject_type = 'competitor' AND competitor_id IS NOT NULL AND location_id   IS NULL))
);
CREATE UNIQUE INDEX ranking_results_loc_uq  ON ranking_results (grid_point_id, location_id)   WHERE location_id   IS NOT NULL;
CREATE UNIQUE INDEX ranking_results_comp_uq ON ranking_results (grid_point_id, competitor_id) WHERE competitor_id IS NOT NULL;
CREATE INDEX ranking_results_scan_idx ON ranking_results (scan_id, subject_type);

-- Derived metrics per (scan, subject); raw rows above remain the source of truth.
CREATE TABLE historical_metrics (
    id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    org_id        uuid NOT NULL,
    scan_id       uuid NOT NULL,
    subject_type  subject_type NOT NULL,
    location_id   uuid,
    competitor_id uuid,
    total_points int NOT NULL, valid_points int NOT NULL, ranked_points int NOT NULL,
    not_found_points int NOT NULL, error_points int NOT NULL,
    average_position numeric(7,2), capped_average_position numeric(7,2), median_position numeric(7,2),
    best_position int, worst_position int,
    top3_count int NOT NULL, top10_count int NOT NULL, top20_count int NOT NULL,
    top3_coverage numeric(5,2), top10_coverage numeric(5,2), top20_coverage numeric(5,2),
    not_found_pct numeric(5,2),
    computed_at  timestamptz NOT NULL DEFAULT now(),
    FOREIGN KEY (org_id, scan_id) REFERENCES scans(org_id, id) ON DELETE CASCADE
);
CREATE UNIQUE INDEX historical_metrics_loc_uq  ON historical_metrics (scan_id, location_id)   WHERE location_id   IS NOT NULL;
CREATE UNIQUE INDEX historical_metrics_comp_uq ON historical_metrics (scan_id, competitor_id) WHERE competitor_id IS NOT NULL;

CREATE TABLE api_usage (
    id            bigserial PRIMARY KEY,
    org_id        uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    provider_code text NOT NULL REFERENCES api_providers(code),
    scan_id       uuid,
    campaign_id   uuid,
    client_id     uuid,
    success       boolean NOT NULL,
    cost_usd      numeric(12,6),
    created_at    timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX api_usage_org_time_idx ON api_usage (org_id, created_at);

CREATE TABLE audit_logs (
    id         bigserial PRIMARY KEY,
    org_id     uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    user_id    uuid,
    action     text NOT NULL,
    entity     text,
    entity_id  uuid,
    detail     jsonb,
    created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX audit_logs_org_time_idx ON audit_logs (org_id, created_at);

-- ---------- immutability of historical data ----------
-- Ranking rows can never be updated.  Deleting is possible only inside a
-- transaction that sets app.allow_purge = 'on' (retention job / org deletion).
CREATE FUNCTION forbid_history_change() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
    IF TG_OP = 'DELETE' AND current_setting('app.allow_purge', true) = 'on' THEN
        RETURN OLD;
    END IF;
    RAISE EXCEPTION 'historical % rows are immutable (% not allowed)', TG_TABLE_NAME, TG_OP
        USING ERRCODE = 'integrity_constraint_violation';
END $$;

CREATE TRIGGER ranking_results_immutable BEFORE UPDATE OR DELETE ON ranking_results
    FOR EACH ROW EXECUTE FUNCTION forbid_history_change();
CREATE TRIGGER historical_metrics_immutable BEFORE UPDATE OR DELETE ON historical_metrics
    FOR EACH ROW EXECUTE FUNCTION forbid_history_change();

-- A scan that reached a final state can no longer be modified.
CREATE FUNCTION forbid_finished_scan_change() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
    IF TG_OP = 'DELETE' THEN
        IF current_setting('app.allow_purge', true) = 'on' THEN RETURN OLD; END IF;
        RAISE EXCEPTION 'scans are immutable history (DELETE not allowed)' USING ERRCODE = 'integrity_constraint_violation';
    END IF;
    IF OLD.status IN ('completed','partial','failed','cancelled') THEN
        RAISE EXCEPTION 'scan % is finished and cannot be modified', OLD.id USING ERRCODE = 'integrity_constraint_violation';
    END IF;
    RETURN NEW;
END $$;
CREATE TRIGGER scans_immutable BEFORE UPDATE OR DELETE ON scans
    FOR EACH ROW EXECUTE FUNCTION forbid_finished_scan_change();

-- ---------- row level security ----------
DO $$
DECLARE t text;
BEGIN
    FOREACH t IN ARRAY ARRAY['clients','business_locations','grid_configurations','campaigns','keywords',
                             'competitors','scan_schedules','scans','grid_points','ranking_results',
                             'historical_metrics','api_usage','audit_logs']
    LOOP
        EXECUTE format('ALTER TABLE %I ENABLE ROW LEVEL SECURITY', t);
        EXECUTE format('ALTER TABLE %I FORCE ROW LEVEL SECURITY', t);
        EXECUTE format($p$CREATE POLICY tenant_isolation ON %I
            USING      (org_id = NULLIF(current_setting('app.current_org', true), '')::uuid)
            WITH CHECK (org_id = NULLIF(current_setting('app.current_org', true), '')::uuid)$p$, t);
    END LOOP;
END $$;

-- ---------- application role ----------
DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'localrank_app') THEN
        CREATE ROLE localrank_app LOGIN;      -- password is set by deployment, not here
    END IF;
END $$;
GRANT USAGE ON SCHEMA public TO localrank_app;
GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO localrank_app;
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO localrank_app;
REVOKE INSERT, UPDATE, DELETE ON plans, api_providers, api_pricing FROM localrank_app;  -- super-admin path only

-- ---------- reference data ----------
INSERT INTO api_providers (code, name) VALUES ('dataforseo', 'DataForSEO Google Maps SERP API'), ('demo', 'Demo Mode (synthetic data)');
-- Prices as published at source_url on verified_on.  Editable by the platform administrator.
INSERT INTO api_pricing (provider_code, mode, unit_price_usd, results_per_unit, source_url, verified_on) VALUES
    ('dataforseo','standard',0.0006,100,'https://dataforseo.com/pricing/serp/google-maps-serp-api','2026-11-17'),
    ('dataforseo','priority',0.0012,100,'https://dataforseo.com/pricing/serp/google-maps-serp-api','2026-11-17'),
    ('dataforseo','live',    0.0020,100,'https://dataforseo.com/pricing/serp/google-maps-serp-api','2026-11-17'),
    ('demo','live',0,100,NULL,NULL);
-- Placeholder limits: commercial plan values are a business decision, edit before launch.
INSERT INTO plans (code, name, limits) VALUES
    ('trial','Free Trial','{"locations":1,"keywords":5,"competitors":3,"max_grid_size":7,"monthly_scan_points":500,"retention_days":30,"team_members":1,"white_label":false}');

CREATE TABLE schema_migrations (version text PRIMARY KEY, applied_at timestamptz NOT NULL DEFAULT now());
INSERT INTO schema_migrations (version) VALUES ('0001_core');

COMMIT;
