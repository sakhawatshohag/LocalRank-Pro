-- Billing (Stripe), plan catalogue, team invitations, Super Admin functions, maintenance mode.
BEGIN;

-- ---------- plans: catalogue fields (prices are data, edited by the Super Admin) ----------
ALTER TABLE plans
    ADD COLUMN description         text,
    ADD COLUMN monthly_price_cents int CHECK (monthly_price_cents >= 0),
    ADD COLUMN currency            text NOT NULL DEFAULT 'usd' CHECK (currency ~ '^[a-z]{3}$'),
    ADD COLUMN stripe_price_id     text UNIQUE,
    ADD COLUMN is_public           boolean NOT NULL DEFAULT false,
    ADD COLUMN sort_order          int NOT NULL DEFAULT 100;

-- Plan with no allowance: used when a trial ends or a subscription is cancelled.  Existing data
-- stays readable; nothing new can be added and no scans run.
INSERT INTO plans (code, name, description, limits, is_public, sort_order) VALUES
    ('inactive', 'No active plan', 'Trial ended or subscription cancelled. Data is kept and can be viewed.',
     '{"locations":0,"keywords":0,"campaigns":0,"competitors":0,"max_grid_size":0,"monthly_scan_points":0,"team_members":1,"white_label":false}', false, 999)
ON CONFLICT (code) DO NOTHING;
UPDATE plans SET limits = limits || '{"campaigns": 2, "team_members": 1}'::jsonb
WHERE code = 'trial' AND NOT (limits ? 'team_members');
-- Commercial plans are created by the Super Admin (name, limits, price, Stripe price ID).

ALTER TABLE users ADD COLUMN last_login_at timestamptz;
ALTER TYPE notification_type ADD VALUE IF NOT EXISTS 'billing_problem';

-- ---------- subscriptions and invoices ----------
CREATE TABLE subscriptions (
    org_id               uuid PRIMARY KEY REFERENCES organizations(id) ON DELETE CASCADE,
    provider             text NOT NULL DEFAULT 'stripe',
    customer_id          text NOT NULL,
    subscription_id      text,
    status               text NOT NULL,                 -- provider status: trialing, active, past_due, canceled, unpaid, incomplete ...
    plan_id              uuid REFERENCES plans(id),
    price_id             text,
    current_period_end   timestamptz,
    cancel_at_period_end boolean NOT NULL DEFAULT false,
    last_event_at        timestamptz,                   -- creation time of the newest provider event applied (older events are ignored)
    updated_at           timestamptz NOT NULL DEFAULT now(),
    UNIQUE (provider, customer_id)
);

CREATE TABLE invoices (
    id                  uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    org_id              uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    provider            text NOT NULL DEFAULT 'stripe',
    provider_invoice_id text NOT NULL,
    number              text,
    status              text,
    amount_due_cents    int,
    amount_paid_cents   int,
    currency            text,
    hosted_invoice_url  text,
    invoice_pdf_url     text,
    period_start        timestamptz,
    period_end          timestamptz,
    created_at          timestamptz NOT NULL DEFAULT now(),
    UNIQUE (provider, provider_invoice_id)
);
CREATE INDEX invoices_org_idx ON invoices (org_id, created_at DESC);

-- every processed provider event, so a re-delivered webhook is applied only once
CREATE TABLE billing_events (
    provider     text NOT NULL,
    event_id     text NOT NULL,
    type         text NOT NULL,
    org_id       uuid,
    received_at  timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (provider, event_id)
);

-- ---------- team invitations ----------
CREATE TABLE invitations (
    id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    org_id      uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    email       text NOT NULL,
    role        member_role NOT NULL CHECK (role <> 'owner'),
    token_hash  text NOT NULL UNIQUE,                   -- sha256 of the token; the token itself is never stored
    invited_by  uuid REFERENCES users(id) ON DELETE SET NULL,
    expires_at  timestamptz NOT NULL,
    accepted_at timestamptz,
    created_at  timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX invitations_pending_uq ON invitations (org_id, lower(email)) WHERE accepted_at IS NULL;

DO $$
DECLARE t text;
BEGIN
    FOREACH t IN ARRAY ARRAY['subscriptions','invoices','invitations'] LOOP
        EXECUTE format('ALTER TABLE %I ENABLE ROW LEVEL SECURITY', t);
        EXECUTE format('ALTER TABLE %I FORCE ROW LEVEL SECURITY', t);
        EXECUTE format($p$CREATE POLICY tenant_isolation ON %I
            USING      (org_id = NULLIF(current_setting('app.current_org', true), '')::uuid)
            WITH CHECK (org_id = NULLIF(current_setting('app.current_org', true), '')::uuid)$p$, t);
    END LOOP;
END $$;

-- ---------- platform settings and admin audit ----------
CREATE TABLE system_settings (
    key        text PRIMARY KEY,
    value      jsonb NOT NULL,
    updated_at timestamptz NOT NULL DEFAULT now()
);
INSERT INTO system_settings (key, value) VALUES ('maintenance', '{"enabled": false, "message": null}');

CREATE TABLE admin_audit (
    id         bigserial PRIMARY KEY,
    admin_id   uuid NOT NULL REFERENCES users(id),
    action     text NOT NULL,
    target     text,
    detail     jsonb,
    created_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON subscriptions, invoices, invitations TO localrank_app;
GRANT SELECT, INSERT ON billing_events TO localrank_app;
GRANT SELECT ON system_settings, admin_audit TO localrank_app;
GRANT USAGE, SELECT ON SEQUENCE admin_audit_id_seq TO localrank_app;

-- ---------- functions that need to see across organizations ----------
-- They return identifiers or aggregates only.  Admin functions re-check is_super_admin in the
-- database, so a bug in the API cannot turn an ordinary user into an administrator.

CREATE FUNCTION org_for_billing_customer(p_provider text, p_customer text) RETURNS uuid
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public, pg_temp AS $$
    SELECT org_id FROM subscriptions WHERE provider = p_provider AND customer_id = p_customer
$$;

CREATE FUNCTION invitation_by_token(p_hash text) RETURNS TABLE (id uuid, org_id uuid, email text, role member_role,
                                                                 expires_at timestamptz, accepted_at timestamptz, org_name text)
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public, pg_temp AS $$
    SELECT i.id, i.org_id, i.email, i.role, i.expires_at, i.accepted_at, o.name
    FROM invitations i JOIN organizations o ON o.id = i.org_id WHERE i.token_hash = p_hash
$$;

-- trials that ended without an active subscription move to the 'inactive' plan
CREATE FUNCTION expire_trials() RETURNS SETOF uuid
LANGUAGE sql VOLATILE SECURITY DEFINER SET search_path = public, pg_temp AS $$
    UPDATE organizations o SET plan_id = (SELECT id FROM plans WHERE code = 'inactive')
    WHERE o.trial_ends_at < now()
      AND o.plan_id = (SELECT id FROM plans WHERE code = 'trial')
      AND NOT EXISTS (SELECT 1 FROM subscriptions s WHERE s.org_id = o.id AND s.status IN ('active','trialing','past_due'))
    RETURNING o.id
$$;

CREATE FUNCTION assert_super_admin(p_user uuid) RETURNS void
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = public, pg_temp AS $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM users WHERE id = p_user AND is_super_admin AND is_active) THEN
        RAISE EXCEPTION 'super admin privileges required' USING ERRCODE = 'insufficient_privilege';
    END IF;
END $$;

CREATE FUNCTION admin_overview(p_user uuid) RETURNS jsonb
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = public, pg_temp AS $$
BEGIN
    PERFORM assert_super_admin(p_user);
    RETURN jsonb_build_object(
        'organizations', (SELECT count(*) FROM organizations),
        'users', (SELECT count(*) FROM users WHERE is_active),
        'active_users_30d', (SELECT count(*) FROM users WHERE last_login_at > now() - interval '30 days'),
        'subscriptions_by_status', (SELECT coalesce(jsonb_object_agg(status, n), '{}') FROM (SELECT status, count(*) n FROM subscriptions GROUP BY status) x),
        'orgs_by_plan', (SELECT coalesce(jsonb_object_agg(code, n), '{}') FROM (SELECT p.code, count(*) n FROM organizations o JOIN plans p ON p.id = o.plan_id GROUP BY p.code) x),
        -- monthly recurring revenue from the plan catalogue prices of active subscriptions (not from payments)
        'mrr_cents_by_currency', (SELECT coalesce(jsonb_object_agg(currency, cents), '{}') FROM (
            SELECT p.currency, sum(p.monthly_price_cents) cents FROM subscriptions s JOIN plans p ON p.id = s.plan_id
            WHERE s.status IN ('active','past_due') AND p.monthly_price_cents IS NOT NULL GROUP BY p.currency) x),
        'paid_last_30d_cents_by_currency', (SELECT coalesce(jsonb_object_agg(currency, cents), '{}') FROM (
            SELECT currency, sum(amount_paid_cents) cents FROM invoices WHERE status = 'paid' AND created_at > now() - interval '30 days'
            GROUP BY currency) x),
        'scans_30d_by_status', (SELECT coalesce(jsonb_object_agg(status, n), '{}') FROM (SELECT status::text, count(*) n FROM scans WHERE created_at > now() - interval '30 days' GROUP BY status) x),
        'scans_queued', (SELECT count(*) FROM scans WHERE status = 'queued'),
        'scans_running', (SELECT count(*) FROM scans WHERE status = 'running'),
        'failed_scans_24h', (SELECT count(*) FROM scans WHERE status = 'failed' AND created_at > now() - interval '24 hours'),
        'api_requests_30d', (SELECT count(*) FROM api_usage WHERE created_at > now() - interval '30 days'),
        'api_failed_30d', (SELECT count(*) FROM api_usage WHERE NOT success AND created_at > now() - interval '30 days'),
        'api_cost_30d_usd', (SELECT coalesce(sum(cost_usd), 0) FROM api_usage WHERE created_at > now() - interval '30 days'),
        'provider_health_24h', (SELECT coalesce(jsonb_object_agg(provider_code, jsonb_build_object('requests', n, 'failed', f)), '{}') FROM (
            SELECT provider_code, count(*) n, count(*) FILTER (WHERE NOT success) f FROM api_usage
            WHERE created_at > now() - interval '24 hours' GROUP BY provider_code) x),
        'reports_failed_7d', (SELECT count(*) FROM reports WHERE status = 'failed' AND created_at > now() - interval '7 days'),
        'reports_queued', (SELECT count(*) FROM reports WHERE status IN ('queued','generating'))
    );
END $$;

CREATE FUNCTION admin_organizations(p_user uuid, p_search text DEFAULT NULL)
RETURNS TABLE (id uuid, name text, created_at timestamptz, plan_code text, plan_name text, trial_ends_at timestamptz,
               subscription_status text, members bigint, locations bigint, campaigns bigint, scans_30d bigint, api_cost_30d_usd numeric)
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = public, pg_temp AS $$
BEGIN
    PERFORM assert_super_admin(p_user);
    RETURN QUERY
    SELECT o.id, o.name, o.created_at, p.code, p.name, o.trial_ends_at, s.status,
           (SELECT count(*) FROM organization_members m WHERE m.org_id = o.id),
           (SELECT count(*) FROM business_locations l WHERE l.org_id = o.id AND l.archived_at IS NULL),
           (SELECT count(*) FROM campaigns c WHERE c.org_id = o.id),
           (SELECT count(*) FROM scans x WHERE x.org_id = o.id AND x.created_at > now() - interval '30 days'),
           (SELECT coalesce(sum(u.cost_usd), 0) FROM api_usage u WHERE u.org_id = o.id AND u.created_at > now() - interval '30 days')
    FROM organizations o LEFT JOIN plans p ON p.id = o.plan_id LEFT JOIN subscriptions s ON s.org_id = o.id
    WHERE p_search IS NULL OR o.name ILIKE '%' || p_search || '%'
    ORDER BY o.created_at DESC LIMIT 500;
END $$;

CREATE FUNCTION admin_set_org_plan(p_user uuid, p_org uuid, p_plan_code text, p_trial_ends_at timestamptz DEFAULT NULL) RETURNS void
LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path = public, pg_temp AS $$
DECLARE v_plan uuid;
BEGIN
    PERFORM assert_super_admin(p_user);
    SELECT id INTO v_plan FROM plans WHERE code = p_plan_code;
    IF v_plan IS NULL THEN RAISE EXCEPTION 'unknown plan %', p_plan_code; END IF;
    UPDATE organizations SET plan_id = v_plan, trial_ends_at = coalesce(p_trial_ends_at, trial_ends_at) WHERE id = p_org;
    IF NOT FOUND THEN RAISE EXCEPTION 'organization not found'; END IF;
    INSERT INTO admin_audit (admin_id, action, target, detail)
    VALUES (p_user, 'set_org_plan', p_org::text, jsonb_build_object('plan', p_plan_code, 'trial_ends_at', p_trial_ends_at));
END $$;

CREATE FUNCTION admin_upsert_plan(p_user uuid, p_code text, p_name text, p_limits jsonb, p_description text,
                                  p_price_cents int, p_currency text, p_stripe_price_id text, p_is_public boolean,
                                  p_sort int, p_active boolean) RETURNS uuid
LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path = public, pg_temp AS $$
DECLARE v_id uuid;
BEGIN
    PERFORM assert_super_admin(p_user);
    IF p_code IN ('inactive') AND p_is_public THEN RAISE EXCEPTION 'the inactive plan cannot be public'; END IF;
    INSERT INTO plans (code, name, limits, description, monthly_price_cents, currency, stripe_price_id, is_public, sort_order, is_active)
    VALUES (p_code, p_name, p_limits, p_description, p_price_cents, coalesce(p_currency, 'usd'), p_stripe_price_id, p_is_public, p_sort, p_active)
    ON CONFLICT (code) DO UPDATE SET name = EXCLUDED.name, limits = EXCLUDED.limits, description = EXCLUDED.description,
        monthly_price_cents = EXCLUDED.monthly_price_cents, currency = EXCLUDED.currency, stripe_price_id = EXCLUDED.stripe_price_id,
        is_public = EXCLUDED.is_public, sort_order = EXCLUDED.sort_order, is_active = EXCLUDED.is_active
    RETURNING id INTO v_id;
    INSERT INTO admin_audit (admin_id, action, target, detail)
    VALUES (p_user, 'upsert_plan', p_code, jsonb_build_object('limits', p_limits, 'price_cents', p_price_cents,
            'stripe_price_id', p_stripe_price_id, 'public', p_is_public, 'active', p_active));
    RETURN v_id;
END $$;

CREATE FUNCTION admin_set_api_price(p_user uuid, p_provider text, p_mode execution_mode, p_price numeric,
                                    p_results_per_unit int, p_source_url text) RETURNS void
LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path = public, pg_temp AS $$
BEGIN
    PERFORM assert_super_admin(p_user);
    INSERT INTO api_pricing (provider_code, mode, unit_price_usd, results_per_unit, source_url, verified_on)
    VALUES (p_provider, p_mode, p_price, p_results_per_unit, p_source_url, current_date)
    ON CONFLICT (provider_code, mode) DO UPDATE SET unit_price_usd = EXCLUDED.unit_price_usd,
        results_per_unit = EXCLUDED.results_per_unit, source_url = EXCLUDED.source_url, verified_on = current_date;
    INSERT INTO admin_audit (admin_id, action, target, detail)
    VALUES (p_user, 'set_api_price', p_provider || ':' || p_mode, jsonb_build_object('price', p_price, 'source', p_source_url));
END $$;

CREATE FUNCTION admin_set_provider_enabled(p_user uuid, p_provider text, p_enabled boolean) RETURNS void
LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path = public, pg_temp AS $$
BEGIN
    PERFORM assert_super_admin(p_user);
    UPDATE api_providers SET is_enabled = p_enabled WHERE code = p_provider;
    IF NOT FOUND THEN RAISE EXCEPTION 'unknown provider'; END IF;
    INSERT INTO admin_audit (admin_id, action, target, detail) VALUES (p_user, 'set_provider_enabled', p_provider, jsonb_build_object('enabled', p_enabled));
END $$;

CREATE FUNCTION admin_set_user_active(p_user uuid, p_target uuid, p_active boolean) RETURNS void
LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path = public, pg_temp AS $$
BEGIN
    PERFORM assert_super_admin(p_user);
    IF p_user = p_target THEN RAISE EXCEPTION 'you cannot deactivate your own account'; END IF;
    UPDATE users SET is_active = p_active WHERE id = p_target;
    IF NOT FOUND THEN RAISE EXCEPTION 'user not found'; END IF;
    INSERT INTO admin_audit (admin_id, action, target, detail) VALUES (p_user, 'set_user_active', p_target::text, jsonb_build_object('active', p_active));
END $$;

CREATE FUNCTION admin_users(p_user uuid, p_search text DEFAULT NULL)
RETURNS TABLE (id uuid, email text, full_name text, is_active boolean, is_super_admin boolean, created_at timestamptz,
               last_login_at timestamptz, organizations text)
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = public, pg_temp AS $$
BEGIN
    PERFORM assert_super_admin(p_user);
    RETURN QUERY
    SELECT u.id, u.email, u.full_name, u.is_active, u.is_super_admin, u.created_at, u.last_login_at,
           (SELECT string_agg(o.name || ' (' || m.role || ')', ', ') FROM organization_members m JOIN organizations o ON o.id = m.org_id WHERE m.user_id = u.id)
    FROM users u WHERE p_search IS NULL OR u.email ILIKE '%' || p_search || '%' OR u.full_name ILIKE '%' || p_search || '%'
    ORDER BY u.created_at DESC LIMIT 500;
END $$;

CREATE FUNCTION admin_set_setting(p_user uuid, p_key text, p_value jsonb) RETURNS void
LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path = public, pg_temp AS $$
BEGIN
    PERFORM assert_super_admin(p_user);
    INSERT INTO system_settings (key, value, updated_at) VALUES (p_key, p_value, now())
    ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value, updated_at = now();
    INSERT INTO admin_audit (admin_id, action, target, detail) VALUES (p_user, 'set_setting', p_key, p_value);
END $$;

DO $$
DECLARE f text;
BEGIN
    FOREACH f IN ARRAY ARRAY['org_for_billing_customer(text,text)', 'invitation_by_token(text)', 'expire_trials()',
        'assert_super_admin(uuid)', 'admin_overview(uuid)', 'admin_organizations(uuid,text)',
        'admin_set_org_plan(uuid,uuid,text,timestamptz)',
        'admin_upsert_plan(uuid,text,text,jsonb,text,int,text,text,boolean,int,boolean)',
        'admin_set_api_price(uuid,text,execution_mode,numeric,int,text)', 'admin_set_provider_enabled(uuid,text,boolean)',
        'admin_set_user_active(uuid,uuid,boolean)', 'admin_users(uuid,text)', 'admin_set_setting(uuid,text,jsonb)'] LOOP
        EXECUTE format('REVOKE ALL ON FUNCTION %s FROM PUBLIC', f);
        EXECUTE format('GRANT EXECUTE ON FUNCTION %s TO localrank_app', f);
    END LOOP;
END $$;

INSERT INTO schema_migrations (version) VALUES ('0006_billing_admin_team');
COMMIT;
