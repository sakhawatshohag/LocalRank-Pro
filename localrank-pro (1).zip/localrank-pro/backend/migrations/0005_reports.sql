-- White-label reports: branding, generated reports (PDF + CSV kept for download), report schedules.
BEGIN;

CREATE TABLE report_branding (
    org_id        uuid PRIMARY KEY REFERENCES organizations(id) ON DELETE CASCADE,
    agency_name   text,
    website       text,
    email         text,
    phone         text,
    primary_color text NOT NULL DEFAULT '#0b1f3a' CHECK (primary_color ~ '^#[0-9a-fA-F]{6}$'),
    footer_text   text,
    logo_png      bytea,            -- re-encoded PNG, validated and size-limited by the API
    updated_at    timestamptz NOT NULL DEFAULT now(),
    CHECK (logo_png IS NULL OR octet_length(logo_png) <= 2 * 1024 * 1024)
);

ALTER TABLE clients ADD COLUMN logo_png bytea CHECK (logo_png IS NULL OR octet_length(logo_png) <= 2 * 1024 * 1024);

CREATE TYPE report_type   AS ENUM ('weekly','monthly','geogrid_comparison','competitor_comparison','performance','custom');
CREATE TYPE report_status AS ENUM ('queued','generating','ready','failed');

CREATE TABLE report_schedules (
    id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    org_id       uuid NOT NULL,
    client_id    uuid NOT NULL,
    report_type  report_type NOT NULL CHECK (report_type IN ('weekly','monthly')),
    title        text,
    campaign_ids uuid[],                       -- NULL = all campaigns of the client
    time_zone    text NOT NULL DEFAULT 'UTC',
    local_time   time NOT NULL DEFAULT '07:00',
    anchor_date  date NOT NULL DEFAULT current_date,
    is_paused    boolean NOT NULL DEFAULT false,
    next_run_at  timestamptz NOT NULL,
    last_run_at  timestamptz,
    last_error   text,
    created_at   timestamptz NOT NULL DEFAULT now(),
    UNIQUE (org_id, id),
    UNIQUE (client_id, report_type),
    FOREIGN KEY (org_id, client_id) REFERENCES clients(org_id, id) ON DELETE CASCADE
);

CREATE TABLE reports (
    id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    org_id        uuid NOT NULL,
    client_id     uuid NOT NULL,
    report_type   report_type NOT NULL,
    title         text NOT NULL,
    period_start  date NOT NULL,
    period_end    date NOT NULL,
    options       jsonb NOT NULL DEFAULT '{}'::jsonb,   -- campaign_ids, scan ids, sections, recommendations
    status        report_status NOT NULL DEFAULT 'queued',
    is_demo       boolean,                              -- set on generation: true if any scan used is demo data
    pdf           bytea,
    csv           text,
    page_count    int,
    error         text,
    schedule_id   uuid REFERENCES report_schedules(id) ON DELETE SET NULL,
    idempotency_key text,
    created_by    uuid REFERENCES users(id) ON DELETE SET NULL,
    created_at    timestamptz NOT NULL DEFAULT now(),
    generated_at  timestamptz,
    UNIQUE (org_id, id),
    UNIQUE (org_id, idempotency_key),
    FOREIGN KEY (org_id, client_id) REFERENCES clients(org_id, id) ON DELETE CASCADE,
    CHECK (period_end >= period_start),
    CHECK (status <> 'ready' OR pdf IS NOT NULL)
);
CREATE INDEX reports_client_idx ON reports (org_id, client_id, created_at DESC);

CREATE FUNCTION due_report_schedules(p_limit int DEFAULT 100) RETURNS TABLE (schedule_id uuid, org_id uuid)
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public, pg_temp AS $$
    SELECT id, org_id FROM report_schedules WHERE NOT is_paused AND next_run_at <= now()
    ORDER BY next_run_at LIMIT least(greatest(p_limit, 1), 1000)
$$;
CREATE FUNCTION stale_queued_reports(p_minutes int DEFAULT 10) RETURNS TABLE (report_id uuid, org_id uuid)
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public, pg_temp AS $$
    SELECT id, org_id FROM reports
    WHERE status = 'queued' AND created_at < now() - make_interval(mins => greatest(p_minutes, 1)) LIMIT 200
$$;
REVOKE ALL ON FUNCTION due_report_schedules(int), stale_queued_reports(int) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION due_report_schedules(int), stale_queued_reports(int) TO localrank_app;

DO $$
DECLARE t text;
BEGIN
    FOREACH t IN ARRAY ARRAY['report_branding','report_schedules','reports'] LOOP
        EXECUTE format('ALTER TABLE %I ENABLE ROW LEVEL SECURITY', t);
        EXECUTE format('ALTER TABLE %I FORCE ROW LEVEL SECURITY', t);
        EXECUTE format($p$CREATE POLICY tenant_isolation ON %I
            USING      (org_id = NULLIF(current_setting('app.current_org', true), '')::uuid)
            WITH CHECK (org_id = NULLIF(current_setting('app.current_org', true), '')::uuid)$p$, t);
    END LOOP;
END $$;
GRANT SELECT, INSERT, UPDATE, DELETE ON report_branding, report_schedules, reports TO localrank_app;

ALTER TYPE notification_type ADD VALUE IF NOT EXISTS 'report_ready';
ALTER TYPE notification_type ADD VALUE IF NOT EXISTS 'report_failed';

-- white_label is a plan feature; placeholder values (commercial plans are a business decision)
UPDATE plans SET limits = limits || '{"white_label": false}'::jsonb WHERE NOT (limits ? 'white_label');

INSERT INTO schema_migrations (version) VALUES ('0005_reports');
COMMIT;
