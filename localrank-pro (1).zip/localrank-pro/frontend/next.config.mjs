/** @type {import("next").NextConfig} */
// The browser talks only to this Next.js server; /api/* is forwarded to the backend container.
// One origin means no CORS setup, and it works behind forwarded URLs such as GitHub Codespaces.
// API_INTERNAL_URL is read at build time (Docker build arg).
const apiInternal = (process.env.API_INTERNAL_URL || "http://api:8000").replace(/\/+$/, "");

const nextConfig = {
  reactStrictMode: true,
  output: "standalone",
  async rewrites() {
    return [
      { source: "/api/:path*", destination: `${apiInternal}/api/:path*` },
      { source: "/health", destination: `${apiInternal}/health` },
    ];
  },
};
export default nextConfig;
