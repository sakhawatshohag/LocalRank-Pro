// Thin, typed HTTP client for the LocalRank Pro API.  No provider credentials ever reach this code.
export class ApiError extends Error {
  constructor(public status: number, message: string, public detail: unknown = null) {
    super(message);
    this.name = "ApiError";
  }
}

/** Turns a FastAPI error body into one readable sentence. */
export function errorMessage(status: number, body: unknown): string {
  const detail = body && typeof body === "object" && "detail" in body ? (body as { detail: unknown }).detail : body;
  if (typeof detail === "string" && detail) return detail;
  if (Array.isArray(detail) && detail.length) {
    return detail
      .map((d) => {
        const field = Array.isArray(d?.loc) ? d.loc.filter((p: unknown) => p !== "body").join(".") : "";
        return field ? `${field}: ${d?.msg ?? "invalid"}` : String(d?.msg ?? "invalid");
      })
      .join("; ");
  }
  if (detail && typeof detail === "object" && typeof (detail as { message?: unknown }).message === "string") {
    return (detail as { message: string }).message;
  }
  return `Request failed (${status})`;
}

export type Query = Record<string, string | number | boolean | null | undefined>;

export function buildUrl(base: string, path: string, query?: Query): string {
  const url = base.replace(/\/+$/, "") + path;
  if (!query) return url;
  const qs = Object.entries(query)
    .filter(([, v]) => v !== null && v !== undefined && v !== "")
    .map(([k, v]) => `${encodeURIComponent(k)}=${encodeURIComponent(String(v))}`)
    .join("&");
  return qs ? `${url}?${qs}` : url;
}

export interface ApiOptions {
  baseUrl: string;
  getToken: () => string | null;
  onUnauthorized?: () => void;
  fetchImpl?: typeof fetch;
}

export function createApi({ baseUrl, getToken, onUnauthorized, fetchImpl }: ApiOptions) {
  async function request<T>(method: string, path: string, body?: unknown, query?: Query): Promise<T> {
    const headers: Record<string, string> = { Accept: "application/json" };
    const token = getToken();
    if (token) headers.Authorization = `Bearer ${token}`;
    if (body !== undefined) headers["Content-Type"] = "application/json";
    let res: Response;
    try {
      res = await (fetchImpl ?? fetch)(buildUrl(baseUrl, path, query), {
        method, headers, body: body === undefined ? undefined : JSON.stringify(body),
      });
    } catch {
      throw new ApiError(0, "Cannot reach the server. Check your connection and try again.");
    }
    if (res.status === 204) return undefined as T;
    let parsed: unknown = null;
    try { parsed = await res.json(); } catch { /* non-JSON body */ }
    if (!res.ok) {
      if (res.status === 401 && token) onUnauthorized?.();
      const detail = parsed && typeof parsed === "object" && "detail" in parsed ? (parsed as { detail: unknown }).detail : parsed;
      throw new ApiError(res.status, errorMessage(res.status, parsed), detail);
    }
    return parsed as T;
  }
  /** Authenticated file download (PDF, CSV, images). */
  async function blob(path: string): Promise<Blob> {
    const token = getToken();
    let res: Response;
    try {
      res = await (fetchImpl ?? fetch)(buildUrl(baseUrl, path), { headers: token ? { Authorization: `Bearer ${token}` } : {} });
    } catch {
      throw new ApiError(0, "Cannot reach the server. Check your connection and try again.");
    }
    if (!res.ok) {
      let parsed: unknown = null;
      try { parsed = await res.json(); } catch { /* not JSON */ }
      if (res.status === 401 && token) onUnauthorized?.();
      throw new ApiError(res.status, errorMessage(res.status, parsed));
    }
    return res.blob();
  }
  return {
    blob,
    get: <T>(path: string, query?: Query) => request<T>("GET", path, undefined, query),
    post: <T>(path: string, body?: unknown, query?: Query) => request<T>("POST", path, body ?? {}, query),
    put: <T>(path: string, body: unknown) => request<T>("PUT", path, body),
    patch: <T>(path: string, body: unknown) => request<T>("PATCH", path, body),
    del: (path: string) => request<void>("DELETE", path),
  };
}
export type Api = ReturnType<typeof createApi>;
