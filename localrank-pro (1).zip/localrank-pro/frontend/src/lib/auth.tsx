"use client";

import { useQuery, useQueryClient } from "@tanstack/react-query";
import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from "react";

import { createApi, type Api } from "./api";
import type { Me } from "./types";

const STORAGE_KEY = "lrp_token";
const API_URL = process.env.NEXT_PUBLIC_API_URL ?? "/api/v1";

interface AuthState {
  api: Api;
  token: string | null;
  ready: boolean;          // false until the stored session has been read
  me: Me | undefined;
  meLoading: boolean;
  signIn: (token: string) => void;
  signOut: () => void;
}

const AuthContext = createContext<AuthState | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [token, setToken] = useState<string | null>(null);
  const [ready, setReady] = useState(false);
  const tokenRef = useRef<string | null>(null);
  const queryClient = useQueryClient();

  // sessionStorage: the session ends with the browser tab and is never sent automatically
  useEffect(() => {
    try {
      const stored = window.sessionStorage.getItem(STORAGE_KEY);
      tokenRef.current = stored;
      setToken(stored);
    } catch { /* storage unavailable: stay signed out */ }
    setReady(true);
  }, []);

  const signOut = useCallback(() => {
    tokenRef.current = null;
    setToken(null);
    try { window.sessionStorage.removeItem(STORAGE_KEY); } catch { /* ignore */ }
    queryClient.clear();   // never show one account's cached data to the next
  }, [queryClient]);

  const signIn = useCallback((next: string) => {
    queryClient.clear();
    tokenRef.current = next;
    setToken(next);
    try { window.sessionStorage.setItem(STORAGE_KEY, next); } catch { /* ignore */ }
  }, [queryClient]);

  const api = useMemo(
    () => createApi({ baseUrl: API_URL, getToken: () => tokenRef.current, onUnauthorized: signOut }),
    [signOut],
  );

  const meQuery = useQuery({ queryKey: ["me", token], queryFn: () => api.get<Me>("/auth/me"), enabled: ready && !!token });

  const value = useMemo<AuthState>(
    () => ({ api, token, ready, me: meQuery.data, meLoading: meQuery.isLoading, signIn, signOut }),
    [api, token, ready, meQuery.data, meQuery.isLoading, signIn, signOut],
  );
  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth(): AuthState {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used inside <AuthProvider>");
  return ctx;
}

export const useApi = (): Api => useAuth().api;
