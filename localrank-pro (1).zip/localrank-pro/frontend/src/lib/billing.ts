import type { Plan, PlanLimits, Role } from "./types";
import { ROLE_RANK } from "./nav";

/** "$99.00 / month"; null price = not sold online. Amounts are integer cents. */
export function formatPrice(cents: number | null | undefined, currency = "usd"): string {
  if (cents === null || cents === undefined) return "Contact us";
  return `${new Intl.NumberFormat("en-US", { style: "currency", currency: currency.toUpperCase() }).format(cents / 100)} / month`;
}

export function formatMoney(cents: number | null | undefined, currency: string | null | undefined): string {
  if (cents === null || cents === undefined || !currency) return "—";
  return new Intl.NumberFormat("en-US", { style: "currency", currency: currency.toUpperCase() }).format(cents / 100);
}

export const LIMIT_LABELS: [keyof PlanLimits, string][] = [
  ["locations", "Locations"], ["campaigns", "Active campaigns"], ["keywords", "Active keywords"],
  ["competitors", "Competitors per campaign"], ["max_grid_size", "Largest grid"], ["monthly_scan_points", "Grid points per month"],
  ["team_members", "Team members"],
];

/** Share of a limit used, clamped to 0–100; null when the plan has no such limit. */
export function usageShare(used: number, limit: number | undefined): number | null {
  if (limit === undefined || limit === null) return null;
  if (limit <= 0) return used > 0 ? 100 : 0;
  return Math.min(100, Math.round((100 * used) / limit));
}

export function limitText(key: keyof PlanLimits, value: PlanLimits[keyof PlanLimits]): string {
  if (value === undefined) return "—";
  if (key === "max_grid_size") return value ? `${value}×${value}` : "None";
  return typeof value === "boolean" ? (value ? "Yes" : "No") : Number(value).toLocaleString("en-US");
}

export function sortPlans(plans: Plan[]): Plan[] {
  return [...plans].sort((a, b) => a.sort_order - b.sort_order || (a.monthly_price_cents ?? Infinity) - (b.monthly_price_cents ?? Infinity));
}

/** Roles a user may assign: owners any non-owner role, admins only roles below admin. Mirrors the API. */
export function assignableRoles(actor: Role): Role[] {
  const all: Role[] = ["admin", "manager", "seo_specialist", "client_viewer"];
  if (actor === "owner") return all;
  if (actor === "admin") return all.filter((r) => ROLE_RANK[r] < ROLE_RANK.admin);
  return [];
}

export function canManageMember(actor: Role, target: Role): boolean {
  return actor === "owner" || (actor === "admin" && ROLE_RANK[target] < ROLE_RANK.admin);
}

export const SUBSCRIPTION_LABEL: Record<string, string> = {
  active: "Active", trialing: "Trial", past_due: "Payment overdue", canceled: "Cancelled", unpaid: "Unpaid",
  incomplete: "Payment incomplete", incomplete_expired: "Payment expired",
};
