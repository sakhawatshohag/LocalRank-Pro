import { z } from "zod";

const optionalText = (max: number) =>
  z.string().trim().max(max).transform((v) => (v === "" ? null : v)).nullable().optional();

export const loginSchema = z.object({ email: z.string().trim().email("Enter a valid email"), password: z.string().min(1, "Enter your password") });

export const registerSchema = z.object({
  full_name: z.string().trim().min(1, "Enter your name").max(120),
  organization_name: z.string().trim().min(1, "Enter your agency or business name").max(120),
  email: z.string().trim().email("Enter a valid email"),
  password: z.string().min(10, "Use at least 10 characters").max(128),
});

export const clientSchema = z.object({
  name: z.string().trim().min(1, "Client name is required").max(160),
  contact_email: z.union([z.literal(""), z.string().trim().email("Enter a valid email")]).transform((v) => v || null),
  notes: optionalText(5000),
});

export const locationSchema = z.object({
  name: z.string().trim().min(1, "Business name is required").max(200),
  client_id: z.string().uuid().nullable().optional(),
  latitude: z.coerce.number({ invalid_type_error: "Latitude must be a number" }).min(-85).max(85),
  longitude: z.coerce.number({ invalid_type_error: "Longitude must be a number" }).min(-180).max(180),
  place_id: optionalText(300),
  cid: optionalText(40),
  gbp_url: optionalText(2000),
  address: optionalText(500),
  city: optionalText(100),
  state: optionalText(100),
  country: optionalText(100),
  postal_code: optionalText(20),
  website: optionalText(2000),
  phone: optionalText(40),
  primary_category: optionalText(200),
  time_zone: z.string().trim().min(1).default("UTC"),
  language_code: z.string().trim().min(2).max(10).default("en"),
});

export const campaignSchema = z.object({
  location_id: z.string().uuid("Choose a location"),
  name: z.string().trim().min(1, "Campaign name is required").max(160),
  grid_size: z.coerce.number().int().min(1).max(21).refine((n) => n % 2 === 1, "Grid size must be odd"),
  spacing_m: z.coerce.number().min(50, "Spacing must be at least 50 m").max(50000),
  center_lat: z.number().min(-85).max(85).nullable().optional(),
  center_lng: z.number().min(-180).max(180).nullable().optional(),
  language_code: z.string().trim().min(2).max(10).default("en"),
  device: z.enum(["desktop", "mobile"]).default("desktop"),
  zoom: z.coerce.number().int().min(3).max(21).default(15),
  depth: z.coerce.number().int().min(1).max(700).default(100),
});

export const keywordSchema = z.object({ keyword: z.string().trim().min(1, "Enter a keyword").max(700) });

export const competitorSchema = z
  .object({ name: z.string().trim().min(1, "Competitor name is required").max(200), place_id: optionalText(300), cid: optionalText(40) })
  .refine((c) => Boolean(c.place_id || c.cid), { message: "Add a Google Place ID or CID. Rankings are matched by identifier, not by name.", path: ["place_id"] });

/** First error per field, for showing under inputs. */
export function fieldErrors(error: z.ZodError): Record<string, string> {
  const out: Record<string, string> = {};
  for (const issue of error.issues) {
    const key = issue.path.join(".") || "_form";
    if (!(key in out)) out[key] = issue.message;
  }
  return out;
}
