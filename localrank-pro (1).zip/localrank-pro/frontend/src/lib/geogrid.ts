// GeoGrid presentation rules.  Mirrors backend/app/engine/analytics.py::rank_color.
import type { ResultStatus, ScanPoint } from "./types";

export type Bucket = "green" | "yellow" | "orange" | "red" | "gray" | "error" | "pending";

export const BUCKETS: Record<Bucket, { label: string; bg: string; fg: string }> = {
  green: { label: "Position 1–3", bg: "#16a34a", fg: "#ffffff" },
  yellow: { label: "Position 4–10", bg: "#facc15", fg: "#1f2937" },
  orange: { label: "Position 11–20", bg: "#f97316", fg: "#ffffff" },
  red: { label: "Position 21+", bg: "#dc2626", fg: "#ffffff" },
  gray: { label: "Not found", bg: "#9ca3af", fg: "#ffffff" },
  error: { label: "No data (API error)", bg: "#ffffff", fg: "#b91c1c" },
  pending: { label: "Waiting", bg: "#e5e7eb", fg: "#6b7280" },
};
export const LEGEND_ORDER: Bucket[] = ["green", "yellow", "orange", "red", "gray", "error"];

export function bucketFor(status: ResultStatus | null, position: number | null): Bucket {
  if (status === null) return "pending";
  if (status === "error") return "error";
  if (status === "not_found") return "gray";
  if (position === null || position < 1) return "error"; // a ranked point without a position is corrupt data, never a rank
  return position <= 3 ? "green" : position <= 10 ? "yellow" : position <= 20 ? "orange" : "red";
}

/** Text inside a marker.  Not-found shows the search depth ("100+"), never 0. */
export function markerLabel(status: ResultStatus | null, position: number | null, depth: number): string {
  const b = bucketFor(status, position);
  if (b === "pending") return "…";
  if (b === "error") return "!";
  if (b === "gray") return `${depth}+`;
  return String(position);
}

export function summarize(points: Pick<ScanPoint, "result_status" | "position">[]): Record<Bucket, number> {
  const out: Record<Bucket, number> = { green: 0, yellow: 0, orange: 0, red: 0, gray: 0, error: 0, pending: 0 };
  for (const p of points) out[bucketFor(p.result_status, p.position)] += 1;
  return out;
}

/** Rows (north to south) of points (west to east) for the non-map grid view. */
export function toRows<T extends { row_no: number; col_no: number }>(points: T[]): T[][] {
  const rows = new Map<number, T[]>();
  for (const p of points) rows.set(p.row_no, [...(rows.get(p.row_no) ?? []), p]);
  return [...rows.entries()].sort((a, b) => a[0] - b[0]).map(([, r]) => r.sort((a, b) => a.col_no - b.col_no));
}

export function isScanActive(status: string): boolean {
  return status === "queued" || status === "running";
}

export const GRID_SIZES = [3, 5, 7, 9, 11, 13, 15] as const;

export function formatDistance(metres: number): string {
  return metres >= 1000 ? `${(metres / 1000).toFixed(metres % 1000 === 0 ? 0 : 1)} km` : `${Math.round(metres)} m`;
}

export function formatMetric(value: number | null | undefined, suffix = ""): string {
  return value === null || value === undefined ? "—" : `${Number.isInteger(value) ? value : value.toFixed(2)}${suffix}`;
}
