import type { ReportType } from "./types";

export const REPORT_TYPES: { value: ReportType; label: string; hint: string }[] = [
  { value: "weekly", label: "Weekly ranking report", hint: "Latest scan of each keyword in the week versus the scan before it." },
  { value: "monthly", label: "Monthly ranking report", hint: "Latest scan of each keyword in the month versus the scan before it." },
  { value: "performance", label: "Local SEO performance report", hint: "All campaigns of the client for any period." },
  { value: "competitor_comparison", label: "Competitor comparison report", hint: "Always includes the competitor tables." },
  { value: "geogrid_comparison", label: "GeoGrid comparison report", hint: "Two scans of one keyword that you pick." },
  { value: "custom", label: "Custom report", hint: "Your own title, period and campaigns." },
];

const iso = (d: Date) => d.toISOString().slice(0, 10);
const utcDate = (y: number, m: number, d: number) => new Date(Date.UTC(y, m, d));

/** Default period for a report type, in whole UTC days, as [start, end]. */
export function defaultPeriod(type: ReportType, today: Date = new Date()): [string, string] {
  const t = utcDate(today.getUTCFullYear(), today.getUTCMonth(), today.getUTCDate());
  if (type === "monthly") {
    const end = utcDate(t.getUTCFullYear(), t.getUTCMonth(), 0);            // last day of previous month
    return [iso(utcDate(end.getUTCFullYear(), end.getUTCMonth(), 1)), iso(end)];
  }
  const days = type === "weekly" ? 6 : 29;
  return [iso(new Date(t.getTime() - days * 86_400_000)), iso(t)];
}

export function validatePeriod(start: string, end: string): string | null {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(start) || !/^\d{4}-\d{2}-\d{2}$/.test(end)) return "Choose a start and end date";
  if (end < start) return "The end date is before the start date";
  if ((Date.parse(end) - Date.parse(start)) / 86_400_000 > 400) return "A report can cover at most 400 days";
  return null;
}

export const STATUS_TONE = { queued: "blue", generating: "blue", ready: "green", failed: "red" } as const;

export function isHexColor(v: string): boolean {
  return /^#[0-9a-fA-F]{6}$/.test(v);
}

/** Browser-only: file -> base64 data URL for the logo endpoints (max 1 MB is enforced by the server too). */
export function fileToDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    if (file.size > 1_000_000) return reject(new Error("The logo must be 1 MB or smaller"));
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result));
    reader.onerror = () => reject(new Error("The file could not be read"));
    reader.readAsDataURL(file);
  });
}
