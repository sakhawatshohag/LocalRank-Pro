import type { Role } from "./types";

export const ROLE_RANK: Record<Role, number> = { client_viewer: 10, seo_specialist: 20, manager: 30, admin: 40, owner: 50 };
export const roleAtLeast = (role: Role, minimum: Role): boolean => ROLE_RANK[role] >= ROLE_RANK[minimum];

export interface NavItem { href: string; label: string; minRole: Role; superAdminOnly?: boolean }

// Only sections that exist are listed: no links that lead nowhere.  Remaining modules
// (citations, reviews, audit, billing, team, ...) are added when built.
export const NAV: NavItem[] = [
  { href: "/dashboard", label: "Overview", minRole: "client_viewer" },
  { href: "/clients", label: "Clients", minRole: "client_viewer" },
  { href: "/locations", label: "Locations", minRole: "client_viewer" },
  { href: "/campaigns", label: "Rank Tracking", minRole: "client_viewer" },
  { href: "/schedules", label: "Scheduled Scans", minRole: "client_viewer" },
  { href: "/reports", label: "Reports", minRole: "client_viewer" },
  { href: "/notifications", label: "Notifications", minRole: "client_viewer" },
  { href: "/team", label: "Team Management", minRole: "manager" },
  { href: "/billing", label: "Billing & Subscription", minRole: "admin" },
  { href: "/settings", label: "Settings", minRole: "manager" },
  { href: "/admin", label: "Super Admin", minRole: "client_viewer", superAdminOnly: true },
];

export const navFor = (role: Role, isSuperAdmin = false): NavItem[] =>
  NAV.filter((n) => roleAtLeast(role, n.minRole) && (!n.superAdminOnly || isSuperAdmin));
