// Presentation rules for scan-to-scan changes, competitor dominance and trend charts.
import type { ChangeType, DominanceType, TrendEntry } from "./types";

export interface Swatch { label: string; bg: string; fg: string; dashed?: boolean }

export const CHANGES: Record<ChangeType, Swatch> = {
  improved: { label: "Improved", bg: "#16a34a", fg: "#ffffff" },
  newly_found: { label: "Newly found", bg: "#0d9488", fg: "#ffffff" },
  unchanged: { label: "Unchanged", bg: "#64748b", fg: "#ffffff" },
  declined: { label: "Declined", bg: "#dc2626", fg: "#ffffff" },
  lost_visibility: { label: "Lost visibility", bg: "#7f1d1d", fg: "#ffffff" },
  not_found_both: { label: "Not found in both", bg: "#9ca3af", fg: "#ffffff" },
  not_comparable: { label: "Not comparable (missing data)", bg: "#ffffff", fg: "#b91c1c", dashed: true },
};
export const CHANGE_ORDER: ChangeType[] = ["improved", "newly_found", "unchanged", "declined", "lost_visibility", "not_found_both", "not_comparable"];

/** Marker text for a change.  A delta exists only when the business was ranked in both scans. */
export function changeLabel(change: ChangeType, delta: number | null): string {
  switch (change) {
    case "improved": return `+${delta ?? ""}`;
    case "declined": return `−${Math.abs(delta ?? 0)}`;
    case "unchanged": return "=";
    case "newly_found": return "NEW";
    case "lost_visibility": return "LOST";
    case "not_found_both": return "–";
    default: return "!";
  }
}

/** Sentence for a point, e.g. "15 → 8, improved by 7 positions". */
export function describeChange(change: ChangeType, prev: number | null, curr: number | null, delta: number | null): string {
  const n = Math.abs(delta ?? 0);
  const unit = n === 1 ? "position" : "positions";
  switch (change) {
    case "improved": return `${prev} → ${curr}, improved by ${n} ${unit}`;
    case "declined": return `${prev} → ${curr}, declined by ${n} ${unit}`;
    case "unchanged": return `${prev} → ${curr}, unchanged`;
    case "newly_found": return `Not found → ${curr}, newly found`;
    case "lost_visibility": return `${prev} → not found, lost visibility`;
    case "not_found_both": return "Not found in both scans";
    default: return "Cannot be compared: data is missing in one of the scans";
  }
}

export const DOMINANCE: Record<DominanceType, Swatch> = {
  mine: { label: "You lead", bg: "#16a34a", fg: "#ffffff" },
  similar: { label: "Similar rankings", bg: "#facc15", fg: "#1f2937" },
  competitor: { label: "Competitor leads", bg: "#dc2626", fg: "#ffffff" },
  all_weak: { label: "Everyone weak", bg: "#9ca3af", fg: "#ffffff" },
  no_data: { label: "No data (API error)", bg: "#ffffff", fg: "#b91c1c", dashed: true },
};
export const DOMINANCE_ORDER: DominanceType[] = ["mine", "similar", "competitor", "all_weak", "no_data"];

export function dominanceLabel(d: DominanceType, my: number | null, leader: number | null): string {
  if (d === "no_data") return "!";
  if (d === "all_weak") return "–";
  return `${my ?? "–"}/${leader ?? "–"}`;
}

// ---------- trend chart ----------
export type TrendMetric = "average_position" | "top3_coverage" | "top10_coverage" | "top20_coverage";
export const TREND_METRICS: Record<TrendMetric, { label: string; lowerIsBetter: boolean; suffix: string }> = {
  average_position: { label: "Average position", lowerIsBetter: true, suffix: "" },
  top3_coverage: { label: "Top 3 coverage", lowerIsBetter: false, suffix: "%" },
  top10_coverage: { label: "Top 10 coverage", lowerIsBetter: false, suffix: "%" },
  top20_coverage: { label: "Top 20 coverage", lowerIsBetter: false, suffix: "%" },
};

export interface Series { id: string; name: string; isMine: boolean; values: (number | null)[] }

/** One series per business; a scan without usable data for a business yields null (a gap), never a guess. */
export function buildSeries(entries: TrendEntry[], metric: TrendMetric): { dates: string[]; series: Series[] } {
  const dates = entries.map((e) => e.completed_at ?? e.created_at);
  const byId = new Map<string, Series>();
  entries.forEach((e, i) => {
    for (const b of e.businesses) {
      let s = byId.get(b.subject_id);
      if (!s) {
        s = { id: b.subject_id, name: b.name, isMine: b.subject_type === "location", values: Array(entries.length).fill(null) };
        byId.set(b.subject_id, s);
      }
      const v = b[metric];
      s.values[i] = typeof v === "number" ? v : null;
    }
  });
  const series = [...byId.values()].sort((a, b) => Number(b.isMine) - Number(a.isMine) || a.name.localeCompare(b.name));
  return { dates, series };
}

export interface ChartGeometry {
  min: number; max: number;
  lines: { id: string; segments: { x: number; y: number; value: number; index: number }[][] }[];
  ticks: { y: number; value: number }[];
}

/** Maps series to pixel coordinates.  Null values break the line into separate segments. */
export function chartGeometry(series: Series[], count: number, width: number, height: number, pad: number, invert: boolean): ChartGeometry {
  const all = series.flatMap((s) => s.values).filter((v): v is number => v !== null);
  let min = all.length ? Math.min(...all) : 0;
  let max = all.length ? Math.max(...all) : 1;
  if (min === max) { min -= 1; max += 1; }
  const x = (i: number) => (count <= 1 ? width / 2 : pad + (i * (width - 2 * pad)) / (count - 1));
  const y = (v: number) => {
    const t = (v - min) / (max - min);
    return invert ? pad + t * (height - 2 * pad) : height - pad - t * (height - 2 * pad);
  };
  const lines = series.map((s) => {
    const segments: { x: number; y: number; value: number; index: number }[][] = [];
    let current: { x: number; y: number; value: number; index: number }[] = [];
    s.values.forEach((v, i) => {
      if (v === null) { if (current.length) segments.push(current); current = []; return; }
      current.push({ x: x(i), y: y(v), value: v, index: i });
    });
    if (current.length) segments.push(current);
    return { id: s.id, segments };
  });
  const ticks = [0, 0.25, 0.5, 0.75, 1].map((t) => { const value = min + t * (max - min); return { y: y(value), value }; });
  return { min, max, lines, ticks };
}

export const DATE_RANGES: { label: string; days: number | null }[] = [
  { label: "Last 7 days", days: 7 }, { label: "Last 14 days", days: 14 }, { label: "Last 30 days", days: 30 },
  { label: "Last 90 days", days: 90 }, { label: "Last 6 months", days: 183 }, { label: "Last 12 months", days: 365 },
  { label: "All time", days: null },
];
