// Shapes returned by the LocalRank Pro API (backend/app/routers).
export type Role = "owner" | "admin" | "manager" | "seo_specialist" | "client_viewer";
export type ResultStatus = "ranked" | "not_found" | "error";
export type ScanStatus = "queued" | "running" | "completed" | "partial" | "failed" | "cancelled";

export interface Token { access_token: string; token_type: string; org_id: string; role: Role }
export interface Me {
  user_id: string; email: string; full_name: string | null; org_id: string; organization: string; role: Role;
  is_super_admin: boolean; organizations: { id: string; name: string; role: Role }[];
}

export interface Client { id: string; name: string; contact_email: string | null; notes: string | null; archived_at: string | null; created_at: string }

export interface BusinessLocation {
  id: string; client_id: string | null; name: string; gbp_url: string | null; place_id: string | null; cid: string | null;
  address: string | null; latitude: number; longitude: number; website: string | null; phone: string | null;
  primary_category: string | null; additional_categories: string[]; country: string | null; state: string | null;
  city: string | null; postal_code: string | null; time_zone: string; language_code: string;
  identity_verified_at: string | null; archived_at: string | null; created_at: string;
}

export interface Campaign {
  id: string; location_id: string; location_name: string; name: string; grid_size: number; spacing_m: number;
  center_lat: number; center_lng: number; language_code: string; se_domain: string | null; device: string;
  zoom: number; depth: number; is_active: boolean; created_at: string;
  keyword_count?: number; competitor_count?: number; last_scan_at?: string | null; radius_m?: number;
}
export interface Keyword { id: string; keyword: string; is_paused: boolean; created_at: string }
export interface Competitor { id: string; name: string; place_id: string | null; cid: string | null; identity_verified_at: string | null }
export interface CampaignDetail extends Campaign { keywords: Keyword[]; competitors: Competitor[] }

export interface GridPreviewPoint { index: number; row: number; col: number; lat: number; lng: number }
export interface GridPreview {
  points: GridPreviewPoint[]; radius_m: number;
  estimate: { api_requests: number; estimated_cost_usd: string; unit_price_usd: string; price_source: string | null;
              price_verified_on: string | null; requires_confirmation: boolean; note: string };
}

export interface Scan {
  id: string; campaign_id: string; keyword_id: string; keyword_text: string; provider_code: string; is_demo: boolean;
  status: ScanStatus; grid_size: number; spacing_m: number; center_lat: number; center_lng: number; depth: number;
  points_total: number; points_failed: number; estimated_cost_usd: string | null; actual_cost_usd: string | null;
  created_at: string; started_at: string | null; completed_at: string | null;
}
export interface ScanMetrics {
  total_points: number; valid_points: number; ranked_points: number; not_found_points: number; error_points: number;
  average_position: number | null; capped_average_position: number | null; median_position: number | null;
  best_position: number | null; worst_position: number | null; top3_count: number; top10_count: number; top20_count: number;
  top3_coverage: number | null; top10_coverage: number | null; top20_coverage: number | null; not_found_pct: number | null;
}
export interface ScanPoint {
  point_index: number; row_no: number; col_no: number; latitude: number; longitude: number;
  point_status: "pending" | "ok" | "error"; error_code: string | null; error_message: string | null;
  check_url: string | null; fetched_at: string | null; result_status: ResultStatus | null; position: number | null;
}
export interface ScanDetail { scan: Scan; metrics: ScanMetrics | null; points: ScanPoint[]; data_notice: string | null }
export interface HistoryEntry extends Scan { metrics: ScanMetrics | null }
export interface LaunchResult { scans: { scan_id: string; keyword: string; is_demo: boolean }[]; api_requests: number; estimated_cost_usd: string }
export interface PointDetail {
  point_index: number; latitude: number; longitude: number; point_status: string; error_code: string | null;
  error_message: string | null; check_url: string | null; fetched_at: string | null;
  top_listings: { position: number; title: string | null; rating: number | null; reviews: number | null }[] | null;
  businesses: { subject_type: "location" | "competitor"; name: string; subject_id: string; result_status: ResultStatus; position: number | null }[];
}

// ---- step 4: comparison and trends ----
export type ChangeType = "improved" | "declined" | "unchanged" | "newly_found" | "lost_visibility" | "not_found_both" | "not_comparable";
export interface PointChange {
  point_index: number; change: ChangeType; previous_position: number | null; current_position: number | null;
  delta: number | null; latitude: number | null; longitude: number | null;
}
export interface ScanComparison {
  previous: Scan; current: Scan; metrics: { previous: ScanMetrics | null; current: ScanMetrics | null };
  comparable_points: number; total_points: number; counts: Record<ChangeType, number>; average_delta: number | null;
  points: PointChange[]; data_notice: string | null;
}
export type DominanceType = "mine" | "competitor" | "similar" | "all_weak" | "no_data";
export interface BusinessMetrics extends ScanMetrics { subject_type: "location" | "competitor"; subject_id: string; name: string }
export interface CompetitorComparison {
  scan: Scan; businesses: BusinessMetrics[];
  dominance: null | {
    tolerance: number; valid_points: number; counts: Record<DominanceType, number>;
    points: { point_index: number; dominance: DominanceType; my_position: number | null; leader_id: string | null;
              leader_position: number | null; latitude: number; longitude: number }[];
  };
  data_source: string; data_notice: string | null;
}
export interface TrendEntry {
  id: string; status: ScanStatus; is_demo: boolean; grid_signature: string; created_at: string; completed_at: string | null;
  businesses: BusinessMetrics[];
}

// ---- step 5: schedules and notifications ----
export type Frequency = "daily" | "every_2_days" | "weekly" | "biweekly" | "monthly" | "custom";
export interface Schedule {
  id: string; campaign_id: string; frequency: Frequency; interval_days: number | null; local_time: string; anchor_date: string;
  is_paused: boolean; next_run_at: string | null; last_run_at: string | null; last_occurrence: string | null;
  last_error: string | null; updated_at: string;
}
export interface ScheduleProjection {
  active_keywords: number; points_per_run: number; runs_per_month: number; points_per_month: number;
  estimated_cost_per_run_usd: string | null; estimated_cost_per_month_usd: string | null;
  monthly_points_used: number; monthly_points_limit: number;
}
export interface ScheduleResponse { schedule: Schedule | null; time_zone: string; projection: ScheduleProjection }
export interface ScheduleListItem extends Schedule {
  campaign_name: string; campaign_active: boolean; location_name: string; time_zone: string; active_keywords: number;
  last_scans: { id: string; keyword: string; status: ScanStatus }[] | null;
}
export type NotificationType = "scan_completed" | "scan_failed" | "ranking_improved" | "ranking_declined" |
  "competitor_change" | "usage_warning" | "schedule_problem" | "report_ready" | "report_failed" | "billing_problem";
export interface AppNotification { id: string; type: NotificationType; title: string; body: string | null; link: string | null; read_at: string | null; created_at: string }
export interface NotificationList { unread_count: number; items: AppNotification[] }
export interface NotificationPreference { type: NotificationType; in_app: boolean; email: boolean }

// ---- step 6: reports ----
export type ReportType = "weekly" | "monthly" | "geogrid_comparison" | "competitor_comparison" | "performance" | "custom";
export type ReportStatus = "queued" | "generating" | "ready" | "failed";
export interface Report {
  id: string; client_id: string; client_name: string; report_type: ReportType; title: string; period_start: string; period_end: string;
  status: ReportStatus; is_demo: boolean | null; page_count: number | null; error: string | null; created_at: string;
  generated_at: string | null; schedule_id: string | null;
}
export interface ReportSchedule {
  id: string; client_id: string; report_type: "weekly" | "monthly"; title: string | null; campaign_ids: string[] | null;
  time_zone: string; local_time: string; is_paused: boolean; next_run_at: string; last_run_at: string | null; last_error: string | null;
}
export interface BrandingSettings {
  agency_name: string | null; website: string | null; email: string | null; phone: string | null; primary_color: string;
  footer_text: string | null; has_logo: boolean; white_label_enabled: boolean;
}

// ---- step 7a: billing, team, admin ----
export interface PlanLimits {
  locations?: number; keywords?: number; campaigns?: number; competitors?: number; max_grid_size?: number;
  monthly_scan_points?: number; team_members?: number; white_label?: boolean;
}
export interface Plan {
  code: string; name: string; description: string | null; limits: PlanLimits; monthly_price_cents: number | null;
  currency: string; is_public: boolean; sort_order: number; purchasable: boolean;
}
export interface BillingOverview {
  plan: Plan; trial_ends_at: string | null; payments_enabled: boolean;
  subscription: { status: string; current_period_end: string | null; cancel_at_period_end: boolean; has_customer: boolean } | null;
  usage: { locations: number; campaigns: number; keywords: number; competitors: number; team_members: number; monthly_scan_points: number };
  monthly_scan_points_limit: number; plans: Plan[];
  invoices: { number: string | null; status: string | null; amount_due_cents: number | null; amount_paid_cents: number | null; currency: string | null;
              hosted_invoice_url: string | null; invoice_pdf_url: string | null; period_start: string | null; period_end: string | null; created_at: string }[];
}
export interface TeamMember { user_id: string; email: string; full_name: string | null; role: Role; created_at: string; last_login_at: string | null }
export interface Invitation { id: string; email: string; role: Role; expires_at: string; created_at: string }
export interface AdminPlan extends Omit<Plan, "purchasable"> { stripe_price_id: string | null; is_active: boolean; organizations: number }
export interface AdminOrg {
  id: string; name: string; created_at: string; plan_code: string | null; plan_name: string | null; trial_ends_at: string | null;
  subscription_status: string | null; members: number; locations: number; campaigns: number; scans_30d: number; api_cost_30d_usd: string;
}
export interface AdminUser { id: string; email: string; full_name: string | null; is_active: boolean; is_super_admin: boolean; created_at: string; last_login_at: string | null; organizations: string | null }
