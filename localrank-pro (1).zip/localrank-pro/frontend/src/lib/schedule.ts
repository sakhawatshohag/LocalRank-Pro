import type { Frequency, NotificationType, ScheduleProjection } from "./types";

export const FREQUENCIES: { value: Frequency; label: string }[] = [
  { value: "daily", label: "Daily" }, { value: "every_2_days", label: "Every 2 days" }, { value: "weekly", label: "Weekly" },
  { value: "biweekly", label: "Every 2 weeks" }, { value: "monthly", label: "Monthly" }, { value: "custom", label: "Every N days" },
];

export function describeSchedule(frequency: Frequency, intervalDays: number | null, localTime: string, timeZone: string): string {
  const base = frequency === "custom" ? `Every ${intervalDays} day${intervalDays === 1 ? "" : "s"}`
    : FREQUENCIES.find((f) => f.value === frequency)?.label ?? frequency;
  return `${base} at ${localTime} (${timeZone})`;
}

/** "HH:MM", 00:00–23:59. */
export function isValidTime(v: string): boolean {
  const m = /^(\d{2}):(\d{2})$/.exec(v);
  return !!m && Number(m[1]) < 24 && Number(m[2]) < 60;
}

export function validateSchedule(frequency: Frequency, intervalDays: string, localTime: string): Record<string, string> {
  const errors: Record<string, string> = {};
  if (!isValidTime(localTime)) errors.local_time = "Use a 24-hour time like 06:00";
  if (frequency === "custom") {
    const n = Number(intervalDays);
    if (!Number.isInteger(n) || n < 1 || n > 90) errors.interval_days = "Enter a whole number of days from 1 to 90";
  }
  return errors;
}

/** Share of the monthly allowance the schedule alone would use, or null when there is no limit to compare against. */
export function allowanceShare(p: ScheduleProjection): number | null {
  return p.monthly_points_limit > 0 ? Math.round((100 * p.points_per_month) / p.monthly_points_limit) : null;
}

export const NOTIFICATION_LABELS: Record<NotificationType, string> = {
  scan_completed: "Scan completed", scan_failed: "Scan failed", ranking_improved: "Significant ranking improvement",
  ranking_declined: "Significant ranking decline", competitor_change: "Competitor gained ground",
  usage_warning: "Scan allowance warnings", schedule_problem: "Scheduled scan skipped",
  report_ready: "Report ready", report_failed: "Report failed", billing_problem: "Billing and plan",
};

export function timeAgo(iso: string, now: Date = new Date()): string {
  const s = Math.max(0, Math.round((now.getTime() - new Date(iso).getTime()) / 1000));
  if (s < 60) return "just now";
  const m = Math.round(s / 60);
  if (m < 60) return `${m} min ago`;
  const h = Math.round(m / 60);
  if (h < 24) return `${h} h ago`;
  const d = Math.round(h / 24);
  return `${d} day${d === 1 ? "" : "s"} ago`;
}
