"use client";

// Dependency-free SVG line chart.  Gaps in the data stay gaps: lines are never drawn across a
// scan that has no value.
import { TREND_METRICS, chartGeometry, type Series, type TrendMetric } from "@/lib/compare";

const COLORS = ["#2563eb", "#dc2626", "#16a34a", "#9333ea", "#ea580c", "#0891b2", "#be185d", "#4d7c0f"];
const W = 760, H = 280, PAD = 36;

export function TrendChart({ dates, series, metric }: { dates: string[]; series: Series[]; metric: TrendMetric }) {
  const meta = TREND_METRICS[metric];
  const hasData = series.some((s) => s.values.some((v) => v !== null));
  if (!hasData) return <p className="py-8 text-center text-sm text-slate-500">No scans with usable data in this period.</p>;
  const g = chartGeometry(series, dates.length, W, H, PAD, meta.lowerIsBetter);
  const fmt = (v: number) => `${Number.isInteger(v) ? v : v.toFixed(1)}${meta.suffix}`;
  const step = Math.max(1, Math.ceil(dates.length / 8));
  const xOf = (i: number) => (dates.length <= 1 ? W / 2 : PAD + (i * (W - 2 * PAD)) / (dates.length - 1));
  return (
    <figure>
      <svg viewBox={`0 0 ${W} ${H}`} role="img" aria-label={`${meta.label} over time`} className="w-full">
        {g.ticks.map((t) => (
          <g key={t.value}>
            <line x1={PAD} x2={W - PAD} y1={t.y} y2={t.y} stroke="#e2e8f0" />
            <text x={PAD - 6} y={t.y + 4} textAnchor="end" fontSize="11" fill="#64748b">{fmt(t.value)}</text>
          </g>
        ))}
        {dates.map((d, i) => i % step === 0 && (
          <text key={d + i} x={xOf(i)} y={H - 8} textAnchor="middle" fontSize="11" fill="#64748b">
            {new Date(d).toLocaleDateString(undefined, { month: "short", day: "numeric" })}
          </text>
        ))}
        {g.lines.map((line, li) => {
          const s = series[li];
          const color = COLORS[li % COLORS.length];
          return (
            <g key={line.id}>
              {line.segments.map((seg, si) => (
                <polyline key={si} fill="none" stroke={color} strokeWidth={s.isMine ? 3 : 1.75}
                  points={seg.map((p) => `${p.x},${p.y}`).join(" ")} />
              ))}
              {line.segments.flat().map((p) => (
                <circle key={p.index} cx={p.x} cy={p.y} r={s.isMine ? 4 : 3} fill={color}>
                  <title>{`${s.name}: ${fmt(p.value)} on ${new Date(dates[p.index]).toLocaleString()}`}</title>
                </circle>
              ))}
            </g>
          );
        })}
      </svg>
      <figcaption className="mt-2 flex flex-wrap gap-3 text-xs text-slate-600">
        {series.map((s, i) => (
          <span key={s.id} className="flex items-center gap-1.5">
            <span className="inline-block h-2 w-4 rounded" style={{ background: COLORS[i % COLORS.length] }} />
            {s.name}{s.isMine ? " (you)" : ""}
          </span>
        ))}
        {meta.lowerIsBetter && <span className="text-slate-400">Lower position = better; the axis is inverted so up is better.</span>}
      </figcaption>
    </figure>
  );
}
