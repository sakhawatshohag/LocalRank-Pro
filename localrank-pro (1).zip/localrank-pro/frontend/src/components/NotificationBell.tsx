"use client";

import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect, useRef, useState } from "react";

import { useApi } from "@/lib/auth";
import { timeAgo } from "@/lib/schedule";
import type { AppNotification, NotificationList } from "@/lib/types";

export function NotificationBell() {
  const api = useApi();
  const qc = useQueryClient();
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const box = useRef<HTMLDivElement>(null);
  const list = useQuery({ queryKey: ["notifications", "bell"], queryFn: () => api.get<NotificationList>("/notifications", { limit: 8 }), refetchInterval: 60_000 });
  const markRead = useMutation({ mutationFn: (id: string) => api.post(`/notifications/${id}/read`), onSuccess: () => qc.invalidateQueries({ queryKey: ["notifications"] }) });
  const markAll = useMutation({ mutationFn: () => api.post("/notifications/read-all"), onSuccess: () => qc.invalidateQueries({ queryKey: ["notifications"] }) });

  useEffect(() => {
    if (!open) return;
    const close = (e: MouseEvent) => { if (box.current && !box.current.contains(e.target as Node)) setOpen(false); };
    const esc = (e: KeyboardEvent) => { if (e.key === "Escape") setOpen(false); };
    document.addEventListener("mousedown", close);
    document.addEventListener("keydown", esc);
    return () => { document.removeEventListener("mousedown", close); document.removeEventListener("keydown", esc); };
  }, [open]);

  function openItem(n: AppNotification) {
    if (!n.read_at) markRead.mutate(n.id);
    setOpen(false);
    if (n.link) router.push(n.link);
  }
  const unread = list.data?.unread_count ?? 0;

  return (
    <div ref={box} className="relative">
      <button onClick={() => setOpen((o) => !o)} aria-label={`Notifications${unread ? `, ${unread} unread` : ""}`} aria-expanded={open}
        className="relative rounded-md border border-slate-200 bg-white px-3 py-1.5 text-sm text-slate-700 hover:bg-slate-50">
        Notifications
        {unread > 0 && <span className="ml-2 rounded-full bg-red-600 px-1.5 py-0.5 text-xs font-semibold text-white">{unread > 99 ? "99+" : unread}</span>}
      </button>
      {open && (
        <div className="absolute right-0 z-30 mt-2 w-96 rounded-lg border border-slate-200 bg-white shadow-xl">
          <div className="flex items-center justify-between border-b border-slate-100 px-4 py-2">
            <span className="text-sm font-semibold">Notifications</span>
            {unread > 0 && <button className="text-xs text-blue-600" onClick={() => markAll.mutate()}>Mark all read</button>}
          </div>
          {list.isError ? <p className="px-4 py-3 text-sm text-red-700">{list.error.message}</p>
            : !list.data ? <p className="px-4 py-3 text-sm text-slate-500">Loading…</p>
            : list.data.items.length === 0 ? <p className="px-4 py-6 text-center text-sm text-slate-500">No notifications yet.</p>
            : (
              <ul className="max-h-96 divide-y divide-slate-100 overflow-y-auto">
                {list.data.items.map((n) => (
                  <li key={n.id}>
                    <button onClick={() => openItem(n)} className={`block w-full px-4 py-2.5 text-left hover:bg-slate-50 ${n.read_at ? "" : "bg-blue-50/60"}`}>
                      <span className="block text-sm font-medium text-slate-800">{n.title}</span>
                      {n.body && <span className="mt-0.5 block text-xs text-slate-600">{n.body}</span>}
                      <span className="mt-0.5 block text-xs text-slate-400">{timeAgo(n.created_at)}</span>
                    </button>
                  </li>
                ))}
              </ul>
            )}
          <Link href="/notifications" onClick={() => setOpen(false)} className="block border-t border-slate-100 px-4 py-2 text-center text-xs font-medium text-blue-600">
            All notifications and settings
          </Link>
        </div>
      )}
    </div>
  );
}
