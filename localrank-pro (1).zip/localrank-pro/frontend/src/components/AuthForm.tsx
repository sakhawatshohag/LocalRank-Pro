"use client";

import { useMutation } from "@tanstack/react-query";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect, useState, type FormEvent } from "react";

import { Button, ErrorState, Field, Input } from "@/components/ui";
import { useAuth } from "@/lib/auth";
import type { Token } from "@/lib/types";
import { fieldErrors, loginSchema, registerSchema } from "@/lib/validation";

const FIELDS = {
  login: [["email", "Email", "email"], ["password", "Password", "password"]],
  register: [["full_name", "Your name", "text"], ["organization_name", "Agency or business name", "text"], ["email", "Email", "email"], ["password", "Password (at least 10 characters)", "password"]],
} as const;

const ALLOW_SIGNUP = process.env.NEXT_PUBLIC_ALLOW_SIGNUP !== "false";

export function AuthForm({ mode }: { mode: "login" | "register" }) {
  const { api, signIn, token, ready } = useAuth();
  const router = useRouter();
  const [values, setValues] = useState<Record<string, string>>({});
  const [errors, setErrors] = useState<Record<string, string>>({});

  useEffect(() => { if (ready && token) router.replace("/dashboard"); }, [ready, token, router]);

  const submit = useMutation({
    mutationFn: (body: unknown) => api.post<Token>(mode === "login" ? "/auth/login" : "/auth/register", body),
    onSuccess: (t) => { signIn(t.access_token); router.replace("/dashboard"); },
  });

  function onSubmit(e: FormEvent) {
    e.preventDefault();
    const parsed = (mode === "login" ? loginSchema : registerSchema).safeParse(
      Object.fromEntries(FIELDS[mode].map(([name]) => [name, values[name] ?? ""])));
    if (!parsed.success) return setErrors(fieldErrors(parsed.error));
    setErrors({});
    submit.mutate(parsed.data);
  }

  if (mode === "register" && !ALLOW_SIGNUP) {
    return (
      <main className="flex min-h-screen items-center justify-center bg-navy-900 p-4">
        <div className="w-full max-w-sm rounded-xl bg-white p-6 shadow-xl">
          <p className="text-lg font-semibold text-navy-900">LocalRank Pro</p>
          <p className="mt-3 text-sm text-slate-600">Accounts are created by your account manager. Please contact them for access.</p>
          <Link className="mt-4 inline-block text-sm font-medium text-blue-600" href="/login">Back to sign in</Link>
        </div>
      </main>
    );
  }

  return (
    <main className="flex min-h-screen items-center justify-center bg-navy-900 p-4">
      <div className="w-full max-w-sm rounded-xl bg-white p-6 shadow-xl">
        <p className="text-lg font-semibold text-navy-900">LocalRank Pro</p>
        <h1 className="mt-1 text-sm text-slate-500">{mode === "login" ? "Sign in to your account" : "Create your account"}</h1>
        <form onSubmit={onSubmit} noValidate className="mt-5 space-y-4">
          {FIELDS[mode].map(([name, label, type]) => (
            <Field key={name} label={label} error={errors[name]}>
              <Input type={type} name={name} value={values[name] ?? ""} autoComplete={name === "password" ? (mode === "login" ? "current-password" : "new-password") : name === "email" ? "email" : "on"}
                onChange={(e) => setValues((v) => ({ ...v, [name]: e.target.value }))} />
            </Field>
          ))}
          {submit.isError && <ErrorState error={submit.error} />}
          <Button type="submit" loading={submit.isPending} className="w-full">{mode === "login" ? "Sign in" : "Create account"}</Button>
        </form>
        <p className="mt-4 text-center text-sm text-slate-500">
          {mode === "login" ? (ALLOW_SIGNUP ? <>No account? <Link className="font-medium text-blue-600" href="/register">Create one</Link></>
                                            : <>No account? Ask your account manager.</>)
                            : <>Already registered? <Link className="font-medium text-blue-600" href="/login">Sign in</Link></>}
        </p>
      </div>
    </main>
  );
}
