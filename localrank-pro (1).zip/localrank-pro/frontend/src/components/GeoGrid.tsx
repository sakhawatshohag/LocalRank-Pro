"use client";

// GeoGrid display.  With a Google Maps key it renders an interactive map; without one it
// renders the same grid as a plain matrix (north at the top) so results are always visible.
import { importLibrary, setOptions } from "@googlemaps/js-api-loader";
import { useEffect, useRef, useState } from "react";

import { BUCKETS, LEGEND_ORDER, type Bucket } from "@/lib/geogrid";

const MAPS_KEY = process.env.NEXT_PUBLIC_GOOGLE_MAPS_API_KEY ?? "";
const MAP_ID = process.env.NEXT_PUBLIC_GOOGLE_MAPS_MAP_ID ?? "DEMO_MAP_ID";
let loaderConfigured = false;

export interface MarkerStyle { label: string; bg: string; fg: string; dashed?: boolean }
export interface GridMarker {
  index: number; row: number; col: number; lat: number; lng: number; label: string; bucket: Bucket;
  /** Overrides the rank colours, e.g. for change or dominance maps. */
  style?: MarkerStyle;
}
const styleOf = (m: GridMarker): MarkerStyle => m.style ?? { ...BUCKETS[m.bucket], dashed: m.bucket === "error" };

interface Props {
  markers: GridMarker[];
  center: { lat: number; lng: number };
  selected?: number | null;
  onSelect?: (index: number) => void;
  /** When set, a draggable pin lets the user move the grid centre. */
  onCenterChange?: (center: { lat: number; lng: number }) => void;
  height?: number;
}

function markerElement(m: GridMarker, selected: boolean): HTMLElement {
  const el = document.createElement("div");
  const b = styleOf(m);
  el.textContent = m.label;
  el.title = `Point ${m.index + 1}: ${b.label}`;
  Object.assign(el.style, {
    width: m.label.length > 3 ? "44px" : "34px", height: "34px", borderRadius: "9999px", display: "flex", alignItems: "center",
    justifyContent: "center", fontSize: "12px", fontWeight: "700", cursor: "pointer",
    background: b.bg, color: b.fg, boxShadow: "0 1px 3px rgba(0,0,0,.4)",
    border: b.dashed ? "2px dashed #b91c1c" : selected ? "3px solid #0b1f3a" : "2px solid #ffffff",
  });
  return el;
}

export function GeoGrid(props: Props) {
  return MAPS_KEY ? <MapGrid {...props} /> : <MatrixGrid {...props} />;
}

function MapGrid({ markers, center, selected, onSelect, onCenterChange, height = 520 }: Props) {
  const container = useRef<HTMLDivElement>(null);
  const map = useRef<google.maps.Map | null>(null);
  const drawn = useRef<google.maps.marker.AdvancedMarkerElement[]>([]);
  const centerPin = useRef<google.maps.marker.AdvancedMarkerElement | null>(null);
  const fitted = useRef("");
  const [ready, setReady] = useState(false);
  const [failed, setFailed] = useState<string | null>(null);
  const [fullscreen, setFullscreen] = useState(false);
  const onSelectRef = useRef(onSelect);
  const onCenterRef = useRef(onCenterChange);
  onSelectRef.current = onSelect;
  onCenterRef.current = onCenterChange;

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        if (!loaderConfigured) {
          setOptions({ key: MAPS_KEY, v: "weekly" });
          loaderConfigured = true;
        }
        const { Map } = await importLibrary("maps");
        await importLibrary("marker");
        if (cancelled || !container.current) return;
        map.current = new Map(container.current, {
          center, zoom: 12, mapId: MAP_ID, streetViewControl: false, mapTypeControl: false, fullscreenControl: false,
        });
        setReady(true);
      } catch (e) {
        if (!cancelled) setFailed(e instanceof Error ? e.message : "Google Maps could not be loaded");
      }
    })();
    return () => { cancelled = true; };
    // the map is created once; later centre changes are handled below
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (!ready || !map.current) return;
    drawn.current.forEach((m) => { m.map = null; });
    drawn.current = markers.map((m) => {
      const marker = new google.maps.marker.AdvancedMarkerElement({
        map: map.current, position: { lat: m.lat, lng: m.lng }, content: markerElement(m, m.index === selected),
        zIndex: m.index === selected ? 1000 : undefined,
      });
      marker.addListener("click", () => onSelectRef.current?.(m.index));
      return marker;
    });
    // fit the view only when the grid geometry changes, not on every result update
    const shape = markers.length ? `${markers[0].lat},${markers[0].lng},${markers.length},${markers[markers.length - 1].lat}` : "";
    if (shape && shape !== fitted.current) {
      const bounds = new google.maps.LatLngBounds();
      markers.forEach((m) => bounds.extend({ lat: m.lat, lng: m.lng }));
      map.current.fitBounds(bounds, 48);
      fitted.current = shape;
    }
  }, [ready, markers, selected]);

  useEffect(() => {
    if (!ready || !map.current) return;
    if (!onCenterRef.current) {
      if (centerPin.current) { centerPin.current.map = null; centerPin.current = null; }
      return;
    }
    if (!centerPin.current) {
      const pin = new google.maps.marker.AdvancedMarkerElement({ map: map.current, position: center, gmpDraggable: true, title: "Drag to move the grid centre", zIndex: 2000 });
      pin.addListener("dragend", () => {
        const pos = pin.position;
        if (!pos) return;
        const lat = typeof pos.lat === "function" ? pos.lat() : pos.lat;
        const lng = typeof pos.lng === "function" ? pos.lng() : pos.lng;
        onCenterRef.current?.({ lat, lng });
      });
      centerPin.current = pin;
    } else {
      centerPin.current.position = center;
    }
  }, [ready, center, onCenterChange]);

  if (failed) {
    return (
      <div>
        <p role="alert" className="mb-2 rounded-md border border-amber-300 bg-amber-50 px-3 py-2 text-sm text-amber-900">
          Google Maps could not be loaded ({failed}). Showing the grid without a map.
        </p>
        <MatrixGrid markers={markers} center={center} selected={selected} onSelect={onSelect} />
      </div>
    );
  }
  return (
    <div className={fullscreen ? "fixed inset-0 z-40 bg-white p-3" : "relative"}>
      <div ref={container} style={{ height: fullscreen ? "calc(100vh - 24px)" : height }} className="w-full rounded-lg border border-slate-200" />
      <button type="button" onClick={() => setFullscreen((f) => !f)}
        className="absolute right-3 top-3 rounded-md bg-white px-3 py-1.5 text-xs font-medium shadow">
        {fullscreen ? "Exit full screen" : "Full screen"}
      </button>
    </div>
  );
}

function MatrixGrid({ markers, selected, onSelect }: Props) {
  const size = Math.max(1, Math.round(Math.sqrt(markers.length)));
  const ordered = [...markers].sort((a, b) => a.row - b.row || a.col - b.col);
  return (
    <div className="rounded-lg border border-slate-200 bg-slate-100 p-4">
      <p className="mb-3 text-xs text-slate-500">Grid view (north at the top). Add a Google Maps key to see this on a map.</p>
      <div className="mx-auto grid w-fit gap-1.5" style={{ gridTemplateColumns: `repeat(${size}, minmax(0, 1fr))` }}>
        {ordered.map((m) => {
          const b = styleOf(m);
          return (
            <button key={m.index} type="button" onClick={() => onSelect?.(m.index)} title={`Point ${m.index + 1}: ${b.label}`}
              aria-label={`Point ${m.index + 1}: ${b.label}${m.bucket === "pending" && !m.style ? "" : `, ${m.label}`}`}
              style={{ background: b.bg, color: b.fg, borderColor: b.dashed ? "#b91c1c" : m.index === selected ? "#0b1f3a" : "#ffffff" }}
              className={`flex h-9 min-w-9 items-center justify-center rounded-full px-1 text-[11px] font-bold shadow ${b.dashed ? "border-2 border-dashed" : m.index === selected ? "border-[3px]" : "border-2"}`}>
              {m.label}
            </button>
          );
        })}
      </div>
    </div>
  );
}

export function Legend({ counts, active, onToggle }: { counts?: Record<Bucket, number>; active?: Set<Bucket>; onToggle?: (b: Bucket) => void }) {
  return (
    <ul className="flex flex-wrap gap-2 text-xs">
      {LEGEND_ORDER.map((b) => {
        const off = active ? !active.has(b) : false;
        return (
          <li key={b}>
            <button type="button" disabled={!onToggle} onClick={() => onToggle?.(b)} aria-pressed={!off}
              className={`flex items-center gap-1.5 rounded-full border border-slate-200 bg-white px-2.5 py-1 ${off ? "opacity-40" : ""}`}>
              <span className="inline-block h-3 w-3 rounded-full" style={{ background: BUCKETS[b].bg, border: b === "error" ? "1px dashed #b91c1c" : undefined }} />
              {BUCKETS[b].label}
              {counts && <strong className="ml-1">{counts[b]}</strong>}
            </button>
          </li>
        );
      })}
    </ul>
  );
}

/** Legend for change and dominance maps (any ordered set of swatches with counts). */
export function SwatchLegend<K extends string>({ order, swatches, counts }: { order: K[]; swatches: Record<K, MarkerStyle>; counts?: Record<K, number> }) {
  return (
    <ul className="flex flex-wrap gap-2 text-xs">
      {order.map((k) => (
        <li key={k} className="flex items-center gap-1.5 rounded-full border border-slate-200 bg-white px-2.5 py-1">
          <span className="inline-block h-3 w-3 rounded-full" style={{ background: swatches[k].bg, border: swatches[k].dashed ? "1px dashed #b91c1c" : undefined }} />
          {swatches[k].label}
          {counts && <strong className="ml-1">{counts[k] ?? 0}</strong>}
        </li>
      ))}
    </ul>
  );
}
