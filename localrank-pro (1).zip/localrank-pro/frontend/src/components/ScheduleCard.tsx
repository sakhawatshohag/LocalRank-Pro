"use client";

import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect, useState } from "react";

import { Badge, Button, Card, ConfirmDialog, ErrorState, Field, Input, Notice, Select, Skeleton } from "@/components/ui";
import { useApi, useAuth } from "@/lib/auth";
import { roleAtLeast } from "@/lib/nav";
import { FREQUENCIES, allowanceShare, describeSchedule, validateSchedule } from "@/lib/schedule";
import type { Frequency, ScheduleResponse } from "@/lib/types";

export function ScheduleCard({ campaignId }: { campaignId: string }) {
  const api = useApi();
  const qc = useQueryClient();
  const { me } = useAuth();
  const canEdit = !!me && roleAtLeast(me.role, "seo_specialist");
  const canDelete = !!me && roleAtLeast(me.role, "manager");
  const [form, setForm] = useState<{ frequency: Frequency; interval_days: string; local_time: string }>({ frequency: "weekly", interval_days: "3", local_time: "06:00" });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [editing, setEditing] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState(false);

  const current = useQuery({ queryKey: ["schedule", campaignId], queryFn: () => api.get<ScheduleResponse>(`/campaigns/${campaignId}/schedule`) });
  const validDays = form.frequency !== "custom" || Object.keys(validateSchedule("custom", form.interval_days, "00:00")).length === 0;
  const preview = useQuery({
    queryKey: ["schedule-preview", campaignId, form.frequency, form.interval_days],
    queryFn: () => api.get<ScheduleResponse>(`/campaigns/${campaignId}/schedule`,
      { frequency: form.frequency, interval_days: form.frequency === "custom" ? form.interval_days : null }),
    enabled: editing && validDays,
  });

  useEffect(() => {
    const s = current.data?.schedule;
    if (s) setForm({ frequency: s.frequency, interval_days: String(s.interval_days ?? 3), local_time: s.local_time });
  }, [current.data]);

  const refresh = () => { qc.invalidateQueries({ queryKey: ["schedule", campaignId] }); qc.invalidateQueries({ queryKey: ["schedules"] }); };
  const save = useMutation({
    mutationFn: (body: unknown) => api.put<ScheduleResponse>(`/campaigns/${campaignId}/schedule`, body),
    onSuccess: () => { setEditing(false); refresh(); },
  });
  const remove = useMutation({ mutationFn: () => api.del(`/campaigns/${campaignId}/schedule`), onSuccess: () => { setConfirmDelete(false); refresh(); } });

  if (current.isError) return <Card title="Scheduled scans"><ErrorState error={current.error} onRetry={() => current.refetch()} /></Card>;
  if (!current.data) return <Card title="Scheduled scans"><Skeleton rows={3} /></Card>;
  const { schedule, time_zone } = current.data;
  const projection = (editing ? preview.data?.projection : undefined) ?? current.data.projection;
  const share = allowanceShare(projection);

  function submit(paused: boolean) {
    const errs = validateSchedule(form.frequency, form.interval_days, form.local_time);
    if (Object.keys(errs).length) return setErrors(errs);
    setErrors({});
    save.mutate({ frequency: form.frequency, interval_days: form.frequency === "custom" ? Number(form.interval_days) : null, local_time: form.local_time, is_paused: paused });
  }

  return (
    <Card title="Scheduled scans" actions={schedule && !editing && (schedule.is_paused ? <Badge>Paused</Badge> : <Badge tone="green">Active</Badge>)}>
      {schedule && !editing ? (
        <div className="space-y-2 text-sm">
          <p className="font-medium">{describeSchedule(schedule.frequency, schedule.interval_days, schedule.local_time, time_zone)}</p>
          <p className="text-slate-600">Next run: {schedule.is_paused || !schedule.next_run_at ? "—" : new Date(schedule.next_run_at).toLocaleString()}</p>
          <p className="text-slate-600">Last run: {schedule.last_run_at ? new Date(schedule.last_run_at).toLocaleString() : "Not yet"}</p>
          {schedule.last_error && <Notice>Last run was skipped: {schedule.last_error}</Notice>}
          {canEdit && (
            <div className="flex flex-wrap gap-2 pt-2">
              <Button variant="secondary" onClick={() => { save.reset(); setEditing(true); }}>Edit</Button>
              <Button variant="secondary" loading={save.isPending}
                onClick={() => save.mutate({ frequency: schedule.frequency, interval_days: schedule.interval_days, local_time: schedule.local_time, is_paused: !schedule.is_paused })}>
                {schedule.is_paused ? "Resume" : "Pause"}
              </Button>
              {canDelete && <Button variant="ghost" onClick={() => { remove.reset(); setConfirmDelete(true); }}>Remove schedule</Button>}
            </div>
          )}
          {save.isError && <ErrorState error={save.error} />}
        </div>
      ) : !canEdit ? (
        <p className="text-sm text-slate-500">No schedule. Scans run only when started manually.</p>
      ) : !editing ? (
        <div className="text-sm text-slate-500">
          <p>No schedule yet. Scans run only when started manually.</p>
          <Button className="mt-3" onClick={() => setEditing(true)}>Set up a schedule</Button>
        </div>
      ) : (
        <div className="space-y-3">
          <div className="grid grid-cols-2 gap-3">
            <Field label="Frequency">
              <Select value={form.frequency} onChange={(e) => setForm({ ...form, frequency: e.target.value as Frequency })}>
                {FREQUENCIES.map((f) => <option key={f.value} value={f.value}>{f.label}</option>)}
              </Select>
            </Field>
            <Field label={`Time (${time_zone})`} error={errors.local_time}>
              <Input type="time" value={form.local_time} onChange={(e) => setForm({ ...form, local_time: e.target.value })} />
            </Field>
            {form.frequency === "custom" && (
              <Field label="Every how many days" error={errors.interval_days}>
                <Input inputMode="numeric" value={form.interval_days} onChange={(e) => setForm({ ...form, interval_days: e.target.value })} />
              </Field>
            )}
          </div>
          <p className="text-xs text-slate-500">Runs in the business location&apos;s time zone. Missed runs are not repeated later.</p>
          {save.isError && <ErrorState error={save.error} />}
          <div className="flex gap-2">
            <Button loading={save.isPending} onClick={() => submit(false)}>Save schedule</Button>
            <Button variant="secondary" onClick={() => { setEditing(false); setErrors({}); }}>Cancel</Button>
          </div>
        </div>
      )}

      <div className="mt-4 border-t border-slate-100 pt-3 text-xs text-slate-600">
        <p>
          {projection.active_keywords} active keyword{projection.active_keywords === 1 ? "" : "s"} × {projection.points_per_run / Math.max(projection.active_keywords, 1)} points
          {" "}= {projection.points_per_run} requests per run, about {projection.runs_per_month} runs a month ({projection.points_per_month} requests).
        </p>
        <p className="mt-1">
          Estimated cost: {projection.estimated_cost_per_run_usd === null ? "unknown (no ranking provider configured)"
            : `$${projection.estimated_cost_per_run_usd} per run, about $${projection.estimated_cost_per_month_usd} a month`}.
        </p>
        <p className="mt-1">
          This month: {projection.monthly_points_used} of {projection.monthly_points_limit} grid points used
          {share !== null && <>; this schedule alone needs about {share}% of the monthly allowance</>}.
        </p>
        {share !== null && share > 100 && <p className="mt-1 font-medium text-red-700">This schedule needs more than your monthly allowance; later runs will be skipped.</p>}
      </div>

      {confirmDelete && (
        <ConfirmDialog title="Remove schedule" confirmLabel="Remove" danger loading={remove.isPending}
          text={<>Stop scheduled scans for this campaign? Scans that already ran stay in history.{remove.isError && <span className="mt-2 block text-red-600">{remove.error.message}</span>}</>}
          onConfirm={() => remove.mutate()} onCancel={() => setConfirmDelete(false)} />
      )}
    </Card>
  );
}
