"use client";

import { useMutation, useQuery } from "@tanstack/react-query";
import { useParams, useRouter } from "next/navigation";
import { useState, type FormEvent } from "react";

import { Button, ErrorState, Field, Input, Skeleton } from "@/components/ui";
import { useAuth } from "@/lib/auth";
import type { Token } from "@/lib/types";

export default function AcceptInvitePage() {
  const { token } = useParams<{ token: string }>();
  const { api, signIn } = useAuth();
  const router = useRouter();
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const preview = useQuery({ queryKey: ["invite", token], queryFn: () => api.get<{ organization: string; email: string; role: string; account_exists: boolean }>(`/auth/invitations/${token}`), retry: false });
  const accept = useMutation({
    mutationFn: () => api.post<Token>("/auth/accept-invite", { token, password, full_name: name || null }),
    onSuccess: (t) => { signIn(t.access_token); router.replace("/dashboard"); },
  });
  const submit = (e: FormEvent) => { e.preventDefault(); accept.mutate(); };
  const tooShort = !preview.data?.account_exists && password.length < 10;

  return (
    <main className="flex min-h-screen items-center justify-center bg-navy-900 p-4">
      <div className="w-full max-w-sm rounded-xl bg-white p-6 shadow-xl">
        <p className="text-lg font-semibold text-navy-900">LocalRank Pro</p>
        {preview.isError ? <div className="mt-4"><ErrorState error={preview.error} /></div>
          : !preview.data ? <div className="mt-4"><Skeleton rows={3} /></div>
          : (
            <form onSubmit={submit} className="mt-4 space-y-4">
              <p className="text-sm text-slate-600">You are invited to <strong>{preview.data.organization}</strong> as <strong>{preview.data.role.replace("_", " ")}</strong> with <strong>{preview.data.email}</strong>.</p>
              {!preview.data.account_exists && <Field label="Your name"><Input value={name} onChange={(e) => setName(e.target.value)} /></Field>}
              <Field label={preview.data.account_exists ? "Your existing password" : "Choose a password (at least 10 characters)"}>
                <Input type="password" autoComplete={preview.data.account_exists ? "current-password" : "new-password"} value={password} onChange={(e) => setPassword(e.target.value)} />
              </Field>
              {accept.isError && <ErrorState error={accept.error} />}
              <Button type="submit" className="w-full" loading={accept.isPending} disabled={!password || tooShort}>Accept invitation</Button>
            </form>
          )}
      </div>
    </main>
  );
}
