"use client";

import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";

import { Badge, Button, Card, ConfirmDialog, ErrorState, Field, Input, Notice, PageHeader, Select, Skeleton, Table, Td, Th } from "@/components/ui";
import { useApi, useAuth } from "@/lib/auth";
import { assignableRoles, canManageMember } from "@/lib/billing";
import { roleAtLeast } from "@/lib/nav";
import type { Invitation, Role, TeamMember } from "@/lib/types";

const ROLE_LABEL: Record<Role, string> = { owner: "Owner", admin: "Admin", manager: "Manager", seo_specialist: "SEO Specialist", client_viewer: "Client Viewer" };

export default function TeamPage() {
  const api = useApi();
  const qc = useQueryClient();
  const { me } = useAuth();
  const role = me?.role ?? "client_viewer";
  const isAdmin = roleAtLeast(role, "admin");
  const team = useQuery({ queryKey: ["team"], queryFn: () => api.get<{ members: TeamMember[]; invitations: Invitation[] }>("/team") });
  const refresh = () => qc.invalidateQueries({ queryKey: ["team"] });
  const [email, setEmail] = useState("");
  const [inviteRole, setInviteRole] = useState<Role>("seo_specialist");
  const [link, setLink] = useState<string | null>(null);
  const [removing, setRemoving] = useState<TeamMember | null>(null);
  const invite = useMutation({ mutationFn: () => api.post<{ invite_url: string }>("/team/invitations", { email: email.trim(), role: inviteRole }),
    onSuccess: (r) => { setLink(r.invite_url); setEmail(""); refresh(); } });
  const revoke = useMutation({ mutationFn: (id: string) => api.del(`/team/invitations/${id}`), onSuccess: refresh });
  const changeRole = useMutation({ mutationFn: (v: { id: string; role: Role }) => api.patch(`/team/members/${v.id}`, { role: v.role }), onSuccess: refresh });
  const remove = useMutation({ mutationFn: (id: string) => api.del(`/team/members/${id}`), onSuccess: () => { setRemoving(null); refresh(); } });

  if (team.isError) return <ErrorState error={team.error} onRetry={() => team.refetch()} />;
  if (!team.data) return <Skeleton rows={6} />;
  // owners can make others owner too; admins only assign roles below admin (mirrors the API)
  const roleOptions = (): Role[] => (role === "owner" ? ["owner" as Role, ...assignableRoles(role)] : assignableRoles(role));

  return (
    <>
      <PageHeader title="Team Management" subtitle="Owners manage everything; admins manage everyone below admin." />
      {(changeRole.isError || revoke.isError) && <div className="mb-3"><ErrorState error={changeRole.error ?? revoke.error} /></div>}
      <Table head={<><Th>Member</Th><Th>Role</Th><Th>Last sign-in</Th><Th /></>}>
        {team.data.members.map((m) => {
          const self = m.user_id === me?.user_id;
          const manageable = isAdmin && !self && canManageMember(role, m.role);
          return (
            <tr key={m.user_id}>
              <Td><span className="font-medium">{m.full_name || m.email}</span>{m.full_name && <span className="block text-xs text-slate-500">{m.email}</span>} {self && <Badge tone="blue">You</Badge>}</Td>
              <Td>
                {manageable ? (
                  <Select aria-label={`Role of ${m.email}`} value={m.role} className="w-44" onChange={(e) => changeRole.mutate({ id: m.user_id, role: e.target.value as Role })}>
                    {roleOptions().map((r) => <option key={r} value={r}>{ROLE_LABEL[r]}</option>)}
                  </Select>
                ) : ROLE_LABEL[m.role]}
              </Td>
              <Td>{m.last_login_at ? new Date(m.last_login_at).toLocaleString() : "Never"}</Td>
              <Td className="text-right">{(manageable || (self && role !== "owner")) && <Button variant="ghost" onClick={() => { remove.reset(); setRemoving(m); }}>{self ? "Leave" : "Remove"}</Button>}</Td>
            </tr>
          );
        })}
      </Table>

      {isAdmin && (
        <div className="mt-6 grid gap-6 lg:grid-cols-2">
          <Card title="Invite someone">
            <div className="grid gap-3 sm:grid-cols-[1fr_180px]">
              <Field label="Email"><Input type="email" value={email} onChange={(e) => setEmail(e.target.value)} /></Field>
              <Field label="Role">
                <Select value={inviteRole} onChange={(e) => setInviteRole(e.target.value as Role)}>
                  {assignableRoles(role).map((r) => <option key={r} value={r}>{ROLE_LABEL[r]}</option>)}
                </Select>
              </Field>
            </div>
            {invite.isError && <div className="mt-2"><ErrorState error={invite.error} /></div>}
            <Button className="mt-3" loading={invite.isPending} disabled={!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email.trim())} onClick={() => { setLink(null); invite.mutate(); }}>Create invitation link</Button>
            {link && (
              <div className="mt-3">
                <Notice tone="blue">Send this link to the person. It is shown only once and works for 7 days.</Notice>
                <div className="mt-2 flex gap-2">
                  <Input readOnly value={link} onFocus={(e) => e.target.select()} />
                  <Button variant="secondary" onClick={() => navigator.clipboard?.writeText(link)}>Copy</Button>
                </div>
              </div>
            )}
          </Card>
          <Card title={`Pending invitations (${team.data.invitations.length})`}>
            {team.data.invitations.length === 0 ? <p className="text-sm text-slate-500">None.</p> : (
              <ul className="divide-y divide-slate-100 text-sm">
                {team.data.invitations.map((i) => (
                  <li key={i.id} className="flex items-center justify-between py-2">
                    <span>{i.email} · {ROLE_LABEL[i.role]}<span className="block text-xs text-slate-500">
                      {Date.parse(i.expires_at) < Date.now() ? "Expired" : `Expires ${new Date(i.expires_at).toLocaleDateString()}`}</span></span>
                    <Button variant="ghost" onClick={() => revoke.mutate(i.id)}>Revoke</Button>
                  </li>
                ))}
              </ul>
            )}
          </Card>
        </div>
      )}
      {removing && (
        <ConfirmDialog title={removing.user_id === me?.user_id ? "Leave organization" : "Remove member"} danger confirmLabel={removing.user_id === me?.user_id ? "Leave" : "Remove"} loading={remove.isPending}
          text={<>{removing.user_id === me?.user_id ? "You will lose access to this organization." : <>Remove <strong>{removing.email}</strong>? Their account stays; they lose access to this organization.</>}{remove.isError && <span className="mt-2 block text-red-600">{remove.error.message}</span>}</>}
          onConfirm={() => remove.mutate(removing.user_id)} onCancel={() => setRemoving(null)} />
      )}
    </>
  );
}
