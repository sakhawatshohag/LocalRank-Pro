"use client";

import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect, useState, type ChangeEvent } from "react";

import { Badge, Button, Card, ErrorState, Field, Input, Notice, PageHeader, Select, Skeleton } from "@/components/ui";
import { useApi, useAuth } from "@/lib/auth";
import { roleAtLeast } from "@/lib/nav";
import { fileToDataUrl, isHexColor } from "@/lib/reports";
import type { BrandingSettings, Client } from "@/lib/types";

function LogoPreview({ path, version }: { path: string; version: number }) {
  const api = useApi();
  const [url, setUrl] = useState<string | null>(null);
  const [missing, setMissing] = useState(false);
  useEffect(() => {
    let current: string | null = null;
    api.blob(path).then((b) => { current = URL.createObjectURL(b); setUrl(current); setMissing(false); }, () => { setUrl(null); setMissing(true); });
    return () => { if (current) URL.revokeObjectURL(current); };
  }, [api, path, version]);
  if (missing) return <p className="text-xs text-slate-500">No logo uploaded.</p>;
  // eslint-disable-next-line @next/next/no-img-element
  return url ? <img src={url} alt="Logo" className="max-h-16 max-w-[240px] rounded border border-slate-200 bg-white p-1" /> : null;
}

function LogoUpload({ path, canEdit, label }: { path: string; canEdit: boolean; label: string }) {
  const api = useApi();
  const [version, setVersion] = useState(0);
  const [error, setError] = useState<Error | null>(null);
  const upload = useMutation({ mutationFn: (data: string) => api.put(path, { data_base64: data }), onSuccess: () => { setError(null); setVersion((v) => v + 1); } });
  const remove = useMutation({ mutationFn: () => api.del(path), onSuccess: () => setVersion((v) => v + 1) });
  async function onFile(e: ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (!file) return;
    try { upload.mutate(await fileToDataUrl(file)); } catch (err) { setError(err as Error); }
  }
  return (
    <div className="space-y-2">
      <p className="text-sm font-medium text-slate-700">{label}</p>
      <LogoPreview path={path} version={version} />
      {canEdit && (
        <div className="flex flex-wrap items-center gap-2">
          <label className="cursor-pointer rounded-md border border-slate-300 bg-white px-3 py-1.5 text-sm font-medium hover:bg-slate-50">
            {upload.isPending ? "Uploading…" : "Upload PNG, JPEG or WebP (max 1 MB)"}
            <input type="file" accept="image/png,image/jpeg,image/webp" className="hidden" onChange={onFile} />
          </label>
          <Button variant="ghost" onClick={() => remove.mutate()}>Remove</Button>
        </div>
      )}
      {(error || upload.isError) && <ErrorState error={error ?? upload.error} />}
    </div>
  );
}

export default function SettingsPage() {
  const api = useApi();
  const qc = useQueryClient();
  const { me } = useAuth();
  const isAdmin = !!me && roleAtLeast(me.role, "admin");
  const canClientLogo = !!me && roleAtLeast(me.role, "manager");
  const branding = useQuery({ queryKey: ["branding"], queryFn: () => api.get<BrandingSettings>("/branding") });
  const clients = useQuery({ queryKey: ["clients", "", false], queryFn: () => api.get<Client[]>("/clients") });
  const [form, setForm] = useState({ agency_name: "", website: "", email: "", phone: "", primary_color: "#0b1f3a", footer_text: "" });
  const [clientId, setClientId] = useState("");
  const [colorError, setColorError] = useState<string | null>(null);
  useEffect(() => {
    const b = branding.data;
    if (b) setForm({ agency_name: b.agency_name ?? "", website: b.website ?? "", email: b.email ?? "", phone: b.phone ?? "", primary_color: b.primary_color, footer_text: b.footer_text ?? "" });
  }, [branding.data]);
  useEffect(() => { if (!clientId && clients.data?.[0]) setClientId(clients.data[0].id); }, [clients.data, clientId]);
  const save = useMutation({
    mutationFn: (body: unknown) => api.put<BrandingSettings>("/branding", body),
    onSuccess: (data) => qc.setQueryData(["branding"], data),
  });
  function submit() {
    if (!isHexColor(form.primary_color)) return setColorError("Use a colour like #0b1f3a");
    setColorError(null);
    const clean = Object.fromEntries(Object.entries(form).map(([k, v]) => [k, v.trim() || null]));
    save.mutate({ ...clean, primary_color: form.primary_color });
  }

  if (branding.isError) return <ErrorState error={branding.error} onRetry={() => branding.refetch()} />;
  if (!branding.data) return <Skeleton rows={8} />;
  const fields: [keyof typeof form, string][] = [["agency_name", "Agency name"], ["website", "Website"], ["email", "Email"], ["phone", "Phone"], ["footer_text", "Report footer text"]];

  return (
    <>
      <PageHeader title="Settings" subtitle="Report branding" />
      <div className="grid gap-6 lg:grid-cols-2">
        <Card title="Agency branding on reports" actions={branding.data.white_label_enabled ? <Badge tone="green">White label</Badge> : <Badge>Standard</Badge>}>
          {!branding.data.white_label_enabled && (
            <div className="mb-3"><Notice tone="blue">Your plan adds a small “Generated with LocalRank Pro” line to report footers. White-label plans remove it.</Notice></div>
          )}
          <div className="grid gap-3 sm:grid-cols-2">
            {fields.map(([k, label]) => (
              <Field key={k} label={label}><Input value={form[k]} disabled={!isAdmin} onChange={(e) => setForm({ ...form, [k]: e.target.value })} /></Field>
            ))}
            <Field label="Brand colour" error={colorError ?? undefined}>
              <div className="flex gap-2">
                <input type="color" aria-label="Pick brand colour" value={isHexColor(form.primary_color) ? form.primary_color : "#0b1f3a"} disabled={!isAdmin}
                  onChange={(e) => setForm({ ...form, primary_color: e.target.value })} className="h-9 w-12 rounded border border-slate-300" />
                <Input value={form.primary_color} disabled={!isAdmin} onChange={(e) => setForm({ ...form, primary_color: e.target.value })} />
              </div>
            </Field>
          </div>
          {save.isError && <div className="mt-3"><ErrorState error={save.error} /></div>}
          {save.isSuccess && <p className="mt-3 text-sm text-green-700">Saved. New reports use these settings.</p>}
          {isAdmin ? <Button className="mt-4" loading={save.isPending} onClick={submit}>Save branding</Button>
                   : <p className="mt-3 text-xs text-slate-500">Only admins can change branding.</p>}
          <div className="mt-6 border-t border-slate-100 pt-4"><LogoUpload path="/branding/logo" canEdit={isAdmin} label="Agency logo" /></div>
        </Card>
        <Card title="Client logos">
          {clients.isError ? <ErrorState error={clients.error} /> : !clients.data ? <Skeleton rows={3} />
            : clients.data.length === 0 ? <p className="text-sm text-slate-500">No clients yet.</p>
            : (
              <>
                <Field label="Client">
                  <Select value={clientId} onChange={(e) => setClientId(e.target.value)}>
                    {clients.data.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
                  </Select>
                </Field>
                {clientId && <div className="mt-4"><LogoUpload key={clientId} path={`/clients/${clientId}/logo`} canEdit={canClientLogo} label="Logo shown on this client's reports" /></div>}
              </>
            )}
        </Card>
      </div>
    </>
  );
}
