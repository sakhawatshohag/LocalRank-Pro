"use client";

import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import Link from "next/link";
import { useEffect, useState } from "react";

import { Button, Card, EmptyState, ErrorState, PageHeader, Skeleton } from "@/components/ui";
import { useApi } from "@/lib/auth";
import { NOTIFICATION_LABELS, timeAgo } from "@/lib/schedule";
import type { NotificationList, NotificationPreference } from "@/lib/types";

export default function NotificationsPage() {
  const api = useApi();
  const qc = useQueryClient();
  const [unreadOnly, setUnreadOnly] = useState(false);
  const list = useQuery({ queryKey: ["notifications", "page", unreadOnly], queryFn: () => api.get<NotificationList>("/notifications", { unread_only: unreadOnly, limit: 100 }) });
  const prefs = useQuery({ queryKey: ["notification-prefs"], queryFn: () => api.get<NotificationPreference[]>("/notifications/preferences") });
  const [draft, setDraft] = useState<NotificationPreference[]>([]);
  useEffect(() => { if (prefs.data) setDraft(prefs.data); }, [prefs.data]);

  const markAll = useMutation({ mutationFn: () => api.post("/notifications/read-all"), onSuccess: () => qc.invalidateQueries({ queryKey: ["notifications"] }) });
  const markRead = useMutation({ mutationFn: (id: string) => api.post(`/notifications/${id}/read`), onSuccess: () => qc.invalidateQueries({ queryKey: ["notifications"] }) });
  const save = useMutation({
    mutationFn: (body: NotificationPreference[]) => api.put<NotificationPreference[]>("/notifications/preferences", body),
    onSuccess: (data) => qc.setQueryData(["notification-prefs"], data),
  });
  const dirty = JSON.stringify(draft) !== JSON.stringify(prefs.data ?? []);
  const toggle = (i: number, key: "in_app" | "email") => setDraft((d) => d.map((p, j) => (j === i ? { ...p, [key]: !p[key] } : p)));

  return (
    <>
      <PageHeader title="Notifications" actions={<Button variant="secondary" onClick={() => markAll.mutate()} loading={markAll.isPending}>Mark all read</Button>} />
      <div className="grid gap-6 lg:grid-cols-[1fr_380px]">
        <div>
          <label className="mb-3 flex items-center gap-2 text-sm text-slate-600">
            <input type="checkbox" checked={unreadOnly} onChange={(e) => setUnreadOnly(e.target.checked)} /> Unread only
          </label>
          {list.isError ? <ErrorState error={list.error} onRetry={() => list.refetch()} />
            : !list.data ? <Skeleton />
            : list.data.items.length === 0 ? <EmptyState title={unreadOnly ? "No unread notifications" : "No notifications yet"} />
            : (
              <ul className="divide-y divide-slate-100 rounded-lg border border-slate-200 bg-white">
                {list.data.items.map((n) => (
                  <li key={n.id} className={`flex items-start justify-between gap-3 px-4 py-3 ${n.read_at ? "" : "bg-blue-50/60"}`}>
                    <div>
                      <p className="text-sm font-medium">{n.link ? <Link href={n.link} onClick={() => !n.read_at && markRead.mutate(n.id)} className="text-blue-700">{n.title}</Link> : n.title}</p>
                      {n.body && <p className="mt-0.5 text-sm text-slate-600">{n.body}</p>}
                      <p className="mt-0.5 text-xs text-slate-400">{new Date(n.created_at).toLocaleString()} · {timeAgo(n.created_at)}</p>
                    </div>
                    {!n.read_at && <button className="shrink-0 text-xs text-blue-600" onClick={() => markRead.mutate(n.id)}>Mark read</button>}
                  </li>
                ))}
              </ul>
            )}
        </div>
        <Card title="What to notify me about">
          {prefs.isError ? <ErrorState error={prefs.error} onRetry={() => prefs.refetch()} />
            : !prefs.data ? <Skeleton rows={6} />
            : (
              <>
                <table className="w-full text-sm">
                  <thead><tr className="text-left text-xs text-slate-500"><th className="pb-2">Event</th><th className="pb-2 text-center">In app</th><th className="pb-2 text-center">Email</th></tr></thead>
                  <tbody>
                    {draft.map((p, i) => (
                      <tr key={p.type} className="border-t border-slate-100">
                        <td className="py-2">{NOTIFICATION_LABELS[p.type]}</td>
                        <td className="text-center"><input type="checkbox" aria-label={`${NOTIFICATION_LABELS[p.type]} in app`} checked={p.in_app} onChange={() => toggle(i, "in_app")} /></td>
                        <td className="text-center"><input type="checkbox" aria-label={`${NOTIFICATION_LABELS[p.type]} by email`} checked={p.email} onChange={() => toggle(i, "email")} /></td>
                      </tr>
                    ))}
                  </tbody>
                </table>
                <p className="mt-3 text-xs text-slate-500">Email delivery is not connected yet: your choice is saved and will be used once email sending is set up.</p>
                {save.isError && <div className="mt-2"><ErrorState error={save.error} /></div>}
                <Button className="mt-3" disabled={!dirty} loading={save.isPending} onClick={() => save.mutate(draft)}>Save preferences</Button>
              </>
            )}
        </Card>
      </div>
    </>
  );
}
