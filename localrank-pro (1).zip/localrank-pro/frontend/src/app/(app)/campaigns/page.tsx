"use client";

import { useQuery } from "@tanstack/react-query";
import Link from "next/link";

import { Badge, EmptyState, ErrorState, PageHeader, Skeleton, Table, Td, Th } from "@/components/ui";
import { useApi, useAuth } from "@/lib/auth";
import { formatDistance } from "@/lib/geogrid";
import { roleAtLeast } from "@/lib/nav";
import type { Campaign } from "@/lib/types";

const linkButton = "inline-flex rounded-md bg-blue-600 px-3.5 py-2 text-sm font-medium text-white hover:bg-blue-700";

export default function CampaignsPage() {
  const api = useApi();
  const { me } = useAuth();
  const canCreate = !!me && roleAtLeast(me.role, "seo_specialist");
  const list = useQuery({ queryKey: ["campaigns"], queryFn: () => api.get<Campaign[]>("/campaigns") });
  return (
    <>
      <PageHeader title="Rank Tracking" subtitle="A campaign tracks keywords for one location on a fixed grid."
        actions={canCreate && <Link href="/campaigns/new" className={linkButton}>New campaign</Link>} />
      {list.isError ? <ErrorState error={list.error} onRetry={() => list.refetch()} />
        : !list.data ? <Skeleton />
        : list.data.length === 0 ? (
          <EmptyState title="No campaigns yet" text="Create a campaign to choose a grid and start tracking keywords."
            action={canCreate ? <Link href="/campaigns/new" className={linkButton}>New campaign</Link> : undefined} />
        ) : (
          <Table head={<><Th>Campaign</Th><Th>Location</Th><Th>Grid</Th><Th>Keywords</Th><Th>Competitors</Th><Th>Last scan</Th><Th>Status</Th></>}>
            {list.data.map((c) => (
              <tr key={c.id}>
                <Td><Link className="font-medium text-blue-600" href={`/campaigns/${c.id}`}>{c.name}</Link></Td>
                <Td>{c.location_name}</Td>
                <Td>{c.grid_size}×{c.grid_size} · {formatDistance(c.spacing_m)} apart</Td>
                <Td>{c.keyword_count ?? 0}</Td><Td>{c.competitor_count ?? 0}</Td>
                <Td>{c.last_scan_at ? new Date(c.last_scan_at).toLocaleString() : "Never"}</Td>
                <Td>{c.is_active ? <Badge tone="green">Active</Badge> : <Badge>Paused</Badge>}</Td>
              </tr>
            ))}
          </Table>
        )}
    </>
  );
}
