"use client";

import { useMutation, useQuery } from "@tanstack/react-query";
import { useRouter } from "next/navigation";
import { useMemo, useState, type FormEvent } from "react";

import { GeoGrid, type GridMarker } from "@/components/GeoGrid";
import { Button, Card, EmptyState, ErrorState, Field, Input, Notice, PageHeader, Select, Skeleton } from "@/components/ui";
import { useApi } from "@/lib/auth";
import { GRID_SIZES, formatDistance } from "@/lib/geogrid";
import type { BusinessLocation, Campaign, GridPreview } from "@/lib/types";
import { campaignSchema, fieldErrors } from "@/lib/validation";

export default function NewCampaignPage() {
  const api = useApi();
  const router = useRouter();
  const locations = useQuery({ queryKey: ["locations", "", ""], queryFn: () => api.get<BusinessLocation[]>("/locations") });
  const [form, setForm] = useState({ location_id: "", name: "", grid_size: "7", spacing_m: "500", language_code: "en", device: "desktop", zoom: "15", depth: "100" });
  const [customSize, setCustomSize] = useState(false);
  const [center, setCenter] = useState<{ lat: number; lng: number } | null>(null);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const location = locations.data?.find((l) => l.id === form.location_id);
  const effectiveCenter = center ?? (location ? { lat: location.latitude, lng: location.longitude } : null);

  const size = Number(form.grid_size), spacing = Number(form.spacing_m);
  const previewable = !!effectiveCenter && Number.isInteger(size) && size % 2 === 1 && size >= 1 && size <= 21 && spacing >= 50;
  const preview = useQuery({
    queryKey: ["grid-preview", effectiveCenter, size, spacing, form.depth],
    queryFn: () => api.post<GridPreview>("/grid/preview", { center_lat: effectiveCenter!.lat, center_lng: effectiveCenter!.lng, grid_size: size, spacing_m: spacing, depth: Number(form.depth) || 100 }),
    enabled: previewable,
  });
  const markers = useMemo<GridMarker[]>(
    () => (preview.data?.points ?? []).map((p) => ({ index: p.index, row: p.row, col: p.col, lat: p.lat, lng: p.lng, label: String(p.index + 1), bucket: "pending" as const })),
    [preview.data],
  );

  const create = useMutation({
    mutationFn: (body: unknown) => api.post<Campaign>("/campaigns", body),
    onSuccess: (c) => router.push(`/campaigns/${c.id}`),
  });
  function onSubmit(e: FormEvent) {
    e.preventDefault();
    const parsed = campaignSchema.safeParse({ ...form, center_lat: center?.lat ?? null, center_lng: center?.lng ?? null });
    if (!parsed.success) return setErrors(fieldErrors(parsed.error));
    setErrors({}); create.mutate(parsed.data);
  }
  const set = (k: keyof typeof form) => (e: { target: { value: string } }) => setForm({ ...form, [k]: e.target.value });

  if (locations.isError) return <ErrorState error={locations.error} onRetry={() => locations.refetch()} />;
  if (!locations.data) return <Skeleton />;
  if (locations.data.length === 0) return <EmptyState title="Add a location first" text="A campaign tracks rankings for one business location." />;

  return (
    <>
      <PageHeader title="New campaign" subtitle="The grid and search settings are fixed after creation, so every scan stays comparable." />
      <div className="grid gap-6 lg:grid-cols-[360px_1fr]">
        <Card title="Settings">
          <form onSubmit={onSubmit} noValidate className="space-y-4">
            <Field label="Business location" error={errors.location_id}>
              <Select value={form.location_id} onChange={(e) => { setForm({ ...form, location_id: e.target.value }); setCenter(null); }}>
                <option value="">Choose…</option>
                {locations.data.map((l) => <option key={l.id} value={l.id}>{l.name}{l.city ? ` (${l.city})` : ""}</option>)}
              </Select>
            </Field>
            {location && !location.place_id && !location.cid && (
              <Notice>This location has no Place ID or CID yet. You can create the campaign, but scans cannot run until one is added.</Notice>
            )}
            <Field label="Campaign name" error={errors.name}><Input value={form.name} onChange={set("name")} /></Field>
            <Field label="Grid size" error={errors.grid_size} hint={customSize ? "Odd number from 1 to 21" : undefined}>
              {customSize ? <Input inputMode="numeric" value={form.grid_size} onChange={set("grid_size")} />
                : <Select value={form.grid_size} onChange={(e) => (e.target.value === "custom" ? setCustomSize(true) : set("grid_size")(e))}>
                    {GRID_SIZES.map((n) => <option key={n} value={n}>{n}×{n} ({n * n} points)</option>)}
                    <option value="custom">Custom…</option>
                  </Select>}
            </Field>
            <Field label="Distance between points (metres)" error={errors.spacing_m}
              hint={previewable ? `Radius from centre to edge: ${formatDistance((spacing * (size - 1)) / 2)}` : undefined}>
              <Input inputMode="decimal" value={form.spacing_m} onChange={set("spacing_m")} />
            </Field>
            <div className="grid grid-cols-2 gap-3">
              <Field label="Search language" error={errors.language_code}><Input value={form.language_code} onChange={set("language_code")} /></Field>
              <Field label="Device"><Select value={form.device} onChange={set("device")}><option value="desktop">Desktop</option><option value="mobile">Mobile</option></Select></Field>
              <Field label="Map zoom" error={errors.zoom} hint="3–21. Part of the search setup."><Input inputMode="numeric" value={form.zoom} onChange={set("zoom")} /></Field>
              <Field label="Results depth" error={errors.depth} hint="Up to 100 costs the same."><Input inputMode="numeric" value={form.depth} onChange={set("depth")} /></Field>
            </div>
            {center && <button type="button" className="text-xs text-blue-600 underline" onClick={() => setCenter(null)}>Reset centre to the business location</button>}
            {create.isError && <ErrorState error={create.error} />}
            <Button type="submit" loading={create.isPending} className="w-full">Create campaign</Button>
          </form>
        </Card>
        <div className="space-y-4">
          {!effectiveCenter ? <EmptyState title="Choose a location to preview the grid" />
            : preview.isError ? <ErrorState error={preview.error} onRetry={() => preview.refetch()} />
            : !preview.data ? <Skeleton rows={8} />
            : <>
                <GeoGrid markers={markers} center={effectiveCenter} onCenterChange={setCenter} />
                <Card title="Cost per scan (estimate)">
                  <p className="text-sm">
                    <strong>{preview.data.estimate.api_requests}</strong> requests per keyword ≈ <strong>${preview.data.estimate.estimated_cost_usd}</strong>
                    {" "}at ${preview.data.estimate.unit_price_usd} per request.
                  </p>
                  <p className="mt-1 text-xs text-slate-500">
                    {preview.data.estimate.note}
                    {preview.data.estimate.price_verified_on && ` Price list checked on ${preview.data.estimate.price_verified_on}.`}
                  </p>
                </Card>
              </>}
        </div>
      </div>
    </>
  );
}
