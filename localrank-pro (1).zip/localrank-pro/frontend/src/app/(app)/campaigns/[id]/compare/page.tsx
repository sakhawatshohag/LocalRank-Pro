"use client";

import { useQuery } from "@tanstack/react-query";
import Link from "next/link";
import { useParams } from "next/navigation";
import { useMemo, useState } from "react";

import { GeoGrid, SwatchLegend, type GridMarker } from "@/components/GeoGrid";
import { TrendChart } from "@/components/TrendChart";
import { Card, EmptyState, ErrorState, Notice, PageHeader, Select, Skeleton } from "@/components/ui";
import { useApi } from "@/lib/auth";
import { CHANGES, CHANGE_ORDER, DATE_RANGES, TREND_METRICS, buildSeries, changeLabel, describeChange, type TrendMetric } from "@/lib/compare";
import { bucketFor, formatMetric, markerLabel } from "@/lib/geogrid";
import type { CampaignDetail, HistoryEntry, ScanComparison, ScanDetail, TrendEntry } from "@/lib/types";

const when = (s: { completed_at: string | null; created_at: string }) => new Date(s.completed_at ?? s.created_at).toLocaleString();

function rankMarkers(detail: ScanDetail | undefined): GridMarker[] {
  if (!detail) return [];
  return detail.points.map((p) => ({ index: p.point_index, row: p.row_no, col: p.col_no, lat: p.latitude, lng: p.longitude,
    label: markerLabel(p.result_status, p.position, detail.scan.depth), bucket: bucketFor(p.result_status, p.position) }));
}

export default function ComparePage() {
  const { id } = useParams<{ id: string }>();
  const api = useApi();
  const [keywordId, setKeywordId] = useState("");
  const [competitorId, setCompetitorId] = useState("");
  const [rangeIndex, setRangeIndex] = useState(DATE_RANGES.length - 1);
  const [previousId, setPreviousId] = useState("");
  const [currentId, setCurrentId] = useState("");
  const [metric, setMetric] = useState<TrendMetric>("average_position");
  const [selected, setSelected] = useState<number | null>(null);
  const days = DATE_RANGES[rangeIndex].days;

  const campaign = useQuery({ queryKey: ["campaign", id], queryFn: () => api.get<CampaignDetail>(`/campaigns/${id}`) });
  const keyword = keywordId || campaign.data?.keywords[0]?.id || "";
  const history = useQuery({
    queryKey: ["history", id, keyword, days],
    queryFn: () => api.get<HistoryEntry[]>(`/campaigns/${id}/history`, { keyword_id: keyword, days }),
    enabled: !!keyword,
  });
  const trend = useQuery({
    queryKey: ["trend", id, keyword, days],
    queryFn: () => api.get<TrendEntry[]>(`/campaigns/${id}/trend`, { keyword_id: keyword, days }),
    enabled: !!keyword,
  });

  // only scans with usable results can be compared; newest first
  const usable = useMemo(() => (history.data ?? []).filter((s) => s.status === "completed" || s.status === "partial").reverse(), [history.data]);
  const current = usable.find((s) => s.id === currentId) ?? usable[0];
  const previous = usable.find((s) => s.id === previousId && s.id !== current?.id) ?? usable.find((s) => s.id !== current?.id);
  const ready = !!current && !!previous;

  const comparison = useQuery({
    queryKey: ["compare", previous?.id, current?.id, competitorId],
    queryFn: () => api.get<ScanComparison>(`/scans/compare/${previous!.id}/${current!.id}`, { competitor_id: competitorId }),
    enabled: ready,
  });
  const prevDetail = useQuery({ queryKey: ["scan", previous?.id, competitorId], queryFn: () => api.get<ScanDetail>(`/scans/${previous!.id}`, { competitor_id: competitorId }), enabled: ready });
  const currDetail = useQuery({ queryKey: ["scan", current?.id, competitorId], queryFn: () => api.get<ScanDetail>(`/scans/${current!.id}`, { competitor_id: competitorId }), enabled: ready });

  const changeMarkers = useMemo<GridMarker[]>(() => {
    const coords = new Map((currDetail.data?.points ?? []).map((p) => [p.point_index, p]));
    return (comparison.data?.points ?? []).flatMap((c) => {
      const p = coords.get(c.point_index);
      if (!p) return [];
      return [{ index: c.point_index, row: p.row_no, col: p.col_no, lat: p.latitude, lng: p.longitude,
        label: changeLabel(c.change, c.delta), bucket: "pending" as const, style: CHANGES[c.change] }];
    });
  }, [comparison.data, currDetail.data]);
  const trendData = useMemo(() => buildSeries(trend.data ?? [], metric), [trend.data, metric]);

  if (campaign.isError) return <ErrorState error={campaign.error} onRetry={() => campaign.refetch()} />;
  if (!campaign.data) return <Skeleton rows={8} />;
  const c = campaign.data;
  if (c.keywords.length === 0) return <EmptyState title="No keywords yet" text="Add a keyword and run at least two scans to compare dates." />;
  const subject = competitorId ? c.competitors.find((x) => x.id === competitorId)?.name ?? "Competitor" : c.location_name;
  const cmp = comparison.data;
  const picked = selected !== null ? cmp?.points.find((p) => p.point_index === selected) : undefined;
  const center = { lat: c.center_lat, lng: c.center_lng };

  return (
    <>
      <PageHeader title="Historical rankings" subtitle={`${c.name} · ${subject}`}
        actions={<Link href={`/campaigns/${id}`} className="rounded-md border border-slate-300 bg-white px-3.5 py-2 text-sm font-medium">Back to campaign</Link>} />

      <div className="mb-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
        <label className="text-xs font-medium text-slate-600">Keyword
          <Select value={keyword} onChange={(e) => { setKeywordId(e.target.value); setPreviousId(""); setCurrentId(""); setSelected(null); }}>
            {c.keywords.map((k) => <option key={k.id} value={k.id}>{k.keyword}</option>)}
          </Select>
        </label>
        <label className="text-xs font-medium text-slate-600">Business
          <Select value={competitorId} onChange={(e) => { setCompetitorId(e.target.value); setSelected(null); }}>
            <option value="">{c.location_name} (you)</option>
            {c.competitors.map((x) => <option key={x.id} value={x.id}>{x.name}</option>)}
          </Select>
        </label>
        <label className="text-xs font-medium text-slate-600">Period
          <Select value={rangeIndex} onChange={(e) => { setRangeIndex(Number(e.target.value)); setPreviousId(""); setCurrentId(""); }}>
            {DATE_RANGES.map((r, i) => <option key={r.label} value={i}>{r.label}</option>)}
          </Select>
        </label>
        <label className="text-xs font-medium text-slate-600">Previous scan
          <Select value={previous?.id ?? ""} onChange={(e) => { setPreviousId(e.target.value); setSelected(null); }} disabled={!ready}>
            {usable.filter((s) => s.id !== current?.id).map((s) => <option key={s.id} value={s.id}>{when(s)}</option>)}
          </Select>
        </label>
        <label className="text-xs font-medium text-slate-600">Current scan
          <Select value={current?.id ?? ""} onChange={(e) => { setCurrentId(e.target.value); setSelected(null); }} disabled={usable.length === 0}>
            {usable.map((s) => <option key={s.id} value={s.id}>{when(s)}</option>)}
          </Select>
        </label>
      </div>

      {history.isError ? <ErrorState error={history.error} onRetry={() => history.refetch()} />
        : !history.data ? <Skeleton rows={6} />
        : !ready ? (
          <EmptyState title="Two scans with results are needed"
            text={`${usable.length} usable scan${usable.length === 1 ? "" : "s"} found for this keyword in the selected period. Scans that failed are not offered for comparison.`} />
        ) : comparison.isError ? <ErrorState error={comparison.error} onRetry={() => comparison.refetch()} />
        : !cmp ? <Skeleton rows={8} />
        : (
          <>
            {cmp.data_notice && <div className="mb-3"><Notice>{cmp.data_notice}</Notice></div>}
            <div className="mb-4 grid grid-cols-2 gap-3 md:grid-cols-4 lg:grid-cols-7">
              {CHANGE_ORDER.map((k) => (
                <Card key={k}><p className="text-xs text-slate-500">{CHANGES[k].label}</p><p className="mt-1 text-xl font-semibold text-navy-900">{cmp.counts[k]}</p></Card>
              ))}
            </div>
            <p className="mb-4 text-sm text-slate-600">
              <strong>{cmp.comparable_points}</strong> of {cmp.total_points} points are comparable (valid in both scans).
              {" "}Average position: {formatMetric(cmp.metrics.previous?.average_position)} → {formatMetric(cmp.metrics.current?.average_position)}.
              {cmp.average_delta !== null && <> Average change on points ranked in both scans: <strong>{cmp.average_delta > 0 ? "+" : ""}{cmp.average_delta}</strong> positions (positive = better).</>}
            </p>

            <div className="grid gap-4 lg:grid-cols-2">
              <Card title={`Previous · ${when(cmp.previous)}`}>
                {prevDetail.isError ? <ErrorState error={prevDetail.error} /> : !prevDetail.data ? <Skeleton rows={6} />
                  : <GeoGrid markers={rankMarkers(prevDetail.data)} center={center} selected={selected} onSelect={setSelected} height={380} />}
              </Card>
              <Card title={`Current · ${when(cmp.current)}`}>
                {currDetail.isError ? <ErrorState error={currDetail.error} /> : !currDetail.data ? <Skeleton rows={6} />
                  : <GeoGrid markers={rankMarkers(currDetail.data)} center={center} selected={selected} onSelect={setSelected} height={380} />}
              </Card>
            </div>

            <Card title="Change per point" className="mt-4">
              <div className="mb-3"><SwatchLegend order={CHANGE_ORDER} swatches={CHANGES} counts={cmp.counts} /></div>
              <GeoGrid markers={changeMarkers} center={center} selected={selected} onSelect={setSelected} height={380} />
              <p className="mt-3 text-sm text-slate-600">
                {picked ? <><strong>Point {picked.point_index + 1}:</strong> {describeChange(picked.change, picked.previous_position, picked.current_position, picked.delta)}.</>
                        : "Select a point to see its change."}
              </p>
            </Card>
          </>
        )}

      <Card title="Trend over time" className="mt-6"
        actions={<Select aria-label="Metric" value={metric} onChange={(e) => setMetric(e.target.value as TrendMetric)} className="w-48">
          {(Object.keys(TREND_METRICS) as TrendMetric[]).map((m) => <option key={m} value={m}>{TREND_METRICS[m].label}</option>)}
        </Select>}>
        {trend.isError ? <ErrorState error={trend.error} onRetry={() => trend.refetch()} />
          : !trend.data ? <Skeleton rows={5} />
          : <>
              <TrendChart dates={trendData.dates} series={trendData.series} metric={metric} />
              <p className="mt-2 text-xs text-slate-500">
                {trend.data.length} scan{trend.data.length === 1 ? "" : "s"} in this period, including {trend.data.filter((t) => t.businesses.length === 0).length} without usable data (shown as gaps).
                {trend.data.some((t) => t.is_demo) && " Includes demo data."}
              </p>
            </>}
      </Card>
    </>
  );
}
