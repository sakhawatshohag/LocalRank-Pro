"use client";

import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import Link from "next/link";
import { useParams, useRouter } from "next/navigation";
import { useState, type FormEvent } from "react";

import { ScheduleCard } from "@/components/ScheduleCard";
import { Badge, Button, Card, ConfirmDialog, EmptyState, ErrorState, Field, Input, PageHeader, Select, Skeleton, Table, Td, Th } from "@/components/ui";
import { ApiError } from "@/lib/api";
import { useApi, useAuth } from "@/lib/auth";
import { formatDistance, formatMetric } from "@/lib/geogrid";
import { roleAtLeast } from "@/lib/nav";
import type { CampaignDetail, HistoryEntry, LaunchResult } from "@/lib/types";
import { competitorSchema, fieldErrors, keywordSchema } from "@/lib/validation";

const STATUS_TONE = { queued: "blue", running: "blue", completed: "green", partial: "amber", failed: "red", cancelled: "gray" } as const;

export default function CampaignPage() {
  const { id } = useParams<{ id: string }>();
  const api = useApi();
  const router = useRouter();
  const qc = useQueryClient();
  const { me } = useAuth();
  const canEdit = !!me && roleAtLeast(me.role, "seo_specialist");
  const canDelete = !!me && roleAtLeast(me.role, "manager");

  const campaign = useQuery({ queryKey: ["campaign", id], queryFn: () => api.get<CampaignDetail>(`/campaigns/${id}`) });
  const refresh = () => { qc.invalidateQueries({ queryKey: ["campaign", id] }); qc.invalidateQueries({ queryKey: ["campaigns"] }); };

  const [keyword, setKeyword] = useState("");
  const [competitor, setCompetitor] = useState({ name: "", place_id: "", cid: "" });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [historyKeyword, setHistoryKeyword] = useState("");
  const [costConfirm, setCostConfirm] = useState<{ api_requests: number; estimated_cost_usd: string } | null>(null);
  const [removing, setRemoving] = useState<{ id: string; name: string } | null>(null);

  const addKeyword = useMutation({ mutationFn: (body: unknown) => api.post(`/campaigns/${id}/keywords`, body), onSuccess: () => { setKeyword(""); refresh(); } });
  const pauseKeyword = useMutation({ mutationFn: (k: { id: string; is_paused: boolean }) => api.patch(`/campaigns/${id}/keywords/${k.id}`, { is_paused: !k.is_paused }), onSuccess: refresh });
  const addCompetitor = useMutation({ mutationFn: (body: unknown) => api.post(`/campaigns/${id}/competitors`, body), onSuccess: () => { setCompetitor({ name: "", place_id: "", cid: "" }); refresh(); } });
  const removeCompetitor = useMutation({ mutationFn: (cid: string) => api.del(`/campaigns/${id}/competitors/${cid}`), onSuccess: () => { setRemoving(null); refresh(); } });

  const launch = useMutation({
    mutationFn: (confirm: boolean) => api.post<LaunchResult>(`/campaigns/${id}/scans`, { confirm_cost: confirm }),
    onSuccess: (res) => {
      setCostConfirm(null);
      qc.invalidateQueries({ queryKey: ["history", id] });
      if (res.scans.length === 1) router.push(`/scans/${res.scans[0].scan_id}`);
    },
    onError: (e) => {
      // 409 with an estimate = the scan is above the cost threshold and needs explicit confirmation
      const d = e instanceof ApiError && e.status === 409 ? (e.detail as { api_requests?: number; estimated_cost_usd?: string } | null) : null;
      if (d && typeof d === "object" && d.estimated_cost_usd && typeof d.api_requests === "number") {
        setCostConfirm({ api_requests: d.api_requests, estimated_cost_usd: d.estimated_cost_usd });
      }
    },
  });

  const activeKeyword = historyKeyword || campaign.data?.keywords[0]?.id || "";
  const history = useQuery({
    queryKey: ["history", id, activeKeyword],
    queryFn: () => api.get<HistoryEntry[]>(`/campaigns/${id}/history`, { keyword_id: activeKeyword }),
    enabled: !!activeKeyword,
    refetchInterval: (q) => (q.state.data?.some((s) => s.status === "queued" || s.status === "running") ? 4000 : false),
  });

  if (campaign.isError) return <ErrorState error={campaign.error} onRetry={() => campaign.refetch()} />;
  if (!campaign.data) return <Skeleton rows={8} />;
  const c = campaign.data;
  const activeKeywords = c.keywords.filter((k) => !k.is_paused).length;

  function submitKeyword(e: FormEvent) {
    e.preventDefault();
    const parsed = keywordSchema.safeParse({ keyword });
    if (!parsed.success) return setErrors({ keyword: fieldErrors(parsed.error).keyword });
    setErrors({}); addKeyword.mutate(parsed.data);
  }
  function submitCompetitor(e: FormEvent) {
    e.preventDefault();
    const parsed = competitorSchema.safeParse(competitor);
    if (!parsed.success) { const fe = fieldErrors(parsed.error); return setErrors({ c_name: fe.name, c_id: fe.place_id }); }
    setErrors({}); addCompetitor.mutate(parsed.data);
  }

  return (
    <>
      <PageHeader title={c.name}
        subtitle={`${c.location_name} · ${c.grid_size}×${c.grid_size} grid · ${formatDistance(c.spacing_m)} between points · ${c.language_code} · ${c.device} · zoom ${c.zoom} · depth ${c.depth}`}
        actions={canEdit && <Button onClick={() => launch.mutate(false)} loading={launch.isPending} disabled={activeKeywords === 0}>Run scan now</Button>} />
      {activeKeywords === 0 && <p className="mb-4 text-sm text-slate-500">Add at least one keyword to run a scan.</p>}
      {launch.isError && !costConfirm && <div className="mb-4"><ErrorState error={launch.error} /></div>}
      {launch.isSuccess && launch.data.scans.length !== 1 && (
        <p className="mb-4 rounded-md border border-green-200 bg-green-50 px-4 py-2 text-sm text-green-800">
          {launch.data.scans.length} scans queued ({launch.data.api_requests} requests, about ${launch.data.estimated_cost_usd}). They appear in the history below.
        </p>
      )}

      <div className="grid gap-6 lg:grid-cols-2">
        <Card title={`Keywords (${c.keywords.length})`}>
          {canEdit && (
            <form onSubmit={submitKeyword} className="mb-4 flex items-start gap-2">
              <div className="flex-1"><Field label="Add keyword" error={errors.keyword}><Input value={keyword} placeholder="e.g. bathtub refinishing" onChange={(e) => setKeyword(e.target.value)} /></Field></div>
              <Button type="submit" loading={addKeyword.isPending} className="mt-6">Add</Button>
            </form>
          )}
          {addKeyword.isError && <ErrorState error={addKeyword.error} />}
          {pauseKeyword.isError && <ErrorState error={pauseKeyword.error} />}
          {c.keywords.length === 0 ? <p className="text-sm text-slate-500">No keywords yet.</p> : (
            <ul className="divide-y divide-slate-100">
              {c.keywords.map((k) => (
                <li key={k.id} className="flex items-center justify-between gap-2 py-2 text-sm">
                  <span>{k.keyword} {k.is_paused && <Badge>Paused</Badge>}</span>
                  {canEdit && <Button variant="ghost" onClick={() => pauseKeyword.mutate(k)}>{k.is_paused ? "Resume" : "Pause"}</Button>}
                </li>
              ))}
            </ul>
          )}
        </Card>

        <Card title={`Competitors (${c.competitors.length})`}>
          {canEdit && (
            <form onSubmit={submitCompetitor} className="mb-4 space-y-2">
              <Field label="Competitor name" error={errors.c_name}><Input value={competitor.name} onChange={(e) => setCompetitor({ ...competitor, name: e.target.value })} /></Field>
              <div className="grid grid-cols-2 gap-2">
                <Field label="Place ID" error={errors.c_id}><Input value={competitor.place_id} placeholder="ChIJ…" onChange={(e) => setCompetitor({ ...competitor, place_id: e.target.value })} /></Field>
                <Field label="or CID"><Input value={competitor.cid} onChange={(e) => setCompetitor({ ...competitor, cid: e.target.value })} /></Field>
              </div>
              <Button type="submit" loading={addCompetitor.isPending}>Add competitor</Button>
            </form>
          )}
          {addCompetitor.isError && <ErrorState error={addCompetitor.error} />}
          {c.competitors.length === 0 ? <p className="text-sm text-slate-500">No competitors yet. Competitors are read from the same search results, so they add no API cost.</p> : (
            <ul className="divide-y divide-slate-100">
              {c.competitors.map((x) => (
                <li key={x.id} className="flex items-center justify-between gap-2 py-2 text-sm">
                  <span>{x.name} <span className="text-xs text-slate-400">{x.place_id ?? `CID ${x.cid}`}</span></span>
                  {canDelete && <Button variant="ghost" onClick={() => { removeCompetitor.reset(); setRemoving(x); }}>Remove</Button>}
                </li>
              ))}
            </ul>
          )}
        </Card>
      </div>

      <div className="mt-6"><ScheduleCard campaignId={id} /></div>

      <div className="mb-3 mt-8 flex flex-wrap items-center justify-between gap-3">
        <h2 className="text-sm font-semibold text-slate-700">
          Scan history
          <Link href={`/campaigns/${id}/compare`} className="ml-3 font-medium text-blue-600">Compare dates and trends →</Link>
        </h2>
        {c.keywords.length > 0 && (
          <Select aria-label="Keyword" value={activeKeyword} onChange={(e) => setHistoryKeyword(e.target.value)} className="max-w-xs">
            {c.keywords.map((k) => <option key={k.id} value={k.id}>{k.keyword}</option>)}
          </Select>
        )}
      </div>
      {!activeKeyword ? <EmptyState title="No scans yet" />
        : history.isError ? <ErrorState error={history.error} onRetry={() => history.refetch()} />
        : !history.data ? <Skeleton />
        : history.data.length === 0 ? <EmptyState title="No scans for this keyword yet" text="Run a scan to see the GeoGrid." />
        : (
          <Table head={<><Th>Date</Th><Th>Status</Th><Th>Avg. position</Th><Th>Top 3</Th><Th>Top 10</Th><Th>Valid points</Th><Th /></>}>
            {[...history.data].reverse().map((s) => (
              <tr key={s.id}>
                <Td>{new Date(s.completed_at ?? s.created_at).toLocaleString()} {s.is_demo && <Badge tone="amber">Demo data</Badge>}</Td>
                <Td><Badge tone={STATUS_TONE[s.status]}>{s.status}</Badge></Td>
                <Td>{formatMetric(s.metrics?.average_position)}</Td>
                <Td>{formatMetric(s.metrics?.top3_coverage, "%")}</Td>
                <Td>{formatMetric(s.metrics?.top10_coverage, "%")}</Td>
                <Td>{s.metrics ? `${s.metrics.valid_points} of ${s.metrics.total_points}` : "—"}</Td>
                <Td className="text-right"><Link className="font-medium text-blue-600" href={`/scans/${s.id}`}>View grid</Link></Td>
              </tr>
            ))}
          </Table>
        )}

      {costConfirm && (
        <ConfirmDialog title="Confirm scan cost" confirmLabel="Run scan" loading={launch.isPending}
          text={<>This scan needs <strong>{costConfirm.api_requests}</strong> API requests, estimated at <strong>${costConfirm.estimated_cost_usd}</strong>, which is above your confirmation threshold.</>}
          onConfirm={() => launch.mutate(true)} onCancel={() => { setCostConfirm(null); launch.reset(); }} />
      )}
      {removing && (
        <ConfirmDialog title="Remove competitor" confirmLabel="Remove" danger loading={removeCompetitor.isPending}
          text={<>Remove <strong>{removing.name}</strong> from this campaign?{removeCompetitor.isError && <span className="mt-2 block text-red-600">{removeCompetitor.error.message}</span>}</>}
          onConfirm={() => removeCompetitor.mutate(removing.id)} onCancel={() => setRemoving(null)} />
      )}
    </>
  );
}
