"use client";

import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useSearchParams } from "next/navigation";
import { Suspense, useEffect, useMemo, useState } from "react";

import { Badge, Button, Card, ConfirmDialog, EmptyState, ErrorState, Field, Input, PageHeader, Select, Skeleton, Table, Td, Th } from "@/components/ui";
import type { Api } from "@/lib/api";
import { useApi, useAuth } from "@/lib/auth";
import { roleAtLeast } from "@/lib/nav";
import { REPORT_TYPES, STATUS_TONE, defaultPeriod, validatePeriod } from "@/lib/reports";
import type { Campaign, CampaignDetail, Client, HistoryEntry, Report, ReportSchedule, ReportType } from "@/lib/types";

async function download(api: Api, r: Report, kind: "pdf" | "csv") {
  const blob = await api.blob(`/reports/${r.id}/${kind}`);
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `${r.title.replace(/[^\w-]+/g, "-")}-${r.period_end}.${kind}`;
  a.click();
  URL.revokeObjectURL(url);
}

function GenerateCard({ clients, onCreated }: { clients: Client[]; onCreated: () => void }) {
  const api = useApi();
  const [type, setType] = useState<ReportType>("weekly");
  const [clientId, setClientId] = useState(clients[0]?.id ?? "");
  const [[start, end], setPeriod] = useState(() => defaultPeriod("weekly"));
  const [title, setTitle] = useState("");
  const [campaignIds, setCampaignIds] = useState<string[]>([]);
  const [recommendations, setRecommendations] = useState("");
  const [includeCompetitors, setIncludeCompetitors] = useState(true);
  const [includeHistory, setIncludeHistory] = useState(true);
  const [cmpCampaign, setCmpCampaign] = useState("");
  const [cmpKeyword, setCmpKeyword] = useState("");
  const [prevScan, setPrevScan] = useState("");
  const [currScan, setCurrScan] = useState("");
  const [error, setError] = useState<string | null>(null);

  const campaigns = useQuery({ queryKey: ["campaigns"], queryFn: () => api.get<Campaign[]>("/campaigns") });
  const locations = useQuery({ queryKey: ["locations", "", clientId], queryFn: () => api.get<{ id: string }[]>("/locations", { client_id: clientId }), enabled: !!clientId });
  const clientCampaigns = useMemo(() => {
    const ids = new Set((locations.data ?? []).map((l) => l.id));
    return (campaigns.data ?? []).filter((c) => ids.has(c.location_id));
  }, [campaigns.data, locations.data]);
  const cmpDetail = useQuery({ queryKey: ["campaign", cmpCampaign], queryFn: () => api.get<CampaignDetail>(`/campaigns/${cmpCampaign}`), enabled: type === "geogrid_comparison" && !!cmpCampaign });
  const cmpHistory = useQuery({
    queryKey: ["history", cmpCampaign, cmpKeyword, null],
    queryFn: () => api.get<HistoryEntry[]>(`/campaigns/${cmpCampaign}/history`, { keyword_id: cmpKeyword }),
    enabled: type === "geogrid_comparison" && !!cmpCampaign && !!cmpKeyword,
  });
  const usableScans = (cmpHistory.data ?? []).filter((s) => s.status === "completed" || s.status === "partial").reverse();

  const create = useMutation({
    mutationFn: (body: unknown) => api.post<{ id: string }>("/reports", body),
    onSuccess: () => { setError(null); onCreated(); },
  });

  function changeType(t: ReportType) { setType(t); setPeriod(defaultPeriod(t)); }
  function submit() {
    const periodError = validatePeriod(start, end);
    if (!clientId) return setError("Choose a client");
    if (periodError) return setError(periodError);
    if (type === "geogrid_comparison" && (!prevScan || !currScan || prevScan === currScan)) return setError("Choose two different scans");
    setError(null);
    create.mutate({
      client_id: clientId, report_type: type, title: title.trim() || null, period_start: start, period_end: end,
      campaign_ids: campaignIds.length ? campaignIds : null, include_competitors: includeCompetitors, include_history: includeHistory,
      recommendations: recommendations.trim() || null,
      ...(type === "geogrid_comparison" ? { previous_scan_id: prevScan, current_scan_id: currScan } : {}),
    });
  }
  const when = (s: HistoryEntry) => new Date(s.completed_at ?? s.created_at).toLocaleString();

  return (
    <Card title="Create a report">
      <div className="grid gap-3 md:grid-cols-2">
        <Field label="Report type" hint={REPORT_TYPES.find((r) => r.value === type)?.hint}>
          <Select value={type} onChange={(e) => changeType(e.target.value as ReportType)}>
            {REPORT_TYPES.map((r) => <option key={r.value} value={r.value}>{r.label}</option>)}
          </Select>
        </Field>
        <Field label="Client">
          <Select value={clientId} onChange={(e) => { setClientId(e.target.value); setCampaignIds([]); setCmpCampaign(""); }}>
            {clients.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
          </Select>
        </Field>
        <Field label="From"><Input type="date" value={start} onChange={(e) => setPeriod([e.target.value, end])} /></Field>
        <Field label="To"><Input type="date" value={end} onChange={(e) => setPeriod([start, e.target.value])} /></Field>
        <Field label="Title (optional)"><Input value={title} placeholder={REPORT_TYPES.find((r) => r.value === type)?.label} onChange={(e) => setTitle(e.target.value)} /></Field>
        {type !== "geogrid_comparison" && (
          <Field label="Campaigns" hint="None selected = all of the client's campaigns">
            <Select multiple value={campaignIds} onChange={(e) => setCampaignIds(Array.from(e.target.selectedOptions, (o) => o.value))} className="h-24">
              {clientCampaigns.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
            </Select>
          </Field>
        )}
      </div>

      {type === "geogrid_comparison" && (
        <div className="mt-3 grid gap-3 md:grid-cols-2">
          <Field label="Campaign">
            <Select value={cmpCampaign} onChange={(e) => { setCmpCampaign(e.target.value); setCmpKeyword(""); setPrevScan(""); setCurrScan(""); }}>
              <option value="">Choose…</option>
              {clientCampaigns.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
            </Select>
          </Field>
          <Field label="Keyword">
            <Select value={cmpKeyword} onChange={(e) => { setCmpKeyword(e.target.value); setPrevScan(""); setCurrScan(""); }} disabled={!cmpDetail.data}>
              <option value="">Choose…</option>
              {cmpDetail.data?.keywords.map((k) => <option key={k.id} value={k.id}>{k.keyword}</option>)}
            </Select>
          </Field>
          <Field label="Previous scan">
            <Select value={prevScan} onChange={(e) => setPrevScan(e.target.value)} disabled={!usableScans.length}>
              <option value="">Choose…</option>
              {usableScans.map((s) => <option key={s.id} value={s.id}>{when(s)}{s.is_demo ? " (demo)" : ""}</option>)}
            </Select>
          </Field>
          <Field label="Current scan">
            <Select value={currScan} onChange={(e) => setCurrScan(e.target.value)} disabled={!usableScans.length}>
              <option value="">Choose…</option>
              {usableScans.map((s) => <option key={s.id} value={s.id}>{when(s)}{s.is_demo ? " (demo)" : ""}</option>)}
            </Select>
          </Field>
        </div>
      )}

      <div className="mt-3">
        <Field label="Recommendations (optional, printed as written)">
          <textarea value={recommendations} onChange={(e) => setRecommendations(e.target.value)} rows={4} maxLength={5000}
            className="block w-full rounded-md border border-slate-300 px-3 py-2 text-sm focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500" />
        </Field>
      </div>
      <div className="mt-3 flex flex-wrap gap-4 text-sm text-slate-700">
        <label className="flex items-center gap-2"><input type="checkbox" checked={includeCompetitors || type === "competitor_comparison"} disabled={type === "competitor_comparison"} onChange={(e) => setIncludeCompetitors(e.target.checked)} /> Competitor tables</label>
        <label className="flex items-center gap-2"><input type="checkbox" checked={includeHistory} onChange={(e) => setIncludeHistory(e.target.checked)} /> Scan history tables</label>
      </div>
      <p className="mt-3 text-xs text-slate-500">
        The summary and observations are calculated from stored scans. Keywords without a finished scan in the period are listed as having no data.
      </p>
      {(error || create.isError) && <div className="mt-3"><ErrorState error={error ? new Error(error) : create.error} /></div>}
      <Button className="mt-4" loading={create.isPending} onClick={submit}>Generate report</Button>
    </Card>
  );
}

function SchedulesCard({ clients }: { clients: Client[] }) {
  const api = useApi();
  const qc = useQueryClient();
  const { me } = useAuth();
  const canEdit = !!me && roleAtLeast(me.role, "seo_specialist");
  const canDelete = !!me && roleAtLeast(me.role, "manager");
  const [clientId, setClientId] = useState(clients[0]?.id ?? "");
  const [form, setForm] = useState({ report_type: "weekly" as "weekly" | "monthly", local_time: "07:00", time_zone: "UTC" });
  useEffect(() => {
    try { setForm((f) => ({ ...f, time_zone: Intl.DateTimeFormat().resolvedOptions().timeZone || "UTC" })); } catch { /* keep UTC */ }
  }, []);
  const list = useQuery({ queryKey: ["report-schedules", clientId], queryFn: () => api.get<ReportSchedule[]>(`/clients/${clientId}/report-schedules`), enabled: !!clientId });
  const refresh = () => qc.invalidateQueries({ queryKey: ["report-schedules", clientId] });
  const save = useMutation({ mutationFn: (body: unknown) => api.put(`/clients/${clientId}/report-schedules`, body), onSuccess: refresh });
  const remove = useMutation({ mutationFn: (t: string) => api.del(`/clients/${clientId}/report-schedules/${t}`), onSuccess: refresh });

  return (
    <Card title="Automatic reports">
      <Field label="Client">
        <Select value={clientId} onChange={(e) => setClientId(e.target.value)}>
          {clients.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
        </Select>
      </Field>
      <div className="mt-3">
        {list.isError ? <ErrorState error={list.error} /> : !list.data ? <Skeleton rows={2} />
          : list.data.length === 0 ? <p className="text-sm text-slate-500">No automatic reports for this client.</p>
          : (
            <ul className="divide-y divide-slate-100 text-sm">
              {list.data.map((s) => (
                <li key={s.id} className="flex items-center justify-between gap-2 py-2">
                  <span>
                    <strong className="capitalize">{s.report_type}</strong> at {s.local_time} ({s.time_zone})
                    <span className="block text-xs text-slate-500">
                      {s.is_paused ? "Paused" : `Next: ${new Date(s.next_run_at).toLocaleString()}`}
                      {s.last_error && ` · last error: ${s.last_error}`}
                    </span>
                  </span>
                  <span className="flex gap-1">
                    {canEdit && <Button variant="ghost" onClick={() => save.mutate({ report_type: s.report_type, title: s.title, campaign_ids: s.campaign_ids, time_zone: s.time_zone, local_time: s.local_time, is_paused: !s.is_paused })}>{s.is_paused ? "Resume" : "Pause"}</Button>}
                    {canDelete && <Button variant="ghost" onClick={() => remove.mutate(s.report_type)}>Remove</Button>}
                  </span>
                </li>
              ))}
            </ul>
          )}
      </div>
      {canEdit && (
        <div className="mt-4 grid grid-cols-3 gap-2 border-t border-slate-100 pt-3">
          <Select aria-label="Frequency" value={form.report_type} onChange={(e) => setForm({ ...form, report_type: e.target.value as "weekly" | "monthly" })}>
            <option value="weekly">Weekly</option><option value="monthly">Monthly</option>
          </Select>
          <Input aria-label="Time" type="time" value={form.local_time} onChange={(e) => setForm({ ...form, local_time: e.target.value })} />
          <Input aria-label="Time zone" value={form.time_zone} onChange={(e) => setForm({ ...form, time_zone: e.target.value })} />
          <Button className="col-span-3" loading={save.isPending} onClick={() => save.mutate({ ...form, is_paused: false })}>Save automatic report</Button>
        </div>
      )}
      <p className="mt-2 text-xs text-slate-500">Weekly reports cover the previous 7 days; monthly reports run on the 1st and cover the previous month. Reports are added to the list below; email delivery is not connected yet.</p>
      {(save.isError || remove.isError) && <div className="mt-2"><ErrorState error={save.error ?? remove.error} /></div>}
    </Card>
  );
}

function ReportsInner() {
  const api = useApi();
  const qc = useQueryClient();
  const { me } = useAuth();
  const highlight = useSearchParams().get("highlight");
  const canCreate = !!me && roleAtLeast(me.role, "seo_specialist");
  const canDelete = !!me && roleAtLeast(me.role, "manager");
  const [deleting, setDeleting] = useState<Report | null>(null);
  const [downloadError, setDownloadError] = useState<Error | null>(null);

  const clients = useQuery({ queryKey: ["clients", "", false], queryFn: () => api.get<Client[]>("/clients") });
  const reports = useQuery({
    queryKey: ["reports"], queryFn: () => api.get<Report[]>("/reports"),
    refetchInterval: (q) => (q.state.data?.some((r) => r.status === "queued" || r.status === "generating") ? 3000 : false),
  });
  const refresh = () => qc.invalidateQueries({ queryKey: ["reports"] });
  const retry = useMutation({ mutationFn: (id: string) => api.post(`/reports/${id}/retry`), onSuccess: refresh });
  const remove = useMutation({ mutationFn: (id: string) => api.del(`/reports/${id}`), onSuccess: () => { setDeleting(null); refresh(); } });
  const get = (r: Report, kind: "pdf" | "csv") => download(api, r, kind).then(() => setDownloadError(null), (e) => setDownloadError(e));

  if (clients.isError) return <ErrorState error={clients.error} onRetry={() => clients.refetch()} />;
  if (!clients.data) return <Skeleton rows={8} />;
  if (clients.data.length === 0) return <EmptyState title="Add a client first" text="Reports are prepared per client." />;

  return (
    <>
      <PageHeader title="Reports" subtitle="Branded PDF and CSV reports from stored scans. Set your logo and colours under Settings." />
      {canCreate && (
        <div className="mb-6 grid gap-6 xl:grid-cols-[1fr_380px]">
          <GenerateCard clients={clients.data} onCreated={refresh} />
          <SchedulesCard clients={clients.data} />
        </div>
      )}
      <h2 className="mb-3 text-sm font-semibold text-slate-700">Generated reports</h2>
      {downloadError && <div className="mb-3"><ErrorState error={downloadError} /></div>}
      {reports.isError ? <ErrorState error={reports.error} onRetry={() => reports.refetch()} />
        : !reports.data ? <Skeleton />
        : reports.data.length === 0 ? <EmptyState title="No reports yet" />
        : (
          <Table head={<><Th>Report</Th><Th>Client</Th><Th>Period</Th><Th>Status</Th><Th /></>}>
            {reports.data.map((r) => (
              <tr key={r.id} className={r.id === highlight ? "bg-blue-50" : undefined}>
                <Td>
                  <span className="font-medium">{r.title}</span>
                  <span className="block text-xs text-slate-500">
                    {REPORT_TYPES.find((t) => t.value === r.report_type)?.label}{r.schedule_id ? " · automatic" : ""}
                    {r.page_count ? ` · ${r.page_count} pages` : ""}
                  </span>
                </Td>
                <Td>{r.client_name}</Td>
                <Td>{r.period_start} – {r.period_end}</Td>
                <Td>
                  <Badge tone={STATUS_TONE[r.status]}>{r.status}</Badge> {r.is_demo && <Badge tone="amber">Demo data</Badge>}
                  {r.error && <span className="mt-1 block max-w-xs text-xs text-red-700">{r.error}</span>}
                </Td>
                <Td className="whitespace-nowrap text-right">
                  {r.status === "ready" && <>
                    <Button variant="ghost" onClick={() => get(r, "pdf")}>PDF</Button>
                    <Button variant="ghost" onClick={() => get(r, "csv")}>CSV</Button>
                  </>}
                  {r.status === "failed" && canCreate && <Button variant="ghost" onClick={() => retry.mutate(r.id)}>Retry</Button>}
                  {canDelete && r.status !== "generating" && <Button variant="ghost" onClick={() => { remove.reset(); setDeleting(r); }}>Delete</Button>}
                </Td>
              </tr>
            ))}
          </Table>
        )}
      {deleting && (
        <ConfirmDialog title="Delete report" confirmLabel="Delete" danger loading={remove.isPending}
          text={<>Delete <strong>{deleting.title}</strong> ({deleting.period_start} – {deleting.period_end})? The scans it was built from are not affected.{remove.isError && <span className="mt-2 block text-red-600">{remove.error.message}</span>}</>}
          onConfirm={() => remove.mutate(deleting.id)} onCancel={() => setDeleting(null)} />
      )}
    </>
  );
}

export default function ReportsPage() {
  // useSearchParams needs a Suspense boundary in the App Router
  return <Suspense fallback={<Skeleton rows={8} />}><ReportsInner /></Suspense>;
}
