"use client";

import { useQuery } from "@tanstack/react-query";
import Link from "next/link";

import { Badge, EmptyState, ErrorState, PageHeader, Skeleton, Table, Td, Th } from "@/components/ui";
import { useApi } from "@/lib/auth";
import { describeSchedule } from "@/lib/schedule";
import type { ScheduleListItem } from "@/lib/types";

const TONE = { queued: "blue", running: "blue", completed: "green", partial: "amber", failed: "red", cancelled: "gray" } as const;

export default function SchedulesPage() {
  const api = useApi();
  const list = useQuery({ queryKey: ["schedules"], queryFn: () => api.get<ScheduleListItem[]>("/schedules"), refetchInterval: 30_000 });
  return (
    <>
      <PageHeader title="Scheduled Scans" subtitle="Automatic scans by campaign. Set up or change a schedule on the campaign page." />
      {list.isError ? <ErrorState error={list.error} onRetry={() => list.refetch()} />
        : !list.data ? <Skeleton />
        : list.data.length === 0 ? (
          <EmptyState title="No schedules yet" text="Open a campaign and set up a schedule to scan its keywords automatically."
            action={<Link className="text-sm font-medium text-blue-600" href="/campaigns">Go to campaigns</Link>} />
        ) : (
          <Table head={<><Th>Campaign</Th><Th>Schedule</Th><Th>Next run</Th><Th>Last run</Th><Th>Status</Th></>}>
            {list.data.map((s) => (
              <tr key={s.id}>
                <Td>
                  <Link className="font-medium text-blue-600" href={`/campaigns/${s.campaign_id}`}>{s.campaign_name}</Link>
                  <span className="block text-xs text-slate-500">{s.location_name} · {s.active_keywords} active keyword{s.active_keywords === 1 ? "" : "s"}</span>
                </Td>
                <Td>{describeSchedule(s.frequency, s.interval_days, s.local_time, s.time_zone)}</Td>
                <Td>{s.is_paused || !s.campaign_active || !s.next_run_at ? "—" : new Date(s.next_run_at).toLocaleString()}</Td>
                <Td>
                  {s.last_run_at ? new Date(s.last_run_at).toLocaleString() : "Not yet"}
                  {s.last_error && <span className="block text-xs text-red-700">Skipped: {s.last_error}</span>}
                  {s.last_scans && (
                    <span className="mt-1 flex flex-wrap gap-1">
                      {s.last_scans.map((x) => <Link key={x.id} href={`/scans/${x.id}`}><Badge tone={TONE[x.status]}>{x.keyword}: {x.status}</Badge></Link>)}
                    </span>
                  )}
                </Td>
                <Td>{!s.campaign_active ? <Badge>Campaign paused</Badge> : s.is_paused ? <Badge>Paused</Badge> : <Badge tone="green">Active</Badge>}</Td>
              </tr>
            ))}
          </Table>
        )}
    </>
  );
}
