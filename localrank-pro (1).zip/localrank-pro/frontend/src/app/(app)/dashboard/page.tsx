"use client";

import { useQuery } from "@tanstack/react-query";
import Link from "next/link";

import { Card, EmptyState, ErrorState, PageHeader, Skeleton, Table, Td, Th } from "@/components/ui";
import { useApi } from "@/lib/auth";
import type { BusinessLocation, Campaign, Client } from "@/lib/types";

export default function Dashboard() {
  const api = useApi();
  const clients = useQuery({ queryKey: ["clients", ""], queryFn: () => api.get<Client[]>("/clients") });
  const locations = useQuery({ queryKey: ["locations", ""], queryFn: () => api.get<BusinessLocation[]>("/locations") });
  const campaigns = useQuery({ queryKey: ["campaigns"], queryFn: () => api.get<Campaign[]>("/campaigns") });
  const error = clients.error ?? locations.error ?? campaigns.error;
  if (error) return <ErrorState error={error} onRetry={() => { clients.refetch(); locations.refetch(); campaigns.refetch(); }} />;
  if (!clients.data || !locations.data || !campaigns.data) return <Skeleton rows={6} />;

  const keywords = campaigns.data.reduce((n, c) => n + (c.keyword_count ?? 0), 0);
  const competitors = campaigns.data.reduce((n, c) => n + (c.competitor_count ?? 0), 0);
  const kpis: [string, number][] = [["Clients", clients.data.length], ["Locations", locations.data.length],
    ["Campaigns", campaigns.data.length], ["Tracked keywords", keywords], ["Competitors", competitors]];

  return (
    <>
      <PageHeader title="Overview" subtitle="Counts come from your saved records. Ranking trends appear here once the analytics dashboard is built." />
      <div className="grid grid-cols-2 gap-4 md:grid-cols-5">
        {kpis.map(([label, value]) => (
          <Card key={label}><p className="text-xs text-slate-500">{label}</p><p className="mt-1 text-2xl font-semibold text-navy-900">{value}</p></Card>
        ))}
      </div>
      <h2 className="mb-3 mt-8 text-sm font-semibold text-slate-700">Campaigns</h2>
      {campaigns.data.length === 0 ? (
        <EmptyState title="No campaigns yet" text="Add a business location, then create a campaign to start tracking rankings on a grid."
          action={<Link className="text-sm font-medium text-blue-600" href="/campaigns/new">Create a campaign</Link>} />
      ) : (
        <Table head={<><Th>Campaign</Th><Th>Location</Th><Th>Grid</Th><Th>Keywords</Th><Th>Last scan</Th></>}>
          {campaigns.data.map((c) => (
            <tr key={c.id}>
              <Td><Link className="font-medium text-blue-600" href={`/campaigns/${c.id}`}>{c.name}</Link></Td>
              <Td>{c.location_name}</Td><Td>{c.grid_size}×{c.grid_size}</Td><Td>{c.keyword_count ?? 0}</Td>
              <Td>{c.last_scan_at ? new Date(c.last_scan_at).toLocaleString() : "Never"}</Td>
            </tr>
          ))}
        </Table>
      )}
    </>
  );
}
