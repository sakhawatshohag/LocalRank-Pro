"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useEffect, useState, type ReactNode } from "react";

import { NotificationBell } from "@/components/NotificationBell";
import { Skeleton } from "@/components/ui";
import { useAuth } from "@/lib/auth";
import { navFor } from "@/lib/nav";

export default function AppLayout({ children }: { children: ReactNode }) {
  const { ready, token, me, signOut, api, signIn } = useAuth();
  const switchOrg = (orgId: string) =>
    api.post<{ access_token: string }>("/auth/switch-org", { org_id: orgId }).then((t) => { signIn(t.access_token); router.replace("/dashboard"); }, () => undefined);
  const router = useRouter();
  const pathname = usePathname();
  const [collapsed, setCollapsed] = useState(false);

  useEffect(() => { if (ready && !token) router.replace("/login"); }, [ready, token, router]);
  if (!ready || !token) return null;

  return (
    <div className="flex min-h-screen">
      <aside className={`${collapsed ? "w-16" : "w-60"} flex shrink-0 flex-col bg-navy-900 text-slate-200 transition-all`}>
        <div className="flex h-14 items-center justify-between px-4">
          {!collapsed && <span className="font-semibold text-white">LocalRank Pro</span>}
          <button onClick={() => setCollapsed((c) => !c)} aria-label={collapsed ? "Expand sidebar" : "Collapse sidebar"}
            className="rounded p-1 hover:bg-navy-800">{collapsed ? "»" : "«"}</button>
        </div>
        <nav aria-label="Main" className="flex-1 space-y-1 px-2 py-2">
          {me && navFor(me.role, me.is_super_admin).map((item) => {
            const active = pathname === item.href || pathname.startsWith(item.href + "/");
            return (
              <Link key={item.href} href={item.href} title={item.label} aria-current={active ? "page" : undefined}
                className={`block truncate rounded-md px-3 py-2 text-sm ${active ? "bg-blue-600 text-white" : "hover:bg-navy-800"}`}>
                {collapsed ? item.label.charAt(0) : item.label}
              </Link>
            );
          })}
        </nav>
        {!collapsed && me && (
          <div className="border-t border-navy-800 p-4 text-xs">
            {me.organizations.length > 1 ? (
              <select aria-label="Switch organization" value={me.org_id} onChange={(e) => switchOrg(e.target.value)}
                className="mb-1 w-full rounded bg-navy-800 px-2 py-1 text-xs text-white">
                {me.organizations.map((o) => <option key={o.id} value={o.id}>{o.name}</option>)}
              </select>
            ) : <p className="truncate font-medium text-white">{me.organization}</p>}
            <p className="truncate text-slate-400">{me.email} · {me.role.replace("_", " ")}</p>
            <button onClick={signOut} className="mt-2 text-slate-300 underline">Sign out</button>
          </div>
        )}
      </aside>
      <div className="min-w-0 flex-1">
        <header className="flex h-14 items-center justify-end border-b border-slate-200 bg-white px-6">{me && <NotificationBell />}</header>
        <main className="p-6">{me ? children : <Skeleton rows={6} />}</main>
      </div>
    </div>
  );
}
