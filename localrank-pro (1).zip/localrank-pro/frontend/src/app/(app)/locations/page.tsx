"use client";

import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useState, type FormEvent } from "react";

import { Badge, Button, ConfirmDialog, EmptyState, ErrorState, Field, Input, Modal, PageHeader, Select, Skeleton, Table, Td, Th } from "@/components/ui";
import { useApi, useAuth } from "@/lib/auth";
import { roleAtLeast } from "@/lib/nav";
import type { BusinessLocation, Client } from "@/lib/types";
import { fieldErrors, locationSchema } from "@/lib/validation";

const TEXT_FIELDS: [keyof FormState, string, string?][] = [
  ["name", "Business name"], ["place_id", "Google Place ID", "Starts with ChIJ…  Needed to track rankings."],
  ["cid", "Google CID (optional)", "Numeric profile ID. Used if no Place ID is given."],
  ["gbp_url", "Google Business Profile URL (optional)"], ["address", "Address"], ["city", "City"], ["state", "State / Province"],
  ["country", "Country"], ["postal_code", "Postal code"], ["latitude", "Latitude"], ["longitude", "Longitude"],
  ["website", "Website"], ["phone", "Phone"], ["primary_category", "Primary category"],
  ["time_zone", "Time zone", "IANA name, e.g. America/Toronto"], ["language_code", "Search language", "e.g. en, fr"],
];
type FormState = Record<"name" | "place_id" | "cid" | "gbp_url" | "address" | "city" | "state" | "country" | "postal_code" | "latitude" | "longitude" | "website" | "phone" | "primary_category" | "time_zone" | "language_code" | "client_id", string>;
const EMPTY: FormState = { name: "", place_id: "", cid: "", gbp_url: "", address: "", city: "", state: "", country: "", postal_code: "", latitude: "", longitude: "", website: "", phone: "", primary_category: "", time_zone: "UTC", language_code: "en", client_id: "" };

export default function LocationsPage() {
  const api = useApi();
  const { me } = useAuth();
  const qc = useQueryClient();
  const canEdit = !!me && roleAtLeast(me.role, "seo_specialist");
  const canArchive = !!me && roleAtLeast(me.role, "manager");
  const [search, setSearch] = useState("");
  const [clientFilter, setClientFilter] = useState("");
  const [editing, setEditing] = useState<BusinessLocation | "new" | null>(null);
  const [archiving, setArchiving] = useState<BusinessLocation | null>(null);
  const [form, setForm] = useState<FormState>(EMPTY);
  const [errors, setErrors] = useState<Record<string, string>>({});

  const clients = useQuery({ queryKey: ["clients", "", false], queryFn: () => api.get<Client[]>("/clients") });
  const list = useQuery({
    queryKey: ["locations", search, clientFilter],
    queryFn: () => api.get<BusinessLocation[]>("/locations", { q: search, client_id: clientFilter }),
  });
  const refresh = () => qc.invalidateQueries({ queryKey: ["locations"] });
  const save = useMutation({
    mutationFn: (body: unknown) => (editing && editing !== "new" ? api.put<BusinessLocation>(`/locations/${editing.id}`, body) : api.post<BusinessLocation>("/locations", body)),
    onSuccess: () => { setEditing(null); refresh(); },
  });
  const archive = useMutation({
    mutationFn: (l: BusinessLocation) => api.post<BusinessLocation>(`/locations/${l.id}/archive`, {}, { archived: true }),
    onSuccess: () => { setArchiving(null); refresh(); },
  });

  function open(l: BusinessLocation | "new") {
    if (l === "new") setForm({ ...EMPTY, client_id: clientFilter });
    else {
      const next = { ...EMPTY };
      (Object.keys(EMPTY) as (keyof FormState)[]).forEach((k) => { const v = l[k as keyof BusinessLocation]; next[k] = v === null || v === undefined ? "" : String(v); });
      setForm(next);
    }
    setErrors({}); save.reset(); setEditing(l);
  }
  function onSubmit(e: FormEvent) {
    e.preventDefault();
    const parsed = locationSchema.safeParse({ ...form, client_id: form.client_id || null });
    if (!parsed.success) return setErrors(fieldErrors(parsed.error));
    setErrors({});
    const existing = editing && editing !== "new" ? editing.additional_categories : [];
    save.mutate({ ...parsed.data, additional_categories: existing });
  }
  const clientName = (id: string | null) => clients.data?.find((c) => c.id === id)?.name ?? "—";

  return (
    <>
      <PageHeader title="Locations" subtitle="Business locations you track. A Place ID or CID is required before rankings can be matched."
        actions={canEdit && <Button onClick={() => open("new")}>Add location</Button>} />
      <div className="mb-4 flex flex-wrap gap-3">
        <Input aria-label="Search locations" placeholder="Search by name or city…" value={search} onChange={(e) => setSearch(e.target.value)} className="max-w-xs" />
        <Select aria-label="Filter by client" value={clientFilter} onChange={(e) => setClientFilter(e.target.value)} className="max-w-xs">
          <option value="">All clients</option>
          {clients.data?.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
        </Select>
      </div>
      {list.isError ? <ErrorState error={list.error} onRetry={() => list.refetch()} />
        : !list.data ? <Skeleton />
        : list.data.length === 0 ? (
          <EmptyState title={search || clientFilter ? "No locations match" : "No locations yet"}
            text={search || clientFilter ? undefined : "Add a business location to start building rank-tracking campaigns."}
            action={canEdit && !search && !clientFilter ? <Button onClick={() => open("new")}>Add location</Button> : undefined} />
        ) : (
          <Table head={<><Th>Business</Th><Th>Client</Th><Th>City</Th><Th>Identifier</Th><Th /></>}>
            {list.data.map((l) => (
              <tr key={l.id}>
                <Td className="font-medium">{l.name}</Td>
                <Td>{clientName(l.client_id)}</Td>
                <Td>{l.city ?? "—"}</Td>
                <Td>
                  {!l.place_id && !l.cid ? <Badge tone="red">Missing: cannot be tracked</Badge>
                    : l.identity_verified_at ? <Badge tone="green">Verified</Badge>
                    : <Badge tone="amber">Not verified yet</Badge>}
                </Td>
                <Td className="text-right">
                  {canEdit && <Button variant="ghost" onClick={() => open(l)}>Edit</Button>}
                  {canArchive && <Button variant="ghost" onClick={() => setArchiving(l)}>Archive</Button>}
                </Td>
              </tr>
            ))}
          </Table>
        )}

      {editing && (
        <Modal title={editing === "new" ? "Add location" : "Edit location"} onClose={() => setEditing(null)}>
          <form onSubmit={onSubmit} noValidate className="space-y-3">
            <Field label="Client (optional)">
              <Select value={form.client_id} onChange={(e) => setForm({ ...form, client_id: e.target.value })}>
                <option value="">No client</option>
                {clients.data?.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
              </Select>
            </Field>
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              {TEXT_FIELDS.map(([name, label, hint]) => (
                <Field key={name} label={label} hint={hint} error={errors[name]}>
                  <Input value={form[name]} inputMode={name === "latitude" || name === "longitude" ? "decimal" : undefined}
                    onChange={(e) => setForm({ ...form, [name]: e.target.value })} />
                </Field>
              ))}
            </div>
            {save.isError && <ErrorState error={save.error} />}
            <div className="flex justify-end gap-2">
              <Button type="button" variant="secondary" onClick={() => setEditing(null)}>Cancel</Button>
              <Button type="submit" loading={save.isPending}>Save</Button>
            </div>
          </form>
        </Modal>
      )}
      {archiving && (
        <ConfirmDialog title="Archive location" confirmLabel="Archive" loading={archive.isPending}
          text={<>Archive <strong>{archiving.name}</strong>? Its scan history is kept.{archive.isError && <span className="mt-2 block text-red-600">{archive.error.message}</span>}</>}
          onConfirm={() => archive.mutate(archiving)} onCancel={() => setArchiving(null)} />
      )}
    </>
  );
}
