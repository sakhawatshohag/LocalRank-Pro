"use client";

import { useMutation, useQuery } from "@tanstack/react-query";
import { useSearchParams } from "next/navigation";
import { Suspense } from "react";

import { Badge, Button, Card, ErrorState, Notice, PageHeader, Skeleton, Table, Td, Th } from "@/components/ui";
import { useApi, useAuth } from "@/lib/auth";
import { LIMIT_LABELS, SUBSCRIPTION_LABEL, formatMoney, formatPrice, limitText, sortPlans, usageShare } from "@/lib/billing";
import type { BillingOverview, PlanLimits } from "@/lib/types";

const USAGE_KEY: Partial<Record<keyof PlanLimits, keyof BillingOverview["usage"]>> = {
  locations: "locations", campaigns: "campaigns", keywords: "keywords", competitors: "competitors",
  monthly_scan_points: "monthly_scan_points", team_members: "team_members",
};

function BillingInner() {
  const api = useApi();
  const { me } = useAuth();
  const isOwner = me?.role === "owner";
  const params = useSearchParams();
  const data = useQuery({ queryKey: ["billing"], queryFn: () => api.get<BillingOverview>("/billing"),
    refetchInterval: params.get("checkout") === "success" ? 5000 : false });
  const go = (u: { url: string }) => { window.location.href = u.url; };
  const checkout = useMutation({ mutationFn: (plan_code: string) => api.post<{ url: string }>("/billing/checkout", { plan_code }), onSuccess: go });
  const portal = useMutation({ mutationFn: () => api.post<{ url: string }>("/billing/portal"), onSuccess: go });

  if (data.isError) return <ErrorState error={data.error} onRetry={() => data.refetch()} />;
  if (!data.data) return <Skeleton rows={8} />;
  const b = data.data;
  const sub = b.subscription;
  const subscribed = !!sub && ["active", "trialing", "past_due"].includes(sub.status);
  const trialLeft = b.trial_ends_at ? Math.ceil((Date.parse(b.trial_ends_at) - Date.now()) / 86_400_000) : null;

  return (
    <>
      <PageHeader title="Billing & Subscription"
        actions={isOwner && sub?.has_customer && b.payments_enabled && <Button variant="secondary" loading={portal.isPending} onClick={() => portal.mutate()}>Manage billing</Button>} />
      <div className="mb-4 space-y-2">
        {params.get("checkout") === "success" && !subscribed && <Notice tone="blue">Payment received. Your plan is being activated; this page updates automatically.</Notice>}
        {params.get("checkout") === "cancelled" && <Notice>Checkout was cancelled. Nothing was charged.</Notice>}
        {b.plan.code === "inactive" && <Notice>Your organization has no active plan. Your data is kept; choose a plan to add items and run scans again.</Notice>}
        {sub?.status === "past_due" && <Notice>The last payment failed. Update your payment method under “Manage billing”.</Notice>}
        {!b.payments_enabled && <Notice tone="blue">Online payments are not set up yet. Contact support to change your plan.</Notice>}
        {(checkout.isError || portal.isError) && <ErrorState error={checkout.error ?? portal.error} />}
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <Card title="Current plan" actions={sub && <Badge tone={sub.status === "active" ? "green" : sub.status === "past_due" ? "red" : "gray"}>{SUBSCRIPTION_LABEL[sub.status] ?? sub.status}</Badge>}>
          <p className="text-lg font-semibold text-navy-900">{b.plan.name}</p>
          {b.plan.code === "trial" && trialLeft !== null && (
            <p className="text-sm text-slate-600">{trialLeft > 0 ? `${trialLeft} day${trialLeft === 1 ? "" : "s"} of trial left` : "Trial ended"}</p>
          )}
          {sub?.current_period_end && (
            <p className="text-sm text-slate-600">{sub.cancel_at_period_end ? "Ends" : "Renews"} on {new Date(sub.current_period_end).toLocaleDateString()}</p>
          )}
          <div className="mt-4 space-y-3">
            {LIMIT_LABELS.map(([key, label]) => {
              const limit = b.plan.limits[key];
              const usageKey = USAGE_KEY[key];
              const used = usageKey ? b.usage[usageKey] : undefined;
              const share = used !== undefined && typeof limit === "number" ? usageShare(used, limit) : null;
              return (
                <div key={key} className="text-sm">
                  <div className="flex justify-between"><span>{label}</span>
                    <span className="text-slate-600">{used !== undefined ? `${used.toLocaleString("en-US")} of ` : ""}{limitText(key, limit)}</span></div>
                  {share !== null && (
                    <div className="mt-1 h-1.5 rounded bg-slate-100" role="progressbar" aria-valuenow={share} aria-valuemin={0} aria-valuemax={100} aria-label={label}>
                      <div className={`h-1.5 rounded ${share >= 100 ? "bg-red-600" : share >= 80 ? "bg-orange-500" : "bg-blue-600"}`} style={{ width: `${share}%` }} />
                    </div>
                  )}
                </div>
              );
            })}
            <p className="text-sm">White-label reports: {b.plan.limits.white_label ? "Yes" : "No"}</p>
            <p className="text-xs text-slate-500">If you move to a smaller plan, nothing is deleted; you just cannot add more until usage is within the new limits.</p>
          </div>
        </Card>

        <Card title="Plans">
          {b.plans.length === 0 ? <p className="text-sm text-slate-500">No plans are published yet.</p> : (
            <ul className="space-y-3">
              {sortPlans(b.plans).map((p) => (
                <li key={p.code} className={`rounded-lg border p-3 ${p.code === b.plan.code ? "border-blue-500 bg-blue-50" : "border-slate-200"}`}>
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <p className="font-semibold">{p.name}</p>
                      <p className="text-sm text-slate-600">{formatPrice(p.monthly_price_cents, p.currency)}</p>
                      {p.description && <p className="mt-1 text-xs text-slate-500">{p.description}</p>}
                      <p className="mt-1 text-xs text-slate-500">
                        {limitText("locations", p.limits.locations)} locations · {limitText("keywords", p.limits.keywords)} keywords · {limitText("monthly_scan_points", p.limits.monthly_scan_points)} grid points/month · grids up to {limitText("max_grid_size", p.limits.max_grid_size)}
                      </p>
                    </div>
                    {p.code === b.plan.code ? <Badge tone="blue">Current</Badge>
                      : isOwner && b.payments_enabled && p.purchasable && (
                        subscribed ? <Button variant="secondary" onClick={() => portal.mutate()}>Change</Button>
                                   : <Button loading={checkout.isPending && checkout.variables === p.code} onClick={() => checkout.mutate(p.code)}>Choose</Button>
                      )}
                  </div>
                </li>
              ))}
            </ul>
          )}
          {!isOwner && <p className="mt-3 text-xs text-slate-500">Only the organization owner can change the plan.</p>}
          <p className="mt-3 text-xs text-slate-500">Payments are handled by Stripe; card details never reach LocalRank Pro.</p>
        </Card>
      </div>

      <h2 className="mb-3 mt-8 text-sm font-semibold text-slate-700">Invoices</h2>
      {b.invoices.length === 0 ? <p className="text-sm text-slate-500">No invoices yet.</p> : (
        <Table head={<><Th>Date</Th><Th>Number</Th><Th>Amount</Th><Th>Status</Th><Th /></>}>
          {b.invoices.map((i, n) => (
            <tr key={i.number ?? n}>
              <Td>{new Date(i.created_at).toLocaleDateString()}</Td>
              <Td>{i.number ?? "—"}</Td>
              <Td>{formatMoney(i.status === "paid" ? i.amount_paid_cents : i.amount_due_cents, i.currency)}</Td>
              <Td><Badge tone={i.status === "paid" ? "green" : i.status === "open" ? "amber" : "gray"}>{i.status ?? "—"}</Badge></Td>
              <Td className="text-right">
                {i.hosted_invoice_url && <a className="mr-3 text-sm text-blue-600" href={i.hosted_invoice_url} target="_blank" rel="noopener noreferrer">View</a>}
                {i.invoice_pdf_url && <a className="text-sm text-blue-600" href={i.invoice_pdf_url} target="_blank" rel="noopener noreferrer">PDF</a>}
              </Td>
            </tr>
          ))}
        </Table>
      )}
    </>
  );
}

export default function BillingPage() {
  return <Suspense fallback={<Skeleton rows={8} />}><BillingInner /></Suspense>;
}
