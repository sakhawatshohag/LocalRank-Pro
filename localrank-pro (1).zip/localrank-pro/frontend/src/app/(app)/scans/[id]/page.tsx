"use client";

import { useMutation, useQuery } from "@tanstack/react-query";
import Link from "next/link";
import { useParams, useRouter } from "next/navigation";
import { useMemo, useState } from "react";

import { GeoGrid, Legend, type GridMarker } from "@/components/GeoGrid";
import { Badge, Button, Card, ErrorState, Notice, PageHeader, Select, Skeleton } from "@/components/ui";
import { useApi, useAuth } from "@/lib/auth";
import { BUCKETS, LEGEND_ORDER, bucketFor, formatMetric, isScanActive, markerLabel, summarize, type Bucket } from "@/lib/geogrid";
import { roleAtLeast } from "@/lib/nav";
import type { CampaignDetail, LaunchResult, PointDetail, ScanDetail } from "@/lib/types";

function downloadCsv(detail: ScanDetail, subject: string) {
  const rows = [["point", "latitude", "longitude", "status", "position", "business", "keyword", "scan_date"]];
  for (const p of detail.points) {
    rows.push([String(p.point_index + 1), String(p.latitude), String(p.longitude), p.result_status ?? "pending",
      p.position === null ? "" : String(p.position), subject, detail.scan.keyword_text, detail.scan.completed_at ?? ""]);
  }
  const csv = rows.map((r) => r.map((v) => `"${v.replace(/"/g, '""')}"`).join(",")).join("\n");
  const url = URL.createObjectURL(new Blob([csv], { type: "text/csv" }));
  const a = document.createElement("a");
  a.href = url; a.download = `geogrid-${detail.scan.id}.csv`; a.click();
  URL.revokeObjectURL(url);
}

export default function ScanPage() {
  const { id } = useParams<{ id: string }>();
  const api = useApi();
  const [competitorId, setCompetitorId] = useState("");
  const [selected, setSelected] = useState<number | null>(null);
  const [visible, setVisible] = useState<Set<Bucket>>(() => new Set(LEGEND_ORDER));
  const router = useRouter();
  const { me } = useAuth();
  const retry = useMutation({
    mutationFn: () => api.post<LaunchResult>(`/scans/${id}/retry`),
    onSuccess: (res) => res.scans[0] && router.push(`/scans/${res.scans[0].scan_id}`),
  });

  const scan = useQuery({
    queryKey: ["scan", id, competitorId],
    queryFn: () => api.get<ScanDetail>(`/scans/${id}`, { competitor_id: competitorId }),
    refetchInterval: (q) => (q.state.data && isScanActive(q.state.data.scan.status) ? 3000 : false),
  });
  const campaignId = scan.data?.scan.campaign_id;
  const campaign = useQuery({ queryKey: ["campaign", campaignId], queryFn: () => api.get<CampaignDetail>(`/campaigns/${campaignId}`), enabled: !!campaignId });
  const point = useQuery({
    queryKey: ["scan-point", id, selected],
    queryFn: () => api.get<PointDetail>(`/scans/${id}/points/${selected}`),
    enabled: selected !== null && !!scan.data && !isScanActive(scan.data.scan.status),
  });

  const depth = scan.data?.scan.depth ?? 100;
  const markers = useMemo<GridMarker[]>(
    () => (scan.data?.points ?? [])
      .map((p) => ({ index: p.point_index, row: p.row_no, col: p.col_no, lat: p.latitude, lng: p.longitude,
        label: markerLabel(p.result_status, p.position, depth), bucket: bucketFor(p.result_status, p.position) }))
      .filter((m) => m.bucket === "pending" || visible.has(m.bucket)),
    [scan.data, depth, visible],
  );

  if (scan.isError) return <ErrorState error={scan.error} onRetry={() => scan.refetch()} />;
  if (!scan.data) return <Skeleton rows={10} />;
  const { scan: s, metrics: m } = scan.data;
  const active = isScanActive(s.status);
  const subjectName = competitorId ? campaign.data?.competitors.find((c) => c.id === competitorId)?.name ?? "Competitor" : campaign.data?.location_name ?? "Your business";
  const counts = summarize(scan.data.points);
  const toggle = (b: Bucket) => setVisible((prev) => { const next = new Set(prev); if (next.has(b)) next.delete(b); else next.add(b); return next; });
  const kpis: [string, string, string][] = [
    ["Average position", formatMetric(m?.average_position), "Mean position over points where the business was found. Not-found and failed points are excluded."],
    ["Top 3 coverage", formatMetric(m?.top3_coverage, "%"), "Share of valid points where the business ranks 1–3."],
    ["Top 10 coverage", formatMetric(m?.top10_coverage, "%"), "Share of valid points where the business ranks 1–10."],
    ["Not found", formatMetric(m?.not_found_pct, "%"), `Share of valid points where the business is not in the first ${depth} results.`],
    ["Valid points", m ? `${m.valid_points} of ${m.total_points}` : "—", "Points with a usable answer from the data provider. Failed points are never counted as rankings."],
  ];

  return (
    <>
      <PageHeader title={`“${s.keyword_text}”`}
        subtitle={`${subjectName} · ${s.grid_size}×${s.grid_size} grid · ${s.completed_at ? new Date(s.completed_at).toLocaleString() : "in progress"}`}
        actions={<>
          <Link href={`/campaigns/${s.campaign_id}`} className="rounded-md border border-slate-300 bg-white px-3.5 py-2 text-sm font-medium">Back to campaign</Link>
          {!active && s.status !== "failed" && <Link href={`/scans/${id}/competitors`} className="rounded-md border border-slate-300 bg-white px-3.5 py-2 text-sm font-medium">Competitor comparison</Link>}
          {!active && <button onClick={() => downloadCsv(scan.data, subjectName)} className="rounded-md border border-slate-300 bg-white px-3.5 py-2 text-sm font-medium">Export CSV</button>}
        </>} />

      <div className="mb-4 space-y-2">
        {scan.data.data_notice && <Notice>{scan.data.data_notice}</Notice>}
        {active && <Notice tone="blue">Scan {s.status}. This page refreshes automatically.</Notice>}
        {s.status === "failed" && <Notice>This scan returned no usable data. No rankings were recorded.</Notice>}
        {(s.status === "failed" || s.status === "partial") && me && roleAtLeast(me.role, "seo_specialist") && (
          <div className="flex items-center gap-3">
            <Button variant="secondary" loading={retry.isPending} onClick={() => retry.mutate()}>Run this keyword again</Button>
            <span className="text-xs text-slate-500">Creates a new scan; this one stays in history unchanged.</span>
          </div>
        )}
        {retry.isError && <ErrorState error={retry.error} />}
        {s.status === "partial" && <Notice>{s.points_failed} of {s.points_total} points returned no data and are excluded from all metrics.</Notice>}
      </div>

      <div className="mb-4 grid grid-cols-2 gap-3 md:grid-cols-5">
        {kpis.map(([label, value, tip]) => (
          <Card key={label}><p className="text-xs text-slate-500" title={tip}>{label} ⓘ</p><p className="mt-1 text-xl font-semibold text-navy-900">{value}</p></Card>
        ))}
      </div>

      <div className="mb-3 flex flex-wrap items-center justify-between gap-3">
        <Legend counts={counts} active={visible} onToggle={toggle} />
        {campaign.data && campaign.data.competitors.length > 0 && (
          <Select aria-label="Business shown" value={competitorId} onChange={(e) => { setCompetitorId(e.target.value); setSelected(null); }} className="max-w-xs">
            <option value="">{campaign.data.location_name} (your business)</option>
            {campaign.data.competitors.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
          </Select>
        )}
      </div>

      <div className="grid gap-4 lg:grid-cols-[1fr_320px]">
        <GeoGrid markers={markers} center={{ lat: s.center_lat, lng: s.center_lng }} selected={selected} onSelect={setSelected} />
        <Card title={selected === null ? "Point details" : `Point ${selected + 1}`}>
          {selected === null ? <p className="text-sm text-slate-500">Select a point on the grid.</p>
            : active ? <p className="text-sm text-slate-500">Details are available when the scan finishes.</p>
            : point.isError ? <ErrorState error={point.error} onRetry={() => point.refetch()} />
            : !point.data ? <Skeleton rows={5} />
            : (
              <div className="space-y-3 text-sm">
                <p className="text-slate-500">{point.data.latitude.toFixed(6)}, {point.data.longitude.toFixed(6)}</p>
                {point.data.fetched_at && <p className="text-slate-500">Scanned {new Date(point.data.fetched_at).toLocaleString()}</p>}
                {point.data.point_status === "error" && (
                  <p className="rounded border border-red-200 bg-red-50 px-2 py-1 text-red-800">
                    No data for this point ({point.data.error_code}). This is an API failure, not a ranking.
                  </p>
                )}
                <ul className="divide-y divide-slate-100">
                  {point.data.businesses.map((b) => {
                    const bucket = bucketFor(b.result_status, b.position);
                    return (
                      <li key={b.subject_id} className="flex items-center justify-between gap-2 py-1.5">
                        <span>{b.name} {b.subject_type === "location" && <Badge tone="blue">You</Badge>}</span>
                        <span className="rounded-full px-2 py-0.5 text-xs font-bold" style={{ background: BUCKETS[bucket].bg, color: BUCKETS[bucket].fg, border: bucket === "error" ? "1px dashed #b91c1c" : undefined }}>
                          {b.result_status === "ranked" ? `#${b.position}` : b.result_status === "not_found" ? "Not found" : "No data"}
                        </span>
                      </li>
                    );
                  })}
                </ul>
                {point.data.top_listings && point.data.top_listings.length > 0 && (
                  <div>
                    <p className="mb-1 text-xs font-semibold uppercase text-slate-500">Top results at this point</p>
                    <ol className="space-y-0.5 text-xs text-slate-600">
                      {point.data.top_listings.slice(0, 10).map((l) => <li key={l.position}>{l.position}. {l.title ?? "Unnamed"}{l.rating ? ` · ${l.rating}★` : ""}</li>)}
                    </ol>
                  </div>
                )}
                {point.data.check_url && <a className="text-xs text-blue-600 underline" href={point.data.check_url} target="_blank" rel="noopener noreferrer">Open this search in Google Maps</a>}
              </div>
            )}
        </Card>
      </div>
    </>
  );
}
