"use client";

import { useQuery } from "@tanstack/react-query";
import Link from "next/link";
import { useParams } from "next/navigation";
import { useMemo, useState } from "react";

import { GeoGrid, SwatchLegend, type GridMarker } from "@/components/GeoGrid";
import { Badge, Card, EmptyState, ErrorState, Notice, PageHeader, Select, Skeleton, Table, Td, Th } from "@/components/ui";
import { useApi } from "@/lib/auth";
import { DOMINANCE, DOMINANCE_ORDER, dominanceLabel } from "@/lib/compare";
import { bucketFor, formatMetric, markerLabel } from "@/lib/geogrid";
import type { CompetitorComparison, ScanDetail } from "@/lib/types";

function rankMarkers(detail: ScanDetail | undefined): GridMarker[] {
  if (!detail) return [];
  return detail.points.map((p) => ({ index: p.point_index, row: p.row_no, col: p.col_no, lat: p.latitude, lng: p.longitude,
    label: markerLabel(p.result_status, p.position, detail.scan.depth), bucket: bucketFor(p.result_status, p.position) }));
}

export default function CompetitorComparisonPage() {
  const { id } = useParams<{ id: string }>();
  const api = useApi();
  const [left, setLeft] = useState("");            // "" = the tracked business
  const [right, setRight] = useState<string | null>(null);
  const [selected, setSelected] = useState<number | null>(null);

  const cmp = useQuery({ queryKey: ["competitors", id], queryFn: () => api.get<CompetitorComparison>(`/scans/${id}/competitors`) });
  const competitors = useMemo(() => (cmp.data?.businesses ?? []).filter((b) => b.subject_type === "competitor"), [cmp.data]);
  const rightId = right ?? competitors[0]?.subject_id ?? "";
  const leftDetail = useQuery({ queryKey: ["scan", id, left], queryFn: () => api.get<ScanDetail>(`/scans/${id}`, { competitor_id: left }), enabled: !!cmp.data });
  const rightDetail = useQuery({ queryKey: ["scan", id, rightId], queryFn: () => api.get<ScanDetail>(`/scans/${id}`, { competitor_id: rightId }), enabled: !!cmp.data && !!rightId });

  const dominanceMarkers = useMemo<GridMarker[]>(() => {
    const grid = new Map((leftDetail.data?.points ?? []).map((p) => [p.point_index, p]));
    return (cmp.data?.dominance?.points ?? []).flatMap((d) => {
      const p = grid.get(d.point_index);
      if (!p) return [];
      return [{ index: d.point_index, row: p.row_no, col: p.col_no, lat: d.latitude, lng: d.longitude,
        label: dominanceLabel(d.dominance, d.my_position, d.leader_position), bucket: "pending" as const, style: DOMINANCE[d.dominance] }];
    });
  }, [cmp.data, leftDetail.data]);

  if (cmp.isError) return <ErrorState error={cmp.error} onRetry={() => cmp.refetch()} />;
  if (!cmp.data) return <Skeleton rows={8} />;
  const { scan: s, businesses, dominance } = cmp.data;
  const center = { lat: s.center_lat, lng: s.center_lng };
  const nameOf = (sid: string | null) => businesses.find((b) => b.subject_id === sid)?.name ?? "—";
  const picked = selected !== null ? dominance?.points.find((p) => p.point_index === selected) : undefined;
  const options = businesses.map((b) => ({ value: b.subject_type === "location" ? "" : b.subject_id, label: b.subject_type === "location" ? `${b.name} (you)` : b.name }));

  return (
    <>
      <PageHeader title="Competitor comparison" subtitle={`“${s.keyword_text}” · ${s.grid_size}×${s.grid_size} grid · ${s.completed_at ? new Date(s.completed_at).toLocaleString() : ""}`}
        actions={<Link href={`/scans/${id}`} className="rounded-md border border-slate-300 bg-white px-3.5 py-2 text-sm font-medium">Back to grid</Link>} />
      <div className="mb-4 space-y-2">
        {cmp.data.data_notice && <Notice>{cmp.data.data_notice}</Notice>}
        <p className="text-xs text-slate-500">
          Every business is read from the same search results at each grid point: same keyword, coordinates, time and search settings. Source: {cmp.data.data_source}.
        </p>
      </div>

      <Table head={<><Th>Business</Th><Th>Average rank</Th><Th>Top 3</Th><Th>Top 10</Th><Th>Top 20</Th><Th>Not found</Th><Th>Valid points</Th></>}>
        {businesses.map((b) => (
          <tr key={b.subject_id}>
            <Td className="font-medium">{b.name} {b.subject_type === "location" && <Badge tone="blue">You</Badge>}</Td>
            <Td>{formatMetric(b.average_position)}</Td>
            <Td>{formatMetric(b.top3_coverage, "%")} <span className="text-xs text-slate-400">({b.top3_count})</span></Td>
            <Td>{formatMetric(b.top10_coverage, "%")} <span className="text-xs text-slate-400">({b.top10_count})</span></Td>
            <Td>{formatMetric(b.top20_coverage, "%")} <span className="text-xs text-slate-400">({b.top20_count})</span></Td>
            <Td>{formatMetric(b.not_found_pct, "%")}</Td>
            <Td>{b.valid_points} of {b.total_points}</Td>
          </tr>
        ))}
      </Table>
      <p className="mt-2 text-xs text-slate-500">Average rank counts only points where the business was found. Coverage is the share of valid points; failed points are excluded.</p>

      {!dominance ? (
        <div className="mt-6"><EmptyState title="No competitors in this scan" text="Add competitors to the campaign; they are included from the next scan onward. Past scans are not changed." /></div>
      ) : (
        <>
          <Card title="Geographic dominance" className="mt-6">
            <div className="mb-3"><SwatchLegend order={DOMINANCE_ORDER} swatches={DOMINANCE} counts={dominance.counts} /></div>
            {leftDetail.isError ? <ErrorState error={leftDetail.error} /> : !leftDetail.data ? <Skeleton rows={6} />
              : <GeoGrid markers={dominanceMarkers} center={center} selected={selected} onSelect={setSelected} height={420} />}
            <p className="mt-3 text-sm text-slate-600">
              {picked
                ? <><strong>Point {picked.point_index + 1}:</strong> {DOMINANCE[picked.dominance].label}. You: {picked.my_position ?? "not found"}. Best competitor: {picked.leader_id ? `${nameOf(picked.leader_id)} at ${picked.leader_position}` : "none found"}.</>
                : <>Markers show your position / the best competitor's position. Rankings within {dominance.tolerance} positions count as similar; “everyone weak” means nobody is inside the top 20.</>}
            </p>
          </Card>

          <h2 className="mb-3 mt-8 text-sm font-semibold text-slate-700">Side by side</h2>
          <div className="grid gap-4 lg:grid-cols-2">
            {([[left, setLeft, leftDetail], [rightId, setRight, rightDetail]] as const).map(([value, setValue, detail], i) => (
              <Card key={i} title={i === 0 ? "Business A" : "Business B"}
                actions={<Select aria-label={i === 0 ? "Business A" : "Business B"} value={value} onChange={(e) => setValue(e.target.value)} className="w-56">
                  {options.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
                </Select>}>
                {detail.isError ? <ErrorState error={detail.error} /> : !detail.data ? <Skeleton rows={6} />
                  : <>
                      <GeoGrid markers={rankMarkers(detail.data)} center={center} selected={selected} onSelect={setSelected} height={360} />
                      <p className="mt-2 text-xs text-slate-500">
                        Average rank {formatMetric(detail.data.metrics?.average_position)} · Top 3 {formatMetric(detail.data.metrics?.top3_coverage, "%")} · Top 10 {formatMetric(detail.data.metrics?.top10_coverage, "%")}
                      </p>
                    </>}
              </Card>
            ))}
          </div>
        </>
      )}
    </>
  );
}
