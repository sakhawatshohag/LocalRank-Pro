"use client";

import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect, useState } from "react";

import { Badge, Button, Card, EmptyState, ErrorState, Field, Input, Modal, Notice, PageHeader, Select, Skeleton, Table, Td, Th } from "@/components/ui";
import { useApi, useAuth } from "@/lib/auth";
import { LIMIT_LABELS, formatMoney } from "@/lib/billing";
import type { AdminOrg, AdminPlan, AdminUser, PlanLimits } from "@/lib/types";

type Overview = Record<string, unknown> & {
  organizations: number; users: number; active_users_30d: number; scans_queued: number; scans_running: number; failed_scans_24h: number;
  api_requests_30d: number; api_failed_30d: number; api_cost_30d_usd: number | string; reports_failed_7d: number; reports_queued: number;
  subscriptions_by_status: Record<string, number>; orgs_by_plan: Record<string, number>; mrr_cents_by_currency: Record<string, number>;
  paid_last_30d_cents_by_currency: Record<string, number>; scans_30d_by_status: Record<string, number>;
  provider_health_24h: Record<string, { requests: number; failed: number }>;
};
const TABS = ["Overview", "Organizations", "Users", "Plans", "API pricing", "Maintenance", "Audit log"] as const;

const kv = (o: Record<string, number> | undefined, money = false) =>
  !o || Object.keys(o).length === 0 ? "—" : Object.entries(o).map(([k, v]) => `${money ? formatMoney(v, k) : `${k}: ${v}`}`).join(" · ");

function OverviewTab() {
  const api = useApi();
  const q = useQuery({ queryKey: ["admin", "overview"], queryFn: () => api.get<Overview>("/admin/overview"), refetchInterval: 30_000 });
  if (q.isError) return <ErrorState error={q.error} onRetry={() => q.refetch()} />;
  if (!q.data) return <Skeleton rows={6} />;
  const o = q.data;
  const cards: [string, string | number][] = [
    ["Organizations", o.organizations], ["Active users", o.users], ["Signed in, last 30 days", o.active_users_30d],
    ["MRR (catalogue prices)", kv(o.mrr_cents_by_currency, true)], ["Paid, last 30 days", kv(o.paid_last_30d_cents_by_currency, true)],
    ["API requests, 30 days", `${o.api_requests_30d} (${o.api_failed_30d} failed)`], ["API cost, 30 days", `$${Number(o.api_cost_30d_usd).toFixed(2)}`],
    ["Scan queue", `${o.scans_queued} queued · ${o.scans_running} running`], ["Failed scans, 24 h", o.failed_scans_24h],
    ["Reports", `${o.reports_queued} in progress · ${o.reports_failed_7d} failed (7 days)`],
  ];
  return (
    <>
      <div className="grid grid-cols-2 gap-3 md:grid-cols-5">
        {cards.map(([l, v]) => <Card key={l}><p className="text-xs text-slate-500">{l}</p><p className="mt-1 text-lg font-semibold text-navy-900">{v}</p></Card>)}
      </div>
      <div className="mt-4 grid gap-4 md:grid-cols-2">
        <Card title="Subscriptions by status"><p className="text-sm">{kv(o.subscriptions_by_status)}</p></Card>
        <Card title="Organizations by plan"><p className="text-sm">{kv(o.orgs_by_plan)}</p></Card>
        <Card title="Scans, last 30 days"><p className="text-sm">{kv(o.scans_30d_by_status)}</p></Card>
        <Card title="Provider health, last 24 h">
          {Object.keys(o.provider_health_24h).length === 0 ? <p className="text-sm text-slate-500">No requests.</p> :
            <ul className="text-sm">{Object.entries(o.provider_health_24h).map(([p, h]) => (
              <li key={p}>{p}: {h.requests} requests, {h.failed} failed {h.requests > 0 && h.failed / h.requests > 0.1 && <Badge tone="red">High failure rate</Badge>}</li>))}</ul>}
        </Card>
      </div>
      <p className="mt-3 text-xs text-slate-500">MRR is calculated from the plan catalogue prices of active subscriptions, not from payments; “Paid” comes from stored invoices.</p>
    </>
  );
}

function OrganizationsTab() {
  const api = useApi();
  const qc = useQueryClient();
  const [q, setQ] = useState("");
  const orgs = useQuery({ queryKey: ["admin", "orgs", q], queryFn: () => api.get<AdminOrg[]>("/admin/organizations", { q }) });
  const plans = useQuery({ queryKey: ["admin", "plans"], queryFn: () => api.get<AdminPlan[]>("/admin/plans") });
  const setPlan = useMutation({ mutationFn: (v: { id: string; plan: string }) => api.put(`/admin/organizations/${v.id}/plan`, { plan_code: v.plan }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["admin"] }) });
  return (
    <>
      <Input aria-label="Search organizations" placeholder="Search organizations…" value={q} onChange={(e) => setQ(e.target.value)} className="mb-3 max-w-xs" />
      {setPlan.isError && <div className="mb-3"><ErrorState error={setPlan.error} /></div>}
      {orgs.isError ? <ErrorState error={orgs.error} /> : !orgs.data ? <Skeleton /> : orgs.data.length === 0 ? <EmptyState title="No organizations" /> : (
        <Table head={<><Th>Organization</Th><Th>Plan</Th><Th>Subscription</Th><Th>Members</Th><Th>Locations</Th><Th>Scans 30 d</Th><Th>API cost 30 d</Th></>}>
          {orgs.data.map((o) => (
            <tr key={o.id}>
              <Td><span className="font-medium">{o.name}</span><span className="block text-xs text-slate-500">since {new Date(o.created_at).toLocaleDateString()}</span></Td>
              <Td>
                <Select aria-label={`Plan of ${o.name}`} value={o.plan_code ?? ""} className="w-40" onChange={(e) => setPlan.mutate({ id: o.id, plan: e.target.value })}>
                  {plans.data?.map((p) => <option key={p.code} value={p.code}>{p.name}</option>)}
                </Select>
              </Td>
              <Td>{o.subscription_status ?? "—"}</Td><Td>{o.members}</Td><Td>{o.locations}</Td><Td>{o.scans_30d}</Td>
              <Td>${Number(o.api_cost_30d_usd).toFixed(2)}</Td>
            </tr>
          ))}
        </Table>
      )}
      <p className="mt-2 text-xs text-slate-500">Changing a plan here is a manual override (for example an invoiced enterprise customer). A later Stripe event for the organization replaces it.</p>
    </>
  );
}

function UsersTab() {
  const api = useApi();
  const qc = useQueryClient();
  const { me } = useAuth();
  const [q, setQ] = useState("");
  const users = useQuery({ queryKey: ["admin", "users", q], queryFn: () => api.get<AdminUser[]>("/admin/users", { q }) });
  const toggle = useMutation({ mutationFn: (u: AdminUser) => api.put(`/admin/users/${u.id}/active?active=${!u.is_active}`, {}),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["admin", "users"] }) });
  return (
    <>
      <Input aria-label="Search users" placeholder="Search by email or name…" value={q} onChange={(e) => setQ(e.target.value)} className="mb-3 max-w-xs" />
      {toggle.isError && <div className="mb-3"><ErrorState error={toggle.error} /></div>}
      {users.isError ? <ErrorState error={users.error} /> : !users.data ? <Skeleton /> : (
        <Table head={<><Th>User</Th><Th>Organizations</Th><Th>Last sign-in</Th><Th>Status</Th><Th /></>}>
          {users.data.map((u) => (
            <tr key={u.id}>
              <Td><span className="font-medium">{u.email}</span>{u.full_name && <span className="block text-xs text-slate-500">{u.full_name}</span>} {u.is_super_admin && <Badge tone="blue">Super Admin</Badge>}</Td>
              <Td className="text-xs">{u.organizations ?? "—"}</Td>
              <Td>{u.last_login_at ? new Date(u.last_login_at).toLocaleString() : "Never"}</Td>
              <Td>{u.is_active ? <Badge tone="green">Active</Badge> : <Badge tone="red">Deactivated</Badge>}</Td>
              <Td className="text-right">{u.id !== me?.user_id && <Button variant="ghost" onClick={() => toggle.mutate(u)}>{u.is_active ? "Deactivate" : "Reactivate"}</Button>}</Td>
            </tr>
          ))}
        </Table>
      )}
    </>
  );
}

const EMPTY_LIMITS: Required<PlanLimits> = { locations: 0, keywords: 0, campaigns: 0, competitors: 0, max_grid_size: 0, monthly_scan_points: 0, team_members: 1, white_label: false };

function PlansTab() {
  const api = useApi();
  const qc = useQueryClient();
  const plans = useQuery({ queryKey: ["admin", "plans"], queryFn: () => api.get<AdminPlan[]>("/admin/plans") });
  const [edit, setEdit] = useState<(AdminPlan & { price: string }) | null>(null);
  const save = useMutation({
    mutationFn: (p: AdminPlan & { price: string }) => api.put(`/admin/plans/${p.code}`, {
      code: p.code, name: p.name, description: p.description || null, limits: { ...EMPTY_LIMITS, ...p.limits },
      monthly_price_cents: p.price.trim() === "" ? null : Math.round(Number(p.price) * 100), currency: p.currency,
      stripe_price_id: p.stripe_price_id || null, is_public: p.is_public, sort_order: p.sort_order, is_active: p.is_active }),
    onSuccess: () => { setEdit(null); qc.invalidateQueries({ queryKey: ["admin", "plans"] }); },
  });
  const open = (p?: AdminPlan) => { save.reset(); setEdit(p ? { ...p, price: p.monthly_price_cents === null ? "" : String(p.monthly_price_cents / 100) }
    : { code: "", name: "", description: "", limits: { ...EMPTY_LIMITS }, monthly_price_cents: null, currency: "usd", stripe_price_id: null, is_public: false, sort_order: 100, is_active: true, organizations: 0, price: "" }); };
  const setLimit = (k: keyof PlanLimits, v: string | boolean) => edit && setEdit({ ...edit, limits: { ...edit.limits, [k]: typeof v === "boolean" ? v : Number(v) } });

  if (plans.isError) return <ErrorState error={plans.error} />;
  if (!plans.data) return <Skeleton />;
  return (
    <>
      <div className="mb-3 flex justify-end"><Button onClick={() => open()}>New plan</Button></div>
      <Table head={<><Th>Plan</Th><Th>Price</Th><Th>Stripe price</Th><Th>Visible</Th><Th>Organizations</Th><Th /></>}>
        {plans.data.map((p) => (
          <tr key={p.code}>
            <Td><span className="font-medium">{p.name}</span><span className="block text-xs text-slate-500">{p.code}</span></Td>
            <Td>{p.monthly_price_cents === null ? "—" : formatMoney(p.monthly_price_cents, p.currency)}</Td>
            <Td className="text-xs">{p.stripe_price_id ?? "—"}</Td>
            <Td>{!p.is_active ? <Badge>Inactive</Badge> : p.is_public ? <Badge tone="green">Public</Badge> : <Badge>Hidden</Badge>}</Td>
            <Td>{p.organizations}</Td>
            <Td className="text-right"><Button variant="ghost" onClick={() => open(p)}>Edit</Button></Td>
          </tr>
        ))}
      </Table>
      <p className="mt-2 text-xs text-slate-500">Prices shown here are for display; the amount charged is set on the Stripe price. Create the price in Stripe first, then paste its ID.</p>
      {edit && (
        <Modal title={edit.organizations || plans.data.some((p) => p.code === edit.code) ? `Edit ${edit.code}` : "New plan"} onClose={() => setEdit(null)}>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Code (fixed once created)"><Input value={edit.code} disabled={plans.data.some((p) => p.code === edit.code && p.organizations > 0)} onChange={(e) => setEdit({ ...edit, code: e.target.value })} /></Field>
            <Field label="Name"><Input value={edit.name} onChange={(e) => setEdit({ ...edit, name: e.target.value })} /></Field>
            <Field label="Price per month (blank = not sold online)"><Input inputMode="decimal" value={edit.price} onChange={(e) => setEdit({ ...edit, price: e.target.value })} /></Field>
            <Field label="Currency"><Input value={edit.currency} onChange={(e) => setEdit({ ...edit, currency: e.target.value.toLowerCase() })} /></Field>
            <Field label="Stripe price ID"><Input value={edit.stripe_price_id ?? ""} placeholder="price_…" onChange={(e) => setEdit({ ...edit, stripe_price_id: e.target.value })} /></Field>
            <Field label="Sort order"><Input inputMode="numeric" value={edit.sort_order} onChange={(e) => setEdit({ ...edit, sort_order: Number(e.target.value) })} /></Field>
            {LIMIT_LABELS.map(([k, l]) => (
              <Field key={k} label={l}><Input inputMode="numeric" value={String(edit.limits[k] ?? 0)} onChange={(e) => setLimit(k, e.target.value)} /></Field>
            ))}
          </div>
          <Field label="Description"><Input value={edit.description ?? ""} onChange={(e) => setEdit({ ...edit, description: e.target.value })} /></Field>
          <div className="mt-3 flex flex-wrap gap-4 text-sm">
            <label className="flex items-center gap-2"><input type="checkbox" checked={!!edit.limits.white_label} onChange={(e) => setLimit("white_label", e.target.checked)} /> White label</label>
            <label className="flex items-center gap-2"><input type="checkbox" checked={edit.is_public} onChange={(e) => setEdit({ ...edit, is_public: e.target.checked })} /> Shown to customers</label>
            <label className="flex items-center gap-2"><input type="checkbox" checked={edit.is_active} onChange={(e) => setEdit({ ...edit, is_active: e.target.checked })} /> Active</label>
          </div>
          {save.isError && <div className="mt-3"><ErrorState error={save.error} /></div>}
          <div className="mt-4 flex justify-end gap-2"><Button variant="secondary" onClick={() => setEdit(null)}>Cancel</Button><Button loading={save.isPending} onClick={() => save.mutate(edit)}>Save plan</Button></div>
        </Modal>
      )}
    </>
  );
}

function PricingTab() {
  const api = useApi();
  const qc = useQueryClient();
  const data = useQuery({ queryKey: ["admin", "pricing"], queryFn: () => api.get<{ prices: { provider_code: string; mode: string; unit_price_usd: number; results_per_unit: number; source_url: string | null; verified_on: string | null }[]; providers: { code: string; name: string; is_enabled: boolean }[] }>("/admin/api-pricing") });
  const [form, setForm] = useState({ provider: "dataforseo", mode: "live", unit_price_usd: "", results_per_unit: "100", source_url: "" });
  const refresh = () => qc.invalidateQueries({ queryKey: ["admin", "pricing"] });
  const save = useMutation({ mutationFn: () => api.put("/admin/api-pricing", { ...form, unit_price_usd: Number(form.unit_price_usd), results_per_unit: Number(form.results_per_unit) }), onSuccess: refresh });
  const toggle = useMutation({ mutationFn: (p: { code: string; is_enabled: boolean }) => api.put(`/admin/providers/${p.code}?enabled=${!p.is_enabled}`, {}), onSuccess: refresh });
  if (data.isError) return <ErrorState error={data.error} />;
  if (!data.data) return <Skeleton />;
  return (
    <div className="grid gap-6 lg:grid-cols-2">
      <Card title="Price table (used for cost estimates)">
        <ul className="divide-y divide-slate-100 text-sm">
          {data.data.prices.map((p) => (
            <li key={p.provider_code + p.mode} className="py-2">
              <strong>{p.provider_code}</strong> · {p.mode}: ${p.unit_price_usd} per {p.results_per_unit} results
              <span className="block text-xs text-slate-500">{p.verified_on ? `checked ${p.verified_on}` : "never checked"}{p.source_url && <> · <a className="text-blue-600" href={p.source_url} target="_blank" rel="noopener noreferrer">source</a></>}</span>
            </li>
          ))}
        </ul>
        <div className="mt-4 grid grid-cols-2 gap-2 border-t border-slate-100 pt-3">
          <Select aria-label="Provider" value={form.provider} onChange={(e) => setForm({ ...form, provider: e.target.value })}>{data.data.providers.map((p) => <option key={p.code}>{p.code}</option>)}</Select>
          <Select aria-label="Mode" value={form.mode} onChange={(e) => setForm({ ...form, mode: e.target.value })}><option>live</option><option>priority</option><option>standard</option></Select>
          <Input aria-label="Price in USD" placeholder="Price (USD)" inputMode="decimal" value={form.unit_price_usd} onChange={(e) => setForm({ ...form, unit_price_usd: e.target.value })} />
          <Input aria-label="Results per billed unit" inputMode="numeric" value={form.results_per_unit} onChange={(e) => setForm({ ...form, results_per_unit: e.target.value })} />
          <Input aria-label="Source URL" className="col-span-2" placeholder="Official pricing page URL (required)" value={form.source_url} onChange={(e) => setForm({ ...form, source_url: e.target.value })} />
          <Button className="col-span-2" loading={save.isPending} disabled={!form.unit_price_usd || !form.source_url} onClick={() => save.mutate()}>Save price</Button>
        </div>
        {save.isError && <div className="mt-2"><ErrorState error={save.error} /></div>}
      </Card>
      <Card title="Ranking providers">
        <ul className="divide-y divide-slate-100 text-sm">
          {data.data.providers.map((p) => (
            <li key={p.code} className="flex items-center justify-between py-2">
              <span>{p.name} <span className="text-xs text-slate-500">({p.code})</span></span>
              <Button variant="ghost" onClick={() => toggle.mutate(p)}>{p.is_enabled ? "Disable" : "Enable"}</Button>
            </li>
          ))}
        </ul>
        <p className="mt-2 text-xs text-slate-500">While a provider is disabled, new scans that use it are refused with a clear message.</p>
      </Card>
    </div>
  );
}

function MaintenanceTab() {
  const api = useApi();
  const qc = useQueryClient();
  const q = useQuery({ queryKey: ["admin", "maintenance"], queryFn: () => api.get<{ enabled: boolean; message: string | null }>("/admin/maintenance") });
  const [message, setMessage] = useState("");
  useEffect(() => { setMessage(q.data?.message ?? ""); }, [q.data]);
  const save = useMutation({ mutationFn: (enabled: boolean) => api.put("/admin/maintenance", { enabled, message: message || null }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["admin", "maintenance"] }) });
  if (!q.data) return q.isError ? <ErrorState error={q.error} /> : <Skeleton />;
  return (
    <Card title="Maintenance mode">
      {q.data.enabled ? <Notice>Maintenance mode is ON. Customers see the message below; Super Admins keep access.</Notice> : <p className="text-sm text-slate-600">The platform is open.</p>}
      <Field label="Message shown to customers"><Input value={message} onChange={(e) => setMessage(e.target.value)} placeholder="We are upgrading LocalRank Pro and will be back shortly." /></Field>
      <div className="mt-3 flex gap-2">
        <Button variant={q.data.enabled ? "secondary" : "danger"} loading={save.isPending} onClick={() => save.mutate(!q.data.enabled)}>{q.data.enabled ? "Turn off" : "Turn on"}</Button>
        {q.data.enabled && <Button variant="secondary" onClick={() => save.mutate(true)}>Update message</Button>}
      </div>
      <p className="mt-2 text-xs text-slate-500">Changes reach all API servers within about 30 seconds.</p>
      {save.isError && <div className="mt-2"><ErrorState error={save.error} /></div>}
    </Card>
  );
}

function AuditTab() {
  const api = useApi();
  const q = useQuery({ queryKey: ["admin", "audit"], queryFn: () => api.get<{ created_at: string; admin: string; action: string; target: string | null; detail: unknown }[]>("/admin/audit") });
  if (!q.data) return q.isError ? <ErrorState error={q.error} /> : <Skeleton />;
  return q.data.length === 0 ? <EmptyState title="No admin actions yet" /> : (
    <Table head={<><Th>When</Th><Th>Admin</Th><Th>Action</Th><Th>Target</Th><Th>Detail</Th></>}>
      {q.data.map((a, i) => <tr key={i}><Td>{new Date(a.created_at).toLocaleString()}</Td><Td>{a.admin}</Td><Td>{a.action}</Td><Td className="text-xs">{a.target}</Td><Td className="max-w-md truncate text-xs">{JSON.stringify(a.detail)}</Td></tr>)}
    </Table>
  );
}

export default function AdminPage() {
  const { me } = useAuth();
  const [tab, setTab] = useState<(typeof TABS)[number]>("Overview");
  if (!me?.is_super_admin) return <EmptyState title="Not found" />;
  return (
    <>
      <PageHeader title="Super Admin" subtitle="Platform-wide data. Every change is recorded in the audit log." />
      <div role="tablist" className="mb-4 flex flex-wrap gap-1 border-b border-slate-200">
        {TABS.map((t) => (
          <button key={t} role="tab" aria-selected={tab === t} onClick={() => setTab(t)}
            className={`-mb-px border-b-2 px-3 py-2 text-sm ${tab === t ? "border-blue-600 font-medium text-blue-700" : "border-transparent text-slate-600 hover:text-slate-900"}`}>{t}</button>
        ))}
      </div>
      {tab === "Overview" && <OverviewTab />}
      {tab === "Organizations" && <OrganizationsTab />}
      {tab === "Users" && <UsersTab />}
      {tab === "Plans" && <PlansTab />}
      {tab === "API pricing" && <PricingTab />}
      {tab === "Maintenance" && <MaintenanceTab />}
      {tab === "Audit log" && <AuditTab />}
    </>
  );
}
