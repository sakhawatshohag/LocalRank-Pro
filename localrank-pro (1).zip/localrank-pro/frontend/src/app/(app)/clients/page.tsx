"use client";

import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useState, type FormEvent } from "react";

import { Badge, Button, ConfirmDialog, EmptyState, ErrorState, Field, Input, Modal, PageHeader, Skeleton, Table, Td, Th } from "@/components/ui";
import { useApi, useAuth } from "@/lib/auth";
import { roleAtLeast } from "@/lib/nav";
import type { Client } from "@/lib/types";
import { clientSchema, fieldErrors } from "@/lib/validation";

export default function ClientsPage() {
  const api = useApi();
  const { me } = useAuth();
  const qc = useQueryClient();
  const canEdit = !!me && roleAtLeast(me.role, "manager");
  const [search, setSearch] = useState("");
  const [showArchived, setShowArchived] = useState(false);
  const [editing, setEditing] = useState<Client | "new" | null>(null);
  const [archiving, setArchiving] = useState<Client | null>(null);
  const [form, setForm] = useState({ name: "", contact_email: "", notes: "" });
  const [errors, setErrors] = useState<Record<string, string>>({});

  const list = useQuery({
    queryKey: ["clients", search, showArchived],
    queryFn: () => api.get<Client[]>("/clients", { q: search, include_archived: showArchived }),
  });
  const refresh = () => qc.invalidateQueries({ queryKey: ["clients"] });
  const save = useMutation({
    mutationFn: (body: unknown) => (editing && editing !== "new" ? api.put<Client>(`/clients/${editing.id}`, body) : api.post<Client>("/clients", body)),
    onSuccess: () => { setEditing(null); refresh(); },
  });
  const archive = useMutation({
    mutationFn: (c: Client) => api.post<Client>(`/clients/${c.id}/archive`, {}, { archived: !c.archived_at }),
    onSuccess: () => { setArchiving(null); refresh(); },
  });

  function open(c: Client | "new") {
    setForm(c === "new" ? { name: "", contact_email: "", notes: "" } : { name: c.name, contact_email: c.contact_email ?? "", notes: c.notes ?? "" });
    setErrors({}); save.reset(); setEditing(c);
  }
  function onSubmit(e: FormEvent) {
    e.preventDefault();
    const parsed = clientSchema.safeParse(form);
    if (!parsed.success) return setErrors(fieldErrors(parsed.error));
    setErrors({}); save.mutate(parsed.data);
  }

  return (
    <>
      <PageHeader title="Clients" subtitle="Each client's locations, campaigns and rankings are kept separate."
        actions={canEdit && <Button onClick={() => open("new")}>Add client</Button>} />
      <div className="mb-4 flex flex-wrap items-center gap-3">
        <Input aria-label="Search clients" placeholder="Search clients…" value={search} onChange={(e) => setSearch(e.target.value)} className="max-w-xs" />
        <label className="flex items-center gap-2 text-sm text-slate-600">
          <input type="checkbox" checked={showArchived} onChange={(e) => setShowArchived(e.target.checked)} /> Show archived
        </label>
      </div>
      {list.isError ? <ErrorState error={list.error} onRetry={() => list.refetch()} />
        : !list.data ? <Skeleton />
        : list.data.length === 0 ? (
          <EmptyState title={search ? "No clients match your search" : "No clients yet"}
            text={search ? undefined : "Add your first client to organise locations and campaigns."}
            action={canEdit && !search ? <Button onClick={() => open("new")}>Add client</Button> : undefined} />
        ) : (
          <Table head={<><Th>Name</Th><Th>Contact</Th><Th>Status</Th><Th /></>}>
            {list.data.map((c) => (
              <tr key={c.id}>
                <Td className="font-medium">{c.name}</Td>
                <Td>{c.contact_email ?? "—"}</Td>
                <Td>{c.archived_at ? <Badge tone="gray">Archived</Badge> : <Badge tone="green">Active</Badge>}</Td>
                <Td className="text-right">
                  {canEdit && <>
                    <Button variant="ghost" onClick={() => open(c)}>Edit</Button>
                    <Button variant="ghost" onClick={() => setArchiving(c)}>{c.archived_at ? "Restore" : "Archive"}</Button>
                  </>}
                </Td>
              </tr>
            ))}
          </Table>
        )}

      {editing && (
        <Modal title={editing === "new" ? "Add client" : "Edit client"} onClose={() => setEditing(null)}>
          <form onSubmit={onSubmit} noValidate className="space-y-4">
            <Field label="Client name" error={errors.name}><Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} autoFocus /></Field>
            <Field label="Contact email (optional)" error={errors.contact_email}><Input type="email" value={form.contact_email} onChange={(e) => setForm({ ...form, contact_email: e.target.value })} /></Field>
            <Field label="Internal notes (optional)" error={errors.notes}><Input value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} /></Field>
            {save.isError && <ErrorState error={save.error} />}
            <div className="flex justify-end gap-2">
              <Button type="button" variant="secondary" onClick={() => setEditing(null)}>Cancel</Button>
              <Button type="submit" loading={save.isPending}>Save</Button>
            </div>
          </form>
        </Modal>
      )}
      {archiving && (
        <ConfirmDialog title={archiving.archived_at ? "Restore client" : "Archive client"} loading={archive.isPending}
          text={<>{archiving.archived_at ? "Restore" : "Archive"} <strong>{archiving.name}</strong>? {archiving.archived_at ? "" : "Its data is kept and can be restored later."}{archive.isError && <span className="mt-2 block text-red-600">{archive.error.message}</span>}</>}
          confirmLabel={archiving.archived_at ? "Restore" : "Archive"} onConfirm={() => archive.mutate(archiving)} onCancel={() => setArchiving(null)} />
      )}
    </>
  );
}
