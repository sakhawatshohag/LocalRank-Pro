import assert from "node:assert/strict";
import test from "node:test";

import { assignableRoles, canManageMember, formatMoney, formatPrice, limitText, sortPlans, usageShare } from "../src/lib/billing";
import type { Plan } from "../src/lib/types";

test("prices and money", () => {
  assert.equal(formatPrice(9900, "usd"), "$99.00 / month");
  assert.equal(formatPrice(null), "Contact us");
  assert.equal(formatMoney(12345, "cad"), "CA$123.45");
  assert.equal(formatMoney(null, "usd"), "—");
});

test("usage and limits", () => {
  assert.equal(usageShare(18, 20), 90);
  assert.equal(usageShare(30, 20), 100);
  assert.equal(usageShare(0, 0), 0);
  assert.equal(usageShare(1, 0), 100);
  assert.equal(usageShare(5, undefined), null);
  assert.equal(limitText("max_grid_size", 15), "15×15");
  assert.equal(limitText("max_grid_size", 0), "None");
  assert.equal(limitText("monthly_scan_points", 50000), "50,000");
  assert.equal(limitText("white_label", true), "Yes");
});

test("plans sort by order then price", () => {
  const p = (code: string, sort: number, price: number | null) => ({ code, sort_order: sort, monthly_price_cents: price } as Plan);
  assert.deepEqual(sortPlans([p("agency", 30, 19900), p("pro", 20, 9900), p("starter", 20, 2900), p("ent", 30, null)]).map((x) => x.code),
    ["starter", "pro", "agency", "ent"]);
});

test("team role rules mirror the API", () => {
  assert.deepEqual(assignableRoles("owner"), ["admin", "manager", "seo_specialist", "client_viewer"]);
  assert.deepEqual(assignableRoles("admin"), ["manager", "seo_specialist", "client_viewer"]);
  assert.deepEqual(assignableRoles("manager"), []);
  assert.ok(canManageMember("owner", "admin") && canManageMember("admin", "manager"));
  assert.ok(!canManageMember("admin", "admin") && !canManageMember("admin", "owner") && !canManageMember("manager", "client_viewer"));
});
