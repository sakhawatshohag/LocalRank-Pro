import assert from "node:assert/strict";
import test from "node:test";

import { buildSeries, changeLabel, chartGeometry, describeChange, dominanceLabel } from "../src/lib/compare";
import type { BusinessMetrics, TrendEntry } from "../src/lib/types";

test("change labels and descriptions match the specification examples", () => {
  assert.equal(changeLabel("improved", 7), "+7");
  assert.equal(changeLabel("declined", -7), "−7");
  assert.equal(changeLabel("unchanged", 0), "=");
  assert.equal(changeLabel("newly_found", null), "NEW");
  assert.equal(changeLabel("lost_visibility", null), "LOST");
  assert.equal(changeLabel("not_comparable", null), "!");
  assert.equal(describeChange("improved", 15, 8, 7), "15 → 8, improved by 7 positions");
  assert.equal(describeChange("declined", 5, 12, -7), "5 → 12, declined by 7 positions");
  assert.equal(describeChange("unchanged", 8, 8, 0), "8 → 8, unchanged");
  assert.equal(describeChange("improved", 25, 15, 10), "25 → 15, improved by 10 positions");
  assert.equal(describeChange("improved", 3, 2, 1), "3 → 2, improved by 1 position");
  assert.equal(describeChange("newly_found", null, 9, null), "Not found → 9, newly found");
  assert.equal(describeChange("lost_visibility", 4, null, null), "4 → not found, lost visibility");
});

test("dominance labels", () => {
  assert.equal(dominanceLabel("mine", 2, 9), "2/9");
  assert.equal(dominanceLabel("competitor", null, 3), "–/3");
  assert.equal(dominanceLabel("all_weak", null, null), "–");
  assert.equal(dominanceLabel("no_data", null, null), "!");
});

const biz = (id: string, name: string, mine: boolean, avg: number | null, top3: number | null): BusinessMetrics =>
  ({ subject_id: id, name, subject_type: mine ? "location" : "competitor", average_position: avg, top3_coverage: top3 } as BusinessMetrics);
const entry = (date: string, businesses: BusinessMetrics[]): TrendEntry =>
  ({ id: date, status: "completed", is_demo: false, grid_signature: "g", created_at: date, completed_at: date, businesses });

test("trend series keep gaps for scans without data", () => {
  const entries = [
    entry("2026-11-01", [biz("me", "Me", true, 9, 20), biz("c", "Rival", false, 4, 60)]),
    entry("2026-11-07", []),                                            // failed scan: no metrics at all
    entry("2026-11-14", [biz("me", "Me", true, 5, 40), biz("c", "Rival", false, null, 0)]),
  ];
  const { dates, series } = buildSeries(entries, "average_position");
  assert.deepEqual(dates, ["2026-11-01", "2026-11-07", "2026-11-14"]);
  assert.deepEqual(series.map((s) => [s.name, s.isMine, s.values]), [["Me", true, [9, null, 5]], ["Rival", false, [4, null, null]]]);
  assert.deepEqual(buildSeries(entries, "top3_coverage").series[1].values, [60, null, 0], "0% coverage is a real value, not a gap");
});

test("chart geometry: inverted axis for positions, broken lines at gaps", () => {
  const g = chartGeometry([{ id: "me", name: "Me", isMine: true, values: [10, null, 2, 6] }], 4, 400, 200, 20, true);
  assert.equal(g.min, 2);
  assert.equal(g.max, 10);
  assert.equal(g.lines[0].segments.length, 2, "the null splits the line");
  const [first] = g.lines[0].segments[0];
  const [best] = g.lines[0].segments[1];
  assert.equal(first.x, 20);
  assert.ok(best.y < first.y, "position 2 is drawn above position 10");
  assert.equal(g.lines[0].segments[1][1].x, 380);
  const up = chartGeometry([{ id: "a", name: "A", isMine: true, values: [0, 100] }], 2, 400, 200, 20, false);
  assert.ok(up.lines[0].segments[0][1].y < up.lines[0].segments[0][0].y, "higher coverage is drawn higher");
  const flat = chartGeometry([{ id: "a", name: "A", isMine: true, values: [5, 5] }], 2, 400, 200, 20, true);
  assert.ok(Number.isFinite(flat.lines[0].segments[0][0].y), "a flat series does not divide by zero");
  const empty = chartGeometry([], 0, 400, 200, 20, true);
  assert.deepEqual(empty.lines, []);
});
