import assert from "node:assert/strict";
import test from "node:test";

import { ApiError, createApi } from "../src/lib/api";
import { defaultPeriod, isHexColor, validatePeriod } from "../src/lib/reports";

test("default report periods", () => {
  const today = new Date("2026-11-17T15:00:00Z");
  assert.deepEqual(defaultPeriod("weekly", today), ["2026-11-11", "2026-11-17"]);
  assert.deepEqual(defaultPeriod("monthly", today), ["2026-10-01", "2026-10-31"]);
  assert.deepEqual(defaultPeriod("monthly", new Date("2026-03-05T00:00:00Z")), ["2026-02-01", "2026-02-28"]);
  assert.deepEqual(defaultPeriod("monthly", new Date("2026-01-10T00:00:00Z")), ["2025-12-01", "2025-12-31"]);
  assert.deepEqual(defaultPeriod("performance", today), ["2026-10-19", "2026-11-17"]);
});

test("period and colour validation", () => {
  assert.equal(validatePeriod("2026-11-01", "2026-11-07"), null);
  assert.equal(validatePeriod("2026-11-08", "2026-11-07"), "The end date is before the start date");
  assert.equal(validatePeriod("", "2026-11-07"), "Choose a start and end date");
  assert.equal(validatePeriod("2025-01-01", "2026-11-07"), "A report can cover at most 400 days");
  assert.ok(isHexColor("#0b1f3a") && !isHexColor("0b1f3a") && !isHexColor("#0b1f3"));
});

test("authenticated file download", async () => {
  const seen: RequestInit[] = [];
  const api = createApi({
    baseUrl: "http://x", getToken: () => "tok",
    fetchImpl: (async (_u: string, init: RequestInit) => { seen.push(init); return new Response("%PDF-1.4", { status: 200 }); }) as typeof fetch,
  });
  const b = await api.blob("/reports/1/pdf");
  assert.equal(await b.text(), "%PDF-1.4");
  assert.equal((seen[0].headers as Record<string, string>).Authorization, "Bearer tok");
  const failing = createApi({ baseUrl: "http://x", getToken: () => "tok",
    fetchImpl: (async () => new Response(JSON.stringify({ detail: "The report is generating" }), { status: 409 })) as typeof fetch });
  await assert.rejects(failing.blob("/r"), (e: ApiError) => e.status === 409 && e.message === "The report is generating");
});
