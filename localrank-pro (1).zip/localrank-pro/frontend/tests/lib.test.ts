import assert from "node:assert/strict";
import test from "node:test";

import { ApiError, buildUrl, createApi, errorMessage } from "../src/lib/api";
import { bucketFor, formatDistance, formatMetric, isScanActive, markerLabel, summarize, toRows } from "../src/lib/geogrid";
import { navFor, roleAtLeast } from "../src/lib/nav";
import { campaignSchema, clientSchema, competitorSchema, fieldErrors, locationSchema, registerSchema } from "../src/lib/validation";

const json = (status: number, body: unknown) =>
  new Response(body === undefined ? null : JSON.stringify(body), { status, headers: { "Content-Type": "application/json" } });

test("api: sends bearer token, JSON body and query string", async () => {
  const calls: { url: string; init: RequestInit }[] = [];
  const api = createApi({
    baseUrl: "http://x/api/v1/", getToken: () => "tok",
    fetchImpl: (async (url: string, init: RequestInit) => { calls.push({ url, init }); return json(200, { ok: 1 }); }) as typeof fetch,
  });
  assert.deepEqual(await api.get("/clients", { q: "a b", include_archived: false, skip: null, empty: "" }), { ok: 1 });
  await api.post("/clients", { name: "A" });
  assert.equal(calls[0].url, "http://x/api/v1/clients?q=a%20b&include_archived=false");
  assert.equal((calls[0].init.headers as Record<string, string>).Authorization, "Bearer tok");
  assert.equal(calls[1].init.body, '{"name":"A"}');
  assert.equal(buildUrl("http://x", "/p"), "http://x/p");
});

test("api: errors become ApiError with a readable message; 401 triggers sign-out", async () => {
  let signedOut = 0;
  const mk = (res: Response | Error, token: string | null = "tok") =>
    createApi({ baseUrl: "http://x", getToken: () => token, onUnauthorized: () => { signedOut += 1; },
                fetchImpl: (async () => { if (res instanceof Error) throw res; return res; }) as typeof fetch });
  await assert.rejects(mk(json(404, { detail: "Client not found" })).get("/c"), (e: ApiError) => e.status === 404 && e.message === "Client not found");
  await assert.rejects(mk(json(401, { detail: "Invalid or expired token" })).get("/c"), ApiError);
  assert.equal(signedOut, 1);
  await assert.rejects(mk(json(401, { detail: "Incorrect email or password" }), null).post("/auth/login"), ApiError);
  assert.equal(signedOut, 1, "a failed login must not trigger sign-out");
  await assert.rejects(mk(new TypeError("network")).get("/c"), (e: ApiError) => e.status === 0 && /Cannot reach/.test(e.message));
  await assert.rejects(mk(new Response("<html>bad gateway</html>", { status: 502 })).get("/c"), (e: ApiError) => e.message === "Request failed (502)");
  assert.equal(await mk(new Response(null, { status: 204 })).del("/c"), undefined);
});

test("api: error message formats", () => {
  assert.equal(errorMessage(422, { detail: [{ loc: ["body", "latitude"], msg: "Input should be less than or equal to 85" }] }),
    "latitude: Input should be less than or equal to 85");
  assert.equal(errorMessage(409, { detail: { message: "This scan exceeds the cost threshold.", estimated_cost_usd: "2.0" } }),
    "This scan exceeds the cost threshold.");
  assert.equal(errorMessage(500, null), "Request failed (500)");
});

test("geogrid: colour buckets match the specification", () => {
  const cases: [number, string][] = [[1, "green"], [3, "green"], [4, "yellow"], [10, "yellow"], [11, "orange"], [20, "orange"], [21, "red"], [87, "red"]];
  for (const [pos, bucket] of cases) assert.equal(bucketFor("ranked", pos), bucket);
  assert.equal(bucketFor("not_found", null), "gray");
  assert.equal(bucketFor("error", null), "error");
  assert.equal(bucketFor(null, null), "pending");
  assert.equal(bucketFor("ranked", null), "error", "ranked without a position is never shown as a rank");
  assert.equal(bucketFor("ranked", 0), "error", "position 0 is never a rank");
});

test("geogrid: labels never show 0 for missing data", () => {
  assert.equal(markerLabel("ranked", 7, 100), "7");
  assert.equal(markerLabel("not_found", null, 100), "100+");
  assert.equal(markerLabel("not_found", null, 20), "20+");
  assert.equal(markerLabel("error", null, 100), "!");
  assert.equal(markerLabel(null, null, 100), "…");
});

test("geogrid: summary, rows and formatting", () => {
  const pts = [
    { row_no: 1, col_no: 1, result_status: "ranked" as const, position: 2 },
    { row_no: 0, col_no: 1, result_status: "not_found" as const, position: null },
    { row_no: 1, col_no: 0, result_status: "error" as const, position: null },
    { row_no: 0, col_no: 0, result_status: "ranked" as const, position: 15 },
  ];
  assert.deepEqual(summarize(pts), { green: 1, yellow: 0, orange: 1, red: 0, gray: 1, error: 1, pending: 0 });
  assert.deepEqual(toRows(pts).map((r) => r.map((p) => `${p.row_no}${p.col_no}`)), [["00", "01"], ["10", "11"]]);
  assert.equal(formatDistance(500), "500 m");
  assert.equal(formatDistance(2000), "2 km");
  assert.equal(formatDistance(1500), "1.5 km");
  assert.equal(formatMetric(null), "—");
  assert.equal(formatMetric(4.5), "4.50");
  assert.equal(formatMetric(37.5, "%"), "37.50%");
  assert.equal(formatMetric(3), "3");
  assert.ok(isScanActive("queued") && isScanActive("running") && !isScanActive("partial"));
});

test("nav: role hierarchy", () => {
  assert.ok(roleAtLeast("owner", "admin") && !roleAtLeast("client_viewer", "seo_specialist"));
  assert.ok(navFor("client_viewer").length > 0);
});

test("validation: forms", () => {
  assert.ok(!registerSchema.safeParse({ full_name: "A", organization_name: "B", email: "a@b.co", password: "short" }).success);
  assert.ok(registerSchema.safeParse({ full_name: "A", organization_name: "B", email: "a@b.co", password: "longenough1" }).success);
  assert.deepEqual(clientSchema.parse({ name: " Acme ", contact_email: "", notes: "" }), { name: "Acme", contact_email: null, notes: null });
  assert.ok(!clientSchema.safeParse({ name: "", contact_email: "", notes: "" }).success);

  const loc = locationSchema.parse({ name: "Biz", latitude: "43.65", longitude: "-79.38", place_id: " ChIJ_x ", cid: "" });
  assert.equal(loc.latitude, 43.65);
  assert.equal(loc.place_id, "ChIJ_x");
  assert.equal(loc.cid, null);
  assert.equal(loc.time_zone, "UTC");
  assert.ok(!locationSchema.safeParse({ name: "Biz", latitude: "abc", longitude: "0" }).success);
  assert.ok(!locationSchema.safeParse({ name: "Biz", latitude: "89", longitude: "0" }).success);

  const base = { location_id: "11111111-1111-4111-8111-111111111111", name: "C", spacing_m: "500" };
  assert.ok(campaignSchema.safeParse({ ...base, grid_size: "7" }).success);
  const even = campaignSchema.safeParse({ ...base, grid_size: "4" });
  assert.ok(!even.success && fieldErrors(even.error).grid_size === "Grid size must be odd");
  assert.ok(!campaignSchema.safeParse({ ...base, grid_size: "7", spacing_m: "10" }).success);

  const noId = competitorSchema.safeParse({ name: "Rival", place_id: "", cid: "" });
  assert.ok(!noId.success && /identifier/.test(fieldErrors(noId.error).place_id));
  assert.ok(competitorSchema.safeParse({ name: "Rival", place_id: "", cid: "123" }).success);
});

test("super admin navigation is hidden from everyone else", () => {
  assert.ok(!navFor("owner").some((n) => n.href === "/admin"));
  assert.ok(navFor("client_viewer", true).some((n) => n.href === "/admin"));
  assert.ok(!navFor("manager").some((n) => n.href === "/billing") && navFor("admin").some((n) => n.href === "/billing"));
});
