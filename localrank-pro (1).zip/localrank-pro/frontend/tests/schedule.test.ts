import assert from "node:assert/strict";
import test from "node:test";

import { allowanceShare, describeSchedule, isValidTime, timeAgo, validateSchedule } from "../src/lib/schedule";
import type { ScheduleProjection } from "../src/lib/types";

test("schedule descriptions and validation", () => {
  assert.equal(describeSchedule("weekly", null, "06:00", "America/Toronto"), "Weekly at 06:00 (America/Toronto)");
  assert.equal(describeSchedule("custom", 1, "23:30", "UTC"), "Every 1 day at 23:30 (UTC)");
  assert.equal(describeSchedule("custom", 5, "07:15", "UTC"), "Every 5 days at 07:15 (UTC)");
  assert.ok(isValidTime("00:00") && isValidTime("23:59"));
  assert.ok(!isValidTime("24:00") && !isValidTime("6:00") && !isValidTime("06:60"));
  assert.deepEqual(validateSchedule("daily", "", "06:00"), {});
  assert.deepEqual(Object.keys(validateSchedule("custom", "0", "06:00")), ["interval_days"]);
  assert.deepEqual(Object.keys(validateSchedule("custom", "2.5", "25:00")).sort(), ["interval_days", "local_time"]);
  assert.deepEqual(validateSchedule("custom", "90", "06:00"), {});
});

test("allowance share and relative time", () => {
  const p = { points_per_month: 300, monthly_points_limit: 1000 } as ScheduleProjection;
  assert.equal(allowanceShare(p), 30);
  assert.equal(allowanceShare({ ...p, monthly_points_limit: 0 }), null);
  const now = new Date("2026-11-17T12:00:00Z");
  assert.equal(timeAgo("2026-11-17T11:59:30Z", now), "just now");
  assert.equal(timeAgo("2026-11-17T11:45:00Z", now), "15 min ago");
  assert.equal(timeAgo("2026-11-17T09:00:00Z", now), "3 h ago");
  assert.equal(timeAgo("2026-11-16T12:00:00Z", now), "1 day ago");
});
