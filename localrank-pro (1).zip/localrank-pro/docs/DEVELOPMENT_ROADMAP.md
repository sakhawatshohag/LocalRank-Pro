# Development roadmap and status

Legend: ✅ implemented and tested · 🟡 implemented, not yet executed/tested · ⬜ pending

Last updated: 2026-11-17. Build sandbox had no package index access, so FastAPI, SQLAlchemy,
Celery and Next.js could not be installed or run there. Anything depending on them is 🟡 or ⬜.

## Phase 0 — Discovery ✅
* ✅ Environment inspected, architecture defined, DataForSEO docs and pricing verified

## Phase 1 — Foundation
* ✅ Database schema: tenancy, RLS, constraints, immutability (database checks pass on PostgreSQL 16)
* ✅ Migration runner (`scripts/migrate.sh`)
* ✅ Password hashing, JWT, role hierarchy, configuration validation
* 🟡 FastAPI app: register, login, me, clients CRUD, locations CRUD, plan-limit check, grid preview + cost estimate (code compiles; never run)
* 🟡 `0002_postgis.sql` (PostGIS not available in sandbox)
* 🟡 Dockerfile, docker-compose.yml (not built)
* ⬜ Email verification, password reset, refresh tokens, rate limiting
* ⬜ Team invitations and member management endpoints
* ✅ Frontend library layer: API client, GeoGrid colour/label rules, form validation, role navigation (8 tests, strict type-check)
* 🟡 Frontend screens: sign in, register, collapsible sidebar shell, overview, clients, locations (syntax-checked only; never installed, built or opened in a browser)

## Phase 2 — Rank tracking engine
* ✅ GeoGrid generation (3×3 … 15×15, custom up to 21×21), radius/spacing, grid signature
* ✅ Provider abstraction, subject matching by Place ID / CID
* ✅ DataForSEO request building, response normalisation, retries (tested against documented response shape)
* ⬜ **DataForSEO live verification** — run `pytest tests/live` with real credentials
* ✅ Scan execution for business + competitors from the same responses
* ✅ Demo provider (deterministic, flagged)
* ✅ Scan storage: `store_scan_result()` writes points, rankings, metrics, usage and final status atomically; rejects invented rankings, foreign businesses, wrong grids and double storage (27 database checks, payloads produced by the real Python pipeline)
* 🟡 Campaign, keyword, competitor endpoints (plan limits for campaigns, keywords, competitors, grid size)
* 🟡 Scan launch endpoint (cost estimate, confirmation threshold, monthly limit), scan service, Celery worker task
* 🟡 Read endpoints: GeoGrid of a scan, marker detail, history per keyword, two-scan comparison
* ⬜ Scan progress reporting, Place ID verification flow, concurrent point fetching
* 🟡 Campaign screens: list, create with live grid preview, draggable centre and cost estimate, keywords, competitors, run scan with cost confirmation, history table
* 🟡 GeoGrid screen: Google Maps markers with positions and colours, legend filters, full screen, business/competitor selector, point details, CSV export, auto-refresh while running; plain grid fallback without a Maps key

## Phase 3 — Historical analytics
* ✅ Per-scan metrics and two-scan comparison maths (improved / declined / unchanged / newly found / lost)
* ✅ Storage model that never overwrites scans
* 🟡 History, comparison and trend endpoints (SQL run once by hand against stored test data; endpoints never run)
* ✅ Change labels/descriptions and trend-chart geometry with gaps for missing data (frontend tests)
* 🟡 Historical rankings screen: keyword, business, period (7 days to 12 months, all time), previous/current scan pickers, change counts, side-by-side grids, change-per-point grid, trend chart for average position and Top 3/10/20 coverage (never built or opened)

## Phase 4 — Competitor intelligence
* ✅ Same-coordinate competitor resolution (engine)
* ✅ Competitor rankings stored from the same coordinates (database-tested)
* ✅ Dominance rules: you lead / competitor leads / similar / everyone weak / no data (engine tests)
* 🟡 Competitor comparison endpoint and screen: comparison table, geographic dominance grid, side-by-side business grids (never run)
* ⬜ Competitor gains and losses between dates as a dedicated view (available per business through the historical screen)

## Phase 5 — Automation
* ✅ Schedule maths: daily, every 2 days, weekly, every 2 weeks, monthly (month-end clamp), every N days; location time zone; daylight-saving edges (engine tests)
* ✅ Dispatcher: due schedules found across organizations without exposing data, one scan per keyword per occurrence, locked against concurrent dispatch, problems recorded and skipped, monthly allowance enforced (database integration tests)
* ✅ Maintenance: re-queue scans never picked up, fail scans stuck in "running" (database integration tests)
* ✅ Notifications: scan completed / failed, significant ranking improvement or decline, competitor gained ground, allowance at 80% and 100%, scheduled scan skipped; per-user preferences; idempotent per event (database integration tests)
* ✅ Full scan pipeline from step 2 (create → run → store → notify) now runs against PostgreSQL in tests for the first time
* ✅ Retry of failed/partial scans as a new scan; deleting a schedule keeps finished scans
* 🟡 Schedule, notification and retry endpoints (all their SQL executed against the database; FastAPI layer never run)
* 🟡 Celery beat + worker wiring, `beat` service in docker-compose (never run)
* 🟡 Screens: schedule card on the campaign page with cost and allowance projection, Scheduled Scans page, notification bell, notifications page with preferences, retry button (syntax-checked only)
* ⬜ Email sending (preferences are stored; rows are marked `pending` for a mailer)
* ⬜ DataForSEO Standard queue for cheaper scheduled scans (Live mode is used)
* ⬜ Fetching grid points concurrently (points are fetched one after another)

## Phase 6 — Reporting
* ✅ PDF renderer: cover with agency and client logos, executive summary, keyword summary table, per keyword previous vs current metrics, side-by-side GeoGrids, data-based observations, competitor table, scan history, "how to read" appendix, page header/footer, demo watermark (tests read the generated PDF back)
* ✅ CSV export of every grid point for every business
* ✅ Report types: weekly, monthly, local SEO performance, competitor comparison, GeoGrid comparison (two chosen scans), custom
* ✅ Generation from stored scans, kept for download; failed reports recorded with the reason (database integration tests)
* ✅ Automatic weekly/monthly reports: one report per period, never duplicated (database integration tests)
* ✅ White label: agency name, logo, colour, contact line, footer; "Generated with LocalRank Pro" removed only on plans with `white_label` (database integration tests)
* ✅ Logo uploads validated and re-encoded to PNG (tests)
* 🟡 Report, schedule, branding and logo endpoints (all their SQL executed against the database; FastAPI layer never run)
* 🟡 Screens: Reports page (create, automatic reports, history with PDF/CSV download, retry, delete), Settings page (branding, agency and client logos) (syntax-checked only)
* ⬜ Emailing reports to clients (needs the email integration)
* ⬜ Trend charts inside the PDF (tables are used)

## Phase 7 — Citations, reviews, Local SEO audit ⬜ (step 7b)

## Phase 8 — Commercial SaaS (step 7a)
* ✅ Plan catalogue in the database (limits, price for display, Stripe price ID, public/hidden, active); `inactive` plan for ended trials and cancelled subscriptions
* ✅ Stripe webhook handling: checkout links the customer; subscription created/updated/deleted sets the plan; past_due keeps the plan and warns; cancelled/unpaid moves to `inactive`; invoices stored; out-of-order events ignored; re-delivered events applied once; unknown price flagged, never guessed (database integration tests)
* ✅ Webhook signature verification, Stripe form encoding, current and pre-Basil billing period fields (tests with locally signed fixtures)
* ✅ Trial expiry job (database integration test)
* ✅ Team invitations by link (token stored only as SHA-256), lookup across organizations without exposing data (database integration test)
* ✅ Super Admin functions re-check `is_super_admin` in the database and write an audit log: overview (organizations, users, subscriptions, MRR from catalogue prices, payments, scans, API usage and cost, provider health, report failures), organizations, users, plan editor, organization plan override, API price table, provider on/off, maintenance mode (database integration tests)
* 🟡 Endpoints: billing overview, checkout, customer portal, webhook; team (members, roles, invitations, accept, switch organization); Super Admin. SQL of billing/team/auth executed against the database (this caught and fixed one broken query); FastAPI layer never run
* 🟡 Screens: Billing & Subscription, Team Management, invitation acceptance, organization switcher, Super Admin (7 tabs) (syntax-checked only)
* 🟡 Maintenance mode middleware (never run)
* ⬜ **Stripe live verification**: no keys were available; no real Stripe request has been made
* ⬜ Plan limit on historical retention (deleting history is irreversible; needs a decision)
* ⬜ Client Viewer restricted to assigned clients
* ⬜ Emailing invitations (links are shared manually)

## Phase 9 — Production readiness
* 🟡 Single-server production stack: `docker-compose.prod.yml` with Caddy (automatic HTTPS, security headers), plain PostgreSQL on x86 and ARM, restart policies, only ports 80/443 exposed (YAML validated; never built or started)
* ✅ Migration runner skips PostGIS when unavailable; all 7 migrations applied twice on plain PostgreSQL 16 (idempotent)
* ✅ Operator account commands: create account, add member, set plan, reset password, list (database integration tests); public sign-up switch `ALLOW_SIGNUP`
* 🟡 Daily backup script with 14-day retention (never run)
* 🟡 Deployment guide for Oracle Cloud Always Free / any VPS (never performed)
* ⬜ CI pipeline, monitoring and alerting, error tracking, external security review

## Acceptance criteria (section 30)

| # | Criterion | Status |
|---|---|---|
| 1 | Register and log in | 🟡 API + UI |
| 2 | Manage clients | 🟡 API + UI |
| 3 | Add business locations | 🟡 API + UI |
| 4 | Create keyword campaigns | 🟡 API + UI |
| 5 | Configure geographic grids | ✅ engine, 🟡 preview API + UI |
| 6 | Retrieve real API rankings | 🟡 awaiting live test |
| 7 | Rankings on interactive map | 🟡 |
| 8–9 | Competitors at matching coordinates | ✅ engine + storage, 🟡 API + UI incl. side-by-side |
| 10 | Every scan stored historically | ✅ storage function, 🟡 worker |
| 11–12 | Compare two dates, correct maths | ✅ maths, 🟡 API + UI |
| 13 | Scheduled scans | ✅ dispatch + idempotency (database-tested), 🟡 API/UI/beat |
| 14 | Client reports | ✅ generation + PDF/CSV (database-tested), 🟡 API/UI |
| 15 | Access permissions | ✅ database isolation, 🟡 API RBAC |
| 16 | API usage monitored | ✅ logged per request, ⬜ dashboard |
| 17 | Critical automated tests pass | ✅ for what exists (88 Python (28 of them against PostgreSQL) + 51 SQL checks + 22 frontend) |
| 18 | Deployable from documentation | ⬜ |

**The product is not production-ready.**

## Next steps, in order

1. On a machine with internet: `docker compose up --build`, exercise every endpoint (register → client → location → campaign → keyword → competitor → scan in DEMO_MODE), fix what surfaces, add API integration tests.
2. Add DataForSEO credentials, run `pytest tests/live` (one request, about $0.002), then one real 3×3 scan.
3. In `frontend/`: `npm install`, `npm run typecheck`, `npm run build`, then walk through every screen against the running API and fix what surfaces. Pin dependency versions (`package-lock.json`).
4. In Stripe test mode: create products/prices, add the price IDs to plans in Super Admin, point a webhook at `/api/v1/billing/webhook/stripe`, run a test checkout.
5. Step 7b: citations, reviews, Local SEO audit, production deployment.

Frontend items still open from the specification: shadcn/ui components and React Hook Form (plain components and zod validation are used for now), Recharts (a small built-in SVG chart is used for now), mobile layout review, component tests.
