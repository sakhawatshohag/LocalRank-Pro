# Database schema

Source of truth: `backend/migrations/*.sql`. PostgreSQL 16 + PostGIS.

```mermaid
erDiagram
    users ||--o{ organization_members : "belongs to"
    organizations ||--o{ organization_members : has
    plans ||--o{ organizations : "limits"
    organizations ||--o{ clients : owns
    clients ||--o{ business_locations : has
    business_locations ||--o{ campaigns : "tracked by"
    campaigns ||--o{ keywords : tracks
    campaigns ||--o{ competitors : "compares with"
    campaigns ||--o{ scan_schedules : "scheduled by"
    keywords ||--o{ scans : "scanned in"
    scan_schedules ||--o{ scans : triggers
    scans ||--o{ grid_points : "has points"
    grid_points ||--o{ ranking_results : "one per business"
    business_locations ||--o{ ranking_results : "subject (location)"
    competitors ||--o{ ranking_results : "subject (competitor)"
    scans ||--o{ historical_metrics : "derived per business"
    api_providers ||--o{ api_pricing : priced
    api_providers ||--o{ scans : "data source"
    organizations ||--o{ api_usage : consumes
    organizations ||--o{ audit_logs : records
```

Chain: Organization → Clients → Locations → Campaigns → Keywords → Scans → Grid Points → Ranking Results.

## Key rules enforced by the database

| Rule | Mechanism |
|---|---|
| An organization only sees its own rows | `FORCE ROW LEVEL SECURITY` + policy on `app.current_org` on all 13 tenant tables |
| A child row cannot point at another organization's parent | Composite foreign keys `(org_id, parent_id)` |
| A position exists only when ranked; never 0 | `CHECK ((result_status='ranked') = (position IS NOT NULL))`, `position >= 1` |
| Errors are distinct from not-found | `result_status` enum: `ranked`, `not_found`, `error`; `grid_points.status` + `error_code` |
| One result per business per grid point | Partial unique indexes on `ranking_results` |
| Every grid point has a unique coordinate | `UNIQUE (scan_id, latitude, longitude)` and `UNIQUE (scan_id, point_index)` |
| Historical rankings are never changed | Trigger blocks UPDATE/DELETE on `ranking_results`, `historical_metrics` |
| Finished scans are frozen | Trigger blocks UPDATE once status is completed/partial/failed/cancelled |
| Competitors are matched by identifier | `CHECK (place_id IS NOT NULL OR cid IS NOT NULL)` |
| Scheduled occurrence runs once | `UNIQUE (org_id, idempotency_key)`; key = schedule:keyword:local date |
| Notifications are per user and per event | `UNIQUE (user_id, dedupe_key)` |
| A scheduled report period is generated once | `UNIQUE (org_id, idempotency_key)` on `reports` |
| Logos are size-limited | CHECK on `octet_length(logo_png)`; the API also validates and re-encodes |
| Plan limits in one place | `plans.limits` JSON, read by `deps.enforce_plan_limit` |
| Prices are data, not code | `api_pricing` (app role has read-only access) |

Retention purges and organization deletion run in a transaction that sets `app.allow_purge = 'on'`;
that is the only way historical rows can be removed.

Scans store a snapshot (`grid_size`, `spacing_m`, centre, `search_config`, `depth`, `grid_signature`).
Two scans are compared point by point only when `grid_signature` and `search_config` match.

## Not created yet

`citations`, `reviews`, `subscriptions`, `invoices`, `scan_jobs`,
granular `roles`/`permissions` (roles are currently an enum on `organization_members`).
They are added by later migrations in the phase that uses them.
