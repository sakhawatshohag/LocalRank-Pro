# API documentation

Base path `/api/v1`. JSON. Authenticated endpoints need `Authorization: Bearer <access_token>`.
Interactive OpenAPI docs are served at `/docs` outside production.

**These endpoints are written but have not been executed yet.**

| Method | Path | Minimum role | Description |
|---|---|---|---|
| GET | `/health` | public | Database check, demo flag, provider configured flag |
| POST | `/auth/register` | public | Creates user + organization (trial plan) and returns a token |
| POST | `/auth/login` | public | Returns a token |
| GET | `/auth/me` | any member | Current user, organization, role |
| GET | `/clients?q=&include_archived=` | any member | List/search clients |
| POST | `/clients` | manager | Create client |
| PUT | `/clients/{id}` | manager | Update client |
| POST | `/clients/{id}/archive?archived=` | manager | Archive / restore |
| GET | `/locations?client_id=&q=&include_archived=` | any member | List/search locations |
| POST | `/locations` | seo_specialist | Create location (plan limit `locations` enforced) |
| PUT | `/locations/{id}` | seo_specialist | Update; changing Place ID/CID clears verification |
| POST | `/locations/{id}/archive?archived=` | manager | Archive / restore |
| DELETE | `/locations/{id}` | admin | Delete if it has no campaigns or history |
| POST | `/grid/preview` | any member | Grid coordinates + request count + cost estimate (no provider call) |
| GET | `/campaigns?location_id=` | any member | List campaigns with keyword/competitor counts and last scan |
| POST | `/campaigns` | seo_specialist | Create campaign (grid validated; plan limits `campaigns`, `max_grid_size`) |
| GET | `/campaigns/{id}` | any member | Campaign with keywords and competitors |
| PATCH | `/campaigns/{id}` | seo_specialist | Rename / pause. Grid and search settings are fixed to keep scans comparable |
| POST | `/campaigns/{id}/keywords` | seo_specialist | Add keyword (plan limit `keywords`) |
| PATCH | `/campaigns/{id}/keywords/{kid}` | seo_specialist | Pause / resume |
| DELETE | `/campaigns/{id}/keywords/{kid}` | manager | Delete if it has no scan history |
| POST | `/campaigns/{id}/competitors` | seo_specialist | Add competitor; Place ID or CID required (plan limit `competitors` per campaign) |
| DELETE | `/campaigns/{id}/competitors/{cid}` | manager | Delete if it has no ranking history |
| POST | `/campaigns/{id}/scans` | seo_specialist | Queue one scan per active keyword. `409` with the estimate if above the cost threshold and `confirm_cost` is false |
| GET | `/scans/{id}?competitor_id=` | any member | GeoGrid: points, coordinates, position/status/colour, metrics |
| GET | `/scans/{id}/points/{index}` | any member | Marker detail: every business at the point + top listings |
| GET | `/campaigns/{id}/history?keyword_id=&competitor_id=&days=` | any member | All scans of a keyword with metrics |
| GET | `/scans/compare/{previous}/{current}?competitor_id=` | any member | Point-by-point change between two scans |
| GET | `/scans/{id}/competitors?tolerance=` | any member | Comparison table for every business in the scan + per-point dominance (`mine`, `competitor`, `similar`, `all_weak`, `no_data`) |
| GET | `/campaigns/{id}/trend?keyword_id=&days=` | any member | Metrics of every business for each scan of a keyword; scans without data have an empty list |
| POST | `/scans/{id}/retry` | seo_specialist | Run a failed/partial scan's keyword again as a new scan |
| GET | `/schedules` | any member | All schedules with next/last run, last error and last scans |
| GET | `/campaigns/{id}/schedule?frequency=&interval_days=` | any member | Schedule (or null) + cost/allowance projection; parameters preview an unsaved schedule |
| PUT | `/campaigns/{id}/schedule` | seo_specialist | Create or change: `frequency`, `interval_days` (custom only, 1–90), `local_time`, `is_paused` |
| DELETE | `/campaigns/{id}/schedule` | manager | Stop scheduled scans; history is kept |
| GET | `/notifications?unread_only=&limit=` | any member | Your notifications + unread count |
| POST | `/notifications/{id}/read`, `/notifications/read-all` | any member | Mark read |
| GET / PUT | `/notifications/preferences` | any member | In-app / email choice per notification type |
| GET | `/reports?client_id=` | any member | Generated reports (newest first) |
| POST | `/reports` | seo_specialist | Queue a report: `client_id`, `report_type`, `period_start`, `period_end`, optional `title`, `campaign_ids`, `previous_scan_id` + `current_scan_id` (GeoGrid comparison), `include_competitors`, `include_history`, `recommendations` |
| GET | `/reports/{id}/pdf`, `/reports/{id}/csv` | any member | Download (409 while not ready) |
| POST | `/reports/{id}/retry` | seo_specialist | Re-queue a failed report |
| DELETE | `/reports/{id}` | manager | Delete a generated report (scans are not affected) |
| GET / PUT | `/clients/{id}/report-schedules` | any member / seo_specialist | Automatic weekly or monthly reports |
| DELETE | `/clients/{id}/report-schedules/{weekly\|monthly}` | manager | Stop an automatic report |
| GET / PUT | `/branding` | any member / admin | Agency name, contact line, colour, footer; shows whether the plan is white label |
| GET / PUT / DELETE | `/branding/logo`, `/clients/{id}/logo` | any member / admin (agency), manager (client) | Logos; upload as `{"data_base64": "..."}`, PNG/JPEG/WebP up to 1 MB, stored re-encoded as PNG |
| POST | `/auth/switch-org` | member | Token for another organization the user belongs to |
| GET | `/auth/invitations/{token}` | public | Invitation preview |
| POST | `/auth/accept-invite` | public | Accept: new email creates the account; existing account must give its password |
| GET | `/billing` | any member | Plan, limits, usage, subscription, public plans, invoices |
| POST | `/billing/checkout` | owner | Stripe Checkout URL for a public plan |
| POST | `/billing/portal` | owner | Stripe Customer Portal URL (change plan, payment method, cancel) |
| POST | `/billing/webhook/stripe` | Stripe (signed) | Subscription and invoice events |
| GET | `/team` | any member | Members and pending invitations |
| POST | `/team/invitations` | admin | Create an invitation link (plan limit `team_members`) |
| DELETE | `/team/invitations/{id}` | admin | Revoke |
| PATCH / DELETE | `/team/members/{user_id}` | admin | Change role / remove (owners only for admins and owners; last owner protected) |
| GET | `/admin/overview`, `/admin/organizations`, `/admin/users`, `/admin/plans`, `/admin/api-pricing`, `/admin/maintenance`, `/admin/audit` | Super Admin | Platform data |
| PUT | `/admin/organizations/{id}/plan`, `/admin/users/{id}/active`, `/admin/plans/{code}`, `/admin/api-pricing`, `/admin/providers/{code}`, `/admin/maintenance` | Super Admin | Changes (audited) |

Result states per point: `ranked` (with `position`), `not_found`, `error`. Demo scans carry `is_demo: true`
and a `data_notice`.

Errors: `401` not authenticated, `402` plan limit reached, `503` maintenance or payments not configured, `403` insufficient role, `404` not found
in this organization, `409` conflict, `422` validation.
