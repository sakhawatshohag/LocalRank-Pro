# Testing guide

| Suite | Command (from `backend/`) | Needs | Result on 2026-11-17 |
|---|---|---|---|
| Unit | `python -m pytest -q` | Python 3.11+, pydantic, requests, pyjwt, reportlab, pillow, pdfplumber, pytest | 60 passed (database tests skipped) |
| Database integration | `TEST_PGURL=postgresql://postgres@localhost:5432/postgres python -m pytest tests/db -q` | `psql` and a server where the user can create databases | 28 passed |
| Database | `PGURL=... tests/sql/run.sh` | PostgreSQL 14+ superuser URL | 51 checks passed (PostgreSQL 16; PostGIS migration skipped) |
| Live provider | `python -m pytest tests/live -q` | DataForSEO credentials, ~$0.002 | **not run** |
| Stripe | Stripe test mode + Stripe CLI (`stripe listen --forward-to …/billing/webhook/stripe`) | Stripe test keys | **not run** |
| API integration | – | FastAPI + database | **not written yet** |
| Frontend library | `npm test` (from `frontend/`) | Node 22, tsx, zod | 22 passed |
| Frontend screens | `npm run typecheck && npm run build` | installed dependencies | **not run** (syntax check only) |

## Critical scenarios (specification section 26)

| # | Scenario | Covered by | Status |
|---|---|---|---|
| 1–2 | Add business, create campaign | SQL fixtures only | partial |
| 3 | GeoGrid generated | `test_engine.py` grid tests | pass |
| 4 | Real API data retrieved | `tests/live` | not run |
| 5–6 | Scan saved; second does not overwrite first | `make_scan_storage_test.py` (real pipeline → real SQL function) | pass |
| 7 | Historical comparison correct | `test_comparison_matches_specification_examples` | pass |
| 8 | Competitors use matching coordinates | `test_scan_evaluates_all_businesses_from_the_same_response_per_coordinate`, storage test | pass |
| 9 | Missing rankings handled | metrics + `40102` tests | pass |
| 10 | API failures never create rankings | `test_api_failures_become_errors_never_rankings`, SQL CHECKs, storage rejects invented rankings | pass |
| 11 | Organizations isolated | `test_schema.sql` tenant section | pass (database level) |
| 12 | PDF reports correct | – | not built |
| 13 | Scheduled scan runs once per occurrence | `test_schedule_dispatch_runs_each_occurrence_once` (real dispatcher, real database) | pass |

A feature is marked done in DEVELOPMENT_ROADMAP.md only when its tests have actually been run.

## How the database integration tests work

`tests/db/pgshim.py` is a small test-only connection that talks to PostgreSQL through a `psql`
subprocess. It lets the real service code (`app/services/*`) run against a real database even
where no Python PostgreSQL driver is installed. Each run creates a throw-away database, applies
every migration, and drops it afterwards. `tests/db/test_router_sql.py` also executes every SQL
statement in the scan, schedule and notification endpoints.
