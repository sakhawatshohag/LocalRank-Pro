# Architecture

## Overview

```
Browser (Next.js, TypeScript, Tailwind, shadcn/ui, TanStack Query, Google Maps JS)
        │ HTTPS, Bearer JWT
Nginx ──┤
        ▼
FastAPI  (app/routers)  ── REST /api/v1, Pydantic validation, RBAC
        │
        ├── app/engine      pure Python, no I/O: grid maths, analytics, scan execution
        ├── app/providers   RankingProvider interface → DataForSEO | Demo
        ▼
PostgreSQL 16 + PostGIS   (Row Level Security per organization, immutable history)
        ▲
Celery workers + Redis    scheduled scans, retries, reports   (Phase 5)
```

Design rules

* **The engine has no database or HTTP dependency.** Grid generation, metric maths and scan
  orchestration are plain functions, so every ranking rule is unit-tested without infrastructure.
* **One provider request = one keyword at one coordinate.** The response lists every business at
  that point, so the tracked business and all competitors are resolved from the *same* response.
  This guarantees matching keyword, coordinate, time and search configuration, and means
  competitors cost nothing extra.
* **Three result states, never merged:** `ranked` (has a position ≥ 1), `not_found` (searched
  successfully, not within the requested depth, no position), `error` (no usable data). Enforced
  in Python (`PointResult`) and again by database CHECK constraints.
* **Tenancy is enforced by the database**, not only by application code (see SECURITY.md).
* **History is append-only.** Scans snapshot their grid and search settings; ranking rows cannot be
  updated; finished scans cannot be modified.

## Folder structure

```
localrank-pro/
├── docker-compose.yml  .env.example
├── scripts/migrate.sh                 SQL migration runner
├── docs/
├── backend/
│   ├── Dockerfile  requirements.txt  pytest.ini
│   ├── migrations/                    0001_core.sql … 0006_billing_admin_team.sql
│   ├── app/
│   │   ├── main.py  config.py  db.py  deps.py  security.py  worker.py
│   │   ├── engine/      geogrid.py  analytics.py  dominance.py  schedule.py  alerts.py  report_model.py  scan_runner.py  payload.py
│   │   ├── reporting/   pdf.py  images.py
│   │   ├── services/    scans.py  schedules.py  notifications.py  reports.py  billing.py
│   │   ├── billing/     stripe.py
│   │   ├── providers/   base.py  dataforseo.py  demo.py
│   │   └── routers/     auth.py  clients.py  locations.py  grid.py  campaigns.py  scans.py  schedules.py  notifications.py  reports.py  billing.py  team.py  admin.py
│   └── tests/           unit tests, sql/ (database tests), live/ (real API, opt-in)
└── frontend/
    ├── package.json  tsconfig.json  Dockerfile
    ├── src/lib/         api.ts  auth.tsx  geogrid.ts  compare.ts  validation.ts  nav.ts  types.ts
    ├── src/components/  ui.tsx  GeoGrid.tsx  TrendChart.tsx  AuthForm.tsx
    ├── src/app/         login, register, (app)/dashboard, clients, locations, campaigns (+ compare), scans/[id] (+ competitors)
    └── tests/           lib.test.ts  compare.test.ts
```

## Scan lifecycle

1. `POST /campaigns/{id}/scans` validates limits and cost, inserts one `queued` scan per keyword with a
   snapshot of grid and search settings, commits, then enqueues a Celery task per scan.
2. The worker claims the scan (`queued` → `running` in one UPDATE, so a duplicate task does nothing),
   then calls the provider once per grid point, outside any database transaction.
3. The result is serialised (`engine/payload.py`) and handed to the SQL function `store_scan_result`,
   which validates and writes grid points, rankings, metrics, API usage and the final status
   (`completed`, `partial`, `failed`) in one transaction. A scan can be stored only once.
4. If the worker crashes, the scan is marked `failed`; it never stays `running` and never gets rankings.

Points are currently fetched one after another. Concurrent fetching is needed before large grids
are practical in Live mode.

## Scheduling

* Celery beat runs `schedules.dispatch` every minute and `scans.maintenance` every 5 minutes.
  Exactly one beat process may run.
* The dispatcher has no tenant context. `due_schedules()` (SECURITY DEFINER, returns only ids)
  lists due schedules; each is then processed inside its own organization's RLS transaction,
  locked with `FOR UPDATE SKIP LOCKED`.
* The occurrence key is the local date of the run; it is part of the scans' unique idempotency
  key, so the same occurrence can never produce two scans for a keyword.
* Missed occurrences are not back-filled. A schedule that cannot run (no keywords, missing Place
  ID, allowance used up) records the reason, notifies, and moves to the next occurrence.
* Scheduled runs need no cost confirmation (the schedule is the approval); they do respect the
  monthly allowance. The schedule card shows the projected cost and allowance share.
* Significant change = average position moves ≥ 3 or Top 10 coverage moves ≥ 15 points versus the
  previous comparable scan; a decline wins over an improvement in the same scan.

## Reports

* Reports are generated by a worker from stored scans (`services/reports.py`) and rendered with
  reportlab (`reporting/pdf.py`). The PDF and CSV are stored in the `reports` table and served for
  download, so a report always shows the data it was generated from.
* Which scans a report uses: the latest finished scan of each keyword in the period, compared with
  the latest comparable scan before the period (or the earliest comparable one inside it).
  Keywords without a scan in the period are listed as "no data".
* The executive summary and observations are rule-based statements calculated from the data;
  recommendations are written by the user. Nothing is generated or estimated.
* GeoGrids in the PDF are drawn as vector grids, not Google map images (map images in a PDF would
  need the Maps Static API and its terms).
* White label is a plan feature (`plans.limits.white_label`): without it, report footers carry
  "Generated with LocalRank Pro".
* The Docker image installs `fonts-dejavu-core` so reports can print arrows, minus signs and
  accented names; without it the renderer falls back to Helvetica with ASCII substitutes.

## Billing

* Payment gateway: Stripe (assumed: target customers are agencies in Canada and the US). Stripe
  Checkout for sign-up and the Customer Portal for upgrades, downgrades, payment methods and
  cancellation, so the platform never handles card data or proration itself.
* Stripe is called over REST with a pinned `Stripe-Version` (no SDK dependency). The gateway sits
  behind `services/billing.py`; another gateway needs its own client and event mapping.
* The plan an organization is on is `organizations.plan_id`; all limits come from `plans.limits`.
  Webhooks change it; the Super Admin can override it. Trials that end without a subscription and
  cancelled subscriptions move to the `inactive` plan; data is never deleted by billing.

## Technical decisions and trade-offs

| Decision | Chosen | Why | Trade-off |
|---|---|---|---|
| Auth | Own JWT auth (scrypt + HS256) | No external dependency, works on a single VPS, same Postgres | Email verification, reset and MFA must be built (pending). Supabase Auth remains a drop-in alternative: only `deps.current_principal` changes. |
| Data access | SQLAlchemy Core with explicit SQL | SQL is visible, matches the tested schema, RLS context is explicit | More SQL to write than with an ORM |
| Migrations | Ordered plain SQL files + `schema_migrations` | RLS, triggers and PostGIS are SQL-first; runner is 20 lines | No auto-generated diffs |
| Ranking position | `rank_group` of `maps_search` items | Organic map rank, ads excluded | Ads shown above are ignored by design |
| Business matching | Place ID, then CID. Never by name | Names collide; wrong matches would be fake rankings | A business without a verified identifier cannot be tracked |
| Default depth | 100 | DataForSEO bills per 100 results, so depth 20 costs the same as 100 | Larger responses to store |

## Frontend notes

* Next.js App Router, client components, TanStack Query for server state, Tailwind v4.
* The access token lives in `sessionStorage` and is sent as a Bearer header; the query cache is
  cleared on sign-in and sign-out so one account never sees another's cached data.
* Google Maps is loaded with `@googlemaps/js-api-loader` (`setOptions` + `importLibrary`) and drawn
  with `AdvancedMarkerElement`, which needs a Map ID. Without a Maps key the same grid is shown as a
  plain matrix, so results are always visible.
* Colour and label rules live in `src/lib/geogrid.ts` and mirror the backend: an API error is shown
  as "no data", never as a position; not-found shows the search depth ("100+"), never 0.
* The sidebar lists only sections that exist.

## Ranking API integration strategy

Provider: DataForSEO Google Maps SERP API. Verified against official docs on 2026-11-17
(details in `app/providers/dataforseo.py`).

* Live endpoint `POST /v3/serp/google/maps/live/advanced`, Basic auth, one task per request.
* Location is sent as `location_coordinate = "lat,lng,ZOOMz"` (max 7 decimals, zoom 3–21).
* `20000` = success. `40102` = search ran and returned nothing → valid empty result
  (`not_found`), not an error. Everything else → `error`.
* Timeouts, HTTP 429 and 5xx are retried with exponential backoff, then recorded as `error`.
* Provider task id, status, timing and `check_url` are stored per grid point for troubleshooting.

**Status: implemented and tested against documented response shapes only. No real request has
been made (no credentials). It must not be called "connected" until `tests/live` passes.**

Not implemented yet: Standard/Priority queue (`task_post` → `task_get`), needed for cheap
scheduled scans.

## API cost methodology

```
requests       = grid points × keywords                (competitors add 0)
billed units   = ceil(depth / results_per_unit)        (DataForSEO: per 100 results)
estimated cost = requests × billed units × unit price  (price for the chosen mode)
```

Unit prices are read from the `api_pricing` table (admin-editable, with source URL and date),
never from code. Values seeded from the DataForSEO pricing page, checked 2026-11-17:
Standard $0.0006, Priority $0.0012, Live $0.002 per SERP of up to 100 results. Keywords that
contain search operators are billed ×5 by the provider (not modelled yet).

Worked examples (one keyword, depth ≤ 100):

| Grid | Points | Live | Standard |
|---|---|---|---|
| 5×5 | 25 | $0.05 | $0.015 |
| 9×9 | 81 | $0.162 | $0.0486 |
| 13×13 | 169 | $0.338 | $0.1014 |
| 15×15 | 225 | $0.45 | $0.135 |

A 9×9 grid, 10 keywords, weekly on Standard ≈ 81 × 10 × 4.33 × $0.0006 ≈ $2.10 per month.
Actual cost is taken from the provider's `cost` field per request and stored next to the estimate.

## Known technical limitations

1. Rankings are what the provider observes for a coordinate and zoom level. They approximate, but
   are not identical to, what a person standing there sees (personalisation, device, time).
2. `not_found` means "not within the requested depth", not "not ranking anywhere".
3. Live mode is one request per point; a 15×15 grid is 225 requests (about 6 s each per the
   provider), so scans must run concurrently in background workers, not in a web request.
4. Results depend on the zoom level sent with each coordinate; changing zoom changes rankings, so
   zoom is part of the search configuration and of scan comparability.
5. Google Business Profile data (reviews, profile audit) needs the owner's OAuth consent through
   Google's Business Profile APIs, which require an access application to Google. Competitor
   reviews can only come from a SERP/reviews data provider.
6. Showing third-party ranking data on Google Maps JS must follow the Google Maps Platform terms;
   review them before launch (not legally assessed here).
7. Citation "live/accurate" status cannot be verified automatically without a citation data source.
