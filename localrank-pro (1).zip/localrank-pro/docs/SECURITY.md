# Security

## Implemented
* **Tenant isolation in the database.** All tenant tables use `FORCE ROW LEVEL SECURITY`. The API
  connects as `localrank_app` (not owner, not superuser) and sets `app.current_org` per
  transaction (`set_config(..., true)`, so it cannot leak across pooled connections). With no
  context, tenant tables return nothing and reject writes. Composite foreign keys stop cross-tenant
  references. Tested in `backend/tests/sql/test_schema.sql`.
* **Passwords**: scrypt (N=2^15, r=8, p=1), per-password salt, constant-time comparison, minimum 10 characters.
* **Tokens**: HS256 JWT, 60-minute default lifetime, secret ≥ 32 characters enforced at start-up.
  Organization membership is re-checked on every request.
* **RBAC**: owner > admin > manager > seo_specialist > client_viewer, enforced per endpoint.
* **SQL injection**: all queries use bound parameters; dynamic SQL only interpolates fixed column lists.
* **Secrets**: only from environment variables; provider credentials never reach the frontend.
* **Pricing and plans** are read-only for the application role.
* **Login** returns the same error for unknown email and wrong password.
* **Demo data** cannot be enabled when `APP_ENV=production`.

* **Super Admin**: granted only with `scripts/make_super_admin.sh` (database superuser). Every admin
  operation runs in a SECURITY DEFINER function that re-checks `is_super_admin` in the database and is
  written to `admin_audit`. The admin area answers 404 to everyone else.
* **Payments**: card data never reaches the platform (Stripe Checkout and Customer Portal). Webhooks
  are accepted only with a valid `Stripe-Signature` (HMAC-SHA256, 5-minute tolerance) over the raw body.
* **Invitations**: random 256-bit tokens, stored only as SHA-256, single use, 7-day expiry; an
  existing account must prove its password to accept.
* **Team roles**: admins cannot touch owners or other admins; the last owner cannot be removed or demoted.
* **Maintenance mode**: blocks every non-admin request with 503 except health, sign-in and webhooks.

## Pending (required before launch)
* Email verification, password reset, refresh-token rotation, optional MFA
* Rate limiting (login, registration, scan launch) and account lockout
* Client-viewer scoping to assigned clients
* Security headers and TLS at Nginx, CSRF review if cookies are adopted (currently Bearer tokens)
* Encrypted database backups and restore test, error monitoring
* Dependency pinning and vulnerability scanning, external security review
