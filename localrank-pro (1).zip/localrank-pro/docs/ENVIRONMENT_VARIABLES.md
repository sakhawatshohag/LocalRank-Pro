# Environment variables

| Variable | Required | Default | Purpose |
|---|---|---|---|
| `APP_ENV` | no | `development` | `development`, `test` or `production` (disables `/docs`, forbids demo mode) |
| `DATABASE_URL` | yes | – | SQLAlchemy URL for the **application role**, e.g. `postgresql+psycopg://localrank_app:...@db:5432/localrank` |
| `JWT_SECRET` | yes | – | Token signing key, at least 32 characters |
| `ACCESS_TOKEN_TTL_MINUTES` | no | `60` | Access token lifetime |
| `CORS_ORIGINS` | no | empty | Comma-separated allowed origins |
| `REDIS_URL` | no | `redis://redis:6379/0` | Celery broker (Phase 5) |
| `DATAFORSEO_LOGIN`, `DATAFORSEO_PASSWORD` | for real rankings | – | DataForSEO API credentials |
| `DEMO_MODE` | no | `false` | Enables the synthetic demo provider (never in production) |
| `SCAN_COST_CONFIRM_THRESHOLD_USD` | no | `1.0` | Scans estimated above this need explicit confirmation |
| `APP_URL` | yes in production | `http://localhost:3000` | Public web app URL: invitation links, Stripe return URLs |
| `ALLOW_SIGNUP` | no | `true` | `false` closes public registration (accounts via `scripts/create_account.sh`); also hides the sign-up link |
| `DOMAIN` | prod compose | – | Public domain served by Caddy with automatic HTTPS |
| `TRIAL_DAYS` | no | `14` | Free trial length for new organizations |
| `STRIPE_SECRET_KEY` | for payments | – | Stripe secret key (server only) |
| `STRIPE_WEBHOOK_SECRET` | for payments | – | Signing secret of the Stripe webhook endpoint `/api/v1/billing/webhook/stripe` |
| `STRIPE_API_VERSION` | no | `2026-02-25.clover` | Sent as `Stripe-Version`; set the webhook endpoint to the same version |
| `POSTGRES_PASSWORD` | compose | – | Database superuser password (migrations only) |
| `APP_DB_PASSWORD` | compose | – | Password set on the `localrank_app` role by `scripts/migrate.sh` |
| `MIGRATION_DATABASE_URL` | migrate | – | Superuser connection used by `scripts/migrate.sh` |
| `NEXT_PUBLIC_GOOGLE_MAPS_API_KEY` | frontend | – | Browser Maps key; restrict by HTTP referrer |
