# Deployment guide: one server with Docker (Oracle Cloud Always Free or any VPS)

**Status: written, not yet performed.** The production stack (`docker-compose.prod.yml`) has never
been built or started. Expect to fix small problems on the first run.

Works the same on Oracle Cloud (ARM), Hostinger VPS or any Ubuntu server with Docker. Shared or
"Business" web hosting cannot run this app (it needs PostgreSQL, Redis and always-on workers).

Result: `https://app.yourdomain.com` with automatic HTTPS, accounts created by you, daily backups.

---

## 1. Oracle Cloud account and server (about 30 minutes)

1. Sign up at oracle.com/cloud/free. A card is needed for verification.
   Pick your **home region** carefully (Always Free resources live there; it cannot be changed
   later). For clients in Canada, Toronto (`ca-toronto-1`) is close.
2. Console → **Compute → Instances → Create instance**.
   * **Image**: Canonical Ubuntu 24.04.
   * **Shape**: Ampere → `VM.Standard.A1.Flex`, **2 OCPU, 12 GB memory**. Since 15 June 2026 the
     Always Free Ampere allowance is 2 OCPU / 12 GB; anything above that can be charged.
   * **Networking**: create a new virtual cloud network with a public subnet; **assign a public IPv4 address**.
   * **SSH keys**: "Generate a key pair for me" → download the private key (keep it safe).
   * **Boot volume**: 100 GB is fine (Always Free includes 200 GB in total).
   * "Out of capacity" → try another availability domain, or retry later.
3. Note the **public IP address** on the instance page.

## 2. Open ports 80 and 443 (two places)

**a. Oracle security list** — instance page → subnet → **Security Lists** → Default Security List →
**Add Ingress Rules**: Source CIDR `0.0.0.0/0`, protocol TCP, destination port range `80,443`.

**b. Server firewall** — Oracle's Ubuntu image ships with iptables rules that block everything
except SSH. After connecting (step 4):

```bash
sudo iptables -I INPUT 6 -m state --state NEW -p tcp --dport 80 -j ACCEPT
sudo iptables -I INPUT 6 -m state --state NEW -p tcp --dport 443 -j ACCEPT
sudo netfilter-persistent save
```

## 3. Domain

In the DNS settings of your domain (for example Hostinger hPanel → Domains → DNS), add:

| Type | Name | Value |
|---|---|---|
| A | `app` | the server's public IP |

Wait until `ping app.yourdomain.com` shows the IP (minutes to a few hours).

## 4. Connect and install Docker

```bash
chmod 600 ~/Downloads/ssh-key.key
ssh -i ~/Downloads/ssh-key.key ubuntu@SERVER_IP

curl -fsSL https://get.docker.com | sudo sh
sudo usermod -aG docker ubuntu
exit    # reconnect so the group change applies
```

## 5. Put the code on the server

From a private GitHub repo (recommended):

```bash
sudo mkdir -p /opt/localrank-pro && sudo chown ubuntu /opt/localrank-pro
git clone https://github.com/<you>/localrank-pro.git /opt/localrank-pro
```

or copy the zip: `scp -i key localrank-pro.zip ubuntu@SERVER_IP:/opt/` and unzip it there.

## 6. Configure

```bash
cd /opt/localrank-pro
cp .env.production.example .env
for v in POSTGRES_PASSWORD APP_DB_PASSWORD JWT_SECRET; do
  sed -i "s|^$v=.*|$v=$(openssl rand -base64 36 | tr -d '/+=')|" .env
done
nano .env      # set DOMAIN=app.yourdomain.com ; keep APP_ENV=staging and DEMO_MODE=true for the first test
```

Keep `.env` private; it holds every secret.

## 7. Start

```bash
docker compose -f docker-compose.prod.yml up -d --build     # first build on ARM: roughly 10–20 minutes
docker compose -f docker-compose.prod.yml ps                # all services "running"; migrate "exited (0)"
docker compose -f docker-compose.prod.yml logs -f api       # Ctrl+C to leave
curl https://app.yourdomain.com/health
```

Caddy requests the HTTPS certificate automatically on the first visit; this needs the domain to
point to the server and port 80 to be open.

## 8. Create accounts (no public sign-up)

```bash
scripts/create_account.sh plans
scripts/create_account.sh create-account --email you@yourdomain.com --name "Your Name" --org "Your Agency"
scripts/create_account.sh create-account --email owner@client.com --name "Client Owner" --org "Client Business"
scripts/create_account.sh list
scripts/create_account.sh add-member --email staff@client.com --name "Staff" --org-id <id from list> --role seo_specialist
scripts/create_account.sh reset-password --email owner@client.com
```

A password is generated and printed once; send it to the person privately.
New accounts get the hidden `standard` plan (placeholder limits: 10 locations, 100 keywords,
20 000 grid points a month, white-label reports). Change them in SQL or in Super Admin → Plans.

Optional, to use the Super Admin screen yourself:

```bash
docker compose -f docker-compose.prod.yml exec db psql -U postgres -d localrank \
  -c "UPDATE users SET is_super_admin = true WHERE lower(email) = lower('you@yourdomain.com')"
```

## 9. Backups

```bash
mkdir -p backups
(crontab -l 2>/dev/null; echo "30 3 * * * /opt/localrank-pro/scripts/backup.sh >> /opt/localrank-pro/backups/backup.log 2>&1") | crontab -
scripts/backup.sh        # test once now
```

Copy `backups/` off the server regularly (for example `scp` to your computer). A backup on the same
server is lost with the server. Restore instructions are at the top of `scripts/backup.sh`.

## 10. Going live with real rankings

1. In `.env`: `APP_ENV=production`, `DEMO_MODE=false`, `DATAFORSEO_LOGIN`, `DATAFORSEO_PASSWORD`,
   and the Google Maps key (restrict it to `https://app.yourdomain.com/*`).
2. `docker compose -f docker-compose.prod.yml up -d` (the frontend is rebuilt only with `--build`).
3. Check the DataForSEO credentials (free call, no scan cost):
   ```bash
   docker compose -f docker-compose.prod.yml exec api python -c "import os; from app.providers.dataforseo import DataForSEOProvider as P; print(P(os.environ['DATAFORSEO_LOGIN'], os.environ['DATAFORSEO_PASSWORD'], lambda m: 0).validate_credentials())"
   ```
   `True` = connected. Then run one 3×3 scan.
4. Demo scans stay labelled "demo data" in history; they are never mixed with real scans.

## 11. Updating

```bash
cd /opt/localrank-pro && git pull
docker compose -f docker-compose.prod.yml up -d --build    # migrations run automatically
```

## Troubleshooting

| Problem | Check |
|---|---|
| Site does not open | Both firewalls (step 2), DNS points to the IP, `docker compose ps` |
| HTTPS certificate error | DNS must point to this server and port 80 must be open; `docker compose logs caddy` |
| `migrate` failed | `docker compose logs migrate`; fix, then `up -d` again (applied migrations are skipped) |
| Scans stay "queued" | `docker compose logs worker beat redis` |
| Out of memory | `docker stats`; reduce `--concurrency` of the worker |
| Oracle "out of capacity" | Other availability domain, or retry later |

Oracle may reclaim Always Free instances it considers idle; check the current Always Free terms
and keep backups off the server. Move to a paid VPS before relying on it for paying clients.
