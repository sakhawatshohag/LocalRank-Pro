#!/usr/bin/env bash
# First start of a Codespace: create .env with random secrets and demo data switched on.
set -euo pipefail
cd "$(dirname "$0")/.."
if [ ! -f .env ]; then
  rnd() { openssl rand -base64 36 | tr -d '/+='; }
  cp .env.example .env
  sed -i "s|^JWT_SECRET=.*|JWT_SECRET=$(rnd)|; s|^POSTGRES_PASSWORD=.*|POSTGRES_PASSWORD=$(rnd)|; s|^APP_DB_PASSWORD=.*|APP_DB_PASSWORD=$(rnd)|; s|^DEMO_MODE=.*|DEMO_MODE=true|" .env
  echo ".env created (demo data on). Add DATAFORSEO_LOGIN/PASSWORD there for real rankings."
fi
