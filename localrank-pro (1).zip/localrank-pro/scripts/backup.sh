#!/usr/bin/env bash
# Daily database backup with 14-day retention. Install on the server with:
#   (crontab -l 2>/dev/null; echo "30 3 * * * /opt/localrank-pro/scripts/backup.sh >> /opt/localrank-pro/backups/backup.log 2>&1") | crontab -
# Copy the files off the server regularly (a backup on the same disk does not survive losing the server).
# Restore:  gunzip -c FILE.sql.gz | docker compose -f docker-compose.prod.yml exec -T db psql -U postgres -d localrank
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p backups
f="backups/localrank-$(date -u +%Y%m%d-%H%M%S).sql.gz"
docker compose -f docker-compose.prod.yml exec -T db pg_dump -U postgres -d localrank --no-owner | gzip > "$f"
[ -s "$f" ] || { echo "backup failed: empty file" >&2; rm -f "$f"; exit 1; }
find backups -name 'localrank-*.sql.gz' -mtime +14 -delete
echo "$(date -u +%FT%TZ) backup ok: $f ($(du -h "$f" | cut -f1))"
