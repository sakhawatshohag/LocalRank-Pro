#!/usr/bin/env bash
# Applies pending SQL migrations in order.  Needs a superuser/owner connection:
#   MIGRATION_DATABASE_URL=postgresql://postgres:...@db:5432/localrank scripts/migrate.sh
# Optionally sets the application role password from APP_DB_PASSWORD.
set -euo pipefail
: "${MIGRATION_DATABASE_URL:?MIGRATION_DATABASE_URL is required}"
DIR="${MIGRATIONS_DIR:-$(cd "$(dirname "$0")/../backend/migrations" && pwd)}"
q() { psql "$MIGRATION_DATABASE_URL" -v ON_ERROR_STOP=1 -qAt "$@"; }
for f in "$DIR"/*.sql; do
  v="$(basename "$f" .sql)"
  if [ "$(q -c "SELECT to_regclass('public.schema_migrations') IS NOT NULL")" = "t" ] &&
     [ "$(q -c "SELECT count(*) FROM schema_migrations WHERE version = '$v'")" = "1" ]; then
    echo "skip   $v"; continue
  fi
  if [ "$v" = "0002_postgis" ] && [ "$(q -c "SELECT count(*) FROM pg_available_extensions WHERE name = 'postgis'")" = "0" ]; then
    # PostGIS is optional for now: no feature uses the spatial columns yet.  ARM servers (e.g. Oracle
    # Cloud Ampere) run plain PostgreSQL because the official PostGIS image is amd64-only.
    echo "skip   $v (PostGIS is not installed on this server; apply it later if needed)"; continue
  fi
  echo "apply  $v"; q -f "$f"
done
if [ -n "${APP_DB_PASSWORD:-}" ]; then
  q -v pw="$APP_DB_PASSWORD" <<'SQL'
ALTER ROLE localrank_app PASSWORD :'pw';
SQL
  echo "application role password set"
fi
