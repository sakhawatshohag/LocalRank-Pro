#!/usr/bin/env bash
# Grants (or with --revoke removes) Super Admin rights for an existing account.
# Needs the migration (superuser) connection; the application role cannot change this.
#   MIGRATION_DATABASE_URL=postgresql://postgres:...@db:5432/localrank scripts/make_super_admin.sh person@example.com
set -euo pipefail
: "${MIGRATION_DATABASE_URL:?MIGRATION_DATABASE_URL is required}"
EMAIL="${1:?usage: make_super_admin.sh <email> [--revoke]}"
VALUE=true; [ "${2:-}" = "--revoke" ] && VALUE=false
n=$(psql "$MIGRATION_DATABASE_URL" -v ON_ERROR_STOP=1 -qAt -v email="$EMAIL" -v val="$VALUE" <<'SQL'
WITH u AS (UPDATE users SET is_super_admin = :'val'::boolean WHERE lower(email) = lower(:'email') RETURNING 1) SELECT count(*) FROM u;
SQL
)
[ "$n" = "1" ] && echo "is_super_admin=$VALUE for $EMAIL" || { echo "no account with email $EMAIL" >&2; exit 1; }
