#!/usr/bin/env bash
# Operator commands on the server (run from the project folder). Examples:
#   scripts/create_account.sh create-account --email owner@client.com --name "Jane Doe" --org "Acme Plumbing"
#   scripts/create_account.sh add-member --email staff@client.com --name "Sam" --org-id <id> --role seo_specialist
#   scripts/create_account.sh list
#   scripts/create_account.sh reset-password --email owner@client.com
#   scripts/create_account.sh set-plan --org-id <id> --plan standard
set -euo pipefail
cd "$(dirname "$0")/.."
exec docker compose -f docker-compose.prod.yml exec -T api python -m app.cli "$@"
