# LocalRank Pro

Local SEO management and Google Maps GeoGrid rank tracking SaaS.

**Status: early development — not production-ready.** The ranking engine, analytics maths and
database schema are implemented and tested. The HTTP API (Phases 1–2) and the background worker are written but have not been
run yet. The frontend screens are written but have never been installed, built or opened in a browser. See [docs/DEVELOPMENT_ROADMAP.md](docs/DEVELOPMENT_ROADMAP.md)
for the exact status of every item.

## What exists

| Area | Where | Status |
|---|---|---|
| GeoGrid generation | `backend/app/engine/geogrid.py` | tested |
| Ranking analytics, scan comparison | `backend/app/engine/analytics.py` | tested |
| Scan execution (business + competitors) | `backend/app/engine/scan_runner.py` | tested |
| DataForSEO Google Maps provider | `backend/app/providers/dataforseo.py` | tested against documented shapes; **no live request made yet** |
| Demo provider (synthetic, flagged) | `backend/app/providers/demo.py` | tested |
| Schema, RLS, immutable history | `backend/migrations/0001_core.sql` | tested on PostgreSQL 16 |
| Scan storage (atomic, validated) | `backend/migrations/0003_scan_storage.sql` | tested on PostgreSQL 16 |
| Auth, clients, locations, campaigns, keywords, competitors, scans, history, comparison API | `backend/app/routers/` | written, not run |
| Frontend library (API client, GeoGrid rules, validation) | `frontend/src/lib/` | tested |
| Competitor dominance rules | `backend/app/engine/dominance.py` | tested |
| Frontend screens (auth, clients, locations, campaigns, GeoGrid map, historical comparison, competitor comparison, trends, schedules, notifications, reports, settings, billing, team, Super Admin) | `frontend/src/app/`, `frontend/src/components/` | written, not run |
| Schedule maths, change alerts | `backend/app/engine/schedule.py`, `alerts.py` | tested |
| Scan pipeline, scheduler, notifications (services) | `backend/app/services/` | tested against PostgreSQL |
| PDF/CSV reports, white-label branding | `backend/app/reporting/`, `backend/app/services/reports.py` | tested (PDFs read back), against PostgreSQL |
| Billing (Stripe), team, Super Admin | `backend/app/services/billing.py`, `backend/app/billing/`, `migrations/0006_*` | tested against PostgreSQL; **no live Stripe request yet** |
| Celery worker and beat wiring | `backend/app/worker.py` | written, not run |

## Run the tests

```bash
cd backend
python -m pytest -q                      # unit tests (needs pydantic, requests, pyjwt, pytest)
PGURL=postgresql://postgres@localhost:5432/postgres tests/sql/run.sh   # SQL tests
TEST_PGURL=postgresql://postgres@localhost:5432/postgres python -m pytest tests/db -q   # services against PostgreSQL
DATAFORSEO_LOGIN=... DATAFORSEO_PASSWORD=... python -m pytest tests/live -q   # 1 real request, ~$0.002
cd ../frontend && npm install && npm test     # frontend library tests
```

## Run the stack (not yet verified)

```bash
cp .env.example .env        # fill in JWT_SECRET and passwords
docker compose up --build   # db + migrations + redis + api (:8000, docs at /docs) + worker + beat + frontend (:3000)
```

## Try it in GitHub Codespaces (free, no server)

Push this folder to a private GitHub repository → **Code → Codespaces → Create codespace on main**.
The first start builds everything (about 10–20 minutes), creates `.env` with random secrets and
demo data, and opens the app on port 3000 (Ports tab). The link is private to your GitHub login.
A codespace stops when idle; the free quota is 120 core-hours a month (60 hours on a 2-core machine).

## Deploy

One server with Docker (Oracle Cloud Always Free, Hostinger VPS or any Ubuntu VPS):
see [docs/DEPLOYMENT_GUIDE.md](docs/DEPLOYMENT_GUIDE.md). Accounts are created by the operator with
`scripts/create_account.sh`; public sign-up is off (`ALLOW_SIGNUP=false`).

## First Super Admin

```bash
MIGRATION_DATABASE_URL=postgresql://postgres:...@localhost:5432/localrank scripts/make_super_admin.sh you@example.com
```

## Documentation

* [Architecture, API strategy, cost methodology, limitations](docs/ARCHITECTURE.md)
* [Database schema](docs/DATABASE_SCHEMA.md)
* [Roadmap and status](docs/DEVELOPMENT_ROADMAP.md)
* [Security](docs/SECURITY.md)
* [Environment variables](docs/ENVIRONMENT_VARIABLES.md)
* [Testing guide](docs/TESTING_GUIDE.md)
* [API documentation](docs/API_DOCUMENTATION.md)

* [Deployment guide](docs/DEPLOYMENT_GUIDE.md) (written, not yet performed)
